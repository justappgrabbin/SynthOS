# SYSTEM X — Resonance Mechanics Engine

A mathematically grounded consciousness field simulation framework implementing the equation:

**E = m · c · k^β**

Where:
- **m**: pattern density (information content / structural complexity)
- **c**: cognitive velocity (processing speed / conceptual flow)  
- **k**: coherence coefficient (field stability / phase alignment)
- **β**: resonance exponent (non-linear coupling strength)

## Architecture

### Core Modules

| Module | Description | Key Classes |
|--------|-------------|-------------|
| `core.field` | Resonance field definition | `ResonanceField`, `BodyType`, `WaveLayer` |
| `core.engine` | Geometric algebra & resonance mechanics | `ResonanceEngine`, `CliffordEngine`, `CouplingResult` |
| `core.collapse` | Collapse detection & stabilization | `CollapseDetector`, `CollapsePredictor` |
| `core.harmonics` | Harmonic analysis & resonance maps | `HarmonicAnalyzer`, `ResonanceMap` |
| `network.synthai` | Multi-user network resonance | `SynthAI`, `User`, `NetworkState` |
| `companions.fairyganmatter` | Personal AI companions | `FairyCompanion`, `FairyGANmatter` |
| `neural.prediction` | Temporal pattern recognition | `TemporalBuffer`, `PatternRecognizer`, `TrajectoryPredictor` |
| `neural.insights` | Adaptive insight generation | `InsightGenerator`, `AdaptiveModulator` |
| `visualization.maps` | Resonance map rendering | `ResonanceVisualizer`, `ResonanceMapRenderer` |

## Quick Start

```python
from system_x import ResonanceField, ResonanceEngine, BodyType

# Create two consciousness fields
alice_mind = ResonanceField(
    body_type=BodyType.MIND,
    m=1.2, c=0.9, k=0.8, beta=1.2, phase=0.5
)

bob_heart = ResonanceField(
    body_type=BodyType.HEART,
    m=1.0, c=1.1, k=0.6, beta=1.0, phase=2.8
)

# Calculate resonance
engine = ResonanceEngine()
result = engine.step(alice_mind, bob_heart)

print(f"Coupling: {result.harmonic_coupling:.4f}")
print(f"Resonance: {result.resonance_scalar:.4f}")
print(f"Phase alignment: {result.phase_alignment:.4f}")
```

## Multi-User Network (SYNTHAI)

```python
from system_x import SynthAI

# Create network
synthai = SynthAI()

# Add users
alice = synthai.add_user("alice")
bob = synthai.add_user("bob")
charlie = synthai.add_user("charlie")

# Run simulation
for step in range(100):
    synthai.network_step()

# Analyze compatibility
compat = synthai.get_compatibility_report("alice", "bob")
print(f"Compatibility: {compat['compatibility_score']:.3f}")
```

## Personal Companions (FairyGANmatter)

```python
from system_x import FairyGANmatter

# Create companion manager
fairy = FairyGANmatter()

# Create attuned companion
companion_id = fairy.create_companion(
    user=alice, 
    companion_name="Lumina"
)

companion = fairy.get_companion(companion_id)
print(f"Elemental alignment: {companion.elemental_alignment.value}")
print(f"Communication style: {companion.communication_style.value}")
```

## Neural Prediction

```python
from system_x import TemporalBuffer, PatternRecognizer, TrajectoryPredictor

# Record field history
buffer = TemporalBuffer(window_size=1000)
for t in range(100):
    field.k = 0.8 + 0.3 * np.sin(t * 0.3)
    buffer.record(BodyType.MIND, field, timestamp=t)

# Detect cycles
recognizer = PatternRecognizer()
coherence_series = buffer.get_parameter_series(BodyType.MIND, 'k')
cycles = recognizer.detect_cycles(coherence_series)

# Predict trajectory
predictor = TrajectoryPredictor()
forecasts = predictor.ensemble_forecast(coherence_series, steps=10)
```

## Mathematical Foundation

### Resonance Energy

The total resonance energy of a consciousness field:

```
E = m · c · k^β
```

### Harmonic Coupling

Interaction strength between two fields:

```
H = m_A · m_B · k_A · k_B · cos(φ_A - φ_B)
```

### Geometric Algebra (Clifford Algebra Cl(1,3))

Each field is represented as a bivector:

```
F = m·cos(φ)·e_01 + m·sin(φ)·e_02 + c·cos(φ+π/4)·e_03
    + c·sin(φ+π/4)·e_12 + k·cos(β)·e_23 + k·sin(β)·e_31
```

The geometric product:

```
F ⊗ G = ⟨F,G⟩ + F∧G + I·(F×G)
```

Where:
- `⟨F,G⟩`: scalar (inner product) = resonance magnitude
- `F∧G`: bivector (wedge product) = coupling strength  
- `I·(F×G)`: pseudoscalar = phase relation

### Wave Mechanics

Three-layer wave function:

```
ψ_layer(t) = A_layer · sin(ωt + φ + φ_layer)
```

Layer phase offsets:
- Action: φ_layer = 0
- Thought: φ_layer = 2π/3
- Feeling: φ_layer = 4π/3

### Collapse Dynamics

Coherence evolution:

```
dk/dt = α_internal + α_external · H
```

Collapse condition:

```
k < k_critical ≈ 0.3
```

### PID Stabilization

Adaptive field modulation:

```
u(t) = K_p · e(t) + K_i · ∫e(t)dt + K_d · de/dt
```

Where `e(t) = k_target - k_current`.

## Testing

```bash
python -m pytest tests/test_core.py -v
```

Run all examples:

```bash
python examples/basic_usage.py
```

## License

MIT License — see LICENSE file for details.

## Citation

```bibtex
@software{system_x_2024,
  title = {System X: Resonance Mechanics Engine},
  author = {System X Research Group},
  year = {2024},
  url = {https://github.com/systemx-research/system-x}
}
```
