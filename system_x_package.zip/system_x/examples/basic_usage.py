"""
basic_usage.py — System X Usage Examples

Demonstrates all major features of the resonance mechanics engine.
Run with: python examples/basic_usage.py
"""

import numpy as np
from system_x import (
    ResonanceField, ResonanceEngine, BodyType, WaveLayer,
    SynthAI, User, FairyCompanion, FairyGANmatter,
    CollapseDetector, HarmonicAnalyzer, ResonanceVisualizer,
    TemporalBuffer, PatternRecognizer, TrajectoryPredictor,
    InsightGenerator, AdaptiveModulator,
    CliffordEngine
)


def example_1_single_field():
    """Example 1: Create and manipulate a single resonance field"""
    print("=" * 60)
    print("EXAMPLE 1: Single Resonance Field")
    print("=" * 60)

    # Create a Mind field
    mind = ResonanceField(
        body_type=BodyType.MIND,
        m=1.2,      # High pattern density (complex thinker)
        c=0.9,      # Moderate cognitive velocity
        k=0.8,      # Moderate coherence
        beta=1.2,   # Strong non-linear coupling
        phase=0.5   # Phase offset
    )

    print(f"Created: {mind}")
    print(f"Energy: E = {mind.energy():.4f}")
    print(f"Bivector magnitude: |F| = {mind.bivector_magnitude():.4f}")

    # Wave function
    t = np.linspace(0, 4*np.pi, 100)
    action_wave = [mind.wave_amplitude(WaveLayer.ACTION, ti) for ti in t]
    print(f"\nWave samples (Action layer): {action_wave[:5]}")

    # Phase correction
    target_phase = np.pi / 2
    print(f"\nApplying phase correction toward {target_phase:.3f}...")
    for i in range(5):
        mind.apply_phase_correction(target_phase, strength=0.2)
        print(f"  Step {i+1}: phase = {mind.phase:.4f}")

    # Check collapse
    print(f"\nCollapse risk (k={mind.k:.3f}): {mind.is_collapsing()}")

    # Serialize
    data = mind.to_dict()
    print(f"\nSerialized field: {len(str(data))} characters")

    print()


def example_2_field_interaction():
    """Example 2: Two-field resonance interaction"""
    print("=" * 60)
    print("EXAMPLE 2: Field Interaction (Alice & Bob)")
    print("=" * 60)

    engine = ResonanceEngine()

    # Alice's Mind field
    alice_mind = ResonanceField(
        BodyType.MIND, m=1.2, c=0.9, k=0.8, beta=1.2, phase=0.5
    )

    # Bob's Heart field
    bob_heart = ResonanceField(
        BodyType.HEART, m=1.0, c=1.1, k=0.6, beta=1.0, phase=2.8
    )

    print(f"Alice (Mind): {alice_mind}")
    print(f"Bob (Heart): {bob_heart}")

    # Single interaction
    result = engine.step(alice_mind, bob_heart)

    print(f"\nInteraction result:")
    print(f"  Harmonic coupling: {result.harmonic_coupling:.4f}")
    print(f"  Resonance scalar: {result.resonance_scalar:.4f}")
    print(f"  Phase alignment: {result.phase_alignment:.4f}")
    print(f"  Energy transfer: {result.energy_transfer:.6f}")
    print(f"  Alice collapse risk: {result.collapse_risk_a}")
    print(f"  Bob collapse risk: {result.collapse_risk_b}")

    # Run simulation
    print(f"\nRunning 20-step simulation...")
    for t in range(20):
        result = engine.step(alice_mind, bob_heart)
        if t % 5 == 0:
            print(f"  Step {t}: coupling={result.harmonic_coupling:.4f}, "
                  f"E_A={alice_mind.energy():.3f}, E_B={bob_heart.energy():.3f}")

    print()


def example_3_geometric_algebra():
    """Example 3: Clifford algebra operations"""
    print("=" * 60)
    print("EXAMPLE 3: Geometric Algebra (Clifford Engine)")
    print("=" * 60)

    clifford = CliffordEngine()

    # Create two fields with different characteristics
    field_a = ResonanceField(BodyType.MIND, m=2.0, c=1.0, k=1.0, beta=1.0, phase=0.0)
    field_b = ResonanceField(BodyType.HEART, m=1.0, c=2.0, k=1.5, beta=1.0, phase=np.pi/4)

    field_a.update_bivector()
    field_b.update_bivector()

    print(f"Field A bivector: {field_a.bivector}")
    print(f"Field B bivector: {field_b.bivector}")

    # Geometric product
    scalar, bivector, pseudo = clifford.geometric_product(
        field_a.bivector, field_b.bivector
    )

    print(f"\nGeometric Product A ⊗ B:")
    print(f"  Scalar (inner product): {scalar:.4f}")
    print(f"  Bivector (wedge product): {bivector}")
    print(f"  Pseudoscalar: {pseudo:.4f}")

    # Resonance metrics
    resonance = clifford.field_resonance(field_a, field_b)
    coupling = clifford.field_coupling_strength(field_a, field_b)
    phase_rel = clifford.field_phase_relation(field_a, field_b)

    print(f"\nField Resonance: {resonance:.4f}")
    print(f"Coupling Strength: {coupling:.4f}")
    print(f"Phase Relation: {phase_rel:.4f} rad ({np.degrees(phase_rel):.1f}°)")

    print()


def example_4_multi_user_network():
    """Example 4: SYNTHAI multi-user network"""
    print("=" * 60)
    print("EXAMPLE 4: SYNTHAI Network (3 Users)")
    print("=" * 60)

    synthai = SynthAI()

    # Add users with different field characteristics
    alice = synthai.add_user("alice", field_params={
        'mind': {'m': 1.5, 'c': 1.0, 'k': 0.9, 'beta': 1.1, 'phase': 0.0},
        'heart': {'m': 1.0, 'c': 1.2, 'k': 0.7, 'beta': 1.0, 'phase': 1.0},
    })

    bob = synthai.add_user("bob", field_params={
        'mind': {'m': 1.0, 'c': 0.8, 'k': 0.8, 'beta': 1.0, 'phase': 2.0},
        'heart': {'m': 1.3, 'c': 1.0, 'k': 0.9, 'beta': 1.2, 'phase': 3.0},
    })

    charlie = synthai.add_user("charlie", field_params={
        'mind': {'m': 0.8, 'c': 1.5, 'k': 0.6, 'beta': 0.9, 'phase': 4.0},
        'heart': {'m': 1.2, 'c': 0.9, 'k': 1.0, 'beta': 1.1, 'phase': 5.0},
    })

    print(f"Added users: Alice, Bob, Charlie")
    print(f"Alice total energy: {alice.total_energy():.3f}")
    print(f"Bob total energy: {bob.total_energy():.3f}")
    print(f"Charlie total energy: {charlie.total_energy():.3f}")

    # Run network simulation
    print(f"\nRunning 10-step network simulation...")
    for step in range(10):
        results = synthai.network_step()
        if step % 3 == 0:
            state = synthai.network_states[-1]
            print(f"  Step {step}: {state.user_count} users, "
                  f"global coherence={state.global_coherence:.3f}, "
                  f"avg energy={state.average_energy:.3f}")

    # Compatibility analysis
    print(f"\nCompatibility Analysis:")
    for pair in [("alice", "bob"), ("alice", "charlie"), ("bob", "charlie")]:
        compat = synthai.get_compatibility_report(pair[0], pair[1])
        print(f"  {pair[0]} ↔ {pair[1]}: "
              f"score={compat['compatibility_score']:.3f}, "
              f"strongest={compat['strongest_resonance']['body']}, "
              f"weakest={compat['weakest_resonance']['body']}")

    # Network statistics
    stats = synthai.get_network_statistics()
    print(f"\nNetwork Statistics:")
    for key, value in stats.items():
        print(f"  {key}: {value}")

    print()


def example_5_collapse_detection():
    """Example 5: Collapse detection and stabilization"""
    print("=" * 60)
    print("EXAMPLE 5: Collapse Detection & Stabilization")
    print("=" * 60)

    detector = CollapseDetector(threshold=0.3, intervention_strength=0.5)

    # Create fields, one near collapse
    fields = {
        bt: ResonanceField(bt, m=1.0, c=1.0, k=1.0, beta=1.0, phase=0.0)
        for bt in BodyType
    }

    # Stress the Mind field
    fields[BodyType.MIND].k = 0.25  # Near collapse
    fields[BodyType.HEART].k = 0.35  # Also at risk

    print("Initial field states:")
    for bt, field in fields.items():
        status = "⚠️  AT RISK" if field.is_collapsing() else "✓ Stable"
        print(f"  {bt.value}: k={field.k:.3f} {status}")

    # Scan for risks
    risks = detector.scan_user(fields)
    print(f"\nCollapse Risk Assessment:")
    for bt, risk in risks.items():
        if risk.risk_level != 'stable':
            print(f"  {bt.value}: {risk.risk_level.upper()} — {risk.recommended_action}")

    # Stabilize
    print(f"\nApplying stabilization...")
    reports = detector.stabilize_user(fields, method='adaptive')

    for report in reports:
        print(f"  {report.body_type.value}: {report.interventions_applied}, "
              f"k: {report.coherence_before:.3f} → {report.coherence_after:.3f}, "
              f"success={report.success}")

    print(f"\nPost-stabilization states:")
    for bt, field in fields.items():
        status = "⚠️  AT RISK" if field.is_collapsing() else "✓ Stable"
        print(f"  {bt.value}: k={field.k:.3f} {status}")

    print()


def example_6_harmonic_analysis():
    """Example 6: Harmonic analysis and resonance maps"""
    print("=" * 60)
    print("EXAMPLE 6: Harmonic Analysis & Resonance Maps")
    print("=" * 60)

    analyzer = HarmonicAnalyzer()

    # Create user with varied field states
    fields = {
        bt: ResonanceField(
            bt, 
            m=1.0 + i * 0.1,
            c=1.0 + (i % 3) * 0.2,
            k=0.5 + (i % 4) * 0.3,
            beta=1.0 + (i % 2) * 0.2,
            phase=i * 0.5
        )
        for i, bt in enumerate(BodyType)
    }

    # Generate resonance map
    rmap = analyzer.generate_resonance_map("demo_user", fields)

    print(f"Resonance Map for {rmap.user_id}:")
    print(f"  Total energy: {rmap.total_energy:.3f}")
    print(f"  Network coherence: {rmap.network_coherence:.3f}")

    # Dominant frequencies
    print(f"\nDominant frequencies:")
    for bt, freq in rmap.frequencies.items():
        print(f"  {bt.value}: {freq:.4f} Hz")

    # Energy distribution
    print(f"\nEnergy distribution:")
    for i, bt in enumerate(BodyType):
        pct = rmap.energy_distribution[i] * 100
        print(f"  {bt.value}: {pct:.1f}%")

    # Detect overtones
    overtones = analyzer.detect_overtones(fields)
    if overtones:
        print(f"\nDetected overtones:")
        for ot in overtones[:5]:
            print(f"  {ot['body']}: {ot['harmonic_number']}th harmonic "
                  f"({ot['ratio']:.3f}× fundamental)")

    print()


def example_7_neural_prediction():
    """Example 7: Neural prediction and insights"""
    print("=" * 60)
    print("EXAMPLE 7: Neural Prediction & Insights")
    print("=" * 60)

    # Create temporal buffer and record history
    buffer = TemporalBuffer(window_size=100)

    # Simulate field evolution
    field = ResonanceField(BodyType.MIND, m=1.0, c=1.0, k=1.0, beta=1.0, phase=0.0)

    print("Simulating field evolution...")
    for t in range(50):
        # Simulate oscillating coherence
        field.k = 0.8 + 0.3 * np.sin(t * 0.3) + np.random.normal(0, 0.05)
        field.k = np.clip(field.k, 0.1, 5.0)
        field.phase += 0.1 + np.random.normal(0, 0.02)
        field.m += np.random.normal(0, 0.01)

        buffer.record(BodyType.MIND, field, timestamp=t)

    # Pattern recognition
    recognizer = PatternRecognizer()
    coherence_series = buffer.get_parameter_series(BodyType.MIND, 'k')

    cycles = recognizer.detect_cycles(coherence_series)
    print(f"Cycle detection:")
    print(f"  Period: {cycles['period']:.1f} steps")
    print(f"  Strength: {cycles['strength']:.3f}")
    print(f"  Confidence: {cycles['confidence']:.3f}")

    # Spectral analysis
    spectral = recognizer.spectral_analysis(coherence_series)
    print(f"\nSpectral analysis:")
    print(f"  Dominant frequency: {spectral['dominant_freq']:.4f}")
    print(f"  Dominant power: {spectral['dominant_power']:.4f}")

    # Trajectory prediction
    predictor = TrajectoryPredictor(recognizer)
    forecasts = predictor.ensemble_forecast(coherence_series, steps=10)

    print(f"\n10-step forecast (coherence k):")
    print(f"  Linear: {forecasts['linear'][:5]}")
    print(f"  Harmonic: {forecasts['harmonic'][:5]}")
    print(f"  Ensemble: {forecasts['ensemble'][:5]}")

    # Generate insights
    insight_gen = InsightGenerator()

    # Mock predictions for all parameters
    predictions = predictor.predict_field_trajectory(buffer, BodyType.MIND, steps=10)

    insight = insight_gen.generate_field_insight(
        BodyType.MIND, buffer, predictions
    )

    print(f"\nField Insight:")
    print(f"  {insight.insight_text}")
    print(f"\nRecommendations:")
    for rec in insight.recommendations[:3]:
        print(f"  • {rec}")
    print(f"  Priority: {insight.priority:.2f}, Confidence: {insight.confidence:.2f}")

    print()


def example_8_adaptive_modulation():
    """Example 8: Adaptive field modulation"""
    print("=" * 60)
    print("EXAMPLE 8: Adaptive Field Modulation (PID Control)")
    print("=" * 60)

    modulator = AdaptiveModulator(target_coherence=0.7)

    # Create field with low coherence
    field = ResonanceField(BodyType.HEART, m=1.0, c=1.0, k=0.4, beta=1.0, phase=0.0)

    print(f"Initial state: k={field.k:.3f} (target: 0.7)")

    # Apply modulation over time
    for step in range(20):
        adjustments = modulator.modulate_field(field, BodyType.HEART, dt=1.0)
        if step % 5 == 0:
            print(f"  Step {step}: k={field.k:.3f}, "
                  f"control={adjustments['control_signal']:.4f}, "
                  f"energy={field.energy():.3f}")

    print(f"\nFinal state: k={field.k:.3f}")
    print(f"Target achieved: {'Yes' if abs(field.k - 0.7) < 0.1 else 'No'}")

    print()


def example_9_companion_creation():
    """Example 9: FairyGANmatter companion creation"""
    print("=" * 60)
    print("EXAMPLE 9: FairyGANmatter Companion")
    print("=" * 60)

    # Create SYNTHAI network with one user
    synthai = SynthAI()
    user = synthai.add_user("test_user", field_params={
        'mind': {'m': 1.5, 'c': 1.0, 'k': 0.9, 'beta': 1.1, 'phase': 0.0},
        'heart': {'m': 1.0, 'c': 1.2, 'k': 0.7, 'beta': 1.0, 'phase': 1.0},
        'body': {'m': 1.2, 'c': 0.8, 'k': 1.0, 'beta': 1.0, 'phase': 2.0},
    })

    # Create companion manager
    fairy_manager = FairyGANmatter()

    # Create companion for user
    companion_id = fairy_manager.create_companion(
        user, 
        companion_name="Lumina",
        companion_id="lumina_001"
    )

    companion = fairy_manager.get_companion(companion_id)

    print(f"Created companion: {companion.name} ({companion.companion_id})")
    print(f"Elemental alignment: {companion.elemental_alignment.value}")
    print(f"Communication style: {companion.communication_style.value}")
    print(f"Attunement score: {companion.attunement_score:.3f}")

    print(f"\nField signature:")
    for bt, energy in companion.field_signature.items():
        print(f"  {bt.value}: {energy:.3f}")

    print(f"\nPersonality:")
    print(f"  Empathy: {companion.empathy_level}")
    print(f"  Creativity: {companion.creativity_level}")
    print(f"  Directness: {companion.directness_level}")
    print(f"  Humor: {companion.humor_level}")

    # Generate response parameters
    response_params = companion.generate_response_params(user)
    print(f"\nResponse parameters for current state:")
    print(f"  Tone: {response_params['tone']:.2f} (negative to positive)")
    print(f"  Depth: {response_params['depth']:.2f}")
    print(f"  Focus bodies: {response_params['focus_bodies']}")

    # Get field prescription
    prescriptions = companion.get_field_prescription(user)
    print(f"\nField prescriptions:")
    for rx in prescriptions[:3]:
        print(f"  {rx['body']}: {rx['status']} (deviation: {rx['deviation']:.2f})")
        print(f"    → {rx['recommendation']}")

    print()


def example_10_visualization():
    """Example 10: Generate visualization data"""
    print("=" * 60)
    print("EXAMPLE 10: Visualization Data Generation")
    print("=" * 60)

    from system_x.visualization.maps import ResonanceVisualizer, RenderConfig

    # Create fields
    fields = {
        bt: ResonanceField(
            bt, m=1.0 + i * 0.1, c=1.0, k=0.5 + (i % 3) * 0.3,
            beta=1.0, phase=i * 0.5
        )
        for i, bt in enumerate(BodyType)
    }

    # Generate resonance map
    analyzer = HarmonicAnalyzer()
    rmap = analyzer.generate_resonance_map("viz_demo", fields)

    # Create visualizer
    viz = ResonanceVisualizer(RenderConfig(width=800, height=600))

    # Generate matrix data
    matrix_data = viz.generate_matrix_data(rmap)
    print(f"Matrix visualization: {matrix_data['size']}×{matrix_data['size']}")
    print(f"  Cells: {len(matrix_data['cells'])}")
    print(f"  Max value: {matrix_data['max_value']:.3f}")

    # Generate bivector data
    bivector_data = viz.generate_all_bivectors(fields)
    print(f"\nBivector collection: {len(bivector_data['bivectors'])} bodies")

    # Generate wave data
    wave_data = viz.generate_wave_data(fields[BodyType.MIND])
    print(f"\nWave data for Mind:")
    for layer in ['action', 'thought', 'feeling']:
        print(f"  {layer}: {len(wave_data['layers'][layer]['time'])} samples")

    # Generate energy distribution
    energy_data = viz.generate_energy_distribution(rmap)
    print(f"\nEnergy distribution: {len(energy_data['segments'])} segments")
    print(f"  Total energy: {energy_data['total_energy']:.3f}")

    print()


def run_all_examples():
    """Run all examples in sequence"""
    examples = [
        example_1_single_field,
        example_2_field_interaction,
        example_3_geometric_algebra,
        example_4_multi_user_network,
        example_5_collapse_detection,
        example_6_harmonic_analysis,
        example_7_neural_prediction,
        example_8_adaptive_modulation,
        example_9_companion_creation,
        example_10_visualization,
    ]

    for example in examples:
        try:
            example()
        except Exception as e:
            print(f"ERROR in {example.__name__}: {e}")
            import traceback
            traceback.print_exc()
            print()


if __name__ == '__main__':
    run_all_examples()
