"""
SYSTEM X — Resonance Mechanics Engine
A mathematically grounded consciousness field simulation framework.

Core equation: E = m · c · k^β

Modules:
    core: Field mechanics, resonance engine, geometric algebra
    network: Multi-user SYNTHAI resonance networks
    companions: FairyGANmatter personal companion instances
    visualization: Resonance maps and field renderers
    neural: Predictive insight generation via pattern recognition
    utils: Helpers, serializers, configuration

Version: 0.1.0
Author: System X Research Group
License: MIT
"""

__version__ = "0.1.0"
__all__ = [
    "ResonanceField",
    "ResonanceEngine", 
    "BodyType",
    "WaveLayer",
    "SynthAI",
    "User",
    "FairyCompanion",
    "FairyGANmatter",
    "CollapseDetector",
    "HarmonicAnalyzer",
    "ResonanceVisualizer",
    "TemporalBuffer",
    "PatternRecognizer",
    "TrajectoryPredictor",
    "InsightGenerator",
    "AdaptiveModulator",
    "CliffordEngine",
    "CouplingResult",
]

from .core.field import ResonanceField, BodyType, WaveLayer
from .core.engine import ResonanceEngine, CouplingResult, CliffordEngine
from .core.collapse import CollapseDetector
from .core.harmonics import HarmonicAnalyzer
from .network.synthai import SynthAI, User
from .companions.fairyganmatter import FairyCompanion, FairyGANmatter
from .visualization.maps import ResonanceVisualizer
from .neural.prediction import TemporalBuffer, PatternRecognizer, TrajectoryPredictor
from .neural.insights import InsightGenerator, AdaptiveModulator
