"""
serializers.py — Field and Network Serialization

Handles:
- JSON serialization/deserialization of all system objects
- Binary format for efficient storage
- Version compatibility checks
- Export/import of complete system states
"""

import json
import numpy as np
from typing import Dict, List, Any
from pathlib import Path

from ..core.field import ResonanceField, BodyType, WaveLayer
from ..network.synthai import User, SynthAI
from ..companions.fairyganmatter import FairyCompanion


class NumpyEncoder(json.JSONEncoder):
    """JSON encoder that handles numpy arrays and types"""
    def default(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, (np.int_, np.intc, np.intp, np.int8, np.int16, 
                             np.int32, np.int64, np.uint8, np.uint16, 
                             np.uint32, np.uint64)):
            return int(obj)
        if isinstance(obj, (np.float_, np.float16, np.float32, np.float64)):
            return float(obj)
        if isinstance(obj, np.bool_):
            return bool(obj)
        if isinstance(obj, (np.complex_, np.complex64, np.complex128)):
            return {'real': obj.real, 'imag': obj.imag}
        if isinstance(obj, BodyType):
            return obj.value
        if isinstance(obj, WaveLayer):
            return obj.value
        return super().default(obj)


class FieldSerializer:
    """Serialize and deserialize ResonanceField objects"""

    @staticmethod
    def to_json(field: ResonanceField) -> str:
        """Serialize field to JSON string"""
        return json.dumps(field.to_dict(), cls=NumpyEncoder, indent=2)

    @staticmethod
    def from_json(json_str: str) -> ResonanceField:
        """Deserialize field from JSON string"""
        data = json.loads(json_str)
        return ResonanceField.from_dict(data)

    @staticmethod
    def to_dict(field: ResonanceField) -> Dict:
        """Serialize field to dictionary"""
        return field.to_dict()

    @staticmethod
    def from_dict(data: Dict) -> ResonanceField:
        """Deserialize field from dictionary"""
        return ResonanceField.from_dict(data)


class UserSerializer:
    """Serialize and deserialize User objects"""

    @staticmethod
    def to_dict(user: User) -> Dict:
        """Serialize user to dictionary"""
        return user.to_dict()

    @staticmethod
    def from_dict(data: Dict) -> User:
        """Deserialize user from dictionary"""
        fields = {}
        for bt_str, field_data in data['fields'].items():
            body_type = BodyType(bt_str)
            fields[body_type] = ResonanceField.from_dict(field_data)

        user = User(
            user_id=data['user_id'],
            fields=fields,
            metadata=data.get('metadata', {})
        )
        return user

    @staticmethod
    def to_json(user: User) -> str:
        """Serialize user to JSON string"""
        return json.dumps(user.to_dict(), cls=NumpyEncoder, indent=2)

    @staticmethod
    def from_json(json_str: str) -> User:
        """Deserialize user from JSON string"""
        data = json.loads(json_str)
        return UserSerializer.from_dict(data)


class NetworkSerializer:
    """Serialize and deserialize complete network states"""

    @staticmethod
    def export_network(synthai: SynthAI, filepath: str):
        """Export complete network state to JSON file"""
        data = {
            'version': '0.1.0',
            'timestamp': synthai._timestamp,
            'users': {},
            'interaction_history': synthai.interaction_history,
            'network_states': [
                {
                    'timestamp': s.timestamp,
                    'user_count': s.user_count,
                    'global_coherence': float(s.global_coherence),
                    'interaction_count': s.interaction_count,
                    'average_energy': float(s.average_energy),
                    'coherence_distribution': s.coherence_distribution,
                    'dominant_pairs': s.dominant_pairs,
                    'collapse_risks': s.collapse_risks
                }
                for s in synthai.network_states
            ],
            'relationship_matrix': {
                f"{k[0]}::{k[1]}": v
                for k, v in synthai.relationship_matrix.items()
            }
        }

        for user_id, user in synthai.users.items():
            data['users'][user_id] = UserSerializer.to_dict(user)

        with open(filepath, 'w') as f:
            json.dump(data, f, cls=NumpyEncoder, indent=2)

    @staticmethod
    def import_network(filepath: str) -> Dict:
        """Import network state from JSON file"""
        with open(filepath, 'r') as f:
            data = json.load(f)
        return data

    @staticmethod
    def reconstruct_synthai(data: Dict) -> SynthAI:
        """Reconstruct SynthAI from imported data"""
        synthai = SynthAI()

        # Reconstruct users
        for user_id, user_data in data.get('users', {}).items():
            user = UserSerializer.from_dict(user_data)
            synthai.users[user_id] = user

        # Restore state
        synthai._timestamp = data.get('timestamp', 0)
        synthai.interaction_history = data.get('interaction_history', [])

        # Reconstruct network states
        from ..network.synthai import NetworkState
        for state_data in data.get('network_states', []):
            state = NetworkState(
                timestamp=state_data['timestamp'],
                user_count=state_data['user_count'],
                global_coherence=state_data['global_coherence'],
                interaction_count=state_data['interaction_count'],
                average_energy=state_data['average_energy'],
                coherence_distribution=state_data.get('coherence_distribution', {}),
                dominant_pairs=[tuple(p) for p in state_data.get('dominant_pairs', [])],
                collapse_risks=[tuple(c) for c in state_data.get('collapse_risks', [])]
            )
            synthai.network_states.append(state)

        # Reconstruct relationship matrix
        for key, value in data.get('relationship_matrix', {}).items():
            parts = key.split('::')
            if len(parts) == 2:
                synthai.relationship_matrix[(parts[0], parts[1])] = value

        return synthai


class CompanionSerializer:
    """Serialize and deserialize FairyCompanion objects"""

    @staticmethod
    def to_dict(companion: FairyCompanion) -> Dict:
        """Serialize companion to dictionary"""
        return companion.to_dict()

    @staticmethod
    def from_dict(data: Dict) -> FairyCompanion:
        """Deserialize companion from dictionary"""
        from ..companions.fairyganmatter import ElementalAlignment, CommunicationStyle

        companion = FairyCompanion(
            companion_id=data['companion_id'],
            user_id=data['user_id'],
            name=data.get('name', 'Companion'),
            elemental_alignment=ElementalAlignment(data.get('elemental_alignment', 'aether')),
            communication_style=CommunicationStyle(data.get('communication_style', 'balanced')),
            field_signature={
                BodyType(bt): float(v) 
                for bt, v in data.get('field_signature', {}).items()
            },
            body_weights={
                BodyType(bt): float(v)
                for bt, v in data.get('body_weights', {}).items()
            }
        )

        # Restore personality
        personality = data.get('personality', {})
        companion.empathy_level = personality.get('empathy', 0.7)
        companion.creativity_level = personality.get('creativity', 0.5)
        companion.directness_level = personality.get('directness', 0.5)
        companion.humor_level = personality.get('humor', 0.3)

        companion.attunement_score = data.get('attunement_score', 0.0)
        companion.interaction_count = data.get('interaction_count', 0)

        return companion
