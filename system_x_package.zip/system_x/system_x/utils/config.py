"""
config.py — System X Configuration Management

Centralized configuration for all system parameters,
with validation, environment variable overrides,
and profile presets.
"""

import os
from typing import Dict, Optional, Any
from dataclasses import dataclass, field


@dataclass
class SystemXConfig:
    """
    Complete configuration for System X engine.

    All parameters have sensible defaults but can be overridden
    via environment variables or programmatically.
    """

    # ═══════════════════════════════════════════════════════════════════
    # FIELD PARAMETERS
    # ═══════════════════════════════════════════════════════════════════

    # Default field initialization ranges
    default_m_range: tuple = (0.8, 1.2)          # pattern density
    default_c_range: tuple = (0.8, 1.2)          # cognitive velocity
    default_k_range: tuple = (0.6, 1.0)          # coherence
    default_beta_range: tuple = (0.9, 1.1)       # resonance exponent
    default_phase_range: tuple = (0.0, 6.283)     # phase [0, 2π]

    # Field clamps (safety limits)
    m_min: float = 0.1
    m_max: float = 5.0
    c_min: float = 0.1
    c_max: float = 3.0
    k_min: float = 0.001
    k_max: float = 5.0
    beta_min: float = 0.5
    beta_max: float = 2.0

    # ═══════════════════════════════════════════════════════════════════
    # ENGINE PARAMETERS
    # ═══════════════════════════════════════════════════════════════════

    # ResonanceEngine defaults
    collapse_threshold: float = 0.3
    coupling_strength: float = 0.01
    phase_coupling: float = 0.1
    coherence_coupling: float = 0.001
    default_dt: float = 1.0

    # ═══════════════════════════════════════════════════════════════════
    # COLLAPSE DETECTOR PARAMETERS
    # ═══════════════════════════════════════════════════════════════════

    collapse_intervention_strength: float = 0.5
    prediction_horizon: int = 50
    cascade_prevention: bool = True

    # PID controller defaults for AdaptiveModulator
    pid_kp: float = 0.1      # proportional gain
    pid_ki: float = 0.01     # integral gain
    pid_kd: float = 0.05     # derivative gain
    target_coherence: float = 0.7

    # ═══════════════════════════════════════════════════════════════════
    # NEURAL PREDICTION PARAMETERS
    # ═══════════════════════════════════════════════════════════════════

    # TemporalBuffer
    buffer_window_size: int = 1000

    # PatternRecognizer
    cycle_detection_min_length: int = 10
    max_autocorr_lag: Optional[int] = None
    anomaly_threshold_sigma: float = 3.0

    # TrajectoryPredictor
    forecast_steps_default: int = 10
    ensemble_weights: Dict[str, float] = field(default_factory=lambda: {
        'linear': 0.33,
        'harmonic': 0.33,
        'quadratic': 0.34
    })

    # ═══════════════════════════════════════════════════════════════════
    # HARMONIC ANALYZER PARAMETERS
    # ═══════════════════════════════════════════════════════════════════

    fft_samples: int = 256
    sample_rate: float = 1.0
    t_duration: float = 12.566  # 4π

    # ═══════════════════════════════════════════════════════════════════
    # VISUALIZATION PARAMETERS
    # ═══════════════════════════════════════════════════════════════════

    render_width: int = 800
    render_height: int = 600
    color_scheme: str = "spectral"
    show_labels: bool = True
    show_values: bool = True
    animation_frames: int = 60

    # ═══════════════════════════════════════════════════════════════════
    # COMPANION PARAMETERS
    # ═══════════════════════════════════════════════════════════════════

    companion_max_memory: int = 1000
    companion_attunement_learning_rate: float = 0.1
    companion_default_empathy: float = 0.7
    companion_default_creativity: float = 0.5
    companion_default_directness: float = 0.5
    companion_default_humor: float = 0.3

    # ═══════════════════════════════════════════════════════════════════
    # NETWORK PARAMETERS
    # ═══════════════════════════════════════════════════════════════════

    max_users: int = 10000
    relationship_threshold: float = 0.1

    # ═══════════════════════════════════════════════════════════════════
    # PERSISTENCE PARAMETERS
    # ═══════════════════════════════════════════════════════════════════

    auto_save_interval: int = 100  # steps between auto-saves
    checkpoint_dir: str = "./checkpoints"

    @classmethod
    def from_env(cls) -> 'SystemXConfig':
        """Create configuration from environment variables"""
        config = cls()

        # Override with environment variables
        env_mappings = {
            'SYSTEMX_COLLAPSE_THRESHOLD': ('collapse_threshold', float),
            'SYSTEMX_COUPLING_STRENGTH': ('coupling_strength', float),
            'SYSTEMX_BUFFER_SIZE': ('buffer_window_size', int),
            'SYSTEMX_FFT_SAMPLES': ('fft_samples', int),
            'SYSTEMX_MAX_USERS': ('max_users', int),
            'SYSTEMX_CHECKPOINT_DIR': ('checkpoint_dir', str),
            'SYSTEMX_CASCADE_PREVENTION': ('cascade_prevention', lambda x: x.lower() == 'true'),
        }

        for env_var, (attr, converter) in env_mappings.items():
            value = os.getenv(env_var)
            if value is not None:
                try:
                    setattr(config, attr, converter(value))
                except (ValueError, TypeError):
                    pass  # Keep default if conversion fails

        return config

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SystemXConfig':
        """Create configuration from dictionary"""
        config = cls()
        for key, value in data.items():
            if hasattr(config, key):
                setattr(config, key, value)
        return config

    def to_dict(self) -> Dict[str, Any]:
        """Serialize configuration to dictionary"""
        return {
            k: v for k, v in self.__dict__.items()
            if not k.startswith('_')
        }

    def validate(self) -> bool:
        """Validate configuration parameters"""
        checks = [
            self.m_min < self.m_max,
            self.c_min < self.c_max,
            self.k_min < self.k_max,
            self.beta_min < self.beta_max,
            self.collapse_threshold > 0,
            self.coupling_strength >= 0,
            self.buffer_window_size > 0,
            self.fft_samples > 0,
            self.max_users > 0,
            sum(self.ensemble_weights.values()) > 0,
        ]
        return all(checks)


# Predefined configuration profiles
PROFILE_PRESETS = {
    'default': SystemXConfig(),

    'high_precision': SystemXConfig(
        fft_samples=512,
        buffer_window_size=5000,
        prediction_horizon=100,
        anomaly_threshold_sigma=2.5,
    ),

    'low_latency': SystemXConfig(
        fft_samples=128,
        buffer_window_size=500,
        prediction_horizon=20,
        auto_save_interval=50,
    ),

    'stable': SystemXConfig(
        collapse_threshold=0.4,
        collapse_intervention_strength=0.7,
        pid_kp=0.15,
        pid_ki=0.02,
        cascade_prevention=True,
    ),

    'experimental': SystemXConfig(
        coupling_strength=0.02,
        phase_coupling=0.2,
        coherence_coupling=0.005,
        ensemble_weights={'linear': 0.2, 'harmonic': 0.6, 'quadratic': 0.2},
    ),
}
