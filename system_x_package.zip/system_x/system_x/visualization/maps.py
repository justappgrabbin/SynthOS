"""
maps.py — Resonance Map Visualization & Field Rendering

Implements:
- 2D/3D resonance matrix visualization
- Field state rendering (bivector planes, wave interference)
- Network graph generation
- Energy distribution charts
- Phase synchronization diagrams
- Export to various formats (JSON, SVG, PNG data)
"""

import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

from ..core.field import ResonanceField, BodyType, WaveLayer
from ..core.harmonics import ResonanceMap
from ..network.synthai import User, NetworkState


@dataclass
class RenderConfig:
    """Configuration for visualization rendering"""
    width: int = 800
    height: int = 600
    color_scheme: str = "spectral"  # spectral, thermal, ocean, cosmic
    show_labels: bool = True
    show_values: bool = True
    animation_frames: int = 60


class ResonanceVisualizer:
    """
    Generate visualization data structures for resonance fields.

    This class produces data that can be rendered by frontend
    libraries (D3.js, Three.js, matplotlib, etc.). It does not
    directly render graphics but provides structured data for
    all visualization types.
    """

    def __init__(self, config: Optional[RenderConfig] = None):
        self.config = config or RenderConfig()

    # ═══════════════════════════════════════════════════════════════════════
    # RESONANCE MATRIX VISUALIZATION
    # ═══════════════════════════════════════════════════════════════════════

    def generate_matrix_data(self, resonance_map: ResonanceMap) -> Dict:
        """
        Generate data for 9×9 resonance matrix heatmap.

        Returns JSON-serializable dict with cell data, colors,
        labels, and interaction metadata.
        """
        matrix = resonance_map.matrix
        n = len(BodyType)

        cells = []
        body_names = [bt.value for bt in BodyType]

        # Color mapping (spectral: blue=low, red=high)
        def color_for_value(val: float, max_val: float) -> str:
            if max_val <= 0:
                return "#000000"
            normalized = np.clip(val / max_val, 0, 1)
            # Spectral: blue(0) → green(0.5) → red(1)
            if normalized < 0.5:
                # Blue to green
                r = 0
                g = int(255 * normalized * 2)
                b = int(255 * (1 - normalized * 2))
            else:
                # Green to red
                r = int(255 * (normalized - 0.5) * 2)
                g = int(255 * (1 - (normalized - 0.5) * 2))
                b = 0
            return f"#{r:02x}{g:02x}{b:02x}"

        max_val = np.max(np.abs(matrix))

        for i in range(n):
            for j in range(n):
                val = matrix[i, j]
                cells.append({
                    'row': i,
                    'col': j,
                    'row_body': body_names[i],
                    'col_body': body_names[j],
                    'value': float(val),
                    'color': color_for_value(val, max_val),
                    'is_diagonal': i == j,
                    'intensity': float(np.clip(val / max_val, 0, 1)) if max_val > 0 else 0
                })

        return {
            'type': 'matrix_heatmap',
            'size': n,
            'labels': body_names,
            'cells': cells,
            'max_value': float(max_val),
            'min_value': float(np.min(matrix)),
            'average': float(np.mean(matrix)),
            'config': {
                'width': self.config.width,
                'height': self.config.height,
                'show_labels': self.config.show_labels,
                'show_values': self.config.show_values
            }
        }

    # ═══════════════════════════════════════════════════════════════════════
    # BIVECTOR FIELD VISUALIZATION
    # ═══════════════════════════════════════════════════════════════════════

    def generate_bivector_data(self, field: ResonanceField, 
                              scale: float = 100) -> Dict:
        """
        Generate 2D projection of 6D bivector for visualization.

        Projects bivector components onto two 2D planes:
        - Spatial plane: e01, e02 (pattern density × phase)
        - Spacetime plane: e12, e23 (velocity × coherence)
        """
        bv = field.bivector

        # Spatial projection
        spatial_x = bv[0] * scale  # e01
        spatial_y = bv[1] * scale  # e02

        # Spacetime projection
        st_x = bv[3] * scale  # e12
        st_y = bv[4] * scale  # e23

        # Magnitude circle
        magnitude = field.bivector_magnitude() * scale

        return {
            'type': 'bivector_projection',
            'body_type': field.body_type.value,
            'spatial_plane': {
                'x': float(spatial_x),
                'y': float(spatial_y),
                'components': ['e01', 'e02'],
                'label': 'Pattern Density × Phase'
            },
            'spacetime_plane': {
                'x': float(st_x),
                'y': float(st_y),
                'components': ['e12', 'e23'],
                'label': 'Velocity × Coherence'
            },
            'magnitude': float(magnitude),
            'field_parameters': {
                'm': float(field.m),
                'c': float(field.c),
                'k': float(field.k),
                'beta': float(field.beta),
                'phase': float(field.phase)
            }
        }

    def generate_all_bivectors(self, fields: Dict[BodyType, ResonanceField]) -> Dict:
        """Generate bivector data for all 9 bodies"""
        return {
            'type': 'bivector_collection',
            'bivectors': [
                self.generate_bivector_data(fields[bt]) for bt in BodyType
            ],
            'body_names': [bt.value for bt in BodyType]
        }

    # ═══════════════════════════════════════════════════════════════════════
    # WAVE INTERFERENCE VISUALIZATION
    # ═══════════════════════════════════════════════════════════════════════

    def generate_wave_data(self, field: ResonanceField,
                           t_range: Tuple[float, float] = (0, 4 * np.pi),
                           resolution: int = 200) -> Dict:
        """
        Generate wave function data for all three layers.

        Returns time-series data for Action, Thought, Feeling waves
        suitable for line chart rendering.
        """
        t = np.linspace(t_range[0], t_range[1], resolution)

        waves = {}
        for layer in WaveLayer:
            amplitudes = [field.wave_amplitude(layer, ti) for ti in t]
            waves[layer.value] = {
                'time': t.tolist(),
                'amplitude': amplitudes,
                'layer_phase': {
                    WaveLayer.ACTION: 0,
                    WaveLayer.THOUGHT: 2 * np.pi / 3,
                    WaveLayer.FEELING: 4 * np.pi / 3
                }[layer],
                'color': {
                    WaveLayer.ACTION: '#ff6b6b',
                    WaveLayer.THOUGHT: '#4ecdc4',
                    WaveLayer.FEELING: '#45b7d1'
                }[layer]
            }

        # Combined wave (sum of all layers)
        combined = [
            sum(field.wave_amplitude(layer, ti) for layer in WaveLayer) / 3
            for ti in t
        ]

        return {
            'type': 'wave_functions',
            'body_type': field.body_type.value,
            'layers': waves,
            'combined': {
                'time': t.tolist(),
                'amplitude': combined,
                'color': '#9b59b6'
            },
            'field_parameters': {
                'm': float(field.m),
                'c': float(field.c),
                'phase': float(field.phase)
            }
        }

    def generate_interference_data(self, field_a: ResonanceField,
                                  field_b: ResonanceField,
                                  layer: WaveLayer = WaveLayer.ACTION,
                                  t_range: Tuple[float, float] = (0, 4 * np.pi),
                                  resolution: int = 400) -> Dict:
        """
        Generate wave interference pattern between two fields.

        Shows constructive/destructive interference for specified layer.
        """
        t = np.linspace(t_range[0], t_range[1], resolution)

        wave_a = [field_a.wave_amplitude(layer, ti) for ti in t]
        wave_b = [field_b.wave_amplitude(layer, ti) for ti in t]
        combined = [(a + b) / 2 for a, b in zip(wave_a, wave_b)]

        # Detect interference type
        max_amp = max(abs(x) for x in combined)
        avg_amp = np.mean([abs(x) for x in combined])

        if max_amp > 1.5:
            interference_type = "constructive"
        elif max_amp < 0.5:
            interference_type = "destructive"
        else:
            interference_type = "mixed"

        return {
            'type': 'wave_interference',
            'body_a': field_a.body_type.value,
            'body_b': field_b.body_type.value,
            'layer': layer.value,
            'interference_type': interference_type,
            'time': t.tolist(),
            'wave_a': wave_a,
            'wave_b': wave_b,
            'combined': combined,
            'max_amplitude': float(max_amp),
            'average_amplitude': float(avg_amp),
            'phase_difference': float(abs(field_a.phase - field_b.phase) % (2 * np.pi))
        }

    # ═══════════════════════════════════════════════════════════════════════
    # ENERGY DISTRIBUTION VISUALIZATION
    # ═══════════════════════════════════════════════════════════════════════

    def generate_energy_distribution(self, resonance_map: ResonanceMap) -> Dict:
        """
        Generate data for energy distribution chart (pie/bar).
        """
        distribution = resonance_map.energy_distribution
        body_names = [bt.value for bt in BodyType]

        segments = []
        colors = [
            '#e74c3c', '#e67e22', '#f1c40f', '#2ecc71',
            '#1abc9c', '#3498db', '#9b59b6', '#34495e', '#95a5a6'
        ]

        for i, (bt, energy) in enumerate(zip(BodyType, distribution)):
            segments.append({
                'body': bt.value,
                'energy_share': float(energy),
                'percentage': float(energy * 100),
                'color': colors[i % len(colors)],
                'angle': float(energy * 2 * np.pi)  # For pie chart
            })

        return {
            'type': 'energy_distribution',
            'total_energy': float(resonance_map.total_energy),
            'network_coherence': float(resonance_map.network_coherence),
            'segments': segments,
            'body_names': body_names
        }

    # ═══════════════════════════════════════════════════════════════════════
    # PHASE SYNCHRONIZATION VISUALIZATION
    # ═══════════════════════════════════════════════════════════════════════

    def generate_phase_sync_data(self, resonance_map: ResonanceMap) -> Dict:
        """
        Generate phase synchronization chord diagram / matrix data.
        """
        sync_matrix = resonance_map.phase_locking
        body_names = [bt.value for bt in BodyType]
        n = len(body_names)

        links = []
        for i in range(n):
            for j in range(i + 1, n):
                sync_value = sync_matrix[i, j]
                if sync_value > 0.3:  # Only show significant connections
                    links.append({
                        'source': body_names[i],
                        'target': body_names[j],
                        'value': float(sync_value),
                        'strength': 'strong' if sync_value > 0.7 else 'moderate' if sync_value > 0.5 else 'weak'
                    })

        return {
            'type': 'phase_synchronization',
            'nodes': [{'id': name, 'group': i} for i, name in enumerate(body_names)],
            'links': links,
            'average_sync': float(np.mean(sync_matrix)),
            'max_sync': float(np.max(sync_matrix)),
            'min_sync': float(np.min(sync_matrix))
        }

    # ═══════════════════════════════════════════════════════════════════════
    # NETWORK GRAPH VISUALIZATION
    # ═══════════════════════════════════════════════════════════════════════

    def generate_network_graph(self, users: Dict[str, User],
                              relationship_matrix: Dict,
                              threshold: float = 0.1) -> Dict:
        """
        Generate network graph data for multi-user visualization.

        Nodes = users, edges = resonance relationships.
        """
        nodes = []
        edges = []

        # Create nodes
        for user_id, user in users.items():
            # Node size proportional to total energy
            energy = user.total_energy()
            coherence = user.coherence_index()

            nodes.append({
                'id': user_id,
                'energy': float(energy),
                'coherence': float(coherence),
                'dominant_body': user.dominant_body().value,
                'radius': float(np.sqrt(energy) * 10),  # Visual radius
                'color': self._color_for_coherence(coherence)
            })

        # Create edges from relationship matrix
        for pair, data in relationship_matrix.items():
            if data['total_interactions'] == 0:
                continue

            avg_resonance = data['total_resonance'] / data['total_interactions']
            if avg_resonance < threshold:
                continue

            edges.append({
                'source': pair[0],
                'target': pair[1],
                'resonance': float(avg_resonance),
                'interactions': data['total_interactions'],
                'width': float(avg_resonance * 5),  # Visual width
                'color': self._color_for_resonance(avg_resonance)
            })

        return {
            'type': 'network_graph',
            'nodes': nodes,
            'edges': edges,
            'node_count': len(nodes),
            'edge_count': len(edges),
            'average_resonance': float(np.mean([e['resonance'] for e in edges])) if edges else 0
        }

    def _color_for_coherence(self, coherence: float) -> str:
        """Map coherence to color (red=low, green=high)"""
        normalized = np.clip(coherence / 5.0, 0, 1)
        r = int(255 * (1 - normalized))
        g = int(255 * normalized)
        return f"#{r:02x}{g:02x}00"

    def _color_for_resonance(self, resonance: float) -> str:
        """Map resonance strength to color"""
        normalized = np.clip(resonance / 5.0, 0, 1)
        # Blue to purple to pink
        r = int(100 + 155 * normalized)
        g = int(100 * (1 - normalized))
        b = int(200 + 55 * normalized)
        return f"#{r:02x}{g:02x}{b:02x}"

    # ═══════════════════════════════════════════════════════════════════════
    # COMPLETE DASHBOARD DATA
    # ═══════════════════════════════════════════════════════════════════════

    def generate_dashboard(self, user: User, 
                          resonance_map: ResonanceMap) -> Dict:
        """
        Generate complete dashboard data for a single user.

        Combines all visualization types into one JSON structure
        suitable for frontend rendering.
        """
        return {
            'user_id': user.user_id,
            'timestamp': resonance_map.to_dict(),
            'visualizations': {
                'resonance_matrix': self.generate_matrix_data(resonance_map),
                'energy_distribution': self.generate_energy_distribution(resonance_map),
                'phase_synchronization': self.generate_phase_sync_data(resonance_map),
                'bivectors': self.generate_all_bivectors(user.fields),
                'waves': {
                    bt.value: self.generate_wave_data(user.fields[bt])
                    for bt in BodyType
                }
            },
            'summary': {
                'total_energy': float(resonance_map.total_energy),
                'network_coherence': float(resonance_map.network_coherence),
                'dominant_body': user.dominant_body().value,
                'weakest_body': user.weakest_body().value,
                'coherence_index': float(user.coherence_index()),
                'phase_variance': float(user.phase_variance())
            }
        }

    def generate_network_dashboard(self, synthai_state: NetworkState,
                                  users: Dict[str, User],
                                  relationship_matrix: Dict) -> Dict:
        """
        Generate dashboard data for network-wide view.
        """
        return {
            'timestamp': synthai_state.timestamp,
            'network_state': {
                'user_count': synthai_state.user_count,
                'global_coherence': float(synthai_state.global_coherence),
                'average_energy': float(synthai_state.average_energy),
                'interaction_count': synthai_state.interaction_count,
                'coherence_distribution': synthai_state.coherence_distribution,
                'dominant_pairs': [
                    {'user_a': p[0], 'user_b': p[1], 'resonance': float(p[2])}
                    for p in synthai_state.dominant_pairs
                ],
                'collapse_risks': [
                    {'user_id': cr[0], 'body': cr[1]}
                    for cr in synthai_state.collapse_risks
                ]
            },
            'visualizations': {
                'network_graph': self.generate_network_graph(
                    users, relationship_matrix
                )
            }
        }


class ResonanceMapRenderer:
    """
    High-level renderer that combines all visualization components.

    Provides one-call generation of complete visualization suites
    for both individual users and network-wide views.
    """

    def __init__(self, config: Optional[RenderConfig] = None):
        self.visualizer = ResonanceVisualizer(config)

    def render_user(self, user: User) -> Dict:
        """Generate complete visualization data for a user"""
        from ..core.harmonics import HarmonicAnalyzer
        analyzer = HarmonicAnalyzer()
        resonance_map = analyzer.generate_resonance_map(user.user_id, user.fields)
        return self.visualizer.generate_dashboard(user, resonance_map)

    def render_interference(self, field_a: ResonanceField,
                           field_b: ResonanceField,
                           layer: WaveLayer = WaveLayer.ACTION) -> Dict:
        """Render wave interference between two fields"""
        return self.visualizer.generate_interference_data(field_a, field_b, layer)

    def render_network(self, users: Dict[str, User],
                      relationship_matrix: Dict,
                      network_state: NetworkState) -> Dict:
        """Render network-wide visualization"""
        return self.visualizer.generate_network_dashboard(
            network_state, users, relationship_matrix
        )
