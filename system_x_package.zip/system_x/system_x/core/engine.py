"""
engine.py — Geometric Algebra Engine & Resonance Mechanics

Implements:
- Clifford algebra Cl(1,3) operations for field coupling
- Harmonic coupling: H = mA·mB · kA·kB · cos(Δφ)
- Energy redistribution between coupled fields
- Phase correction dynamics
- Full timestep integration
"""

import numpy as np
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional
from .field import ResonanceField, BodyType, WaveLayer


@dataclass
class CouplingResult:
    """Result of field coupling interaction"""
    harmonic_coupling: float      # H = mA·mB · kA·kB · cos(Δφ)
    phase_alignment: float        # |φA - φB| mod 2π
    energy_transfer: float        # ΔE from A to B
    resonance_scalar: float       # ⟨FA, FB⟩ geometric inner product
    bivector_product: np.ndarray  # FA ∧ FB geometric outer product
    pseudoscalar: float           # I-component of geometric product
    collapse_risk_a: bool         # Field A collapsing?
    collapse_risk_b: bool         # Field B collapsing?
    coherence_delta_a: float      # Change in A's coherence
    coherence_delta_b: float      # Change in B's coherence


class CliffordEngine:
    """
    Geometric Algebra Cl(1,3) operations for consciousness fields.

    The geometric product of two bivectors F and G:
        FG = ⟨F,G⟩ + F∧G + I·(F×G)

    Where:
        ⟨F,G⟩ = -Σ fᵢ·gᵢ          (scalar/inner product, negative definite)
        F∧G = grade-2 part        (bivector/wedge product)
        F×G = grade-4 part        (pseudoscalar/trivector)
        I = e0123                 (pseudoscalar unit)
    """

    @staticmethod
    def inner_product(b1: np.ndarray, b2: np.ndarray) -> float:
        """
        Scalar (grade-0) part: ⟨F,G⟩ = -Σᵢ₌₁⁶ fᵢ·gᵢ

        Negative definite because bivectors in Cl(1,3) have
        signature (-, -, -, +, +, +) for (e01,e02,e03,e12,e23,e31).
        """
        return -np.dot(b1, b2)

    @staticmethod
    def wedge_product(b1: np.ndarray, b2: np.ndarray) -> np.ndarray:
        """
        Bivector (grade-2) part of geometric product.

        For Cl(1,3) bivectors, the wedge product yields:
        (f₂₃g₃₁ - f₃₁g₂₃)e₀₁ + ... (6 components)

        This represents the oriented area spanned by the two fields.
        """
        # Component-wise wedge product for Cl(1,3) bivectors
        # Using the structure: e01, e02, e03, e12, e23, e31
        result = np.zeros(6)

        # e01 component: f23·g31 - f31·g23 (from e23 ∧ e31)
        result[0] = b1[4] * b2[5] - b1[5] * b2[4]
        # e02 component: f31·g12 - f12·g31 (from e31 ∧ e12)
        result[1] = b1[5] * b2[3] - b1[3] * b2[5]
        # e03 component: f12·g23 - f23·g12 (from e12 ∧ e23)
        result[2] = b1[3] * b2[4] - b1[4] * b2[3]
        # e12 component: f03·g31 - f31·g03 (from e03 ∧ e31)
        result[3] = b1[2] * b2[5] - b1[5] * b2[2]
        # e23 component: f01·g12 - f12·g01 (from e01 ∧ e12)
        result[4] = b1[0] * b2[3] - b1[3] * b2[0]
        # e31 component: f02·g23 - f23·g02 (from e02 ∧ e23)
        result[5] = b1[1] * b2[4] - b1[4] * b2[1]

        return result

    @staticmethod
    def pseudoscalar_part(b1: np.ndarray, b2: np.ndarray) -> float:
        """
        Grade-4 (pseudoscalar) part: I·(F×G)

        In Cl(1,3), the pseudoscalar I = e0∧e1∧e2∧e3.
        The commutator product F×G produces a trivector,
        and its dual gives the pseudoscalar coefficient.
        """
        # Simplified: sum of cyclic products
        return (
            b1[0] * b2[4] + b1[1] * b2[5] + b1[2] * b2[3] +
            b1[3] * b2[2] + b1[4] * b2[0] + b1[5] * b2[1]
        )

    @staticmethod
    def geometric_product(b1: np.ndarray, b2: np.ndarray) -> Tuple[float, np.ndarray, float]:
        """
        Full geometric product: FG = ⟨F,G⟩ + F∧G + I·(F×G)

        Returns:
            scalar: grade-0 part (inner product)
            bivector: grade-2 part (wedge product)
            pseudoscalar: grade-4 part (commutator dual)
        """
        scalar = CliffordEngine.inner_product(b1, b2)
        bivector = CliffordEngine.wedge_product(b1, b2)
        pseudoscalar = CliffordEngine.pseudoscalar_part(b1, b2)
        return scalar, bivector, pseudoscalar

    @staticmethod
    def field_resonance(f1: ResonanceField, f2: ResonanceField) -> float:
        """
        Calculate resonance magnitude between two fields.

        R = |⟨F₁, F₂⟩| = |scalar part of geometric product|

        High resonance: fields are aligned (constructive interference)
        Low resonance: fields are orthogonal (independent)
        Negative resonance: fields are anti-aligned (destructive interference)
        """
        scalar, _, _ = CliffordEngine.geometric_product(f1.bivector, f2.bivector)
        return abs(scalar)

    @staticmethod
    def field_coupling_strength(f1: ResonanceField, f2: ResonanceField) -> float:
        """
        Coupling strength from wedge product magnitude.

        C = |F₁ ∧ F₂| = magnitude of grade-2 part

        High coupling: fields span new dimensions (creative interaction)
        Low coupling: fields are parallel or anti-parallel (redundant)
        """
        _, bivector, _ = CliffordEngine.geometric_product(f1.bivector, f2.bivector)
        return np.linalg.norm(bivector)

    @staticmethod
    def field_phase_relation(f1: ResonanceField, f2: ResonanceField) -> float:
        """
        Phase relation from pseudoscalar part.

        Returns angle in [0, 2π] representing the rotational
        relationship between fields in the 4D spacetime algebra.
        """
        _, _, pseudo = CliffordEngine.geometric_product(f1.bivector, f2.bivector)
        scalar = CliffordEngine.inner_product(f1.bivector, f2.bivector)
        return np.arctan2(pseudo, scalar) % (2 * np.pi)


class ResonanceEngine:
    """
    Core resonance mechanics engine.

    Implements the full field interaction protocol:
    1. Harmonic coupling calculation
    2. Geometric algebra resonance
    3. Phase alignment dynamics
    4. Energy redistribution
    5. Coherence evolution
    6. Collapse detection
    """

    def __init__(self, 
                 collapse_threshold: float = 0.3,
                 coupling_strength: float = 0.01,
                 phase_coupling: float = 0.1,
                 coherence_coupling: float = 0.001,
                 dt: float = 1.0):
        """
        Args:
            collapse_threshold: k < threshold triggers collapse warning
            coupling_strength: energy transfer coefficient (0.01 = 1% per step)
            phase_coupling: phase alignment rate (0.1 = 10% per step)
            coherence_coupling: coherence influence from harmonic coupling
            dt: timestep size
        """
        self.collapse_threshold = collapse_threshold
        self.coupling_strength = coupling_strength
        self.phase_coupling = phase_coupling
        self.coherence_coupling = coherence_coupling
        self.dt = dt
        self.clifford = CliffordEngine()
        self._interaction_log: List[Dict] = []

    def harmonic_coupling(self, A: ResonanceField, B: ResonanceField) -> float:
        """
        Harmonic interaction strength between two fields.

        H = mA · mB · kA · kB · cos(φA - φB)

        Properties:
        - H > 0: constructive coupling (fields amplify each other)
        - H < 0: destructive coupling (fields dampen each other)
        - H = 0: orthogonal coupling (no direct interaction)
        - |H| is maximized when phases align and both fields are coherent
        """
        phase_diff = A.phase - B.phase
        H = (A.m * B.m) * (A.k * B.k) * np.cos(phase_diff)
        return H

    def energy_redistribution(self, A: ResonanceField, B: ResonanceField, 
                              coupling: float) -> float:
        """
        Energy flow between fields based on coupling strength.

        ΔmA = +α · H    (energy flows toward positive coupling)
        ΔmB = -α · H    (energy flows away from negative coupling)

        Conservation: total energy may change due to external coupling.
        """
        transfer = self.coupling_strength * coupling * self.dt
        A.m = np.clip(A.m + transfer, 0.1, 5.0)
        B.m = np.clip(B.m - transfer, 0.1, 5.0)
        return transfer

    def phase_dynamics(self, A: ResonanceField, B: ResonanceField):
        """
        Mutual phase correction: fields attract each other's phases.

        dφA/dt = λ · sin(φB - φA)
        dφB/dt = λ · sin(φA - φB)

        This creates a coupled oscillator system:
        - In-phase lock (φA ≈ φB): stable fixed point
        - Anti-phase lock (φA ≈ φB + π): unstable fixed point  
        - Phase drift: when coupling is weak or frequencies differ
        """
        A.apply_phase_correction(B.phase, strength=self.phase_coupling, dt=self.dt)
        B.apply_phase_correction(A.phase, strength=self.phase_coupling, dt=self.dt)

    def coherence_dynamics(self, A: ResonanceField, B: ResonanceField, 
                          coupling: float):
        """
        Coherence evolution with mutual influence.

        dkA/dt = α_internal + α_external · H
        dkB/dt = α_internal + α_external · H

        Positive coupling (H > 0) increases both coherences.
        Negative coupling (H < 0) decreases both coherences (stress).
        """
        external = self.coherence_coupling * coupling
        A.update_coherence(internal=0.01, external=external, dt=self.dt)
        B.update_coherence(internal=0.01, external=external, dt=self.dt)

    def step(self, A: ResonanceField, B: ResonanceField) -> CouplingResult:
        """
        Execute one complete timestep of resonance mechanics.

        Protocol:
        1. Update bivectors from current field parameters
        2. Calculate harmonic coupling H
        3. Compute geometric algebra products
        4. Redistribute energy based on coupling
        5. Apply phase corrections
        6. Update coherences
        7. Detect collapse risks
        8. Log interaction

        Returns:
            CouplingResult with all interaction metrics
        """
        # 1. Update geometric representations
        A.update_bivector()
        B.update_bivector()

        # 2. Harmonic coupling
        H = self.harmonic_coupling(A, B)

        # 3. Geometric algebra analysis
        scalar, bivector, pseudoscalar = self.clifford.geometric_product(
            A.bivector, B.bivector
        )

        # 4. Energy redistribution
        transfer = self.energy_redistribution(A, B, H)

        # 5. Phase dynamics
        self.phase_dynamics(A, B)

        # 6. Coherence dynamics
        k_before_a = A.k
        k_before_b = B.k
        self.coherence_dynamics(A, B, H)

        # 7. Collapse detection
        collapse_a = A.is_collapsing(self.collapse_threshold)
        collapse_b = B.is_collapsing(self.collapse_threshold)

        # 8. Log interaction
        result = CouplingResult(
            harmonic_coupling=H,
            phase_alignment=abs(A.phase - B.phase) % (2 * np.pi),
            energy_transfer=transfer,
            resonance_scalar=abs(scalar),
            bivector_product=bivector,
            pseudoscalar=pseudoscalar,
            collapse_risk_a=collapse_a,
            collapse_risk_b=collapse_b,
            coherence_delta_a=A.k - k_before_a,
            coherence_delta_b=B.k - k_before_b
        )

        self._log_interaction(A, B, result)
        return result

    def _log_interaction(self, A: ResonanceField, B: ResonanceField, 
                         result: CouplingResult):
        """Record interaction to log"""
        self._interaction_log.append({
            'body_a': A.body_type.value,
            'body_b': B.body_type.value,
            'harmonic_coupling': result.harmonic_coupling,
            'energy_transfer': result.energy_transfer,
            'collapse_risk_a': result.collapse_risk_a,
            'collapse_risk_b': result.collapse_risk_b,
            'timestamp': len(self._interaction_log)
        })

    def get_interaction_log(self) -> List[Dict]:
        """Retrieve full interaction history"""
        return list(self._interaction_log)

    def simulate(self, A: ResonanceField, B: ResonanceField, 
                 steps: int = 100) -> List[CouplingResult]:
        """
        Run full simulation for N steps.

        Useful for analyzing long-term dynamics:
        - Phase locking transitions
        - Energy equilibration
        - Collapse cascades
        - Synchronization phenomena
        """
        results = []
        for _ in range(steps):
            result = self.step(A, B)
            results.append(result)
        return results

    def find_equilibrium(self, A: ResonanceField, B: ResonanceField,
                       tolerance: float = 1e-6, max_steps: int = 10000) -> bool:
        """
        Find equilibrium state where dE/dt ≈ 0 and dφ/dt ≈ 0.

        Returns True if equilibrium found, False if max_steps exceeded.
        Equilibrium conditions:
        - |H| < tolerance (weak coupling)
        - |Δφ| < tolerance or |Δφ - π| < tolerance (phase locked)
        - |Δk| < tolerance per step (coherence stable)
        """
        for step in range(max_steps):
            result = self.step(A, B)

            if (abs(result.harmonic_coupling) < tolerance and
                (abs(result.phase_alignment) < tolerance or
                 abs(result.phase_alignment - np.pi) < tolerance) and
                abs(result.coherence_delta_a) < tolerance and
                abs(result.coherence_delta_b) < tolerance):
                return True

        return False
