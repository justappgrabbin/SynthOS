"""
harmonics.py — Harmonic Analysis & Resonance Map Generation

Implements:
- 9×9 resonance matrix computation
- Dominant frequency extraction via FFT
- Wave interference pattern analysis
- Resonance map generation for visualization
- Harmonic series and overtone detection
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from .field import ResonanceField, BodyType, WaveLayer
from .engine import ResonanceEngine, CliffordEngine


@dataclass
class ResonanceMap:
    """Complete resonance map for a user's consciousness field"""
    user_id: str
    matrix: np.ndarray                    # 9×9 resonance matrix
    frequencies: Dict[BodyType, float]    # Dominant frequency per body
    amplitudes: Dict[BodyType, Dict[WaveLayer, float]]  # Wave amplitudes
    coherence_spectrum: np.ndarray        # FFT of coherence over time
    phase_locking: np.ndarray           # Phase synchronization matrix
    energy_distribution: np.ndarray     # Energy share per body
    total_energy: float
    network_coherence: float              # Global coherence metric

    def to_dict(self) -> Dict:
        """Serialize for JSON transmission"""
        return {
            'user_id': self.user_id,
            'matrix': self.matrix.tolist(),
            'frequencies': {bt.value: float(f) for bt, f in self.frequencies.items()},
            'amplitudes': {
                bt.value: {wl.value: float(a) for wl, a in amps.items()}
                for bt, amps in self.amplitudes.items()
            },
            'coherence_spectrum': self.coherence_spectrum.tolist(),
            'phase_locking': self.phase_locking.tolist(),
            'energy_distribution': self.energy_distribution.tolist(),
            'total_energy': float(self.total_energy),
            'network_coherence': float(self.network_coherence)
        }


class HarmonicAnalyzer:
    """
    Analyze harmonic relationships and generate resonance maps.

    Provides:
    - Pairwise resonance computation
    - Spectral analysis (FFT) of field dynamics
    - Phase synchronization detection
    - Energy distribution analysis
    - Network-wide coherence metrics
    """

    def __init__(self, sample_rate: float = 1.0, fft_samples: int = 256):
        """
        Args:
            sample_rate: samples per unit time
            fft_samples: number of samples for FFT analysis
        """
        self.sample_rate = sample_rate
        self.fft_samples = fft_samples
        self.engine = ResonanceEngine()
        self.clifford = CliffordEngine()

    def compute_resonance_matrix(self, fields: Dict[BodyType, ResonanceField],
                                 dt: float = 0.1) -> np.ndarray:
        """
        Compute 9×9 resonance matrix between all body pairs.

        R[i,j] = |⟨Fᵢ, Fⱼ⟩| = geometric inner product magnitude

        Diagonal R[i,i] = kᵢ (self-coherence)
        Off-diagonal R[i,j] = cross-resonance (i ≠ j)
        """
        bodies = list(BodyType)
        n = len(bodies)
        matrix = np.zeros((n, n))

        for i, body_a in enumerate(bodies):
            for j, body_b in enumerate(bodies):
                if i == j:
                    # Self-resonance = coherence
                    matrix[i, j] = fields[body_a].k
                else:
                    # Cross-resonance via geometric product
                    field_a = fields[body_a]
                    field_b = fields[body_b]

                    # Ensure bivectors are current
                    field_a.update_bivector()
                    field_b.update_bivector()

                    resonance = self.clifford.field_resonance(field_a, field_b)
                    matrix[i, j] = resonance

        return matrix

    def dominant_frequencies(self, fields: Dict[BodyType, ResonanceField],
                            t_duration: float = 4 * np.pi) -> Dict[BodyType, float]:
        """
        Extract dominant frequency for each body via FFT.

        Samples wave function over time, computes FFT,
        returns frequency with maximum power.

        Returns:
            Dict mapping BodyType to dominant frequency (Hz)
        """
        frequencies = {}
        t_samples = np.linspace(0, t_duration, self.fft_samples)

        for body_type, field in fields.items():
            # Sample wave over time (Action layer as representative)
            samples = [field.wave_amplitude(WaveLayer.ACTION, t) 
                      for t in t_samples]

            # FFT
            fft = np.fft.rfft(samples)
            power = np.abs(fft) ** 2
            freq_bins = np.fft.rfftfreq(len(samples), d=t_duration / len(samples))

            # Find dominant frequency (exclude DC component)
            if len(power) > 1:
                dominant_idx = np.argmax(power[1:]) + 1
                frequencies[body_type] = freq_bins[dominant_idx]
            else:
                frequencies[body_type] = 0.0

        return frequencies

    def phase_synchronization(self, fields: Dict[BodyType, ResonanceField]) -> np.ndarray:
        """
        Compute phase synchronization matrix.

        S[i,j] = |cos(φᵢ - φⱼ)| — phase locking value

        S = 1: perfect phase locking
        S = 0: no phase synchronization
        """
        bodies = list(BodyType)
        n = len(bodies)
        sync = np.zeros((n, n))

        for i, body_a in enumerate(bodies):
            for j, body_b in enumerate(bodies):
                phase_diff = fields[body_a].phase - fields[body_b].phase
                sync[i, j] = abs(np.cos(phase_diff))

        return sync

    def energy_distribution(self, fields: Dict[BodyType, ResonanceField]) -> np.ndarray:
        """
        Compute energy share for each body.

        Returns normalized array where sum = 1.0
        """
        energies = np.array([fields[bt].energy() for bt in BodyType])
        total = np.sum(energies)
        if total > 0:
            return energies / total
        return np.ones(len(BodyType)) / len(BodyType)

    def network_coherence(self, fields: Dict[BodyType, ResonanceField]) -> float:
        """
        Global network coherence metric.

        C_global = (1/N²) Σᵢⱼ R[i,j] · S[i,j]

        Where R is resonance matrix and S is phase synchronization.
        Combines amplitude and phase coherence into single metric.
        """
        R = self.compute_resonance_matrix(fields)
        S = self.phase_synchronization(fields)

        n = len(BodyType)
        return np.sum(R * S) / (n * n)

    def coherence_spectrum(self, fields: Dict[BodyType, ResonanceField],
                          t_duration: float = 10 * np.pi) -> Dict[BodyType, np.ndarray]:
        """
        Compute frequency spectrum of coherence time series.

        Useful for detecting rhythmic coherence patterns,
        circadian cycles, or stress-induced oscillations.
        """
        spectra = {}
        t_samples = np.linspace(0, t_duration, self.fft_samples)

        for body_type, field in fields.items():
            # Simulate coherence evolution over time
            coherence_series = []
            original_k = field.k

            for t in t_samples:
                # Apply small perturbation and measure response
                field.apply_phase_perturbation(magnitude=0.01)
                coherence_series.append(field.k)

            # Restore original state
            field.k = original_k
            field.update_bivector()

            # FFT of coherence series
            fft = np.fft.rfft(coherence_series)
            power = np.abs(fft) ** 2

            spectra[body_type] = power

        return spectra

    def generate_resonance_map(self, user_id: str, 
                              fields: Dict[BodyType, ResonanceField]) -> ResonanceMap:
        """
        Generate complete resonance map for a user.

        This is the primary analysis function that combines all
        harmonic analysis methods into a single comprehensive map.
        """
        matrix = self.compute_resonance_matrix(fields)
        frequencies = self.dominant_frequencies(fields)

        amplitudes = {}
        for bt in BodyType:
            amplitudes[bt] = {
                WaveLayer.ACTION: fields[bt].action_amp,
                WaveLayer.THOUGHT: fields[bt].thought_amp,
                WaveLayer.FEELING: fields[bt].feeling_amp
            }

        # Coherence spectrum (average across bodies)
        spectra = self.coherence_spectrum(fields)
        avg_spectrum = np.mean([s for s in spectra.values()], axis=0)

        phase_locking = self.phase_synchronization(fields)
        energy_dist = self.energy_distribution(fields)
        total_energy = sum(fields[bt].energy() for bt in BodyType)
        network_coh = self.network_coherence(fields)

        return ResonanceMap(
            user_id=user_id,
            matrix=matrix,
            frequencies=frequencies,
            amplitudes=amplitudes,
            coherence_spectrum=avg_spectrum,
            phase_locking=phase_locking,
            energy_distribution=energy_dist,
            total_energy=total_energy,
            network_coherence=network_coh
        )

    def detect_overtones(self, fields: Dict[BodyType, ResonanceField],
                        fundamental: Optional[float] = None) -> List[Dict]:
        """
        Detect harmonic overtones in the resonance field.

        Returns list of detected overtones with:
        - frequency: overtone frequency
        - ratio: frequency / fundamental
        - amplitude: relative power
        - source_bodies: which bodies contribute
        """
        frequencies = self.dominant_frequencies(fields)

        if fundamental is None:
            # Use lowest non-zero frequency as fundamental
            freqs = [f for f in frequencies.values() if f > 0.01]
            if not freqs:
                return []
            fundamental = min(freqs)

        overtones = []
        for body_type, freq in frequencies.items():
            if freq < 0.01:
                continue

            ratio = freq / fundamental
            # Check if close to integer ratio (within 5%)
            nearest_int = round(ratio)
            if nearest_int > 0 and abs(ratio - nearest_int) < 0.05:
                overtones.append({
                    'frequency': float(freq),
                    'fundamental': float(fundamental),
                    'ratio': float(ratio),
                    'harmonic_number': nearest_int,
                    'body': body_type.value,
                    'detuning': float(abs(ratio - nearest_int))
                })

        return sorted(overtones, key=lambda x: x['harmonic_number'])

    def interference_pattern(self, fields: Dict[BodyType, ResonanceField],
                            body_a: BodyType, body_b: BodyType,
                            t_range: Tuple[float, float] = (0, 4*np.pi),
                            resolution: int = 400) -> np.ndarray:
        """
        Compute wave interference pattern between two bodies.

        Returns array of combined wave amplitudes over time.
        Useful for visualizing constructive/destructive interference.
        """
        t = np.linspace(t_range[0], t_range[1], resolution)

        # Compute interference for each layer
        patterns = {}
        for layer in WaveLayer:
            wave_a = np.array([fields[body_a].wave_amplitude(layer, ti) for ti in t])
            wave_b = np.array([fields[body_b].wave_amplitude(layer, ti) for ti in t])
            patterns[layer.value] = (wave_a + wave_b) / 2

        return patterns
