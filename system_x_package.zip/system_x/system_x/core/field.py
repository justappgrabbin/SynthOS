"""
field.py — Core Resonance Field Definition

Implements the fundamental consciousness field with:
- E = m · c · k^β energy calculation
- Wave mechanics across Action/Thought/Feeling layers
- Bivector representation in Clifford algebra Cl(1,3)
- Phase dynamics and coherence evolution
- Collapse detection thresholds
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from enum import Enum


class BodyType(Enum):
    """Nine-body consciousness architecture"""
    MIND = "mind"           # Sidereal — analytical cognition
    HEART = "heart"         # Tropical — emotional resonance  
    BODY = "body"           # Draconic — instinctual awareness
    SOUL = "soul"           # Sidereal Shadow — deep memory
    SPIRIT = "spirit"       # Tropical Higher — aspirational self
    SHADOW = "shadow"       # Draconic Unconscious — repressed patterns
    LIGHT = "light"         # Integration Field — unified awareness
    VOID = "void"           # Quantum Potential — unmanifest possibility
    UNITY = "unity"         # Coherence Field — transcendental synthesis


class WaveLayer(Enum):
    """Three-layer wave mechanics"""
    ACTION = "action"       # Physical manifestation (λ = 2π/3 phase)
    THOUGHT = "thought"     # Mental patterning (λ = 4π/3 phase)  
    FEELING = "feeling"     # Emotional resonance (λ = 2π phase)


@dataclass
class ResonanceField:
    """
    Single consciousness body field state.

    Mathematical model:
        E = m · c · k^β

    Where:
        m: pattern density [0.1, 5.0] — information content/structural complexity
        c: cognitive velocity [0.1, 3.0] — processing speed/conceptual flow
        k: coherence coefficient [0.0, 5.0] — field stability/phase alignment
        β: resonance exponent [0.5, 2.0] — non-linear coupling strength
        φ: phase angle [0, 2π] — temporal alignment/cycle position

    Wave mechanics:
        ψ_layer(t) = A_layer · sin(ωt + φ + φ_layer)

    Bivector representation (Clifford algebra Cl(1,3)):
        F = m·cos(φ)·e01 + m·sin(φ)·e02 + c·cos(φ+π/4)·e03 
            + c·sin(φ+π/4)·e12 + k·cos(β)·e23 + k·sin(β)·e31
    """

    body_type: BodyType
    m: float = 1.0          # pattern density [0.1, 5.0]
    c: float = 1.0          # cognitive velocity [0.1, 3.0]  
    k: float = 1.0          # coherence [0.001, 5.0]
    beta: float = 1.0       # resonance exponent [0.5, 2.0]
    phase: float = 0.0      # phase angle [0, 2π]

    # Wave layer amplitudes (coupled to field energy)
    action_amp: float = 1.0
    thought_amp: float = 1.0
    feeling_amp: float = 1.0

    # Bivector: 6 components of Cl(1,3) grade-2 element
    # e01, e02, e03 (spatial), e12, e23, e31 (spacetime planes)
    bivector: np.ndarray = field(default_factory=lambda: np.zeros(6))

    # Metadata
    chart_data: Dict = field(default_factory=dict)
    gate_activations: List[int] = field(default_factory=list)

    # History for trajectory analysis
    _history: List[Dict] = field(default_factory=list, repr=False)
    _max_history: int = 1000

    def __post_init__(self):
        """Initialize bivector from field parameters"""
        self._clamp_parameters()
        self.update_bivector()

    def _clamp_parameters(self):
        """Ensure parameters remain in valid ranges"""
        self.m = np.clip(self.m, 0.1, 5.0)
        self.c = np.clip(self.c, 0.1, 3.0)
        self.k = np.clip(self.k, 0.001, 5.0)
        self.beta = np.clip(self.beta, 0.5, 2.0)
        self.phase = self.phase % (2 * np.pi)

    def energy(self) -> float:
        """
        Total resonance energy: E = m · c · k^β

        Physical interpretation:
        - High m (pattern density): rich information structure
        - High c (velocity): rapid cognitive processing
        - High k (coherence): stable, aligned field
        - High β: strong non-linear coupling amplifies coherence effects
        """
        return self.m * self.c * (self.k ** self.beta)

    def wave_amplitude(self, layer: WaveLayer, t: float, 
                       omega: float = 1.0) -> float:
        """
        Wave function ψ(t) for specific layer at time t.

        ψ_layer(t) = A_layer · sin(ωt + φ + φ_layer)

        Layer phase offsets:
            ACTION: 0          (physical manifestation)
            THOUGHT: 2π/3      (mental patterning)  
            FEELING: 4π/3      (emotional resonance)
        """
        layer_phases = {
            WaveLayer.ACTION: 0.0,
            WaveLayer.THOUGHT: 2 * np.pi / 3,
            WaveLayer.FEELING: 4 * np.pi / 3
        }

        layer_amps = {
            WaveLayer.ACTION: self.action_amp,
            WaveLayer.THOUGHT: self.thought_amp,
            WaveLayer.FEELING: self.feeling_amp
        }

        return layer_amps[layer] * np.sin(omega * t + self.phase + layer_phases[layer])

    def wave_energy(self, layer: WaveLayer) -> float:
        """Time-averaged wave energy: ⟨ψ²⟩ = A²/2"""
        layer_amps = {
            WaveLayer.ACTION: self.action_amp,
            WaveLayer.THOUGHT: self.thought_amp,
            WaveLayer.FEELING: self.feeling_amp
        }
        return 0.5 * layer_amps[layer] ** 2

    def total_wave_energy(self) -> float:
        """Sum of wave energies across all layers"""
        return sum(self.wave_energy(layer) for layer in WaveLayer)

    def update_coherence(self, internal: float = 0.01, 
                         external: float = 0.0,
                         dt: float = 1.0):
        """
        Coherence dynamics with self-regulation and external influence.

        dk/dt = α_internal + α_external · H

        Where H is harmonic coupling strength from external fields.
        Negative external influence can induce decoherence.
        """
        delta_k = (internal + external) * dt
        self.k = np.clip(self.k + delta_k, 0.001, 5.0)
        self._record_state()

    def apply_phase_correction(self, target_phase: float, 
                               strength: float = 0.1,
                               dt: float = 1.0):
        """
        Phase alignment toward target via sinusoidal coupling.

        dφ/dt = λ · sin(φ_target - φ)

        This creates stable attractor dynamics:
        - When |φ_target - φ| < π: convergent (phase locking)
        - When |φ_target - φ| > π: divergent (phase repulsion)
        """
        delta = np.sin(target_phase - self.phase)
        self.phase += strength * delta * dt
        self.phase = self.phase % (2 * np.pi)
        self._record_state()

    def apply_phase_perturbation(self, magnitude: float = 0.1):
        """Apply random phase perturbation (noise/stress)"""
        self.phase += np.random.normal(0, magnitude)
        self.phase = self.phase % (2 * np.pi)
        self._record_state()

    def is_collapsing(self, threshold: float = 0.3) -> bool:
        """
        Detect field collapse: coherence below critical threshold.

        Collapse occurs when k < k_critical, where:
        - k_critical ≈ 0.3 for typical consciousness fields
        - Below threshold: field loses stability, phase decoheres
        - Energy E → 0 as k → 0 (since β > 0)
        """
        return self.k < threshold

    def collapse_severity(self, threshold: float = 0.3) -> float:
        """Normalized collapse severity: 0 = stable, 1 = fully collapsed"""
        if self.k >= threshold:
            return 0.0
        return 1.0 - (self.k / threshold)

    def update_bivector(self):
        """
        Update Clifford algebra bivector representation.

        Maps field parameters to grade-2 element of Cl(1,3):

        F = f₁·e01 + f₂·e02 + f₃·e03 + f₄·e12 + f₅·e23 + f₆·e31

        Where:
            f₁ = m·cos(φ)      (pattern density × phase)
            f₂ = m·sin(φ)      (pattern density × quadrature)
            f₃ = c·cos(φ+π/4)  (velocity × shifted phase)
            f₄ = c·sin(φ+π/4)  (velocity × shifted quadrature)
            f₅ = k·cos(β)      (coherence × exponent)
            f₆ = k·sin(β)      (coherence × exponent quadrature)
        """
        self.bivector[0] = self.m * np.cos(self.phase)          # e01
        self.bivector[1] = self.m * np.sin(self.phase)          # e02
        self.bivector[2] = self.c * np.cos(self.phase + np.pi/4)  # e03
        self.bivector[3] = self.c * np.sin(self.phase + np.pi/4)  # e12
        self.bivector[4] = self.k * np.cos(self.beta)           # e23
        self.bivector[5] = self.k * np.sin(self.beta)           # e31

    def bivector_magnitude(self) -> float:
        """|F| = √(Σ fᵢ²) — total field strength"""
        return np.linalg.norm(self.bivector)

    def bivector_direction(self) -> np.ndarray:
        """Normalized bivector direction (unit grade-2 element)"""
        mag = self.bivector_magnitude()
        if mag < 1e-10:
            return np.zeros(6)
        return self.bivector / mag

    def _record_state(self):
        """Record current state to history buffer"""
        state = {
            'm': self.m, 'c': self.c, 'k': self.k,
            'beta': self.beta, 'phase': self.phase,
            'energy': self.energy(), 'timestamp': len(self._history)
        }
        self._history.append(state)
        if len(self._history) > self._max_history:
            self._history.pop(0)

    def get_history(self, n: Optional[int] = None) -> List[Dict]:
        """Retrieve last n states from history"""
        if n is None:
            return list(self._history)
        return list(self._history)[-n:]

    def to_dict(self) -> Dict:
        """Serialize field to dictionary"""
        return {
            'body_type': self.body_type.value,
            'm': float(self.m),
            'c': float(self.c),
            'k': float(self.k),
            'beta': float(self.beta),
            'phase': float(self.phase),
            'action_amp': float(self.action_amp),
            'thought_amp': float(self.thought_amp),
            'feeling_amp': float(self.feeling_amp),
            'bivector': self.bivector.tolist(),
            'chart_data': self.chart_data,
            'gate_activations': self.gate_activations
        }

    @classmethod
    def from_dict(cls, data: Dict) -> 'ResonanceField':
        """Deserialize field from dictionary"""
        field = cls(
            body_type=BodyType(data['body_type']),
            m=data['m'],
            c=data['c'],
            k=data['k'],
            beta=data['beta'],
            phase=data['phase'],
            action_amp=data.get('action_amp', 1.0),
            thought_amp=data.get('thought_amp', 1.0),
            feeling_amp=data.get('feeling_amp', 1.0)
        )
        field.bivector = np.array(data.get('bivector', np.zeros(6)))
        field.chart_data = data.get('chart_data', {})
        field.gate_activations = data.get('gate_activations', [])
        return field

    def __repr__(self) -> str:
        return (f"ResonanceField({self.body_type.value}, "
                f"E={self.energy():.3f}, m={self.m:.2f}, c={self.c:.2f}, "
                f"k={self.k:.3f}, β={self.beta:.2f}, φ={self.phase:.3f})")
