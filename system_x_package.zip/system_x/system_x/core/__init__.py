"""Core resonance mechanics: fields, engines, geometric algebra."""
from .field import ResonanceField, BodyType, WaveLayer
from .engine import ResonanceEngine, CouplingResult, CliffordEngine
from .collapse import CollapseDetector
from .harmonics import HarmonicAnalyzer
