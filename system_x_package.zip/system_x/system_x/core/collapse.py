"""
collapse.py — Field Collapse Detection & Stabilization

Implements:
- Real-time collapse risk scanning across all 9 bodies
- Predictive collapse forecasting via trajectory analysis
- Emergency stabilization protocols (PID control)
- Collapse cascade prevention in multi-body systems
- Intervention logging and post-collapse analysis
"""

import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from .field import ResonanceField, BodyType


@dataclass
class CollapseRisk:
    """Detailed collapse risk assessment for a single body"""
    body_type: BodyType
    risk_level: str           # 'stable', 'low', 'moderate', 'high', 'critical', 'collapsed'
    probability: float          # 0.0-1.0
    time_to_collapse: Optional[float]  # steps until collapse (None if stable)
    confidence: float           # prediction confidence
    current_coherence: float
    trend: float              # dk/dt trend
    predicted_trajectory: List[float]
    recommended_action: str


@dataclass  
class StabilizationReport:
    """Report of stabilization intervention"""
    body_type: BodyType
    interventions_applied: List[str]
    coherence_before: float
    coherence_after: float
    phase_adjustment: float
    energy_cost: float
    success: bool


class CollapsePredictor:
    """
    Predictive collapse analysis using trajectory forecasting.

    Models coherence decay as: k(t) = k₀ + v·t + a·t²/2
    Where v = trend (velocity), a = acceleration (curvature).

    Collapse time: solve k(t_collapse) = k_threshold for t_collapse.
    """

    def __init__(self, threshold: float = 0.3, horizon: int = 50):
        self.threshold = threshold
        self.horizon = horizon

    def analyze_trajectory(self, coherence_history: List[float]) -> Dict:
        """
        Fit quadratic model to coherence history and predict collapse.

        Returns dict with:
            - risk_level: qualitative assessment
            - probability: 0-1 likelihood
            - time_to_collapse: predicted steps (None if stable)
            - confidence: prediction reliability
            - trend: current velocity (dk/dt)
            - curvature: acceleration (d²k/dt²)
        """
        if len(coherence_history) < 5:
            return {
                'risk_level': 'unknown',
                'probability': 0.0,
                'time_to_collapse': None,
                'confidence': 0.0,
                'trend': 0.0,
                'curvature': 0.0
            }

        n = len(coherence_history)
        x = np.arange(n)
        y = np.array(coherence_history)

        # Fit quadratic: k(t) = a·t² + b·t + c
        coeffs = np.polyfit(x, y, deg=2)
        a, b, c = coeffs

        # Current state
        current_k = y[-1]
        trend = 2 * a * (n-1) + b  # dk/dt at t=n-1
        curvature = 2 * a            # d²k/dt²

        # Predict collapse time: solve a·t² + b·t + c = threshold
        if a > 0 and current_k > self.threshold:
            # Concave up, above threshold — stable
            risk_level = 'stable'
            probability = 0.0
            time_to_collapse = None
        elif a > 0 and current_k <= self.threshold:
            # Already collapsed but recovering
            risk_level = 'recovering'
            probability = 0.3
            time_to_collapse = None
        elif a < 0 and current_k > self.threshold:
            # Concave down, above threshold — decaying
            # Find roots: a·t² + b·t + (c - threshold) = 0
            discriminant = b**2 - 4*a*(c - self.threshold)
            if discriminant >= 0:
                roots = [(-b + np.sqrt(discriminant)) / (2*a),
                        (-b - np.sqrt(discriminant)) / (2*a)]
                # Find positive root after current time
                future_roots = [r for r in roots if r > n-1]
                if future_roots:
                    time_to_collapse = min(future_roots) - (n-1)
                    if time_to_collapse < 5:
                        risk_level = 'critical'
                        probability = 1.0
                    elif time_to_collapse < 20:
                        risk_level = 'high'
                        probability = 0.8
                    else:
                        risk_level = 'moderate'
                        probability = 0.5
                else:
                    risk_level = 'low'
                    probability = 0.2
                    time_to_collapse = None
            else:
                # No real roots — won't cross threshold
                risk_level = 'stable'
                probability = 0.0
                time_to_collapse = None
        else:
            # a ≈ 0, linear or constant
            if abs(trend) < 1e-6:
                if current_k > self.threshold * 1.5:
                    risk_level = 'stable'
                    probability = 0.0
                else:
                    risk_level = 'low'
                    probability = 0.1
                time_to_collapse = None
            elif trend < 0:
                # Linear decay
                time_to_collapse = (self.threshold - current_k) / trend
                if time_to_collapse < 0:
                    risk_level = 'stable'
                    probability = 0.0
                    time_to_collapse = None
                elif time_to_collapse < 5:
                    risk_level = 'critical'
                    probability = 1.0
                elif time_to_collapse < 20:
                    risk_level = 'high'
                    probability = 0.8
                else:
                    risk_level = 'moderate'
                    probability = 0.5
            else:
                # Improving
                risk_level = 'stable'
                probability = 0.0
                time_to_collapse = None

        # Confidence based on fit quality and data length
        predicted = np.polyval(coeffs, x)
        residuals = y - predicted
        mse = np.mean(residuals**2)
        r_squared = 1 - mse / np.var(y) if np.var(y) > 0 else 0
        confidence = min(1.0, (n / 50) * r_squared)

        # Generate predicted trajectory
        future_t = np.arange(n, n + self.horizon)
        predicted_trajectory = np.polyval(coeffs, future_t).tolist()

        return {
            'risk_level': risk_level,
            'probability': float(probability),
            'time_to_collapse': float(time_to_collapse) if time_to_collapse is not None else None,
            'confidence': float(confidence),
            'trend': float(trend),
            'curvature': float(curvature),
            'predicted_trajectory': predicted_trajectory
        }


class CollapseDetector:
    """
    Real-time collapse detection and intervention system.

    Monitors all 9 consciousness bodies and applies
    stabilization when coherence falls below critical thresholds.
    """

    def __init__(self, 
                 threshold: float = 0.3,
                 intervention_strength: float = 0.5,
                 prediction_horizon: int = 50,
                 cascade_prevention: bool = True):
        """
        Args:
            threshold: k < threshold triggers collapse state
            intervention_strength: coherence boost per stabilization (0.5 = +0.5k)
            prediction_horizon: steps ahead for trajectory forecasting
            cascade_prevention: prevent collapse spreading to coupled bodies
        """
        self.threshold = threshold
        self.intervention_strength = intervention_strength
        self.predictor = CollapsePredictor(threshold, prediction_horizon)
        self.cascade_prevention = cascade_prevention

        # Logging
        self.collapse_log: List[Dict] = []
        self.intervention_log: List[StabilizationReport] = []

        # PID controllers for each body (persistent state)
        self._pid_state: Dict[BodyType, Dict] = {}

    def scan_user(self, fields: Dict[BodyType, ResonanceField]) -> Dict[BodyType, CollapseRisk]:
        """
        Full collapse risk assessment across all 9 bodies.

        Returns detailed risk profile for each body with:
        - Current collapse state
        - Predicted time to collapse
        - Recommended interventions
        """
        risks = {}

        for body_type, field in fields.items():
            # Get coherence history
            history = [s['k'] for s in field.get_history(n=100)]
            if len(history) < 5:
                history = [field.k] * 5  # Pad with current value

            # Analyze trajectory
            analysis = self.predictor.analyze_trajectory(history)

            # Check current collapse state (override predictor if already collapsed)
            currently_collapsing = field.is_collapsing(self.threshold)
            if currently_collapsing and analysis['risk_level'] in ['stable', 'recovering', 'low']:
                analysis['risk_level'] = 'critical'
                analysis['probability'] = 1.0
                analysis['time_to_collapse'] = 0.0

            # Determine recommended action
            if analysis['risk_level'] == 'critical':
                action = "EMERGENCY: Immediate stabilization required. Isolate from external coupling."
            elif analysis['risk_level'] == 'high':
                action = "URGENT: Apply stabilization protocol. Reduce external resonance load."
            elif analysis['risk_level'] == 'moderate':
                action = "WARNING: Monitor closely. Prepare stabilization resources."
            elif analysis['risk_level'] == 'low':
                action = "CAUTION: Minor risk. Maintain current field strength."
            else:
                action = "STABLE: No intervention needed."

            risks[body_type] = CollapseRisk(
                body_type=body_type,
                risk_level=analysis['risk_level'],
                probability=analysis['probability'],
                time_to_collapse=analysis['time_to_collapse'],
                confidence=analysis['confidence'],
                current_coherence=field.k,
                trend=analysis['trend'],
                predicted_trajectory=analysis['predicted_trajectory'],
                recommended_action=action
            )

        return risks

    def stabilize_field(self, field: ResonanceField, 
                       method: str = 'direct') -> StabilizationReport:
        """
        Apply emergency stabilization to collapsing field.

        Methods:
            'direct': Immediate coherence boost
            'gentle': Gradual coherence increase (preserves phase)
            'reset': Full phase reset with coherence boost
            'energy_dissipation': Reduce pattern density to lower energy demand
        """
        coherence_before = field.k
        phase_before = field.phase
        energy_before = field.energy()
        interventions = []

        if method == 'direct':
            # Immediate coherence boost
            field.k += self.intervention_strength
            field.k = np.clip(field.k, 0.3, 5.0)
            interventions.append('direct_coherence_boost')

        elif method == 'gentle':
            # Gradual increase (50% of direct strength)
            field.k += self.intervention_strength * 0.5
            field.k = np.clip(field.k, 0.3, 5.0)
            interventions.append('gentle_coherence_increase')

        elif method == 'reset':
            # Full phase reset with coherence boost
            field.phase = (field.phase + np.pi) % (2 * np.pi)
            field.k += self.intervention_strength
            field.k = np.clip(field.k, 0.3, 5.0)
            interventions.append('phase_reset')
            interventions.append('coherence_boost')

        elif method == 'energy_dissipation':
            # Reduce pattern density to lower energy demand
            field.m *= 0.8
            field.m = np.clip(field.m, 0.1, 5.0)
            field.k += self.intervention_strength * 0.3
            field.k = np.clip(field.k, 0.3, 5.0)
            interventions.append('energy_dissipation')
            interventions.append('partial_coherence_boost')

        # Update bivector after changes
        field.update_bivector()

        energy_cost = energy_before - field.energy()
        success = field.k > self.threshold

        report = StabilizationReport(
            body_type=field.body_type,
            interventions_applied=interventions,
            coherence_before=coherence_before,
            coherence_after=field.k,
            phase_adjustment=abs(field.phase - phase_before),
            energy_cost=energy_cost,
            success=success
        )

        self.intervention_log.append(report)
        return report

    def stabilize_user(self, fields: Dict[BodyType, ResonanceField],
                      method: str = 'adaptive') -> List[StabilizationReport]:
        """
        Apply stabilization to all at-risk bodies.

        Adaptive method selects intervention based on risk level:
        - critical: direct + energy dissipation
        - high: direct
        - moderate: gentle
        - low/stable: none
        """
        risks = self.scan_user(fields)
        reports = []

        for body_type, risk in risks.items():
            if risk.risk_level in ['critical', 'collapsed']:
                if method == 'adaptive':
                    report = self.stabilize_field(fields[body_type], 'direct')
                    if not report.success:
                        report = self.stabilize_field(fields[body_type], 'energy_dissipation')
                else:
                    report = self.stabilize_field(fields[body_type], method)
                reports.append(report)

            elif risk.risk_level == 'high':
                if method == 'adaptive':
                    report = self.stabilize_field(fields[body_type], 'direct')
                else:
                    report = self.stabilize_field(fields[body_type], method)
                reports.append(report)

            elif risk.risk_level == 'moderate':
                if method == 'adaptive':
                    report = self.stabilize_field(fields[body_type], 'gentle')
                else:
                    report = self.stabilize_field(fields[body_type], method)
                reports.append(report)

        # Cascade prevention: if any body collapsed, check neighbors
        if self.cascade_prevention:
            collapsed_bodies = [bt for bt, r in risks.items() 
                              if r.risk_level in ['critical', 'collapsed']]
            if collapsed_bodies:
                reports.extend(self._prevent_cascade(fields, collapsed_bodies))

        return reports

    def _prevent_cascade(self, fields: Dict[BodyType, ResonanceField],
                        collapsed: List[BodyType]) -> List[StabilizationReport]:
        """
        Prevent collapse from spreading to coupled bodies.

        Strategy: temporarily boost coherence of bodies that
        have strong harmonic coupling with collapsed bodies.
        """
        reports = []
        # Adjacency in 9-body system (simplified coupling topology)
        adjacency = {
            BodyType.MIND: [BodyType.HEART, BodyType.SOUL, BodyType.SPIRIT],
            BodyType.HEART: [BodyType.MIND, BodyType.BODY, BodyType.LIGHT],
            BodyType.BODY: [BodyType.HEART, BodyType.SHADOW, BodyType.VOID],
            BodyType.SOUL: [BodyType.MIND, BodyType.SHADOW, BodyType.UNITY],
            BodyType.SPIRIT: [BodyType.MIND, BodyType.LIGHT, BodyType.UNITY],
            BodyType.SHADOW: [BodyType.BODY, BodyType.SOUL, BodyType.VOID],
            BodyType.LIGHT: [BodyType.HEART, BodyType.SPIRIT, BodyType.UNITY],
            BodyType.VOID: [BodyType.BODY, BodyType.SHADOW, BodyType.UNITY],
            BodyType.UNITY: [BodyType.SOUL, BodyType.SPIRIT, BodyType.LIGHT, BodyType.VOID]
        }

        for collapsed_body in collapsed:
            neighbors = adjacency.get(collapsed_body, [])
            for neighbor in neighbors:
                if neighbor in fields:
                    # Gentle boost to prevent cascade
                    report = self.stabilize_field(fields[neighbor], 'gentle')
                    report.interventions_applied.append('cascade_prevention')
                    reports.append(report)

        return reports

    def get_collapse_statistics(self) -> Dict:
        """Aggregate statistics from all logged interventions"""
        if not self.intervention_log:
            return {'total_interventions': 0}

        total = len(self.intervention_log)
        successful = sum(1 for r in self.intervention_log if r.success)
        avg_coherence_gain = np.mean([r.coherence_after - r.coherence_before 
                                      for r in self.intervention_log])

        by_body = {}
        for report in self.intervention_log:
            bt = report.body_type.value
            if bt not in by_body:
                by_body[bt] = {'count': 0, 'success': 0}
            by_body[bt]['count'] += 1
            if report.success:
                by_body[bt]['success'] += 1

        return {
            'total_interventions': total,
            'successful_interventions': successful,
            'success_rate': successful / total,
            'average_coherence_gain': float(avg_coherence_gain),
            'interventions_by_body': by_body
        }
