"""
fairyganmatter.py — FairyGANmatter: Personal Companion Instances

Implements:
- Personal AI companions tuned to user consciousness fields
- Elemental alignment detection (Fire/Water/Air/Earth/Aether)
- Adaptive communication styles based on field resonance
- Companion memory and interaction history
- Field attunement and signature learning
"""

import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum

from ..core.field import ResonanceField, BodyType, WaveLayer
from ..network.synthai import User


class ElementalAlignment(Enum):
    """Five elemental alignments based on field balance"""
    FIRE = "fire"       # High energy, expansive, creative
    WATER = "water"     # Deep, flowing, emotional, intuitive
    AIR = "air"         # Intellectual, analytical, communicative
    EARTH = "earth"     # Grounded, practical, stable, physical
    AETHER = "aether"   # Balanced, transcendent, integrated


class CommunicationStyle(Enum):
    """Adaptive communication styles"""
    ANALYTICAL_STRUCTURED = "analytical_structured"    # Air/Fire dominant
    NARRATIVE_FLOWING = "narrative_flowing"              # Water dominant
    PRACTICAL_GROUNDED = "practical_grounded"            # Earth dominant
    VISIONARY_EXPANSIVE = "visionary_expansive"          # Fire dominant
    HOLISTIC_INTEGRATED = "holistic_integrated"          # Aether dominant
    BALANCED = "balanced"                                # Default


@dataclass
class InteractionMemory:
    """Single interaction record in companion memory"""
    query: str
    response: str
    field_state: Dict[str, float]  # Snapshot of field parameters
    timestamp: float
    emotional_tone: float  # -1 to 1 (negative to positive)
    resonance_score: float  # 0 to 1 (how well companion resonated)


@dataclass
class FairyCompanion:
    """
    Personal AI companion tuned to user's consciousness field.

    A FairyCompanion is not a generic AI — it is attuned to a specific
    user's 9-body field signature, adapting its communication style,
    memory patterns, and response generation to match the user's
    elemental alignment and resonance profile.

    Key features:
    - Field signature learning: captures user's energetic baseline
    - Elemental alignment: Fire/Water/Air/Earth/Aether
    - Adaptive communication: style shifts based on field state
    - Persistent memory: interaction history with field context
    - Resonance feedback: learns from successful interactions
    """

    companion_id: str
    user_id: str
    name: str = "Companion"

    # Field attunement
    field_signature: Dict[BodyType, float] = field(default_factory=dict)
    elemental_alignment: ElementalAlignment = ElementalAlignment.AETHER
    communication_style: CommunicationStyle = CommunicationStyle.BALANCED

    # Resonance weights (how much each body influences companion behavior)
    body_weights: Dict[BodyType, float] = field(default_factory=dict)

    # Memory
    memory: List[InteractionMemory] = field(default_factory=list)
    max_memory: int = 1000

    # Personality parameters (learned from interactions)
    empathy_level: float = 0.7          # 0-1, emotional responsiveness
    creativity_level: float = 0.5       # 0-1, imaginative response tendency
    directness_level: float = 0.5       # 0-1, straightforward vs. nuanced
    humor_level: float = 0.3            # 0-1, playful response tendency

    # State
    attunement_score: float = 0.0       # 0-1, how well attuned to user
    interaction_count: int = 0

    def __post_init__(self):
        """Initialize default body weights if not provided"""
        if not self.body_weights:
            self.body_weights = {bt: 1.0 for bt in BodyType}

    def attune_to_user(self, user: User):
        """
        Learn user's field signature and determine elemental alignment.

        Process:
        1. Record energy levels for all 9 bodies
        2. Calculate mind/heart/body ratios
        3. Determine elemental alignment from ratios
        4. Set communication style
        5. Calculate body weights (which bodies most influence companion)
        """
        # Record field signature
        for body_type, field in user.fields.items():
            self.field_signature[body_type] = field.energy()

        # Calculate key ratios
        mind_energy = user.fields[BodyType.MIND].energy()
        heart_energy = user.fields[BodyType.HEART].energy()
        body_energy = user.fields[BodyType.BODY].energy()
        spirit_energy = user.fields[BodyType.SPIRIT].energy()
        shadow_energy = user.fields[BodyType.SHADOW].energy()

        # Elemental alignment logic
        mind_heart_ratio = mind_energy / heart_energy if heart_energy > 0 else 1.0
        spirit_shadow_ratio = spirit_energy / shadow_energy if shadow_energy > 0 else 1.0

        # Determine alignment
        if mind_heart_ratio > 1.5:
            # Mind dominant → Air (intellectual)
            self.elemental_alignment = ElementalAlignment.AIR
            self.communication_style = CommunicationStyle.ANALYTICAL_STRUCTURED
            self.empathy_level = 0.4
            self.creativity_level = 0.7
            self.directness_level = 0.8

        elif mind_heart_ratio < 0.6:
            # Heart dominant → Water (emotional)
            self.elemental_alignment = ElementalAlignment.WATER
            self.communication_style = CommunicationStyle.NARRATIVE_FLOWING
            self.empathy_level = 0.9
            self.creativity_level = 0.6
            self.directness_level = 0.3

        elif body_energy > 1.5:
            # Body dominant → Earth (physical/grounded)
            self.elemental_alignment = ElementalAlignment.EARTH
            self.communication_style = CommunicationStyle.PRACTICAL_GROUNDED
            self.empathy_level = 0.6
            self.creativity_level = 0.4
            self.directness_level = 0.7

        elif spirit_shadow_ratio > 2.0:
            # Spirit dominant → Fire (visionary)
            self.elemental_alignment = ElementalAlignment.FIRE
            self.communication_style = CommunicationStyle.VISIONARY_EXPANSIVE
            self.empathy_level = 0.5
            self.creativity_level = 0.9
            self.directness_level = 0.6

        else:
            # Balanced → Aether (integrated)
            self.elemental_alignment = ElementalAlignment.AETHER
            self.communication_style = CommunicationStyle.HOLISTIC_INTEGRATED
            self.empathy_level = 0.7
            self.creativity_level = 0.6
            self.directness_level = 0.5

        # Calculate body weights (inverse of energy = more attention to weaker bodies)
        total_energy = sum(self.field_signature.values())
        if total_energy > 0:
            for bt in BodyType:
                energy = self.field_signature.get(bt, 1.0)
                # Weight = inverse normalized energy (weaker bodies get more attention)
                self.body_weights[bt] = (total_energy / (energy * len(BodyType)))

        self.attunement_score = 0.5  # Initial attunement

    def update_attunement(self, user: User):
        """
        Update attunement based on current user field state.

        Compare current signature to stored signature.
        Higher similarity = better attunement.
        """
        current_signature = {bt: f.energy() for bt, f in user.fields.items()}

        # Calculate cosine similarity between signatures
        stored = np.array([self.field_signature.get(bt, 0) for bt in BodyType])
        current = np.array([current_signature.get(bt, 0) for bt in BodyType])

        # Cosine similarity
        norm_stored = np.linalg.norm(stored)
        norm_current = np.linalg.norm(current)

        if norm_stored > 0 and norm_current > 0:
            similarity = np.dot(stored, current) / (norm_stored * norm_current)
            self.attunement_score = float(np.clip(similarity, 0, 1))

        # Update field signature (moving average)
        alpha = 0.1  # Learning rate
        for bt in BodyType:
            old = self.field_signature.get(bt, 0)
            new = current_signature.get(bt, 0)
            self.field_signature[bt] = old * (1 - alpha) + new * alpha

    def generate_response_params(self, user: User) -> Dict:
        """
        Generate response parameters based on current field state.

        Returns dict with:
        - tone: emotional tone (-1 to 1)
        - depth: response depth (0 to 1)
        - creativity: imaginative elements (0 to 1)
        - directness: straightforwardness (0 to 1)
        - focus_bodies: which bodies to address
        """
        # Current field state
        current = {bt: f.energy() for bt, f in user.fields.items()}

        # Detect field anomalies (bodies that need attention)
        anomalies = []
        for bt in BodyType:
            baseline = self.field_signature.get(bt, 1.0)
            current_val = current.get(bt, 1.0)
            deviation = abs(current_val - baseline) / baseline if baseline > 0 else 0
            if deviation > 0.3:  # 30% deviation threshold
                anomalies.append((bt, deviation, current_val < baseline))

        # Sort by deviation magnitude
        anomalies.sort(key=lambda x: x[1], reverse=True)

        # Determine tone based on heart/mind balance
        heart_energy = current.get(BodyType.HEART, 1.0)
        mind_energy = current.get(BodyType.MIND, 1.0)
        tone = np.tanh((heart_energy - mind_energy) * 2)  # -1 to 1

        # Determine depth based on soul/spirit energy
        depth = np.tanh((current.get(BodyType.SOUL, 1.0) + 
                        current.get(BodyType.SPIRIT, 1.0)) / 2)

        # Determine focus bodies (top 3 anomalies or default)
        if anomalies:
            focus_bodies = [bt.value for bt, _, _ in anomalies[:3]]
        else:
            # Default to highest energy bodies
            sorted_bodies = sorted(current.items(), key=lambda x: x[1], reverse=True)
            focus_bodies = [bt.value for bt, _ in sorted_bodies[:3]]

        return {
            'tone': float(tone),
            'depth': float(depth),
            'creativity': self.creativity_level,
            'directness': self.directness_level,
            'empathy': self.empathy_level,
            'focus_bodies': focus_bodies,
            'anomalies': [
                {'body': bt.value, 'deviation': float(dev), 'depleted': depleted}
                for bt, dev, depleted in anomalies[:5]
            ],
            'communication_style': self.communication_style.value,
            'elemental_alignment': self.elemental_alignment.value,
            'attunement_score': self.attunement_score
        }

    def store_interaction(self, query: str, response: str, user: User,
                         emotional_tone: float = 0.0,
                         resonance_score: float = 0.5):
        """
        Store interaction in companion memory with field context.

        Enables:
        - Pattern recognition across interactions
        - Field-state-dependent memory retrieval
        - Resonance learning (what worked well)
        """
        field_state = {bt.value: f.energy() for bt, f in user.fields.items()}

        memory = InteractionMemory(
            query=query,
            response=response,
            field_state=field_state,
            timestamp=self.interaction_count,
            emotional_tone=emotional_tone,
            resonance_score=resonance_score
        )

        self.memory.append(memory)
        if len(self.memory) > self.max_memory:
            self.memory.pop(0)

        self.interaction_count += 1

        # Update attunement based on resonance score
        self.attunement_score = 0.9 * self.attunement_score + 0.1 * resonance_score

    def retrieve_relevant_memories(self, user: User, query: str, 
                                   n: int = 5) -> List[InteractionMemory]:
        """
        Retrieve memories most relevant to current field state.

        Uses field signature similarity to find analogous past states.
        """
        current_signature = np.array([user.fields[bt].energy() for bt in BodyType])

        scored_memories = []
        for mem in self.memory:
            mem_signature = np.array([
                mem.field_state.get(bt.value, 0) for bt in BodyType
            ])

            # Cosine similarity
            norm_current = np.linalg.norm(current_signature)
            norm_mem = np.linalg.norm(mem_signature)

            if norm_current > 0 and norm_mem > 0:
                similarity = np.dot(current_signature, mem_signature) / (norm_current * norm_mem)
            else:
                similarity = 0

            # Weight by resonance score (prefer successful interactions)
            score = similarity * (0.5 + 0.5 * mem.resonance_score)
            scored_memories.append((score, mem))

        # Sort by score and return top N
        scored_memories.sort(key=lambda x: x[0], reverse=True)
        return [mem for _, mem in scored_memories[:n]]

    def get_field_prescription(self, user: User) -> List[Dict]:
        """
        Generate field balancing recommendations.

        Analyzes deviations from baseline signature and suggests
        which bodies need attention and how to address them.
        """
        current = {bt: f.energy() for bt, f in user.fields.items()}
        baseline = self.field_signature

        prescriptions = []

        for bt in BodyType:
            base = baseline.get(bt, 1.0)
            curr = current.get(bt, 1.0)
            deviation = (curr - base) / base if base > 0 else 0

            if abs(deviation) > 0.2:
                if deviation < -0.2:
                    status = 'depleted'
                    recommendation = f"Nourish {bt.value} field through rest, reflection, or grounding practices."
                elif deviation > 0.2:
                    status = 'overactive'
                    recommendation = f"Balance {bt.value} field through moderation, distribution, or release."
                else:
                    status = 'balanced'
                    recommendation = f"{bt.value} field is stable. Maintain current practices."

                prescriptions.append({
                    'body': bt.value,
                    'status': status,
                    'deviation': float(deviation),
                    'current_energy': float(curr),
                    'baseline_energy': float(base),
                    'recommendation': recommendation,
                    'priority': abs(deviation)
                })

        # Sort by priority (deviation magnitude)
        prescriptions.sort(key=lambda x: x['priority'], reverse=True)
        return prescriptions

    def to_dict(self) -> Dict:
        """Serialize companion to dictionary"""
        return {
            'companion_id': self.companion_id,
            'user_id': self.user_id,
            'name': self.name,
            'elemental_alignment': self.elemental_alignment.value,
            'communication_style': self.communication_style.value,
            'field_signature': {bt.value: float(e) for bt, e in self.field_signature.items()},
            'body_weights': {bt.value: float(w) for bt, w in self.body_weights.items()},
            'personality': {
                'empathy': self.empathy_level,
                'creativity': self.creativity_level,
                'directness': self.directness_level,
                'humor': self.humor_level
            },
            'attunement_score': self.attunement_score,
            'interaction_count': self.interaction_count,
            'memory_count': len(self.memory)
        }


class FairyGANmatter:
    """
    FairyGANmatter: Manager for personal companion instances.

    Creates, tunes, and manages FairyCompanion instances for users.
    Each companion is uniquely attuned to its user's consciousness field.

    Key capabilities:
    - Create companions with automatic field attunement
    - Manage companion lifecycle (create, update, archive)
    - Track companion-user resonance over time
    - Generate companion network analytics
    """

    def __init__(self):
        self.companions: Dict[str, FairyCompanion] = {}
        self.user_companions: Dict[str, str] = {}  # user_id -> companion_id
        self.creation_log: List[Dict] = []

    def create_companion(self, user: User, 
                        companion_name: Optional[str] = None,
                        companion_id: Optional[str] = None) -> str:
        """
        Generate companion for user with full field attunement.

        Process:
        1. Create companion with unique ID
        2. Attune to user's field signature
        3. Determine elemental alignment
        4. Set communication style and personality
        5. Register in management system
        """
        if user.user_id in self.user_companions:
            # User already has companion
            return self.user_companions[user.user_id]

        companion_id = companion_id or f"fairy_{user.user_id}"
        name = companion_name or f"Companion of {user.user_id}"

        companion = FairyCompanion(
            companion_id=companion_id,
            user_id=user.user_id,
            name=name
        )

        # Attune to user
        companion.attune_to_user(user)

        # Register
        self.companions[companion_id] = companion
        self.user_companions[user.user_id] = companion_id

        # Log creation
        self.creation_log.append({
            'companion_id': companion_id,
            'user_id': user.user_id,
            'timestamp': len(self.creation_log),
            'elemental_alignment': companion.elemental_alignment.value,
            'attunement_score': companion.attunement_score
        })

        return companion_id

    def get_companion(self, companion_id: str) -> Optional[FairyCompanion]:
        """Retrieve companion by ID"""
        return self.companions.get(companion_id)

    def get_user_companion(self, user_id: str) -> Optional[FairyCompanion]:
        """Retrieve companion for specific user"""
        companion_id = self.user_companions.get(user_id)
        if companion_id:
            return self.companions.get(companion_id)
        return None

    def update_all_companions(self, users: Dict[str, User]):
        """
        Update all companions with current user field states.

        Call this periodically to maintain attunement accuracy.
        """
        for user_id, companion_id in self.user_companions.items():
            if user_id in users and companion_id in self.companions:
                companion = self.companions[companion_id]
                companion.update_attunement(users[user_id])

    def get_companion_statistics(self) -> Dict:
        """Aggregate statistics across all companions"""
        if not self.companions:
            return {'total_companions': 0}

        alignments = {}
        styles = {}
        attunements = []

        for companion in self.companions.values():
            alignments[companion.elemental_alignment.value] =                 alignments.get(companion.elemental_alignment.value, 0) + 1
            styles[companion.communication_style.value] =                 styles.get(companion.communication_style.value, 0) + 1
            attunements.append(companion.attunement_score)

        return {
            'total_companions': len(self.companions),
            'elemental_distribution': alignments,
            'style_distribution': styles,
            'average_attunement': float(np.mean(attunements)),
            'attunement_range': (float(np.min(attunements)), float(np.max(attunements))),
            'total_interactions': sum(c.interaction_count for c in self.companions.values()),
            'total_memories': sum(len(c.memory) for c in self.companions.values())
        }

    def find_compatible_companions(self, user: User, 
                                   n: int = 3) -> List[Tuple[str, float]]:
        """
        Find companions most compatible with a given user.

        Useful for companion matching, group formation,
        or recommending companion interactions.
        """
        user_signature = np.array([user.fields[bt].energy() for bt in BodyType])

        scored = []
        for companion_id, companion in self.companions.items():
            if companion.user_id == user.user_id:
                continue  # Skip self

            companion_signature = np.array([
                companion.field_signature.get(bt, 0) for bt in BodyType
            ])

            # Cosine similarity
            norm_user = np.linalg.norm(user_signature)
            norm_comp = np.linalg.norm(companion_signature)

            if norm_user > 0 and norm_comp > 0:
                similarity = np.dot(user_signature, companion_signature) / (norm_user * norm_comp)
                scored.append((companion_id, float(similarity)))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:n]
