"""Personal companion instances (FairyGANmatter)."""
from .fairyganmatter import FairyCompanion, FairyGANmatter, ElementalAlignment
