"""
prediction.py — Neural Prediction Layer: Temporal Pattern Recognition & Trajectory Forecasting

Implements:
- Temporal buffer for field history management
- Pattern recognition via autocorrelation and FFT
- Trajectory prediction using multiple models (linear, harmonic, quadratic)
- Collapse prediction with time-to-collapse estimation
- Spectral analysis for frequency domain insights
- Statistical moment analysis for distribution characterization
"""

import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from collections import deque

from ..core.field import ResonanceField, BodyType, WaveLayer


@dataclass
class FieldSnapshot:
    """Single timestep snapshot of field state"""
    timestamp: float
    m: float
    c: float
    k: float
    beta: float
    phase: float
    energy: float

    def to_vector(self) -> np.ndarray:
        """Convert to feature vector for neural processing"""
        return np.array([
            self.m, self.c, self.k, self.beta,
            np.cos(self.phase), np.sin(self.phase), self.energy
        ])


class TemporalBuffer:
    """
    Rolling buffer of field history for pattern recognition.

    Maintains time-series data for each body type, enabling:
    - Trend analysis
    - Cycle detection
    - Trajectory forecasting
    - Anomaly detection
    """

    def __init__(self, window_size: int = 1000):
        """
        Args:
            window_size: maximum number of snapshots to retain per body
        """
        self.window_size = window_size
        self.buffers: Dict[BodyType, deque] = {
            body: deque(maxlen=window_size) for body in BodyType
        }

    def record(self, body_type: BodyType, field: ResonanceField, 
               timestamp: Optional[float] = None):
        """Add field state to buffer"""
        if timestamp is None:
            timestamp = len(self.buffers[body_type])

        snapshot = FieldSnapshot(
            timestamp=timestamp,
            m=field.m,
            c=field.c,
            k=field.k,
            beta=field.beta,
            phase=field.phase,
            energy=field.energy()
        )
        self.buffers[body_type].append(snapshot)

    def get_sequence(self, body_type: BodyType, 
                    n: Optional[int] = None) -> List[FieldSnapshot]:
        """Get last n snapshots (or all if n=None)"""
        buffer = self.buffers[body_type]
        if n is None:
            return list(buffer)
        return list(buffer)[-n:]

    def get_feature_matrix(self, body_type: BodyType,
                          n: Optional[int] = None) -> np.ndarray:
        """Get feature matrix for neural network input [samples, features]"""
        sequence = self.get_sequence(body_type, n)
        if not sequence:
            return np.array([])
        return np.vstack([snap.to_vector() for snap in sequence])

    def get_parameter_series(self, body_type: BodyType,
                            parameter: str,
                            n: Optional[int] = None) -> np.ndarray:
        """Get time series for a specific parameter (m, c, k, beta, phase, energy)"""
        sequence = self.get_sequence(body_type, n)
        if not sequence:
            return np.array([])
        return np.array([getattr(snap, parameter) for snap in sequence])

    def clear(self, body_type: Optional[BodyType] = None):
        """Clear buffer for specific body or all bodies"""
        if body_type is None:
            for body in BodyType:
                self.buffers[body].clear()
        else:
            self.buffers[body_type].clear()


class PatternRecognizer:
    """
    Identifies recurring patterns in field dynamics using:
    - Autocorrelation for cycle detection
    - FFT for frequency domain analysis
    - Statistical moments for distribution characterization
    - Lyapunov exponent estimation for chaos detection
    """

    @staticmethod
    def detect_cycles(sequence: np.ndarray, 
                     max_lag: Optional[int] = None) -> Dict[str, float]:
        """
        Detect cyclic patterns via autocorrelation.

        Returns:
            period: dominant cycle length (0 if no cycle detected)
            strength: autocorrelation at dominant period (0-1)
            confidence: reliability of detection
        """
        if len(sequence) < 10:
            return {'period': 0.0, 'strength': 0.0, 'confidence': 0.0}

        if max_lag is None:
            max_lag = len(sequence) // 2

        # Normalize
        normalized = (sequence - np.mean(sequence))
        std = np.std(normalized)
        if std < 1e-10:
            return {'period': 0.0, 'strength': 0.0, 'confidence': 0.0}

        normalized = normalized / std

        # Autocorrelation
        autocorr = np.correlate(normalized, normalized, mode='full')
        autocorr = autocorr[len(autocorr)//2:]

        # Normalize by zero-lag
        if autocorr[0] > 0:
            autocorr = autocorr / autocorr[0]

        # Find peaks (excluding zero lag)
        peaks = []
        for i in range(1, min(len(autocorr) - 1, max_lag)):
            if autocorr[i] > autocorr[i-1] and autocorr[i] > autocorr[i+1] and autocorr[i] > 0.1:
                peaks.append((i, autocorr[i]))

        if not peaks:
            return {'period': 0.0, 'strength': 0.0, 'confidence': 0.0}

        # Dominant peak
        dominant = max(peaks, key=lambda x: x[1])
        period = float(dominant[0])
        strength = float(dominant[1])

        # Confidence based on peak prominence and data length
        confidence = min(1.0, len(sequence) / 100) * strength

        return {
            'period': period,
            'strength': strength,
            'confidence': confidence
        }

    @staticmethod
    def spectral_analysis(sequence: np.ndarray, 
                         sample_rate: float = 1.0) -> Dict[str, np.ndarray]:
        """
        Frequency domain analysis via FFT.

        Returns:
            frequencies: frequency bins
            power: power spectral density
            phases: phase spectrum
            dominant_freq: frequency with maximum power
            dominant_power: power at dominant frequency
        """
        if len(sequence) < 4:
            return {
                'frequencies': np.array([]),
                'power': np.array([]),
                'phases': np.array([]),
                'dominant_freq': 0.0,
                'dominant_power': 0.0
            }

        # Detrend
        sequence = sequence - np.mean(sequence)

        # Window function (Hann window)
        window = np.hanning(len(sequence))
        windowed = sequence * window

        # FFT
        fft = np.fft.rfft(windowed)
        power = np.abs(fft) ** 2
        phases = np.angle(fft)
        frequencies = np.fft.rfftfreq(len(sequence), d=1.0/sample_rate)

        # Find dominant frequency (exclude DC)
        if len(power) > 1:
            dominant_idx = np.argmax(power[1:]) + 1
            dominant_freq = frequencies[dominant_idx]
            dominant_power = power[dominant_idx]
        else:
            dominant_freq = 0.0
            dominant_power = power[0] if len(power) > 0 else 0.0

        return {
            'frequencies': frequencies,
            'power': power,
            'phases': phases,
            'dominant_freq': float(dominant_freq),
            'dominant_power': float(dominant_power)
        }

    @staticmethod
    def statistical_moments(sequence: np.ndarray) -> Dict[str, float]:
        """
        Calculate statistical moments for distribution characterization.

        Returns:
            mean, std, skew, kurtosis, entropy
        """
        if len(sequence) == 0:
            return {
                'mean': 0.0, 'std': 0.0, 'skew': 0.0,
                'kurtosis': 0.0, 'entropy': 0.0
            }

        mean = float(np.mean(sequence))
        std = float(np.std(sequence))

        if std < 1e-10:
            return {
                'mean': mean, 'std': 0.0, 'skew': 0.0,
                'kurtosis': 0.0, 'entropy': 0.0
            }

        normalized = (sequence - mean) / std
        skew = float(np.mean(normalized ** 3))
        kurtosis = float(np.mean(normalized ** 4) - 3)

        # Approximate entropy (binning method)
        hist, _ = np.histogram(sequence, bins=20, density=True)
        hist = hist[hist > 0]
        entropy = float(-np.sum(hist * np.log(hist + 1e-10)) * (sequence.max() - sequence.min()) / 20)

        return {
            'mean': mean,
            'std': std,
            'skew': skew,
            'kurtosis': kurtosis,
            'entropy': entropy
        }

    @staticmethod
    def lyapunov_estimation(sequence: np.ndarray, 
                           embedding_dim: int = 3,
                           delay: int = 1) -> float:
        """
        Estimate largest Lyapunov exponent for chaos detection.

        Positive exponent → chaotic dynamics
        Near-zero → quasi-periodic
        Negative → stable fixed point

        Simplified algorithm using nearest neighbors in phase space.
        """
        if len(sequence) < embedding_dim * delay + 10:
            return 0.0

        # Reconstruct phase space
        n = len(sequence) - (embedding_dim - 1) * delay
        phase_space = np.zeros((n, embedding_dim))
        for i in range(embedding_dim):
            phase_space[:, i] = sequence[i * delay:i * delay + n]

        # Find nearest neighbors and track divergence
        divergences = []
        for i in range(n - 10):
            # Find nearest neighbor (excluding close points)
            distances = np.linalg.norm(phase_space - phase_space[i], axis=1)
            distances[i] = np.inf  # Exclude self
            distances[max(0, i-5):min(n, i+5)] = np.inf  # Exclude close points

            j = np.argmin(distances)
            if distances[j] == np.inf:
                continue

            # Track divergence over time
            d0 = distances[j]
            for k in range(1, min(10, n - max(i, j))):
                dk = np.linalg.norm(phase_space[i+k] - phase_space[j+k])
                if dk > 0 and d0 > 0:
                    divergences.append(np.log(dk / d0) / k)

        if not divergences:
            return 0.0

        return float(np.mean(divergences))

    @staticmethod
    def detect_anomalies(sequence: np.ndarray, 
                        threshold_sigma: float = 3.0) -> List[int]:
        """
        Detect anomalous points using Z-score method.

        Returns indices of points exceeding threshold_sigma standard deviations.
        """
        if len(sequence) < 10:
            return []

        mean = np.mean(sequence)
        std = np.std(sequence)

        if std < 1e-10:
            return []

        z_scores = np.abs((sequence - mean) / std)
        return [int(i) for i in np.where(z_scores > threshold_sigma)[0]]


class TrajectoryPredictor:
    """
    Forecast future field states using multiple prediction models:
    - Linear extrapolation (trend continuation)
    - Harmonic prediction (for cyclic patterns)
    - Quadratic model (for accelerating/decelerating trends)
    - Ensemble average (weighted combination)
    """

    def __init__(self, pattern_recognizer: Optional[PatternRecognizer] = None):
        self.pattern_recognizer = pattern_recognizer or PatternRecognizer()

    def linear_forecast(self, sequence: np.ndarray, steps: int = 10) -> np.ndarray:
        """Simple linear extrapolation: x(t) = a·t + b"""
        if len(sequence) < 2:
            return np.zeros(steps)

        x = np.arange(len(sequence))
        coeffs = np.polyfit(x, sequence, deg=1)
        future_x = np.arange(len(sequence), len(sequence) + steps)
        return np.polyval(coeffs, future_x)

    def quadratic_forecast(self, sequence: np.ndarray, steps: int = 10) -> np.ndarray:
        """Quadratic extrapolation: x(t) = a·t² + b·t + c"""
        if len(sequence) < 3:
            return self.linear_forecast(sequence, steps)

        x = np.arange(len(sequence))
        coeffs = np.polyfit(x, sequence, deg=2)
        future_x = np.arange(len(sequence), len(sequence) + steps)
        return np.polyval(coeffs, future_x)

    def harmonic_forecast(self, sequence: np.ndarray, steps: int = 10) -> np.ndarray:
        """
        Predict using detected harmonic patterns.

        Reconstructs signal from dominant FFT components.
        """
        if len(sequence) < 10:
            return self.linear_forecast(sequence, steps)

        # Detect cycles
        cycle_info = self.pattern_recognizer.detect_cycles(sequence)
        period = cycle_info['period']
        strength = cycle_info['strength']

        if period == 0 or strength < 0.3:
            # Not cyclic enough, use linear
            return self.linear_forecast(sequence, steps)

        # Spectral decomposition
        spectral = self.pattern_recognizer.spectral_analysis(sequence)
        frequencies = spectral['frequencies']
        power = spectral['power']
        phases = spectral['phases']

        # Reconstruct with top N harmonics
        n_harmonics = min(5, len(power) - 1)
        top_indices = np.argsort(power[1:])[-n_harmonics:] + 1

        predictions = np.zeros(steps)
        for idx in top_indices:
            freq = frequencies[idx]
            amplitude = np.sqrt(power[idx]) / len(sequence)
            phase = phases[idx]

            future_t = np.arange(len(sequence), len(sequence) + steps)
            predictions += amplitude * np.cos(2 * np.pi * freq * future_t + phase)

        # Add linear trend component
        trend = self.linear_forecast(sequence, steps)
        # Weight by cycle strength
        return strength * predictions + (1 - strength) * trend

    def ensemble_forecast(self, sequence: np.ndarray, steps: int = 10,
                         weights: Optional[Dict[str, float]] = None) -> Dict[str, np.ndarray]:
        """
        Combine multiple forecasting methods with weighted ensemble.

        Default weights adapt based on cycle detection strength.
        """
        if weights is None:
            cycle_info = self.pattern_recognizer.detect_cycles(sequence)
            if cycle_info['strength'] > 0.5:
                weights = {'linear': 0.2, 'harmonic': 0.5, 'quadratic': 0.3}
            else:
                weights = {'linear': 0.5, 'harmonic': 0.1, 'quadratic': 0.4}

        forecasts = {
            'linear': self.linear_forecast(sequence, steps),
            'harmonic': self.harmonic_forecast(sequence, steps),
            'quadratic': self.quadratic_forecast(sequence, steps)
        }

        # Weighted ensemble
        ensemble = np.zeros(steps)
        total_weight = 0
        for method, forecast in forecasts.items():
            w = weights.get(method, 0.33)
            ensemble += w * forecast
            total_weight += w

        if total_weight > 0:
            ensemble /= total_weight

        forecasts['ensemble'] = ensemble
        return forecasts

    def predict_field_trajectory(self, buffer: TemporalBuffer,
                                body_type: BodyType,
                                steps: int = 10) -> Dict[str, np.ndarray]:
        """
        Predict all field parameters forward in time.

        Returns dict with predictions for m, c, k, beta, phase, energy.
        """
        feature_matrix = buffer.get_feature_matrix(body_type)

        if len(feature_matrix) < 5:
            return {
                'm': np.zeros(steps),
                'c': np.zeros(steps),
                'k': np.zeros(steps),
                'beta': np.zeros(steps),
                'phase': np.zeros(steps),
                'energy': np.zeros(steps)
            }

        predictions = {}
        param_names = ['m', 'c', 'k', 'beta']

        for i, param in enumerate(param_names):
            sequence = feature_matrix[:, i]
            forecasts = self.ensemble_forecast(sequence, steps)
            predictions[param] = forecasts['ensemble']

        # Phase prediction (circular, handle via sin/cos)
        phase_cos = feature_matrix[:, 4]
        phase_sin = feature_matrix[:, 5]

        cos_forecasts = self.ensemble_forecast(phase_cos, steps)
        sin_forecasts = self.ensemble_forecast(phase_sin, steps)

        predictions['phase'] = np.arctan2(
            sin_forecasts['ensemble'],
            cos_forecasts['ensemble']
        ) % (2 * np.pi)

        # Energy prediction (derived from m, c, k, beta)
        predictions['energy'] = (
            predictions['m'] * predictions['c'] * 
            np.power(predictions['k'], predictions.get('beta', np.ones(steps)))
        )

        return predictions


class CollapsePredictor:
    """
    Predict likelihood and timing of field collapse.

    Uses trajectory forecasting to predict when coherence will fall
    below critical threshold, enabling proactive intervention.
    """

    def __init__(self, threshold: float = 0.3, horizon: int = 50):
        self.threshold = threshold
        self.horizon = horizon
        self.trajectory_predictor = TrajectoryPredictor()

    def analyze_collapse_risk(self, coherence_history: List[float]) -> Dict:
        """
        Analyze collapse probability over prediction horizon.

        Returns comprehensive risk assessment with:
        - risk_level: qualitative assessment
        - probability: 0-1 likelihood
        - time_to_collapse: predicted steps until collapse (None if stable)
        - confidence: prediction reliability
        - trend: current coherence velocity
        - predicted_trajectory: forecasted coherence values
        """
        if len(coherence_history) < 5:
            return {
                'risk_level': 'unknown',
                'probability': 0.0,
                'time_to_collapse': None,
                'confidence': 0.0,
                'trend': 0.0,
                'predicted_trajectory': []
            }

        sequence = np.array(coherence_history)
        current_k = sequence[-1]

        # Fit quadratic model
        n = len(sequence)
        x = np.arange(n)
        coeffs = np.polyfit(x, sequence, deg=2)
        a, b, c = coeffs

        # Current trend
        trend = 2 * a * (n - 1) + b

        # Generate predictions
        future_x = np.arange(n, n + self.horizon)
        predictions = np.polyval(coeffs, future_x)

        # Find collapse time
        collapse_indices = np.where(predictions < self.threshold)[0]

        if len(collapse_indices) > 0:
            time_to_collapse = collapse_indices[0]
            if time_to_collapse < 5:
                risk_level = 'critical'
                probability = 1.0
            elif time_to_collapse < 15:
                risk_level = 'high'
                probability = 0.8
            elif time_to_collapse < 30:
                risk_level = 'moderate'
                probability = 0.5
            else:
                risk_level = 'low'
                probability = 0.2
        else:
            # Check if trending toward collapse
            if trend < -0.01 and current_k < self.threshold * 2:
                risk_level = 'low'
                probability = 0.15
            else:
                risk_level = 'stable'
                probability = 0.0
            time_to_collapse = None

        # Confidence based on fit quality
        predicted = np.polyval(coeffs, x)
        residuals = sequence - predicted
        mse = np.mean(residuals ** 2)
        r_squared = 1 - mse / np.var(sequence) if np.var(sequence) > 0 else 0
        confidence = min(1.0, (n / 50) * max(0, r_squared))

        return {
            'risk_level': risk_level,
            'probability': float(probability),
            'time_to_collapse': int(time_to_collapse) if time_to_collapse is not None else None,
            'confidence': float(confidence),
            'trend': float(trend),
            'curvature': float(2 * a),
            'predicted_trajectory': predictions.tolist()
        }
