"""
insights.py — Neural Insight Generator & Adaptive Field Modulator

Implements:
- Human-readable insight generation from field analysis
- Predictive recommendations based on trajectory forecasts
- Adaptive field modulation via PID control
- Field balancing prescriptions
- Companion response parameter generation
"""

import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

from ..core.field import ResonanceField, BodyType, WaveLayer
from ..neural.prediction import TemporalBuffer, PatternRecognizer, TrajectoryPredictor


@dataclass
class FieldInsight:
    """Structured insight from field analysis"""
    body_type: BodyType
    insight_text: str
    recommendations: List[str]
    priority: float  # 0-1, higher = more urgent
    confidence: float  # 0-1, prediction reliability
    metrics: Dict[str, float]


class InsightGenerator:
    """
    Generate predictive insights and actionable recommendations
    from field analysis data.

    Translates numerical predictions into human-readable guidance
    with specific, actionable recommendations.
    """

    def __init__(self, pattern_recognizer: Optional[PatternRecognizer] = None):
        self.pattern_recognizer = pattern_recognizer or PatternRecognizer()

    def generate_field_insight(self, body_type: BodyType,
                              buffer: TemporalBuffer,
                              predictions: Dict[str, np.ndarray],
                              steps: int = 10) -> FieldInsight:
        """
        Generate comprehensive insight for a single body field.

        Analyzes historical patterns, current state, and predicted
        trajectory to generate actionable guidance.
        """
        # Get recent history
        history = buffer.get_sequence(body_type, n=50)
        if not history:
            return FieldInsight(
                body_type=body_type,
                insight_text="Insufficient data for analysis.",
                recommendations=["Continue monitoring this field."],
                priority=0.0,
                confidence=0.0,
                metrics={}
            )

        energy_history = np.array([s.energy for s in history])
        coherence_history = np.array([s.k for s in history])
        phase_history = np.array([s.phase for s in history])

        # Pattern analysis
        energy_stats = self.pattern_recognizer.statistical_moments(energy_history)
        coherence_stats = self.pattern_recognizer.statistical_moments(coherence_history)
        cycle_info = self.pattern_recognizer.detect_cycles(energy_history)

        # Current and predicted states
        current_energy = energy_history[-1]
        current_coherence = coherence_history[-1]
        future_energy = np.mean(predictions['energy'][:steps]) if 'energy' in predictions else current_energy
        future_coherence = np.mean(predictions['k'][:steps]) if 'k' in predictions else current_coherence

        # Build insight components
        insight_parts = []
        recommendations = []
        priority = 0.0

        # Energy assessment
        if energy_stats['mean'] > 2.0:
            insight_parts.append(f"{body_type.value} field is operating at high energy ({current_energy:.2f}).")
            if energy_stats['std'] > 0.5:
                insight_parts.append("High variability detected — energy is fluctuating significantly.")
                recommendations.append("Channel excess energy through creative expression or physical activity.")
                priority = max(priority, 0.6)
            else:
                recommendations.append("High energy is stable — good time for focused work.")
        elif energy_stats['mean'] < 0.5:
            insight_parts.append(f"{body_type.value} field energy is depleted ({current_energy:.2f}).")
            recommendations.append("Rest and recharge this consciousness layer. Avoid demanding tasks.")
            priority = max(priority, 0.8)
        else:
            insight_parts.append(f"{body_type.value} field energy is moderate ({current_energy:.2f}).")

        # Coherence assessment
        if current_coherence < 0.3:
            insight_parts.append(f"Critical coherence instability (k={current_coherence:.3f}).")
            recommendations.append("URGENT: Practice grounding and centering techniques immediately.")
            recommendations.append("Minimize external stimuli and focus on breath awareness.")
            priority = max(priority, 1.0)
        elif current_coherence < 0.6:
            insight_parts.append(f"Coherence is below optimal (k={current_coherence:.3f}).")
            recommendations.append("Practice meditation or coherence-building exercises.")
            priority = max(priority, 0.5)
        elif current_coherence > 1.5:
            insight_parts.append(f"Strong coherence maintained (k={current_coherence:.3f}).")
            recommendations.append("Maintain current practices — field is well-aligned.")

        # Trend analysis
        if future_energy > current_energy * 1.2:
            insight_parts.append("Ascending energy trajectory predicted.")
            recommendations.append("Prepare for increased creative capacity. Schedule important work.")
        elif future_energy < current_energy * 0.8:
            insight_parts.append("Descending energy trajectory predicted.")
            recommendations.append("Conserve resources, avoid overcommitment. Plan rest periods.")
            priority = max(priority, 0.4)

        # Cycle detection
        if cycle_info['strength'] > 0.6 and cycle_info['period'] > 0:
            period_days = cycle_info['period']
            insight_parts.append(f"Cyclic pattern detected with ~{period_days:.1f} unit rhythm.")
            recommendations.append(f"Align activities with your natural {period_days:.1f}-unit cycle.")

        # Phase analysis
        phase_variance = np.var(phase_history[-10:]) if len(phase_history) >= 10 else 0
        if phase_variance > 1.0:
            insight_parts.append("Phase is highly variable — field is searching for alignment.")
            recommendations.append("Establish routine to stabilize phase. Consistency helps.")

        # Combine insights
        insight_text = " ".join(insight_parts)
        if not insight_text:
            insight_text = f"{body_type.value} field is stable with no significant patterns detected."

        # Confidence based on data quality
        confidence = min(1.0, len(history) / 100) * (0.5 + 0.5 * cycle_info.get('confidence', 0))

        metrics = {
            'current_energy': float(current_energy),
            'current_coherence': float(current_coherence),
            'predicted_energy': float(future_energy),
            'predicted_coherence': float(future_coherence),
            'energy_mean': energy_stats['mean'],
            'energy_std': energy_stats['std'],
            'coherence_mean': coherence_stats['mean'],
            'cycle_period': cycle_info.get('period', 0),
            'cycle_strength': cycle_info.get('strength', 0)
        }

        return FieldInsight(
            body_type=body_type,
            insight_text=insight_text,
            recommendations=recommendations,
            priority=priority,
            confidence=confidence,
            metrics=metrics
        )

    def generate_user_report(self, user_id: str,
                            buffers: Dict[BodyType, TemporalBuffer],
                            predictions: Dict[BodyType, Dict[str, np.ndarray]]) -> Dict:
        """
        Generate comprehensive consciousness report for a user.

        Analyzes all 9 bodies and provides prioritized insights.
        """
        body_insights = {}
        priority_recommendations = []

        for body_type in BodyType:
            if body_type in buffers and body_type in predictions:
                insight = self.generate_field_insight(
                    body_type,
                    buffers[body_type],
                    predictions[body_type]
                )
                body_insights[body_type.value] = {
                    'insight': insight.insight_text,
                    'recommendations': insight.recommendations,
                    'priority': insight.priority,
                    'confidence': insight.confidence,
                    'metrics': insight.metrics
                }

                # Collect high-priority recommendations
                if insight.priority > 0.5:
                    priority_recommendations.extend([
                        f"[{body_type.value.upper()}] {rec}"
                        for rec in insight.recommendations
                    ])

        # Sort by priority
        sorted_bodies = sorted(
            body_insights.items(),
            key=lambda x: x[1]['priority'],
            reverse=True
        )

        return {
            'user_id': user_id,
            'timestamp': len(list(buffers.values())[0].get_sequence(BodyType.MIND)) if buffers else 0,
            'body_insights': dict(sorted_bodies),
            'priority_recommendations': priority_recommendations[:10],  # Top 10
            'overall_priority': max((i['priority'] for i in body_insights.values()), default=0),
            'average_confidence': np.mean([i['confidence'] for i in body_insights.values()]) if body_insights else 0
        }

    def generate_compatibility_insight(self, user_a_id: str, user_b_id: str,
                                      compatibility_data: Dict) -> str:
        """
        Generate natural language compatibility insight.
        """
        score = compatibility_data['compatibility_score']
        strongest = compatibility_data['strongest_resonance']
        weakest = compatibility_data['weakest_resonance']
        phase_sync = compatibility_data['phase_synchronization']

        parts = []

        # Overall compatibility
        if score > 0.8:
            parts.append(f"Deep resonance between {user_a_id} and {user_b_id}. Their fields harmonize naturally.")
        elif score > 0.6:
            parts.append(f"Strong compatibility with meaningful resonance patterns.")
        elif score > 0.4:
            parts.append(f"Moderate compatibility — some friction but potential for growth.")
        elif score > 0.2:
            parts.append(f"Challenging compatibility. Significant field differences require conscious navigation.")
        else:
            parts.append(f"Low compatibility. Fields operate on fundamentally different frequencies.")

        # Strongest resonance
        parts.append(f"Strongest connection through {strongest['body']} fields (resonance: {strongest['value']:.3f}).")

        # Weakest resonance
        parts.append(f"Most challenging area: {weakest['body']} fields (resonance: {weakest['value']:.3f}).")

        # Phase sync
        if phase_sync > 0.8:
            parts.append("Excellent phase synchronization — natural timing alignment.")
        elif phase_sync > 0.5:
            parts.append("Moderate phase sync — some timing adjustments may help.")
        else:
            parts.append("Low phase synchronization — different rhythms may cause friction.")

        return " ".join(parts)


class AdaptiveModulator:
    """
    Automatically adjust field parameters to optimize for target states.

    Implements feedback control for coherence stabilization using
    PID (Proportional-Integral-Derivative) controllers per body.
    """

    def __init__(self, target_coherence: float = 0.7,
                 kp: float = 0.1, ki: float = 0.01, kd: float = 0.05):
        """
        Args:
            target_coherence: desired coherence level (0-5)
            kp: proportional gain (immediate response)
            ki: integral gain (persistent error correction)
            kd: derivative gain (anticipatory response)
        """
        self.target_coherence = target_coherence
        self.kp = kp
        self.ki = ki
        self.kd = kd

        # PID state per body
        self._integral_error: Dict[BodyType, float] = {}
        self._last_error: Dict[BodyType, float] = {}
        self._last_time: Dict[BodyType, float] = {}

    def pid_control(self, body_type: BodyType, current_k: float,
                   dt: float = 1.0) -> float:
        """
        PID controller for coherence stabilization.

        Control signal u(t) = Kp·e(t) + Ki·∫e(t)dt + Kd·de/dt

        Where e(t) = target - current (error signal)
        """
        # Error
        error = self.target_coherence - current_k

        # Initialize if first time
        if body_type not in self._integral_error:
            self._integral_error[body_type] = 0.0
            self._last_error[body_type] = error
            self._last_time[body_type] = 0.0

        # Integral term (accumulated error)
        self._integral_error[body_type] += error * dt
        # Anti-windup: clamp integral
        self._integral_error[body_type] = np.clip(
            self._integral_error[body_type], -5.0, 5.0
        )

        # Derivative term (rate of change)
        derivative = (error - self._last_error[body_type]) / dt

        # PID output
        control = (
            self.kp * error +
            self.ki * self._integral_error[body_type] +
            self.kd * derivative
        )

        # Update state
        self._last_error[body_type] = error
        self._last_time[body_type] += dt

        return control

    def modulate_field(self, field: ResonanceField, body_type: BodyType,
                      dt: float = 1.0) -> Dict[str, float]:
        """
        Apply adaptive modulation to field based on PID control.

        Returns adjustment report with all changes made.
        """
        # Get control signal
        control = self.pid_control(body_type, field.k, dt)

        adjustments = {}

        # Coherence adjustment (primary control)
        k_adjustment = control * 0.5
        field.k = np.clip(field.k + k_adjustment, 0.1, 5.0)
        adjustments['coherence_delta'] = float(k_adjustment)
        adjustments['coherence_new'] = float(field.k)

        # Secondary adjustments based on control magnitude
        if abs(control) > 0.2:
            # Strong correction needed — adjust pattern density
            m_adjustment = -control * 0.1  # Counter-cyclical
            field.m = np.clip(field.m + m_adjustment, 0.1, 5.0)
            adjustments['pattern_density_delta'] = float(m_adjustment)
            adjustments['pattern_density_new'] = float(field.m)

        if abs(control) > 0.3:
            # Critical correction — phase reset toward stability
            phase_adjustment = control * 0.2
            field.phase = (field.phase + phase_adjustment) % (2 * np.pi)
            adjustments['phase_delta'] = float(phase_adjustment)
            adjustments['phase_new'] = float(field.phase)

        if abs(control) > 0.5:
            # Extreme correction — reduce velocity to stabilize
            c_adjustment = -control * 0.05
            field.c = np.clip(field.c + c_adjustment, 0.1, 3.0)
            adjustments['velocity_delta'] = float(c_adjustment)
            adjustments['velocity_new'] = float(field.c)

        # Update bivector
        field.update_bivector()

        adjustments['control_signal'] = float(control)
        adjustments['energy_new'] = float(field.energy())

        return adjustments

    def modulate_user(self, fields: Dict[BodyType, ResonanceField],
                     dt: float = 1.0) -> Dict[BodyType, Dict[str, float]]:
        """
        Apply adaptive modulation to all user fields.

        Returns comprehensive adjustment report.
        """
        reports = {}
        for body_type, field in fields.items():
            reports[body_type] = self.modulate_field(field, body_type, dt)
        return reports

    def reset_controller(self, body_type: Optional[BodyType] = None):
        """Reset PID controller state for specific or all bodies"""
        if body_type is None:
            self._integral_error.clear()
            self._last_error.clear()
            self._last_time.clear()
        else:
            self._integral_error.pop(body_type, None)
            self._last_error.pop(body_type, None)
            self._last_time.pop(body_type, None)
