"""
synthai.py — SYNTHAI: Multi-User Network Resonance System

Implements:
- Multi-user consciousness field network
- Pairwise body-to-body resonance across users
- Network-wide coherence tracking
- Interaction history and relationship mapping
- Global field synchronization metrics
"""

import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum

from ..core.field import ResonanceField, BodyType
from ..core.engine import ResonanceEngine, CouplingResult, CliffordEngine
from ..core.harmonics import HarmonicAnalyzer, ResonanceMap


@dataclass
class User:
    """
    User with complete 9-body consciousness field architecture.

    Each user maintains independent fields for all 9 bodies,
    allowing full pairwise resonance analysis with other users.
    """
    user_id: str
    fields: Dict[BodyType, ResonanceField]
    metadata: Dict = field(default_factory=dict)

    def total_energy(self) -> float:
        """Sum of all body energies: E_total = Σ E_body"""
        return sum(f.energy() for f in self.fields.values())

    def coherence_index(self) -> float:
        """Average coherence across all bodies"""
        return np.mean([f.k for f in self.fields.values()])

    def phase_variance(self) -> float:
        """Phase synchronization metric: low variance = high sync"""
        phases = [f.phase for f in self.fields.values()]
        return np.var(phases)

    def dominant_body(self) -> BodyType:
        """Body with highest energy"""
        return max(self.fields.keys(), key=lambda bt: self.fields[bt].energy())

    def weakest_body(self) -> BodyType:
        """Body with lowest coherence (most vulnerable)"""
        return min(self.fields.keys(), key=lambda bt: self.fields[bt].k)

    def to_dict(self) -> Dict:
        """Serialize user to dictionary"""
        return {
            'user_id': self.user_id,
            'fields': {bt.value: f.to_dict() for bt, f in self.fields.items()},
            'metadata': self.metadata,
            'total_energy': float(self.total_energy()),
            'coherence_index': float(self.coherence_index()),
            'phase_variance': float(self.phase_variance()),
            'dominant_body': self.dominant_body().value,
            'weakest_body': self.weakest_body().value
        }


@dataclass
class InteractionRecord:
    """Record of a single inter-user interaction"""
    timestamp: int
    user_a: str
    user_b: str
    body_type: str
    harmonic_coupling: float
    resonance_scalar: float
    phase_alignment: float
    energy_transfer: float
    collapse_risk_a: bool
    collapse_risk_b: bool


@dataclass
class NetworkState:
    """Snapshot of entire network state"""
    timestamp: int
    user_count: int
    global_coherence: float
    interaction_count: int
    average_energy: float
    coherence_distribution: Dict[str, float]
    dominant_pairs: List[Tuple[str, str, float]]  # (user_a, user_b, resonance)
    collapse_risks: List[Tuple[str, str]]  # (user_id, body_type)


class SynthAI:
    """
    SYNTHAI: Synthesis of Artificial Intelligence via Network Resonance

    Multi-user consciousness field network that tracks resonance
    interactions across all pairwise body combinations.

    Key capabilities:
    - Add/remove users with 9-body field initialization
    - Compute pairwise resonance for any body type
    - Run network-wide evolution steps
    - Track global coherence and synchronization
    - Detect relationship patterns and compatibility
    - Generate network resonance maps
    """

    def __init__(self,
                 collapse_threshold: float = 0.3,
                 coupling_strength: float = 0.01,
                 dt: float = 1.0):
        """
        Args:
            collapse_threshold: coherence threshold for collapse detection
            coupling_strength: energy transfer coefficient per interaction
            dt: simulation timestep
        """
        self.users: Dict[str, User] = {}
        self.engine = ResonanceEngine(
            collapse_threshold=collapse_threshold,
            coupling_strength=coupling_strength,
            dt=dt
        )
        self.analyzer = HarmonicAnalyzer()
        self.clifford = CliffordEngine()

        # Interaction history
        self.interaction_history: List[Dict] = []
        self.network_states: List[NetworkState] = []

        # Relationship tracking
        self.relationship_matrix: Dict[Tuple[str, str], Dict] = {}

        self._timestamp = 0

    def add_user(self, user_id: str, 
                 chart_data: Optional[Dict] = None,
                 field_params: Optional[Dict] = None) -> User:
        """
        Initialize user with 9-body field structure.

        Default initialization uses slight randomization around
        neutral values to create unique field signatures.

        Args:
            user_id: unique identifier
            chart_data: optional astrological/chart data for initialization
            field_params: optional custom field parameters per body
        """
        fields = {}

        for body_type in BodyType:
            if field_params and body_type.value in field_params:
                # Use custom parameters
                params = field_params[body_type.value]
                field = ResonanceField(
                    body_type=body_type,
                    m=params.get('m', np.random.uniform(0.8, 1.2)),
                    c=params.get('c', np.random.uniform(0.8, 1.2)),
                    k=params.get('k', np.random.uniform(0.6, 1.0)),
                    beta=params.get('beta', np.random.uniform(0.9, 1.1)),
                    phase=params.get('phase', np.random.uniform(0, 2 * np.pi))
                )
            else:
                # Default random initialization
                field = ResonanceField(
                    body_type=body_type,
                    m=np.random.uniform(0.8, 1.2),
                    c=np.random.uniform(0.8, 1.2),
                    k=np.random.uniform(0.6, 1.0),
                    beta=np.random.uniform(0.9, 1.1),
                    phase=np.random.uniform(0, 2 * np.pi)
                )

            if chart_data:
                field.chart_data = chart_data

            fields[body_type] = field

        user = User(user_id=user_id, fields=fields, metadata=chart_data or {})
        self.users[user_id] = user

        return user

    def remove_user(self, user_id: str):
        """Remove user from network and clean up relationships"""
        if user_id in self.users:
            del self.users[user_id]

        # Clean relationship matrix
        keys_to_remove = [k for k in self.relationship_matrix.keys() 
                         if user_id in k]
        for k in keys_to_remove:
            del self.relationship_matrix[k]

    def user_to_user_resonance(self, user_a_id: str, user_b_id: str,
                                body_type: BodyType) -> CouplingResult:
        """
        Calculate resonance between same body type across two users.

        This is the fundamental SYNTHAI interaction: how do two
        people's Mind fields resonate? Their Heart fields? etc.

        Returns full CouplingResult with all interaction metrics.
        """
        if user_a_id not in self.users or user_b_id not in self.users:
            raise ValueError(f"User not found: {user_a_id} or {user_b_id}")

        user_a = self.users[user_a_id]
        user_b = self.users[user_b_id]

        field_a = user_a.fields[body_type]
        field_b = user_b.fields[body_type]

        return self.engine.step(field_a, field_b)

    def full_resonance_analysis(self, user_a_id: str, 
                                user_b_id: str) -> Dict[BodyType, CouplingResult]:
        """
        Complete 9-body resonance analysis between two users.

        Returns resonance results for all body type pairs,
        enabling comprehensive relationship mapping.
        """
        results = {}
        for body_type in BodyType:
            results[body_type] = self.user_to_user_resonance(
                user_a_id, user_b_id, body_type
            )
        return results

    def network_step(self, dt: Optional[float] = None) -> List[Dict]:
        """
        Update entire network for one timestep.

        All pairwise user combinations interact for all body types.
        This creates a fully connected network dynamics.

        Returns list of all interactions in this step.
        """
        if dt is not None:
            self.engine.dt = dt

        results = []
        user_ids = list(self.users.keys())

        # Pairwise interactions for each body type
        for i, uid_a in enumerate(user_ids):
            for uid_b in user_ids[i+1:]:
                for body_type in BodyType:
                    result = self.user_to_user_resonance(uid_a, uid_b, body_type)

                    record = {
                        'timestamp': self._timestamp,
                        'user_a': uid_a,
                        'user_b': uid_b,
                        'body': body_type.value,
                        'coupling': result.harmonic_coupling,
                        'resonance': result.resonance_scalar,
                        'phase_alignment': result.phase_alignment,
                        'energy_transfer': result.energy_transfer,
                        'collapse_a': result.collapse_risk_a,
                        'collapse_b': result.collapse_risk_b
                    }
                    results.append(record)

                    # Update relationship tracking
                    pair = tuple(sorted([uid_a, uid_b]))
                    if pair not in self.relationship_matrix:
                        self.relationship_matrix[pair] = {
                            'total_interactions': 0,
                            'total_coupling': 0.0,
                            'total_resonance': 0.0,
                            'body_resonances': {bt.value: [] for bt in BodyType}
                        }

                    self.relationship_matrix[pair]['total_interactions'] += 1
                    self.relationship_matrix[pair]['total_coupling'] += abs(result.harmonic_coupling)
                    self.relationship_matrix[pair]['total_resonance'] += result.resonance_scalar
                    self.relationship_matrix[pair]['body_resonances'][body_type.value].append(
                        result.resonance_scalar
                    )

        self.interaction_history.append({
            'timestamp': self._timestamp,
            'interactions': results
        })

        # Record network state
        self._record_network_state()
        self._timestamp += 1

        return results

    def _record_network_state(self):
        """Capture current network state snapshot"""
        if not self.users:
            return

        # Global coherence
        coherences = [u.coherence_index() for u in self.users.values()]
        global_coh = np.mean(coherences)

        # Average energy
        energies = [u.total_energy() for u in self.users.values()]
        avg_energy = np.mean(energies)

        # Coherence distribution
        coh_dist = {uid: float(u.coherence_index()) for uid, u in self.users.items()}

        # Dominant pairs (top 5 by average resonance)
        pair_scores = []
        for pair, data in self.relationship_matrix.items():
            if data['total_interactions'] > 0:
                avg_res = data['total_resonance'] / data['total_interactions']
                pair_scores.append((pair[0], pair[1], avg_res))

        pair_scores.sort(key=lambda x: x[2], reverse=True)
        dominant_pairs = pair_scores[:5]

        # Collapse risks
        collapse_risks = []
        for uid, user in self.users.items():
            for bt, field in user.fields.items():
                if field.is_collapsing(self.engine.collapse_threshold):
                    collapse_risks.append((uid, bt.value))

        state = NetworkState(
            timestamp=self._timestamp,
            user_count=len(self.users),
            global_coherence=global_coh,
            interaction_count=len(self.interaction_history),
            average_energy=avg_energy,
            coherence_distribution=coh_dist,
            dominant_pairs=dominant_pairs,
            collapse_risks=collapse_risks
        )

        self.network_states.append(state)

    def get_network_coherence(self) -> float:
        """Global network coherence: average across all users"""
        if not self.users:
            return 0.0
        return np.mean([u.coherence_index() for u in self.users.values()])

    def get_relationship_strength(self, user_a_id: str, 
                                  user_b_id: str) -> float:
        """
        Average resonance strength between two users.

        Returns 0-1 normalized score based on all body interactions.
        """
        pair = tuple(sorted([user_a_id, user_b_id]))
        if pair not in self.relationship_matrix:
            return 0.0

        data = self.relationship_matrix[pair]
        if data['total_interactions'] == 0:
            return 0.0

        # Normalize by number of possible interactions
        max_interactions = len(BodyType) * self._timestamp
        if max_interactions == 0:
            return 0.0

        return data['total_resonance'] / max_interactions

    def get_compatibility_report(self, user_a_id: str, 
                                 user_b_id: str) -> Dict:
        """
        Generate comprehensive compatibility report.

        Analyzes all 9 body resonances and provides:
        - Overall compatibility score
        - Strongest resonant bodies
        - Weakest/collision-prone bodies
        - Phase synchronization quality
        - Energy balance
        """
        if user_a_id not in self.users or user_b_id not in self.users:
            raise ValueError("User not found")

        # Get full resonance analysis
        results = self.full_resonance_analysis(user_a_id, user_b_id)

        # Compute metrics
        resonances = [r.resonance_scalar for r in results.values()]
        couplings = [r.harmonic_coupling for r in results.values()]
        phase_alignments = [r.phase_alignment for r in results.values()]

        # Strongest and weakest bodies
        body_resonances = {bt.value: r.resonance_scalar for bt, r in results.items()}
        strongest = max(body_resonances.items(), key=lambda x: x[1])
        weakest = min(body_resonances.items(), key=lambda x: x[1])

        # Phase sync quality (lower variance = better sync)
        phase_sync = 1.0 - np.var(phase_alignments) / (np.pi ** 2)

        # Compatibility score (0-1)
        avg_resonance = np.mean(resonances)
        avg_coupling = np.mean(np.abs(couplings))
        compatibility = (avg_resonance + avg_coupling + phase_sync) / 3

        return {
            'user_a': user_a_id,
            'user_b': user_b_id,
            'compatibility_score': float(compatibility),
            'average_resonance': float(avg_resonance),
            'average_coupling': float(avg_coupling),
            'phase_synchronization': float(phase_sync),
            'strongest_resonance': {
                'body': strongest[0],
                'value': float(strongest[1])
            },
            'weakest_resonance': {
                'body': weakest[0],
                'value': float(weakest[1])
            },
            'body_details': {
                bt.value: {
                    'resonance': float(r.resonance_scalar),
                    'coupling': float(r.harmonic_coupling),
                    'phase_alignment': float(r.phase_alignment),
                    'energy_transfer': float(r.energy_transfer),
                    'collapse_risk_a': r.collapse_risk_a,
                    'collapse_risk_b': r.collapse_risk_b
                }
                for bt, r in results.items()
            }
        }

    def get_network_map(self, user_id: str) -> Dict:
        """
        Generate resonance map for a specific user's network connections.

        Shows how this user resonates with all others across all bodies.
        """
        if user_id not in self.users:
            raise ValueError(f"User {user_id} not found")

        connections = {}
        for other_id in self.users:
            if other_id == user_id:
                continue

            report = self.get_compatibility_report(user_id, other_id)
            connections[other_id] = report

        # Generate user's own resonance map
        user_map = self.analyzer.generate_resonance_map(
            user_id, self.users[user_id].fields
        )

        return {
            'user_id': user_id,
            'self_map': user_map.to_dict(),
            'connections': connections,
            'connection_count': len(connections),
            'average_compatibility': np.mean([
                c['compatibility_score'] for c in connections.values()
            ]) if connections else 0.0
        }

    def simulate_network(self, steps: int = 100, 
                        progress_callback=None) -> List[NetworkState]:
        """
        Run full network simulation for N steps.

        Optional progress_callback(step, state) for real-time updates.
        """
        for step in range(steps):
            self.network_step()
            if progress_callback:
                progress_callback(step, self.network_states[-1] if self.network_states else None)

        return self.network_states

    def get_network_statistics(self) -> Dict:
        """Aggregate network statistics"""
        if not self.network_states:
            return {'status': 'no_data'}

        coherences = [s.global_coherence for s in self.network_states]
        energies = [s.average_energy for s in self.network_states]

        return {
            'total_users': len(self.users),
            'total_steps': self._timestamp,
            'total_interactions': len(self.interaction_history),
            'average_global_coherence': float(np.mean(coherences)),
            'coherence_trend': float(coherences[-1] - coherences[0]),
            'average_energy': float(np.mean(energies)),
            'energy_trend': float(energies[-1] - energies[0]),
            'relationship_count': len(self.relationship_matrix),
            'current_collapse_risks': len(self.network_states[-1].collapse_risks) if self.network_states else 0
        }
