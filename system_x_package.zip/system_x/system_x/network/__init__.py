"""Multi-user network resonance (SYNTHAI layer)."""
from .synthai import SynthAI, User, NetworkState
