"""
test_core.py — Unit tests for core resonance mechanics
"""

import unittest
import numpy as np
from system_x.core.field import ResonanceField, BodyType, WaveLayer
from system_x.core.engine import ResonanceEngine, CliffordEngine, CouplingResult
from system_x.core.collapse import CollapseDetector, CollapsePredictor
from system_x.core.harmonics import HarmonicAnalyzer, ResonanceMap


class TestResonanceField(unittest.TestCase):
    """Test ResonanceField fundamental operations"""

    def setUp(self):
        self.field = ResonanceField(
            body_type=BodyType.MIND,
            m=1.0, c=1.0, k=1.0, beta=1.0, phase=0.0
        )

    def test_energy_calculation(self):
        """E = m * c * k^β"""
        self.assertAlmostEqual(self.field.energy(), 1.0)

        self.field.m = 2.0
        self.field.c = 1.5
        self.field.k = 2.0
        self.field.beta = 1.5
        expected = 2.0 * 1.5 * (2.0 ** 1.5)
        self.assertAlmostEqual(self.field.energy(), expected)

    def test_parameter_clamping(self):
        """Parameters must stay within valid ranges"""
        self.field.m = 10.0
        self.field._clamp_parameters()
        self.assertEqual(self.field.m, 5.0)

        self.field.k = 0.0001
        self.field._clamp_parameters()
        self.assertEqual(self.field.k, 0.001)

    def test_wave_amplitude(self):
        """Wave function ψ(t) = A·sin(ωt + φ + φ_layer)"""
        t = 0.0
        amp = self.field.wave_amplitude(WaveLayer.ACTION, t)
        self.assertAlmostEqual(amp, 0.0)

        t = np.pi / 2
        amp = self.field.wave_amplitude(WaveLayer.ACTION, t)
        self.assertAlmostEqual(amp, 1.0, places=5)

    def test_phase_correction(self):
        """Phase should converge toward target"""
        self.field.phase = 0.0
        target = np.pi / 2

        for _ in range(50):
            self.field.apply_phase_correction(target, strength=0.2)

        diff = abs(self.field.phase - target)
        self.assertLess(diff, 0.1)

    def test_collapse_detection(self):
        """Collapse when k < threshold"""
        self.field.k = 0.5
        self.assertFalse(self.field.is_collapsing(0.3))

        self.field.k = 0.2
        self.assertTrue(self.field.is_collapsing(0.3))

    def test_bivector_update(self):
        """Bivector should update from field parameters"""
        self.field.update_bivector()
        mag = self.field.bivector_magnitude()
        self.assertGreater(mag, 0)

        direction = self.field.bivector_direction()
        self.assertAlmostEqual(np.linalg.norm(direction), 1.0)

    def test_serialization(self):
        """Round-trip serialization"""
        data = self.field.to_dict()
        restored = ResonanceField.from_dict(data)

        self.assertEqual(restored.body_type, self.field.body_type)
        self.assertAlmostEqual(restored.m, self.field.m)
        self.assertAlmostEqual(restored.c, self.field.c)
        self.assertAlmostEqual(restored.k, self.field.k)


class TestCliffordEngine(unittest.TestCase):
    """Test Geometric Algebra operations"""

    def setUp(self):
        self.engine = CliffordEngine()
        self.b1 = np.array([1.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        self.b2 = np.array([0.0, 1.0, 0.0, 0.0, 0.0, 0.0])

    def test_inner_product(self):
        """⟨F,G⟩ = -Σ fᵢ·gᵢ"""
        result = self.engine.inner_product(self.b1, self.b2)
        self.assertEqual(result, 0.0)

        result = self.engine.inner_product(self.b1, self.b1)
        self.assertEqual(result, -1.0)

    def test_wedge_product(self):
        """F∧G should produce bivector"""
        result = self.engine.wedge_product(self.b1, self.b2)
        self.assertEqual(len(result), 6)

    def test_geometric_product(self):
        """FG = ⟨F,G⟩ + F∧G + I·(F×G)"""
        scalar, bivector, pseudo = self.engine.geometric_product(self.b1, self.b2)

        self.assertIsInstance(scalar, float)
        self.assertEqual(len(bivector), 6)
        self.assertIsInstance(pseudo, float)

    def test_field_resonance(self):
        """Resonance between identical fields should be high"""
        f1 = ResonanceField(BodyType.MIND, m=1.0, c=1.0, k=1.0, beta=1.0, phase=0.0)
        f2 = ResonanceField(BodyType.MIND, m=1.0, c=1.0, k=1.0, beta=1.0, phase=0.0)

        f1.update_bivector()
        f2.update_bivector()

        resonance = self.engine.field_resonance(f1, f2)
        self.assertGreater(resonance, 0)


class TestResonanceEngine(unittest.TestCase):
    """Test resonance interaction mechanics"""

    def setUp(self):
        self.engine = ResonanceEngine()

        self.field_a = ResonanceField(
            BodyType.MIND, m=1.2, c=0.9, k=0.8, beta=1.2, phase=0.5
        )
        self.field_b = ResonanceField(
            BodyType.HEART, m=1.0, c=1.1, k=0.6, beta=1.0, phase=2.8
        )

    def test_harmonic_coupling(self):
        """H = mA·mB · kA·kB · cos(Δφ)"""
        H = self.engine.harmonic_coupling(self.field_a, self.field_b)

        self.assertIsInstance(H, float)
        self.assertLess(H, 0)  # Destructive with large phase diff

    def test_step_protocol(self):
        """Full step should return CouplingResult"""
        result = self.engine.step(self.field_a, self.field_b)

        self.assertIsInstance(result, CouplingResult)
        self.assertIsNotNone(result.harmonic_coupling)
        self.assertIsNotNone(result.resonance_scalar)
        self.assertIsNotNone(result.phase_alignment)

    def test_energy_conservation(self):
        """Total energy should not diverge wildly"""
        E_before = self.field_a.energy() + self.field_b.energy()

        for _ in range(100):
            self.engine.step(self.field_a, self.field_b)

        E_after = self.field_a.energy() + self.field_b.energy()

        self.assertLess(E_after, E_before * 10)
        self.assertGreater(E_after, E_before * 0.1)

    def test_phase_locking(self):
        """Phases should converge when coupling is constructive"""
        self.field_a.phase = 0.1
        self.field_b.phase = 0.2

        for _ in range(200):
            self.engine.step(self.field_a, self.field_b)

        diff = abs(self.field_a.phase - self.field_b.phase)
        self.assertLess(diff, np.pi / 2)


class TestCollapseDetector(unittest.TestCase):
    """Test collapse detection and stabilization"""

    def setUp(self):
        self.detector = CollapseDetector(threshold=0.3, intervention_strength=0.5)

    def test_scan_user_stable(self):
        """All fields stable when k > threshold with flat history"""
        fields = {
            bt: ResonanceField(bt, m=1.0, c=1.0, k=1.0, beta=1.0, phase=0.0)
            for bt in BodyType
        }
        # Add flat history (k=1.0, no decline)
        for _ in range(20):
            for bt in BodyType:
                fields[bt].update_coherence(internal=0.01, external=0.0)

        risks = self.detector.scan_user(fields)
        for bt, risk in risks.items():
            self.assertEqual(risk.risk_level, 'stable')

    def test_scan_user_collapsed(self):
        """Currently collapsed field should be detected as critical"""
        fields = {
            bt: ResonanceField(bt, m=1.0, c=1.0, k=1.0, beta=1.0, phase=0.0)
            for bt in BodyType
        }
        # Set mind to collapsed (k=0.2 < 0.3)
        fields[BodyType.MIND].k = 0.2
        # Add some history
        for _ in range(10):
            fields[BodyType.MIND].update_coherence(internal=-0.05, external=0.0)

        risks = self.detector.scan_user(fields)
        # Currently collapsed field should be detected as critical
        self.assertEqual(risks[BodyType.MIND].risk_level, 'critical')
        self.assertEqual(risks[BodyType.MIND].probability, 1.0)
        self.assertEqual(risks[BodyType.MIND].time_to_collapse, 0.0)

    def test_predictor_future_collapse(self):
        """Predictor should detect impending collapse from declining trajectory"""
        # Create history showing decline toward future collapse
        coherence_history = []
        for i in range(20):
            k = 0.8 - (i * 0.02)  # Declining from 0.8, currently at 0.42
            coherence_history.append(k)

        predictor = CollapsePredictor(threshold=0.3, horizon=50)
        result = predictor.analyze_trajectory(coherence_history)

        # With declining trajectory heading toward threshold, should predict risk
        self.assertIn(result['risk_level'], ['critical', 'high', 'moderate', 'low'])
        self.assertGreater(result['probability'], 0)
        self.assertIsNotNone(result['time_to_collapse'])

    def test_stabilization(self):
        """Stabilization should restore coherence above threshold"""
        field = ResonanceField(BodyType.MIND, m=1.0, c=1.0, k=0.2, beta=1.0, phase=0.0)

        report = self.detector.stabilize_field(field)

        self.assertTrue(report.success)
        self.assertGreater(report.coherence_after, self.detector.threshold)

    def test_cascade_prevention(self):
        """Should stabilize collapsed and at-risk fields"""
        fields = {
            bt: ResonanceField(bt, m=1.0, c=1.0, k=1.0, beta=1.0, phase=0.0)
            for bt in BodyType
        }
        # Set two fields to collapsed/at-risk
        fields[BodyType.MIND].k = 0.2
        fields[BodyType.HEART].k = 0.25

        reports = self.detector.stabilize_user(fields, method='adaptive')

        # Should have stabilized at least the collapsed fields
        self.assertGreater(len(reports), 0)

        # MIND should be stabilized above threshold
        self.assertGreater(fields[BodyType.MIND].k, self.detector.threshold)


class TestHarmonicAnalyzer(unittest.TestCase):
    """Test harmonic analysis functions"""

    def setUp(self):
        self.analyzer = HarmonicAnalyzer()

        self.fields = {
            bt: ResonanceField(bt, m=1.0, c=1.0, k=1.0, beta=1.0, phase=i * 0.5)
            for i, bt in enumerate(BodyType)
        }

    def test_resonance_matrix(self):
        """9×9 matrix should have coherences on diagonal"""
        matrix = self.analyzer.compute_resonance_matrix(self.fields)

        self.assertEqual(matrix.shape, (9, 9))

        for i, bt in enumerate(BodyType):
            self.assertAlmostEqual(matrix[i, i], self.fields[bt].k)

    def test_dominant_frequencies(self):
        """Should detect non-zero frequencies"""
        freqs = self.analyzer.dominant_frequencies(self.fields)

        for bt, freq in freqs.items():
            self.assertIsInstance(freq, float)
            self.assertGreaterEqual(freq, 0)

    def test_phase_synchronization(self):
        """Sync matrix should be symmetric"""
        sync = self.analyzer.phase_synchronization(self.fields)

        self.assertEqual(sync.shape, (9, 9))

        for i in range(9):
            for j in range(9):
                self.assertAlmostEqual(sync[i, j], sync[j, i])

    def test_energy_distribution(self):
        """Distribution should sum to 1"""
        dist = self.analyzer.energy_distribution(self.fields)

        self.assertAlmostEqual(np.sum(dist), 1.0)
        self.assertEqual(len(dist), 9)

    def test_resonance_map(self):
        """Should generate complete ResonanceMap"""
        rmap = self.analyzer.generate_resonance_map("test_user", self.fields)

        self.assertIsInstance(rmap, ResonanceMap)
        self.assertEqual(rmap.user_id, "test_user")
        self.assertEqual(rmap.matrix.shape, (9, 9))
        self.assertEqual(len(rmap.frequencies), 9)
        self.assertEqual(len(rmap.amplitudes), 9)


class TestIntegration(unittest.TestCase):
    """Integration tests for complete workflow"""

    def test_full_simulation(self):
        """Run complete simulation workflow"""
        from system_x.network.synthai import SynthAI

        synthai = SynthAI()

        user1 = synthai.add_user("alice")
        user2 = synthai.add_user("bob")

        results = synthai.network_step()

        self.assertGreater(len(results), 0)

        compat = synthai.get_compatibility_report("alice", "bob")
        self.assertIn('compatibility_score', compat)
        self.assertIn('body_details', compat)

        stats = synthai.get_network_statistics()
        self.assertEqual(stats['total_users'], 2)
        self.assertEqual(stats['total_steps'], 1)


if __name__ == '__main__':
    unittest.main()
