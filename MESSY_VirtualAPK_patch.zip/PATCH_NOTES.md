# MESSY VirtualAPK Patch

This patch fixes the Android/VirtualAPK scaffold shape:

- Plugin files now generate under `app/...` instead of project root.
- Adds `settings.gradle`, root `build.gradle`, and `build_plugin.sh`.
- Adds host-side `MessyHostApplication.java`, host manifest, and host Gradle sample.
- STREAM build command now points to `bash build_plugin.sh`.
- Crash/load failures are logged as `CONTAINS_FLAW`-ready events.

Note: I did not certify VirtualAPK/Gradle compatibility on this machine because no Android SDK/Gradle runtime is available here.
