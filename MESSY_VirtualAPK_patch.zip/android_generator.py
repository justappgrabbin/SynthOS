#!/usr/bin/env python3
from typing import Dict
from schema import MeshState

def java_string(value: str) -> str:
    return str(value).replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')

class AndroidGenerator:
    def __init__(self, mesh: MeshState, package_name: str = 'com.messy.generated'):
        self.mesh = mesh
        self.package_name = package_name
        self.activity_name = 'GeneratedActivity'

    def generate(self) -> Dict[str, str]:
        return {
            'settings.gradle': self._settings_gradle(),
            'build.gradle': self._root_gradle(),
            'app/build.gradle': self._plugin_gradle(),
            'app/src/main/AndroidManifest.xml': self._manifest(),
            'app/src/main/java/com/messy/generated/GeneratedActivity.java': self._activity(),
            'app/src/main/res/layout/activity_generated.xml': self._layout(),
            'app/src/main/res/values/strings.xml': self._strings(),
            'app/src/main/res/values/styles.xml': self._styles(),
            'build_plugin.sh': self._build_script(),
        }

    def _settings_gradle(self) -> str:
        return """pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }
rootProject.name = 'MessyGeneratedVirtualApk'
include ':app'
"""

    def _root_gradle(self) -> str:
        return """buildscript {
    repositories { google(); mavenCentral() }
    dependencies {
        classpath 'com.android.tools.build:gradle:3.6.4'
        classpath 'com.didi.virtualapk:gradle:0.9.8.6'
    }
}
allprojects { repositories { google(); mavenCentral() } }
"""

    def _plugin_gradle(self) -> str:
        return f"""apply plugin: 'com.android.application'
apply plugin: 'com.didi.virtualapk.plugin'

android {{
    compileSdkVersion 29
    defaultConfig {{
        applicationId "{self.package_name}"
        minSdkVersion 21
        targetSdkVersion 29
        versionCode 1
        versionName "1.0"
    }}
}}

dependencies {{
    implementation 'com.didi.virtualapk:core:0.9.8'
}}

virtualApk {{
    packageId = 0x6f
    targetHost = '../host/app'
    applyHostMapping = true
}}
"""

    def _manifest(self) -> str:
        return f"""<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="{self.package_name}">
    <application android:label="@string/app_name" android:theme="@style/MessyGeneratedTheme">
        <activity android:name=".{self.activity_name}" android:exported="true" />
    </application>
</manifest>
"""

    def _activity(self) -> str:
        triples = self.mesh.active_triples()
        entities = sorted(set([str(t.subject) for t in triples] + [str(t.object) for t in triples if t.object]))[:32]
        relations = sorted(set([str(t.relation) for t in triples]))[:32]
        triple_lines = [f'{t.subject}  {t.relation}  {t.object}' for t in triples[:64]]
        entity_array = ', '.join(f'"{java_string(e)}"' for e in entities)
        relation_array = ', '.join(f'"{java_string(r)}"' for r in relations)
        triple_array = ', '.join(f'"{java_string(t)}"' for t in triple_lines)
        return f"""package {self.package_name};

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.widget.TextView;

public class {self.activity_name} extends Activity {{
    @Override
    protected void onCreate(Bundle savedInstanceState) {{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generated);
        String[] entities = new String[]{{{entity_array}}};
        String[] relations = new String[]{{{relation_array}}};
        String[] triples = new String[]{{{triple_array}}};
        StringBuilder sb = new StringBuilder();
        sb.append("MESSY Generated Plugin\\n");
        sb.append("======================\\n\\n");
        sb.append("Entities: ").append(entities.length).append("\\n");
        sb.append("Relations: ").append(relations.length).append("\\n");
        sb.append("Triples: ").append(triples.length).append("\\n\\n");
        sb.append("Triples\\n-------\\n");
        for (String t : triples) sb.append("• ").append(t).append("\\n");
        TextView tv = findViewById(R.id.mesh_view);
        tv.setText(sb.toString());
        tv.setTextColor(Color.parseColor("#E8E8F0"));
        tv.setBackgroundColor(Color.parseColor("#0A0A0F"));
    }}
}}
"""

    def _layout(self) -> str:
        return """<?xml version="1.0" encoding="utf-8"?>
<ScrollView xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="match_parent" android:background="#0A0A0F">
    <TextView android:id="@+id/mesh_view" android:layout_width="match_parent" android:layout_height="wrap_content" android:textSize="14sp" android:typeface="monospace" android:textColor="#E8E8F0" android:padding="16dp" />
</ScrollView>
"""

    def _strings(self) -> str:
        return """<resources><string name="app_name">MESSY Generated</string></resources>\n"""

    def _styles(self) -> str:
        return """<resources><style name="MessyGeneratedTheme" parent="@android:style/Theme.Material.NoActionBar"><item name="android:windowNoTitle">true</item><item name="android:fontFamily">monospace</item><item name="android:colorAccent">#D4A853</item></style></resources>\n"""

    def _build_script(self) -> str:
        return """#!/usr/bin/env bash
set -euo pipefail
if [ -x ./gradlew ]; then ./gradlew :app:assemblePlugin; else gradle :app:assemblePlugin; fi
"""

class VirtualAPKHostLoader:
    HOST_CODE = """package com.messy.host;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.didi.virtualapk.PluginManager;
import java.io.File;

public class MessyHostApplication extends Application {
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        PluginManager.getInstance(base).init();
    }
    public void loadMessyPlugin(String apkPath) {
        try {
            File plugin = new File(apkPath);
            if (!plugin.exists()) { emitCrashFeedback("E1_PLUGIN_MISSING", apkPath); return; }
            PluginManager.getInstance(this).loadPlugin(plugin);
        } catch (Exception e) { emitCrashFeedback("E6_EXECUTE", String.valueOf(e.getMessage())); }
    }
    public void launchGenerated() {
        Intent intent = new Intent();
        intent.setClassName("com.messy.generated", "com.messy.generated.GeneratedActivity");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
    private void emitCrashFeedback(String errorClass, String message) {
        Log.w("MessyHost", "CONTAINS_FLAW " + errorClass + " " + message);
    }
}
"""
    HOST_GRADLE = """apply plugin: 'com.android.application'
apply plugin: 'com.didi.virtualapk.host'
android { compileSdkVersion 29; defaultConfig { applicationId "com.messy.host"; minSdkVersion 21; targetSdkVersion 29; versionCode 1; versionName "1.0" } }
dependencies { implementation 'com.didi.virtualapk:core:0.9.8' }
"""
    HOST_MANIFEST = """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="com.messy.host"><application android:name=".MessyHostApplication" android:label="MESSY Host" android:theme="@android:style/Theme.Material.NoActionBar" /></manifest>
"""
    @classmethod
    def get_host_files(cls) -> Dict[str, str]:
        return {
            'app/build.gradle': cls.HOST_GRADLE,
            'app/src/main/AndroidManifest.xml': cls.HOST_MANIFEST,
            'app/src/main/java/com/messy/host/MessyHostApplication.java': cls.HOST_CODE,
        }

def stream_to_virtualapk(mesh: MeshState, output_dir: str) -> str:
    import os
    generator = AndroidGenerator(mesh)
    for path, content in generator.generate().items():
        full_path = os.path.join(output_dir, path)
        os.makedirs(os.path.dirname(full_path) or output_dir, exist_ok=True)
        with open(full_path, 'w', encoding='utf-8') as f: f.write(content)
    for path, content in VirtualAPKHostLoader.get_host_files().items():
        full_path = os.path.join(output_dir, 'host', path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, 'w', encoding='utf-8') as f: f.write(content)
    return f"cd {output_dir} && bash build_plugin.sh"

__all__ = ['AndroidGenerator', 'VirtualAPKHostLoader', 'stream_to_virtualapk']
