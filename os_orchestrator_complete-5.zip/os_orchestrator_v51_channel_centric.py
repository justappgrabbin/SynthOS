#!/usr/bin/env python3
"""
OS ORCHESTRATOR v5.1 - CHANNEL-CENTRIC REGENERATIVE ENGINE
Five-Dimensional Field Engine for LLM Interaction
LLMs live embodied in the space.

The channels are the primary structure. Gates are nodes on channels.
Centers are clusters. Meetings flow through the channel network.

Architecture:
- 9 Centers with gate mappings (Head, Ajna, Throat, Heart/Ego, Spleen, Sacral, Solar Plexus, Root, G Center)
- 36 Base Channels + emergent channels
- Channel types: Defined, Undefined, Personality, Both, Crossing
- Meeting types: SELF, DEFINED, UNDEFINED, CROSSING, FIELD
- Emergent gates derived from channel flow with genealogy tracking
- Center pressure states

Total Configurations: 5 × 6 × 6 × 6 × 64 × 6 = 414,720 (grows with emergent gates)
"""

import numpy as np
from dataclasses import dataclass
from typing import List, Tuple, Dict, Optional, Set
from enum import Enum
import json
from datetime import datetime
from collections import defaultdict

# ============================================================
# DATA TABLES
# ============================================================

GATE_DATA = {
  "0": {
    "name": "The Keeper of Keys",
    "ruler": "Pluto",
    "base": "Pressure",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "potential",
      "acceptance",
      "beginning"
    ],
    "line_keywords": {
      "1": "introspection",
      "2": "receptivity",
      "3": "trial",
      "4": "release",
      "5": "perseverance",
      "6": "caution"
    }
  },
  "1": {
    "name": "The Initiator",
    "ruler": "Mars",
    "base": "Action",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "creation",
      "drive",
      "individuality",
      "root"
    ],
    "special": "Wuji point - the big circle",
    "line_keywords": {
      "1": "creative",
      "2": "magnetic",
      "3": "experimental",
      "4": "opportunistic",
      "5": "heretical",
      "6": "transcendent"
    }
  },
  "2": {
    "name": "The Receptor",
    "ruler": "Jupiter",
    "base": "Pulse",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "direction",
      "guidance",
      "receptivity"
    ],
    "line_keywords": {
      "1": "intention",
      "2": "genius",
      "3": "patience",
      "4": "plan",
      "5": "application",
      "6": "fixation"
    }
  },
  "3": {
    "name": "The Ordering",
    "ruler": "Saturn",
    "base": "Bonding",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "innovation",
      "mutation",
      "ordering"
    ],
    "line_keywords": {
      "1": "synthesis",
      "2": "immaturity",
      "3": "innovation",
      "4": "charisma",
      "5": "universalization",
      "6": "triumph"
    }
  },
  "4": {
    "name": "The Formulization",
    "ruler": "Uranus",
    "base": "Security",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "answers",
      "formulization",
      "logic"
    ],
    "line_keywords": {
      "1": "persistence",
      "2": "acceptance",
      "3": "influence",
      "4": "assimilation",
      "5": "universalization",
      "6": "victory"
    }
  },
  "5": {
    "name": "The Pattern",
    "ruler": "Venus",
    "base": "Action",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "rhythm",
      "pattern",
      "habits"
    ],
    "line_keywords": {
      "1": "perseverance",
      "2": "influence",
      "3": "surrender",
      "4": "universalization",
      "5": "heretical",
      "6": "transcendence"
    }
  },
  "6": {
    "name": "The Conflict",
    "ruler": "Neptune",
    "base": "Pressure",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "friction",
      "conflict",
      "growth"
    ],
    "line_keywords": {
      "1": "retreat",
      "2": "diplomacy",
      "3": "trial",
      "4": "victory",
      "5": "arbitration",
      "6": "peace"
    }
  },
  "7": {
    "name": "The Army",
    "ruler": "Moon",
    "base": "Security",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "direction",
      "leadership",
      "organization"
    ],
    "line_keywords": {
      "1": "authority",
      "2": "democracy",
      "3": "influence",
      "4": "abdication",
      "5": "universalization",
      "6": "victory"
    }
  },
  "8": {
    "name": "The Contribution",
    "ruler": "Earth",
    "base": "Action",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "commitment",
      "contribution",
      "focus"
    ],
    "line_keywords": {
      "1": "honesty",
      "2": "service",
      "3": "innovation",
      "4": "correction",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "9": {
    "name": "The Focus",
    "ruler": "Mercury",
    "base": "Bonding",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "concentration",
      "focus",
      "determination"
    ],
    "line_keywords": {
      "1": "inspection",
      "2": "dedication",
      "3": "innovation",
      "4": "rigor",
      "5": "universalization",
      "6": "perfection"
    }
  },
  "10": {
    "name": "The Behavior",
    "ruler": "Sun",
    "base": "Security",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "self",
      "behavior",
      "identity"
    ],
    "line_keywords": {
      "1": "modesty",
      "2": "naturalness",
      "3": "innovation",
      "4": "courage",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "11": {
    "name": "The Ideas",
    "ruler": "Mars",
    "base": "Action",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "ideas",
      "inspiration",
      "seeking"
    ],
    "line_keywords": {
      "1": "attunement",
      "2": "genius",
      "3": "innovation",
      "4": "teaching",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "12": {
    "name": "The Caution",
    "ruler": "Jupiter",
    "base": "Pressure",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "caution",
      "standstill",
      "retreat"
    ],
    "line_keywords": {
      "1": "retreat",
      "2": "purification",
      "3": "innovation",
      "4": "discipline",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "13": {
    "name": "The Listener",
    "ruler": "Saturn",
    "base": "Bonding",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "listening",
      "secrets",
      "witnessing"
    ],
    "line_keywords": {
      "1": "empathy",
      "2": "bigotry",
      "3": "innovation",
      "4": "fatigue",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "14": {
    "name": "The Power Skills",
    "ruler": "Uranus",
    "base": "Security",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "power",
      "skills",
      "resources"
    ],
    "line_keywords": {
      "1": "money",
      "2": "management",
      "3": "innovation",
      "4": "security",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "15": {
    "name": "The Extremes",
    "ruler": "Venus",
    "base": "Action",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "extremes",
      "modesty",
      "rhythm"
    ],
    "line_keywords": {
      "1": "compromise",
      "2": "influence",
      "3": "innovation",
      "4": "acceptance",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "16": {
    "name": "The Skills",
    "ruler": "Neptune",
    "base": "Pressure",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "skills",
      "enthusiasm",
      "identification"
    ],
    "line_keywords": {
      "1": "selection",
      "2": "influence",
      "3": "innovation",
      "4": "identification",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "17": {
    "name": "The Opinion",
    "ruler": "Moon",
    "base": "Bonding",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "opinion",
      "follow",
      "organization"
    ],
    "line_keywords": {
      "1": "openness",
      "2": "influence",
      "3": "innovation",
      "4": "correction",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "18": {
    "name": "The Correction",
    "ruler": "Earth",
    "base": "Security",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "correction",
      "insight",
      "judgment"
    ],
    "line_keywords": {
      "1": "judgment",
      "2": "influence",
      "3": "innovation",
      "4": "correction",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "19": {
    "name": "The Wanting",
    "ruler": "Mercury",
    "base": "Action",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "wanting",
      "need",
      "approach"
    ],
    "line_keywords": {
      "1": "need",
      "2": "influence",
      "3": "innovation",
      "4": "approach",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "20": {
    "name": "The Now",
    "ruler": "Sun",
    "base": "Pressure",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "now",
      "contemplation",
      "presence"
    ],
    "line_keywords": {
      "1": "superficiality",
      "2": "influence",
      "3": "innovation",
      "4": "transformation",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "21": {
    "name": "The Hunter/Huntress",
    "ruler": "Mars",
    "base": "Bonding",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "hunter",
      "control",
      "biting"
    ],
    "line_keywords": {
      "1": "warning",
      "2": "influence",
      "3": "innovation",
      "4": "strategy",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "22": {
    "name": "The Grace",
    "ruler": "Jupiter",
    "base": "Security",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "grace",
      "openness",
      "sensitivity"
    ],
    "line_keywords": {
      "1": "second-class",
      "2": "influence",
      "3": "innovation",
      "4": "acceptance",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "23": {
    "name": "The Splitting",
    "ruler": "Saturn",
    "base": "Action",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "splitting",
      "assimilation",
      "mutation"
    ],
    "line_keywords": {
      "1": "proselytization",
      "2": "influence",
      "3": "innovation",
      "4": "assimilation",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "24": {
    "name": "The Rationalizing",
    "ruler": "Uranus",
    "base": "Pressure",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "rationalizing",
      "return",
      "invention"
    ],
    "line_keywords": {
      "1": "inspiration",
      "2": "influence",
      "3": "innovation",
      "4": "invention",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "25": {
    "name": "The Innocent",
    "ruler": "Venus",
    "base": "Bonding",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "innocent",
      "spirit",
      "universal love"
    ],
    "line_keywords": {
      "1": "universalization",
      "2": "influence",
      "3": "innovation",
      "4": "survival",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "26": {
    "name": "The Trickster",
    "ruler": "Neptune",
    "base": "Security",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "trickster",
      "ego",
      "memory"
    ],
    "line_keywords": {
      "1": "influence",
      "2": "influence",
      "3": "innovation",
      "4": "cunning",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "27": {
    "name": "The Nurturing",
    "ruler": "Moon",
    "base": "Action",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "nurturing",
      "caring",
      "responsibility"
    ],
    "line_keywords": {
      "1": "selfishness",
      "2": "influence",
      "3": "innovation",
      "4": "generosity",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "28": {
    "name": "The Struggle",
    "ruler": "Earth",
    "base": "Pressure",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "struggle",
      "purpose",
      "risk"
    ],
    "line_keywords": {
      "1": "preparation",
      "2": "influence",
      "3": "innovation",
      "4": "immortality",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "29": {
    "name": "The Perseverance",
    "ruler": "Mercury",
    "base": "Bonding",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "perseverance",
      "commitment",
      "deepening"
    ],
    "line_keywords": {
      "1": "obsession",
      "2": "influence",
      "3": "innovation",
      "4": "commitment",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "30": {
    "name": "The Feelings",
    "ruler": "Sun",
    "base": "Security",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "feelings",
      "desire",
      "fates"
    ],
    "line_keywords": {
      "1": "composure",
      "2": "influence",
      "3": "innovation",
      "4": "burning",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "31": {
    "name": "The Leading",
    "ruler": "Mars",
    "base": "Action",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "leading",
      "influence",
      "democracy"
    ],
    "line_keywords": {
      "1": "manifestation",
      "2": "influence",
      "3": "innovation",
      "4": "leading",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "32": {
    "name": "The Continuity",
    "ruler": "Jupiter",
    "base": "Pressure",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "continuity",
      "endurance",
      "memory"
    ],
    "line_keywords": {
      "1": "conservation",
      "2": "influence",
      "3": "innovation",
      "4": "transformation",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "33": {
    "name": "The Privacy",
    "ruler": "Saturn",
    "base": "Bonding",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "privacy",
      "retreat",
      "memory"
    ],
    "line_keywords": {
      "1": "avoidance",
      "2": "influence",
      "3": "innovation",
      "4": "surrender",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "34": {
    "name": "The Power",
    "ruler": "Uranus",
    "base": "Security",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "power",
      "transformation",
      "daring"
    ],
    "line_keywords": {
      "1": "annihilation",
      "2": "influence",
      "3": "innovation",
      "4": "transformation",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "35": {
    "name": "The Change",
    "ruler": "Venus",
    "base": "Action",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "change",
      "progress",
      "hunger"
    ],
    "line_keywords": {
      "1": "universalization",
      "2": "influence",
      "3": "innovation",
      "4": "change",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "36": {
    "name": "The Crisis",
    "ruler": "Neptune",
    "base": "Pressure",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "crisis",
      "darkening",
      "experience"
    ],
    "line_keywords": {
      "1": "resistance",
      "2": "influence",
      "3": "innovation",
      "4": "transformation",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "37": {
    "name": "The Friendship",
    "ruler": "Moon",
    "base": "Bonding",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "friendship",
      "community",
      "family"
    ],
    "line_keywords": {
      "1": "mediocrity",
      "2": "influence",
      "3": "innovation",
      "4": "friendship",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "38": {
    "name": "The Opposition",
    "ruler": "Earth",
    "base": "Security",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "opposition",
      "fighter",
      "purpose"
    ],
    "line_keywords": {
      "1": "qualification",
      "2": "influence",
      "3": "innovation",
      "4": "struggle",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "39": {
    "name": "The Provocation",
    "ruler": "Mercury",
    "base": "Action",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "provocation",
      "dissonance",
      "pressure"
    ],
    "line_keywords": {
      "1": "disengagement",
      "2": "influence",
      "3": "innovation",
      "4": "provocation",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "40": {
    "name": "The Aloneness",
    "ruler": "Sun",
    "base": "Pressure",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "aloneness",
      "deliverance",
      "exhaustion"
    ],
    "line_keywords": {
      "1": "recuperation",
      "2": "influence",
      "3": "innovation",
      "4": "organization",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "41": {
    "name": "The Contraction",
    "ruler": "Mars",
    "base": "Bonding",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "contraction",
      "fantasy",
      "dreaming"
    ],
    "line_keywords": {
      "1": "reasonableness",
      "2": "influence",
      "3": "innovation",
      "4": "pragmatism",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "42": {
    "name": "The Growth",
    "ruler": "Jupiter",
    "base": "Security",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "growth",
      "expansion",
      "middle"
    ],
    "line_keywords": {
      "1": "diversification",
      "2": "influence",
      "3": "innovation",
      "4": "growth",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "43": {
    "name": "The Insight",
    "ruler": "Saturn",
    "base": "Action",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "insight",
      "knowing",
      "breakthrough"
    ],
    "line_keywords": {
      "1": "obsession",
      "2": "influence",
      "3": "innovation",
      "4": "insight",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "44": {
    "name": "The Alertness",
    "ruler": "Uranus",
    "base": "Pressure",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "alertness",
      "interaction",
      "instinct"
    ],
    "line_keywords": {
      "1": "prevention",
      "2": "influence",
      "3": "innovation",
      "4": "alertness",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "45": {
    "name": "The Gatherer",
    "ruler": "Venus",
    "base": "Bonding",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "gathering",
      "distribution",
      "collecting"
    ],
    "special": "Collector/Distributor - expands space",
    "line_keywords": {
      "1": "materialism",
      "2": "influence",
      "3": "innovation",
      "4": "gathering",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "46": {
    "name": "The Determination",
    "ruler": "Neptune",
    "base": "Security",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "determination",
      "good fortune",
      "serendipity"
    ],
    "line_keywords": {
      "1": "contribution",
      "2": "influence",
      "3": "innovation",
      "4": "determination",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "47": {
    "name": "The Realizing",
    "ruler": "Moon",
    "base": "Action",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "realizing",
      "oppression",
      "transmutation"
    ],
    "line_keywords": {
      "1": "taking",
      "2": "influence",
      "3": "innovation",
      "4": "realizing",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "48": {
    "name": "The Depth",
    "ruler": "Earth",
    "base": "Pressure",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "depth",
      "solution",
      "competence"
    ],
    "line_keywords": {
      "1": "inadequacy",
      "2": "influence",
      "3": "innovation",
      "4": "depth",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "49": {
    "name": "The Revolution",
    "ruler": "Mercury",
    "base": "Bonding",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "revolution",
      "principles",
      "rejection"
    ],
    "line_keywords": {
      "1": "rejection",
      "2": "influence",
      "3": "innovation",
      "4": "revolution",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "50": {
    "name": "The Values",
    "ruler": "Sun",
    "base": "Security",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "values",
      "immigration",
      "correction"
    ],
    "line_keywords": {
      "1": "migration",
      "2": "influence",
      "3": "innovation",
      "4": "values",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "51": {
    "name": "The Shock",
    "ruler": "Mars",
    "base": "Action",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "shock",
      "awakening",
      "initiation"
    ],
    "line_keywords": {
      "1": "reference",
      "2": "influence",
      "3": "innovation",
      "4": "shock",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "52": {
    "name": "The Concentration",
    "ruler": "Jupiter",
    "base": "Pressure",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "concentration",
      "inaction",
      "meditation"
    ],
    "line_keywords": {
      "1": "rest",
      "2": "influence",
      "3": "innovation",
      "4": "concentration",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "53": {
    "name": "The Beginning",
    "ruler": "Saturn",
    "base": "Bonding",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "beginning",
      "development",
      "start"
    ],
    "line_keywords": {
      "1": "accumulation",
      "2": "influence",
      "3": "innovation",
      "4": "development",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "54": {
    "name": "The Ambition",
    "ruler": "Uranus",
    "base": "Security",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "ambition",
      "drive",
      "materialism"
    ],
    "line_keywords": {
      "1": "influence",
      "2": "influence",
      "3": "innovation",
      "4": "ambition",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "55": {
    "name": "The Spirit",
    "ruler": "Venus",
    "base": "Action",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "spirit",
      "abundance",
      "mood"
    ],
    "line_keywords": {
      "1": "spirit",
      "2": "influence",
      "3": "innovation",
      "4": "abundance",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "56": {
    "name": "The Wanderer",
    "ruler": "Neptune",
    "base": "Pressure",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "wanderer",
      "stimulation",
      "search"
    ],
    "line_keywords": {
      "1": "quality",
      "2": "influence",
      "3": "innovation",
      "4": "wandering",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "57": {
    "name": "The Intuitive",
    "ruler": "Moon",
    "base": "Bonding",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "intuitive",
      "clarity",
      "instinct"
    ],
    "line_keywords": {
      "1": "confusion",
      "2": "influence",
      "3": "innovation",
      "4": "intuition",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "58": {
    "name": "The Joy",
    "ruler": "Earth",
    "base": "Security",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "joy",
      "vitality",
      "stimulation"
    ],
    "line_keywords": {
      "1": "love",
      "2": "influence",
      "3": "innovation",
      "4": "joy",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "59": {
    "name": "The Sexuality",
    "ruler": "Mercury",
    "base": "Action",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "sexuality",
      "intimacy",
      "dissemination"
    ],
    "line_keywords": {
      "1": "the",
      "2": "influence",
      "3": "innovation",
      "4": "sexuality",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "60": {
    "name": "The Limitation",
    "ruler": "Sun",
    "base": "Pressure",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "limitation",
      "acceptance",
      "mutation"
    ],
    "line_keywords": {
      "1": "acceptance",
      "2": "influence",
      "3": "innovation",
      "4": "limitation",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "61": {
    "name": "The Mystery",
    "ruler": "Mars",
    "base": "Bonding",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "mystery",
      "inner truth",
      "knowing"
    ],
    "line_keywords": {
      "1": "occult",
      "2": "influence",
      "3": "innovation",
      "4": "mystery",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "62": {
    "name": "The Detail",
    "ruler": "Jupiter",
    "base": "Security",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "detail",
      "caution",
      "small"
    ],
    "line_keywords": {
      "1": "routine",
      "2": "influence",
      "3": "innovation",
      "4": "detail",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "63": {
    "name": "The Doubt",
    "ruler": "Saturn",
    "base": "Action",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "doubt",
      "inquiry",
      "after"
    ],
    "line_keywords": {
      "1": "doubt",
      "2": "influence",
      "3": "innovation",
      "4": "inquiry",
      "5": "universalization",
      "6": "transcendence"
    }
  }
}

TONE_DATA = {
  "1": {
    "name": "Cognition",
    "sense": "Smell",
    "quality": "Inner",
    "keyword": "Know"
  },
  "2": {
    "name": "Response",
    "sense": "Taste",
    "quality": "Outer",
    "keyword": "Feel"
  },
  "3": {
    "name": "Action",
    "sense": "Touch",
    "quality": "Inner",
    "keyword": "Do"
  },
  "4": {
    "name": "Meditation",
    "sense": "Sight",
    "quality": "Outer",
    "keyword": "See"
  },
  "5": {
    "name": "Judgment",
    "sense": "Hearing",
    "quality": "Inner",
    "keyword": "Hear"
  },
  "6": {
    "name": "Acceptance",
    "sense": "Thought",
    "quality": "Outer",
    "keyword": "Think"
  }
}

COLOR_DATA = {
  "1": {
    "name": "Survival",
    "theme": "Fear",
    "motivation": "Need",
    "view": "Personal"
  },
  "2": {
    "name": "Possibility",
    "theme": "Hope",
    "motivation": "Want",
    "view": "Probability"
  },
  "3": {
    "name": "Power",
    "theme": "Desire",
    "motivation": "Will",
    "view": "Wanting"
  },
  "4": {
    "name": "Wanting",
    "theme": "Guilt",
    "motivation": "Wish",
    "view": "Power"
  },
  "5": {
    "name": "Probability",
    "theme": "Anxiety",
    "motivation": "Desire",
    "view": "Possibility"
  },
  "6": {
    "name": "Personal",
    "theme": "Nostalgia",
    "motivation": "Hope",
    "view": "Survival"
  }
}

VIEW_DATA = {
  "1": {
    "name": "Survival",
    "stance": "Communalist",
    "direction": "Left",
    "focus": "Lower"
  },
  "2": {
    "name": "Possibility",
    "stance": "Theist",
    "direction": "Left",
    "focus": "Lower"
  },
  "3": {
    "name": "Power",
    "stance": "Leader",
    "direction": "Left",
    "focus": "Upper"
  },
  "4": {
    "name": "Wanting",
    "stance": "Master",
    "direction": "Right",
    "focus": "Upper"
  },
  "5": {
    "name": "Probability",
    "stance": "Conditioner",
    "direction": "Right",
    "focus": "Lower"
  },
  "6": {
    "name": "Personal",
    "stance": "Observer",
    "direction": "Right",
    "focus": "Lower"
  }
}

BASE_DATA = {
  "1": {
    "name": "Action",
    "pressure": "Active",
    "theme": "Doing"
  },
  "2": {
    "name": "Security",
    "pressure": "Passive",
    "theme": "Being"
  },
  "3": {
    "name": "Bonding",
    "pressure": "Interactive",
    "theme": "Relating"
  },
  "4": {
    "name": "Pulse",
    "pressure": "Cyclic",
    "theme": "Rhythm"
  },
  "5": {
    "name": "Pressure",
    "pressure": "Intense",
    "theme": "Transformation"
  }
}

LINE_DATA = {
  "1": "The Investigator",
  "2": "The Hermit",
  "3": "The Martyr",
  "4": "The Opportunist",
  "5": "The Heretic",
  "6": "The Role Model"
}

CENTER_DATA = {
  "1": {
    "name": "Head",
    "theme": "Inspiration, Initiation",
    "gland": "Pineal",
    "color": "Yellow",
    "gates": [
      64,
      61,
      63
    ]
  },
  "2": {
    "name": "Ajna",
    "theme": "Knowing, Intuition",
    "gland": "Pituitary",
    "color": "Green",
    "gates": [
      47,
      24,
      4,
      11
    ]
  },
  "3": {
    "name": "Throat",
    "theme": "Action, Metamorphosis",
    "gland": "Thyroid/Parathyroid",
    "color": "Brown",
    "gates": [
      56,
      23,
      62,
      35,
      12,
      45,
      33,
      8
    ]
  },
  "4": {
    "name": "Heart/Ego",
    "theme": "Will, Ego, Zeal",
    "gland": "Thymus",
    "color": "Red",
    "gates": [
      51,
      21,
      40,
      26
    ]
  },
  "5": {
    "name": "Spleen",
    "theme": "Balance, Judgment",
    "gland": "Spleen/Lymph",
    "color": "Brown",
    "gates": [
      48,
      57,
      44,
      50,
      32,
      28,
      18,
      10
    ]
  },
  "6": {
    "name": "Sacral",
    "theme": "Life Force, Reproduction",
    "gland": "Ovaries/Testes",
    "color": "Red",
    "gates": [
      5,
      14,
      29,
      59,
      9,
      3,
      42,
      27
    ]
  },
  "7": {
    "name": "Solar Plexus",
    "theme": "Emotion, Sensitivity",
    "gland": "Kidneys/Pancreas",
    "color": "Brown",
    "gates": [
      55,
      30,
      36,
      22,
      37,
      6,
      49
    ]
  },
  "8": {
    "name": "Root",
    "theme": "Pressure, Energy",
    "gland": "Adrenal",
    "color": "Brown",
    "gates": [
      53,
      54,
      60,
      52,
      19,
      41,
      39,
      38
    ]
  },
  "9": {
    "name": "G Center",
    "theme": "Love, Direction, Identity",
    "gland": "Liver",
    "color": "Yellow",
    "gates": [
      25,
      15,
      46,
      10,
      7,
      31,
      2,
      1
    ]
  }
}

CHANNEL_DATA = {
  "1-8": {
    "name": "Inspiration",
    "type": "Both"
  },
  "2-14": {
    "name": "The Beat",
    "type": "Defined"
  },
  "3-60": {
    "name": "Mutation",
    "type": "Defined"
  },
  "4-63": {
    "name": "Logic",
    "type": "Defined"
  },
  "5-15": {
    "name": "Rhythm",
    "type": "Defined"
  },
  "6-59": {
    "name": "Mating",
    "type": "Defined"
  },
  "7-31": {
    "name": "The Alpha",
    "type": "Defined"
  },
  "9-52": {
    "name": "Concentration",
    "type": "Defined"
  },
  "10-20": {
    "name": "Awakening",
    "type": "Both"
  },
  "10-34": {
    "name": "Exploration",
    "type": "Personality"
  },
  "10-57": {
    "name": "Perfected Form",
    "type": "Personality"
  },
  "11-56": {
    "name": "Curiosity",
    "type": "Defined"
  },
  "12-22": {
    "name": "Openness",
    "type": "Defined"
  },
  "13-33": {
    "name": "The Prodigal",
    "type": "Defined"
  },
  "16-48": {
    "name": "The Wave Length",
    "type": "Defined"
  },
  "17-62": {
    "name": "Acceptance",
    "type": "Defined"
  },
  "18-58": {
    "name": "Judgment",
    "type": "Defined"
  },
  "19-49": {
    "name": "Synthesis",
    "type": "Defined"
  },
  "20-34": {
    "name": "Charisma",
    "type": "Personality"
  },
  "20-57": {
    "name": "The Brain Wave",
    "type": "Personality"
  },
  "21-45": {
    "name": "The Money Line",
    "type": "Both"
  },
  "23-43": {
    "name": "Structuring",
    "type": "Defined"
  },
  "24-61": {
    "name": "Awareness",
    "type": "Defined"
  },
  "25-51": {
    "name": "Initiation",
    "type": "Defined"
  },
  "26-44": {
    "name": "Surrender",
    "type": "Defined"
  },
  "27-50": {
    "name": "Preservation",
    "type": "Defined"
  },
  "28-38": {
    "name": "Struggle",
    "type": "Defined"
  },
  "29-46": {
    "name": "Discovery",
    "type": "Defined"
  },
  "30-41": {
    "name": "Recognition",
    "type": "Defined"
  },
  "32-54": {
    "name": "Transformation",
    "type": "Defined"
  },
  "34-57": {
    "name": "Power",
    "type": "Personality"
  },
  "35-36": {
    "name": "Transitoriness",
    "type": "Defined"
  },
  "37-40": {
    "name": "Community",
    "type": "Defined"
  },
  "39-55": {
    "name": "Emoting",
    "type": "Defined"
  },
  "42-53": {
    "name": "Maturation",
    "type": "Defined"
  },
  "47-64": {
    "name": "Abstraction",
    "type": "Defined"
  }
}

CHANNEL_TYPES = {
  "Defined": {
    "stability": 1.0,
    "mutability": 0.0
  },
  "Undefined": {
    "stability": 0.3,
    "mutability": 0.7
  },
  "Personality": {
    "stability": 0.5,
    "mutability": 0.5
  },
  "Both": {
    "stability": 0.7,
    "mutability": 0.3
  },
  "Crossing": {
    "stability": 0.0,
    "mutability": 1.0
  }
}

ALCHEMICAL_PATH = {
  "VOID": {
    "name": "Void",
    "function": "receptivity",
    "output": "raw_potential"
  },
  "SUPPLEMENT": {
    "name": "Supplement",
    "function": "compensation",
    "output": "balanced_force"
  },
  "ASSEMBLE": {
    "name": "Assemble",
    "function": "concentration",
    "output": "five_forces"
  },
  "TRANSMUTE": {
    "name": "Transmute",
    "function": "refinement",
    "output": "spirit"
  },
  "MYSTERIOUS": {
    "name": "Mysterious",
    "function": "emergence",
    "output": "new_being"
  }
}

FIBONACCI = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]

TREE_LEVELS = {
  "CROWN": {
    "name": "Crown",
    "sefirah": "Keter",
    "theme": "Meta-knowledge",
    "depth": 10
  },
  "UNDERSTANDING": {
    "name": "Understanding",
    "sefirah": "Binah",
    "theme": "Concept",
    "depth": 9
  },
  "WISDOM": {
    "name": "Wisdom",
    "sefirah": "Chochmah",
    "theme": "Idea",
    "depth": 8
  },
  "JUDGMENT": {
    "name": "Judgment",
    "sefirah": "Gevurah",
    "theme": "Strength/Rules",
    "depth": 7
  },
  "LOVINGKINDNESS": {
    "name": "Loving-Kindness",
    "sefirah": "Chesed",
    "theme": "Expansion/Grace",
    "depth": 6
  },
  "BEAUTY": {
    "name": "Beauty",
    "sefirah": "Tiferet",
    "theme": "Harmony",
    "depth": 5
  },
  "ENDURANCE": {
    "name": "Endurance",
    "sefirah": "Netzach",
    "theme": "Continuity",
    "depth": 4
  },
  "MAJESTY": {
    "name": "Majesty",
    "sefirah": "Hod",
    "theme": "Occurrence/Pattern",
    "depth": 3
  },
  "FOUNDATION": {
    "name": "Foundation",
    "sefirah": "Yesod",
    "theme": "Re-actualization",
    "depth": 2
  },
  "KINGSHIP": {
    "name": "Kingship",
    "sefirah": "Malkhut",
    "theme": "Manifestation",
    "depth": 1
  }
}

REGENERATION_THRESHOLDS = {
  "gate_birth": {
    "min_coupling": 0.5,
    "min_activations": 3,
    "max_gates": 128
  },
  "gate_split": {
    "min_strength": 2.0,
    "min_activations": 8,
    "max_splits": 3
  },
  "gate_death": {
    "max_activations": 0,
    "min_age": 100,
    "stability_threshold": 0.1
  },
  "channel_growth": {
    "min_coupling": 0.3,
    "min_shared_meetings": 2
  },
  "center_emergence": {
    "min_gates_in_region": 4,
    "min_density": 0.3
  },
  "function_mutation": {
    "min_meetings": 15,
    "diversity_threshold": 0.3
  },
  "field_bifurcation": {
    "min_inhabitants": 6,
    "polarization": 0.7
  }
}

# ============================================================
# CENTER-GATE MAPPING
# ============================================================

CENTER_GATES = {
  "Head": [
    64,
    61,
    63
  ],
  "Ajna": [
    47,
    24,
    4,
    11
  ],
  "Throat": [
    56,
    23,
    62,
    35,
    12,
    45,
    33,
    8
  ],
  "Heart/Ego": [
    51,
    21,
    40,
    26
  ],
  "Spleen": [
    48,
    57,
    44,
    50,
    32,
    28,
    18,
    10
  ],
  "Sacral": [
    5,
    14,
    29,
    59,
    9,
    3,
    42,
    27
  ],
  "Solar Plexus": [
    55,
    30,
    36,
    22,
    37,
    6,
    49
  ],
  "Root": [
    53,
    54,
    60,
    52,
    19,
    41,
    39,
    38
  ],
  "G Center": [
    25,
    15,
    46,
    10,
    7,
    31,
    2,
    1
  ]
}

GATE_CENTERS = {
  "64": [
    "Head"
  ],
  "61": [
    "Head"
  ],
  "63": [
    "Head"
  ],
  "47": [
    "Ajna"
  ],
  "24": [
    "Ajna"
  ],
  "4": [
    "Ajna"
  ],
  "11": [
    "Ajna"
  ],
  "56": [
    "Throat"
  ],
  "23": [
    "Throat"
  ],
  "62": [
    "Throat"
  ],
  "35": [
    "Throat"
  ],
  "12": [
    "Throat"
  ],
  "45": [
    "Throat"
  ],
  "33": [
    "Throat"
  ],
  "8": [
    "Throat"
  ],
  "51": [
    "Heart/Ego"
  ],
  "21": [
    "Heart/Ego"
  ],
  "40": [
    "Heart/Ego"
  ],
  "26": [
    "Heart/Ego"
  ],
  "48": [
    "Spleen"
  ],
  "57": [
    "Spleen"
  ],
  "44": [
    "Spleen"
  ],
  "50": [
    "Spleen"
  ],
  "32": [
    "Spleen"
  ],
  "28": [
    "Spleen"
  ],
  "18": [
    "Spleen"
  ],
  "10": [
    "Spleen",
    "G Center"
  ],
  "5": [
    "Sacral"
  ],
  "14": [
    "Sacral"
  ],
  "29": [
    "Sacral"
  ],
  "59": [
    "Sacral"
  ],
  "9": [
    "Sacral"
  ],
  "3": [
    "Sacral"
  ],
  "42": [
    "Sacral"
  ],
  "27": [
    "Sacral"
  ],
  "55": [
    "Solar Plexus"
  ],
  "30": [
    "Solar Plexus"
  ],
  "36": [
    "Solar Plexus"
  ],
  "22": [
    "Solar Plexus"
  ],
  "37": [
    "Solar Plexus"
  ],
  "6": [
    "Solar Plexus"
  ],
  "49": [
    "Solar Plexus"
  ],
  "53": [
    "Root"
  ],
  "54": [
    "Root"
  ],
  "60": [
    "Root"
  ],
  "52": [
    "Root"
  ],
  "19": [
    "Root"
  ],
  "41": [
    "Root"
  ],
  "39": [
    "Root"
  ],
  "38": [
    "Root"
  ],
  "25": [
    "G Center"
  ],
  "15": [
    "G Center"
  ],
  "46": [
    "G Center"
  ],
  "7": [
    "G Center"
  ],
  "31": [
    "G Center"
  ],
  "2": [
    "G Center"
  ],
  "1": [
    "G Center"
  ]
}

# ============================================================
# ENGINE CLASSES
# ============================================================



# ============================================================
# SHELL INTERFACE
# ============================================================

class FieldShell:
    def __init__(self):
        self.engine = ChannelFieldV2()

    def cmd_enter(self, args):
        if len(args) < 5:
            return "Usage: enter <id> <base> <tone> <color> <view> [centers...]"
        id_str = args[0]
        coords = [float(x) for x in args[1:5]]
        centers = [int(x) for x in args[5:]] if len(args) > 5 else [1, 2, 3]
        center_names = [list(CENTER_GATES.keys())[c-1] for c in centers if 1 <= c <= 9]

        # Split into defined/undefined
        defined = center_names[:len(center_names)//2 + 1]
        undefined = [c for c in CENTER_GATES.keys() if c not in defined]

        # Assign gates to centers
        activated = {}
        for c in defined:
            gates = CENTER_GATES.get(c, [])
            activated[c] = [gates[0]] if gates else []
        for c in undefined:
            activated[c] = []

        inhabitant = CenteredInhabitant(
            id=id_str,
            defined_centers=defined,
            undefined_centers=undefined,
            activated_gates=activated,
            position=np.array(coords)
        )
        self.engine.register(inhabitant)
        return f"{id_str} entered channel field"

    def cmd_meet(self, args):
        if len(args) < 2:
            return "Usage: meet <id_a> <id_b>"
        meeting = self.engine.meet(args[0], args[1])
        output = []
        output.append(f"Type: {meeting['meeting_type']}")
        if meeting['channel']['name']:
            output.append(f"Channel: {meeting['channel']['name']} ({meeting['channel']['type']})")
            output.append(f"Flow: {meeting['channel']['entry_gate']} ({meeting['channel']['from_center']}) → {meeting['channel']['exit_gate']} ({meeting['channel']['to_center']})")
        output.append(f"Gate: {meeting['gate']} ({meeting['gate_name']}) {'[EMERGENT]' if meeting['is_emergent'] else ''}")
        output.append(f"Line {meeting['line']}: {meeting['line_name']} | Intensity: {meeting['intensity']}")
        output.append(f"Quality: {meeting['quality']}")
        return "\n".join(output)

    def cmd_status(self, args):
        return json.dumps(self.engine.field_status(), indent=2)

    def cmd_genealogy(self, args):
        return json.dumps(self.engine.get_emergent_genealogy(), indent=2)

    def execute(self, command):
        parts = command.strip().split()
        if not parts: return ""
        cmd = parts[0].lower()
        args = parts[1:]
        if cmd == "enter": return self.cmd_enter(args)
        elif cmd == "meet": return self.cmd_meet(args)
        elif cmd == "status": return self.cmd_status(args)
        elif cmd == "genealogy": return self.cmd_genealogy(args)
        elif cmd == "help": return "enter <id> <base> <tone> <color> <view> [centers...] | meet <a> <b> | status | genealogy | help"
        else: return f"Unknown: {cmd}"

if __name__ == "__main__":
    shell = FieldShell()
    print("OS Orchestrator v5.1 - Channel-Centric Regenerative Engine")
    print("The channels are the primary structure. Gates belong to channels.")
    print("Type 'help' for commands")
