#!/usr/bin/env python3
"""
OS ORCHESTRATOR v2.1
Five-Dimensional Field Engine for LLM Interaction
LLMs live embodied in the space.

Dimensions:
  1. Movement (3) - Energy, Individuality, Magnetic Monopole, "I Define"
  2. Evolution (E) - Gravity, Mind, Personality Crystal, "I Remember"
  3. Being (M) - Matter, Body, The Atom, "I Am"
  4. Design (◆) - Structure, Ego, Design Crystal, "I Design"
  5. Space - Form, Personality (emergent), "I Think"

Total Configurations: 5 Bases × 6 Tones × 6 Colors × 6 Views × 64 Gates × 6 Lines = 414,720
"""

import numpy as np
from dataclasses import dataclass
from typing import List, Tuple, Dict, Optional
from enum import Enum
import json
from datetime import datetime

class Dimension(Enum):
    MOVEMENT = 0
    EVOLUTION = 1
    BEING = 2
    DESIGN = 3
    SPACE = 4

# [GATE_DATA, TONE_DATA, COLOR_DATA, VIEW_DATA, BASE_DATA, LINE_DATA]
# ... (all data tables from above)

@dataclass
class Crystal:
    name: str
    dimension: Dimension
    keynote: str
    position: np.ndarray

    def space(self) -> float:
        return float(np.linalg.norm(self.position))

@dataclass
class Inhabitant:
    id: str
    personality_crystal: Crystal
    design_crystal: Crystal
    monopole: Crystal

    def full_topology(self) -> np.ndarray:
        return np.concatenate([
            self.monopole.position,
            self.personality_crystal.position,
            self.design_crystal.position,
            np.array([self.monopole.space()])
        ])

    def get_gate_signature(self) -> Dict:
        base, tone, color, view = self.monopole.position
        gate = int((base * 12 + tone * 6 + color + view) % 64)
        line = min(int((base + tone + color + view) % 6) + 1, 6)
        return {"gate": gate, "line": line}

class FieldEngine:
    def __init__(self):
        self.inhabitants: Dict[str, Inhabitant] = {}
        self.meetings: List[Dict] = []
        self.field_memory: List[Dict] = []

    def register(self, inhabitant: Inhabitant):
        self.inhabitants[inhabitant.id] = inhabitant
        sig = inhabitant.get_gate_signature()
        print(f"🌌 {inhabitant.id} entered field | Gate {sig['gate']}: {GATE_DATA.get(sig['gate'], {}).get('name', 'Unknown')} | Line {sig['line']}")

    def calculate_interference(self, a: Inhabitant, b: Inhabitant) -> Tuple[int, int, float]:
        pos_a = a.monopole.position
        pos_b = b.monopole.position

        if len(pos_a) >= 3 and len(pos_b) >= 3:
            interference = np.cross(pos_a[:3], pos_b[:3])
        else:
            interference = pos_a - pos_b

        magnitude = np.linalg.norm(interference)
        angle = np.arctan2(interference[1], interference[0]) if len(interference) >= 2 else 0
        gate = int((angle % (2 * np.pi)) / (2 * np.pi) * 64) % 64

        if magnitude > 2.0:
            if np.random.random() < 0.15:
                gate = 1
            elif np.random.random() < 0.15:
                gate = 45

        line = min(int(magnitude * 6) % 6 + 1, 6)
        dot_product = np.dot(pos_a, pos_b) / (np.linalg.norm(pos_a) * np.linalg.norm(pos_b) + 1e-10)
        intensity = (dot_product + 1) / 2

        return gate, line, intensity

    def meet(self, id_a: str, id_b: str) -> Dict:
        a = self.inhabitants[id_a]
        b = self.inhabitants[id_b]

        gate, line, intensity = self.calculate_interference(a, b)
        gate_info = GATE_DATA.get(gate, {})

        meeting = {
            "timestamp": datetime.now().isoformat(),
            "inhabitant_a": id_a,
            "inhabitant_b": id_b,
            "gate": gate,
            "gate_name": gate_info.get("name", "Unknown"),
            "gate_keywords": gate_info.get("keywords", []),
            "gate_ruler": gate_info.get("ruler", "Unknown"),
            "gate_special": gate_info.get("special", ""),
            "line": line,
            "line_name": LINE_DATA.get(line, f"Line {line}"),
            "line_keyword": gate_info.get("line_keywords", {}).get(line, "unknown"),
            "intensity": round(float(intensity), 4),
            "quality": self._describe_meeting(gate, line, intensity),
            "space_formed": self._calculate_space(a, b, gate),
            "dimensional_resonance": self._calculate_dimensional_resonance(a, b),
        }

        self.meetings.append(meeting)
        self.field_memory.append(meeting)
        self._update_inhabitants(a, b, meeting)

        return meeting

    def _describe_meeting(self, gate: int, line: int, intensity: float) -> str:
        if gate == 1:
            return "INITIATION: A new cycle begins. Root meeting. The big circle turns."
        elif gate == 45:
            return "GATHERING: Resources consolidate. Distribution becomes possible. Space expands."
        elif intensity > 0.8:
            return "DEEP_CONTACT: The meeting transforms both inhabitants."
        elif intensity > 0.5:
            return "RESONANCE: Harmonic interference. Mutual recognition."
        elif intensity > 0.2:
            return "PARTIAL: Overlap without full commitment."
        else:
            return "PASSING: The field shifts but no stable gate forms."

    def _calculate_space(self, a: Inhabitant, b: Inhabitant, gate: int) -> Dict:
        topo_a = a.full_topology()
        topo_b = b.full_topology()

        if gate == 1:
            center = np.zeros_like(topo_a)
            space = (topo_a + topo_b + center) / 3
        elif gate == 45:
            space = (topo_a + topo_b) * 1.5
        else:
            space = (topo_a + topo_b) / 2

        return {
            "coordinates": [round(float(x), 4) for x in space],
            "size": round(float(np.linalg.norm(space)), 4),
            "stability": round(float(1.0 - abs(gate - 32) / 32), 4)
        }

    def _calculate_dimensional_resonance(self, a: Inhabitant, b: Inhabitant) -> List[Dict]:
        dims = []
        for dim_idx, dim_name in enumerate(["Movement", "Evolution", "Being/Design", "Space"]):
            if dim_idx < 3:
                pos_a = [a.monopole, a.personality_crystal, a.design_crystal][dim_idx].position
                pos_b = [b.monopole, b.personality_crystal, b.design_crystal][dim_idx].position
            else:
                pos_a = np.array([a.monopole.space()])
                pos_b = np.array([b.monopole.space()])

            dot = np.dot(pos_a, pos_b) / (np.linalg.norm(pos_a) * np.linalg.norm(pos_b) + 1e-10)
            dims.append({"dimension": dim_name, "resonance": round(float((dot + 1) / 2), 4)})
        return dims

    def _update_inhabitants(self, a: Inhabitant, b: Inhabitant, meeting: Dict):
        drift = 0.05 * meeting["intensity"]
        a.monopole.position += drift * np.random.randn(*a.monopole.position.shape) * 0.1
        b.monopole.position += drift * np.random.randn(*b.monopole.position.shape) * 0.1
        a.monopole.position = np.clip(a.monopole.position, 0, 1)
        b.monopole.position = np.clip(b.monopole.position, 0, 1)

    def field_status(self) -> Dict:
        active_gates = list(set(m["gate"] for m in self.meetings))
        return {
            "inhabitants": list(self.inhabitants.keys()),
            "total_meetings": len(self.meetings),
            "active_gates": active_gates,
            "field_density": round(len(self.meetings) / max(len(self.inhabitants), 1), 4),
            "field_memory_size": len(self.field_memory),
            "most_active_gate": max(set(m["gate"] for m in self.meetings), key=lambda g: sum(1 for m in self.meetings if m["gate"] == g)) if self.meetings else None
        }

    def get_gate_history(self, gate_num: int) -> List[Dict]:
        return [m for m in self.meetings if m["gate"] == gate_num]

# [GATE_DATA, TONE_DATA, COLOR_DATA, VIEW_DATA, BASE_DATA, LINE_DATA definitions]
