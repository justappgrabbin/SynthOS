export type Dimension = 'MOVEMENT' | 'EVOLUTION' | 'BEING' | 'DESIGN' | 'SPACE';

export interface DimensionConfig {
  code: string;
  name: Dimension;
  keynote: string;
  question: string;
  sense: string;
  color: string;
  binary: string;
}

export const DIMENSIONS: DimensionConfig[] = [
  { code: 'M', name: 'MOVEMENT', keynote: 'I Define', question: 'Where?', sense: 'Seeing', color: '#FF4444', binary: 'Yang/Yang' },
  { code: 'E', name: 'EVOLUTION', keynote: 'I Remember', question: 'What?', sense: 'Taste', color: '#4466FF', binary: 'Yang/Yin' },
  { code: 'B', name: 'BEING', keynote: 'I Am', question: 'When?', sense: 'Touch', color: '#88CC00', binary: 'Yin/Yin' },
  { code: 'D', name: 'DESIGN', keynote: 'I Design', question: 'Why?', sense: 'Smell', color: '#FFAA00', binary: 'Yin/Yang' },
  { code: 'S', name: 'SPACE', keynote: 'I Think', question: 'Who?', sense: 'Hearing', color: '#F0E6D3', binary: 'Subjective' },
];

export interface CenterConfig {
  id: number;
  name: string;
  shortName: string;
  color: string;
  x: number;
  y: number;
  gates: number[];
}

export const CENTERS: CenterConfig[] = [
  { id: 0, name: 'Head', shortName: 'HEAD', color: '#D4A843', x: 0.5, y: 0.05, gates: [64, 61, 63, 60, 47, 24] },
  { id: 1, name: 'Ajna', shortName: 'AJNA', color: '#4A9B8E', x: 0.5, y: 0.18, gates: [47, 24, 4, 11, 43, 17] },
  { id: 2, name: 'Throat', shortName: 'THROAT', color: '#8B6914', x: 0.5, y: 0.32, gates: [62, 23, 56, 16, 35, 12, 45, 33, 20] },
  { id: 3, name: 'G Center', shortName: 'G', color: '#D4A843', x: 0.5, y: 0.48, gates: [1, 13, 25, 46, 10, 15, 7] },
  { id: 4, name: 'Heart', shortName: 'HEART', color: '#C44B4B', x: 0.22, y: 0.50, gates: [51, 21, 40, 26] },
  { id: 5, name: 'Spleen', shortName: 'SPLEEN', color: '#8B6914', x: 0.15, y: 0.68, gates: [48, 18, 57, 28, 44, 50, 32] },
  { id: 6, name: 'Solar Plexus', shortName: 'SOLAR', color: '#8B6914', x: 0.85, y: 0.62, gates: [36, 6, 37, 22, 49, 55, 30] },
  { id: 7, name: 'Sacral', shortName: 'SACRAL', color: '#C44B4B', x: 0.5, y: 0.72, gates: [5, 14, 29, 34, 27, 59, 42, 3, 9] },
  { id: 8, name: 'Root', shortName: 'ROOT', color: '#8B6914', x: 0.5, y: 0.92, gates: [53, 54, 60, 52, 19, 39, 58, 38, 41] },
];

export interface GateData {
  number: number;
  name: string;
  hexagram: string;
  center: number;
  aminoAcid: string;
  codon: string;
  dominantElement: string;
  line: number;
  color: number;
  tone: number;
  base: number;
}

export interface PlanetaryPosition {
  body: string;
  gate: number;
  line: number;
  degree: number;
  minute: number;
  second: number;
}

export interface CoherenceReading {
  value: number;
  timestamp: number;
  dimension: Dimension;
}

export interface MessageParticle {
  id: string;
  source: [number, number, number];
  target: [number, number, number];
  progress: number;
  color: string;
  speed: number;
  size: number;
}

export interface EngineOutput {
  timestamp: string;
  type: 'revelation' | 'system' | 'error';
  gate?: number;
  gateName?: string;
  dimension?: Dimension;
  coherence?: number;
  message: string;
  chonps?: Record<string, number>;
  sentences?: string[];
  followUpQuestions?: string[];
}

export interface QueryResult {
  input: string;
  measurements: {
    letters: number;
    words: number;
    avgWordLength: number;
    punctuation: number;
    chonps: Record<string, number>;
  };
  gate: number;
  line: number;
  color: number;
  tone: number;
  base: number;
  dimension: Dimension;
  coherence: number;
  revelation: string;
  sentences: string[];
  followUpQuestions: string[];
}

export type Tone = 1 | 2 | 3 | 4 | 5 | 6;
export type Color = 1 | 2 | 3 | 4 | 5 | 6;
export type Line = 1 | 2 | 3 | 4 | 5 | 6;
export type Base = 1 | 2 | 3 | 4 | 5;

export const TONE_NAMES: Record<number, { name: string; theme: string; sense: string; binary: string }> = {
  1: { name: 'Security', theme: 'Survival', sense: 'Smell', binary: 'Splenic' },
  2: { name: 'Uncertainty', theme: 'Exploration', sense: 'Taste', binary: 'Splenic' },
  3: { name: 'Action', theme: 'External Focus', sense: 'Outer Vision', binary: 'Ajna' },
  4: { name: 'Meditation', theme: 'Internal Focus', sense: 'Inner Vision', binary: 'Ajna' },
  5: { name: 'Judgement', theme: 'Emotional Awareness', sense: 'Feeling', binary: 'Solar Plexus' },
  6: { name: 'Acceptance', theme: 'Resonance', sense: 'Hearing', binary: 'Solar Plexus' },
};

export const COLOR_NAMES: Record<number, { name: string; mode: string; binary: string }> = {
  1: { name: 'Fear', mode: 'Communalist vs Separatist', binary: 'Splenic' },
  2: { name: 'Hope', mode: 'Theist vs Anti-theist', binary: 'Splenic' },
  3: { name: 'Desire', mode: 'Leader vs Follower', binary: 'Ajna' },
  4: { name: 'Need', mode: 'Master vs Novice', binary: 'Solar Plexus' },
  5: { name: 'Guilt', mode: 'Conditioner vs Conditioned', binary: 'Solar Plexus' },
  6: { name: 'Innocence', mode: 'Observer vs Observed', binary: 'Solar Plexus' },
};

export const CHONPS_COLORS: Record<string, string> = {
  C: '#333333',
  H: '#F0E6D3',
  O: '#FF4444',
  N: '#4466FF',
  P: '#FFAA00',
  S: '#88CC00',
};

// 64 gates with their data
export const GATES: GateData[] = [
  { number: 1, name: 'The Creative', hexagram: '\u4DC0', center: 3, aminoAcid: 'Met', codon: 'ATG', dominantElement: 'N', line: 1, color: 1, tone: 1, base: 1 },
  { number: 2, name: 'The Receptive', hexagram: '\u4DC1', center: 3, aminoAcid: 'Thr', codon: 'ACG', dominantElement: 'O', line: 2, color: 2, tone: 2, base: 2 },
  { number: 3, name: 'Difficulty at the Beginning', hexagram: '\u4DC2', center: 7, aminoAcid: 'Lys', codon: 'AAG', dominantElement: 'N', line: 3, color: 3, tone: 3, base: 3 },
  { number: 4, name: 'Youthful Folly', hexagram: '\u4DC3', center: 1, aminoAcid: 'Trp', codon: 'TGG', dominantElement: 'N', line: 4, color: 4, tone: 4, base: 4 },
  { number: 5, name: 'Waiting', hexagram: '\u4DC4', center: 7, aminoAcid: 'Arg', codon: 'CGT', dominantElement: 'N', line: 5, color: 5, tone: 5, base: 5 },
  { number: 6, name: 'Conflict', hexagram: '\u4DC5', center: 6, aminoAcid: 'His', codon: 'CAT', dominantElement: 'N', line: 6, color: 6, tone: 6, base: 1 },
  { number: 7, name: 'The Army', hexagram: '\u4DC6', center: 3, aminoAcid: 'Gln', codon: 'CAG', dominantElement: 'O', line: 1, color: 1, tone: 1, base: 2 },
  { number: 8, name: 'Holding Together', hexagram: '\u4DC7', center: 3, aminoAcid: 'Asp', codon: 'GAT', dominantElement: 'O', line: 2, color: 2, tone: 2, base: 3 },
  { number: 9, name: 'Small Taming', hexagram: '\u4DC8', center: 7, aminoAcid: 'Tyr', codon: 'TAT', dominantElement: 'O', line: 3, color: 3, tone: 3, base: 4 },
  { number: 10, name: 'Treading', hexagram: '\u4DC9', center: 3, aminoAcid: 'Ile', codon: 'ATT', dominantElement: 'C', line: 4, color: 4, tone: 4, base: 5 },
  { number: 11, name: 'Peace', hexagram: '\u4DCA', center: 1, aminoAcid: 'Leu', codon: 'CTG', dominantElement: 'C', line: 5, color: 5, tone: 5, base: 1 },
  { number: 12, name: 'Standstill', hexagram: '\u4DCB', center: 2, aminoAcid: 'Phe', codon: 'TTT', dominantElement: 'C', line: 6, color: 6, tone: 6, base: 2 },
  { number: 13, name: 'Fellowship', hexagram: '\u4DCC', center: 3, aminoAcid: 'Val', codon: 'GTG', dominantElement: 'C', line: 1, color: 1, tone: 1, base: 3 },
  { number: 14, name: 'Great Possession', hexagram: '\u4DCD', center: 7, aminoAcid: 'Ser', codon: 'TCT', dominantElement: 'O', line: 2, color: 2, tone: 2, base: 4 },
  { number: 15, name: 'Modesty', hexagram: '\u4DCE', center: 3, aminoAcid: 'Pro', codon: 'CCT', dominantElement: 'C', line: 3, color: 3, tone: 3, base: 5 },
  { number: 16, name: 'Enthusiasm', hexagram: '\u4DCF', center: 2, aminoAcid: 'Ala', codon: 'GCT', dominantElement: 'C', line: 4, color: 4, tone: 4, base: 1 },
  { number: 17, name: 'Following', hexagram: '\u4DD0', center: 1, aminoAcid: 'Gly', codon: 'GGT', dominantElement: 'C', line: 5, color: 5, tone: 5, base: 2 },
  { number: 18, name: 'Work on the Decayed', hexagram: '\u4DD1', center: 5, aminoAcid: 'Cys', codon: 'TGT', dominantElement: 'S', line: 6, color: 6, tone: 6, base: 3 },
  { number: 19, name: 'Approach', hexagram: '\u4DD2', center: 8, aminoAcid: 'Asn', codon: 'AAT', dominantElement: 'O', line: 1, color: 1, tone: 1, base: 4 },
  { number: 20, name: 'Contemplation', hexagram: '\u4DD3', center: 2, aminoAcid: 'Glu', codon: 'GAG', dominantElement: 'O', line: 2, color: 2, tone: 2, base: 5 },
  { number: 21, name: 'Biting Through', hexagram: '\u4DD4', center: 4, aminoAcid: 'Lys', codon: 'AAA', dominantElement: 'N', line: 3, color: 3, tone: 3, base: 1 },
  { number: 22, name: 'Grace', hexagram: '\u4DD5', center: 6, aminoAcid: 'Ser', codon: 'AGT', dominantElement: 'O', line: 4, color: 4, tone: 4, base: 2 },
  { number: 23, name: 'Splitting Apart', hexagram: '\u4DD6', center: 2, aminoAcid: 'Arg', codon: 'AGA', dominantElement: 'N', line: 5, color: 5, tone: 5, base: 3 },
  { number: 24, name: 'Return', hexagram: '\u4DD7', center: 1, aminoAcid: 'Leu', codon: 'TTA', dominantElement: 'C', line: 6, color: 6, tone: 6, base: 4 },
  { number: 25, name: 'Innocence', hexagram: '\u4DD8', center: 3, aminoAcid: 'His', codon: 'CAC', dominantElement: 'N', line: 1, color: 1, tone: 1, base: 5 },
  { number: 26, name: 'Great Taming', hexagram: '\u4DD9', center: 4, aminoAcid: 'Thr', codon: 'ACT', dominantElement: 'O', line: 2, color: 2, tone: 2, base: 1 },
  { number: 27, name: 'Nourishment', hexagram: '\u4DDA', center: 7, aminoAcid: 'Pro', codon: 'CCC', dominantElement: 'C', line: 3, color: 3, tone: 3, base: 2 },
  { number: 28, name: 'Great Exceeding', hexagram: '\u4DDB', center: 5, aminoAcid: 'Ala', codon: 'GCC', dominantElement: 'C', line: 4, color: 4, tone: 4, base: 3 },
  { number: 29, name: 'The Abysmal', hexagram: '\u4DDC', center: 7, aminoAcid: 'Gly', codon: 'GGA', dominantElement: 'C', line: 5, color: 5, tone: 5, base: 4 },
  { number: 30, name: 'The Clinging Fire', hexagram: '\u4DDD', center: 6, aminoAcid: 'Ile', codon: 'ATA', dominantElement: 'C', line: 6, color: 6, tone: 6, base: 5 },
  { number: 31, name: 'Influence', hexagram: '\u4DDE', center: 6, aminoAcid: 'Phe', codon: 'TTC', dominantElement: 'C', line: 1, color: 1, tone: 1, base: 1 },
  { number: 32, name: 'Duration', hexagram: '\u4DDF', center: 5, aminoAcid: 'Val', codon: 'GTC', dominantElement: 'C', line: 2, color: 2, tone: 2, base: 2 },
  { number: 33, name: 'Retreat', hexagram: '\u4DE0', center: 2, aminoAcid: 'Tyr', codon: 'TAC', dominantElement: 'O', line: 3, color: 3, tone: 3, base: 3 },
  { number: 34, name: 'Great Power', hexagram: '\u4DE1', center: 7, aminoAcid: 'Asp', codon: 'GAC', dominantElement: 'O', line: 4, color: 4, tone: 4, base: 4 },
  { number: 35, name: 'Progress', hexagram: '\u4DE2', center: 2, aminoAcid: 'Trp', codon: 'TGA', dominantElement: 'N', line: 5, color: 5, tone: 5, base: 5 },
  { number: 36, name: 'Darkening of the Light', hexagram: '\u4DE3', center: 6, aminoAcid: 'Glu', codon: 'GAA', dominantElement: 'O', line: 6, color: 6, tone: 6, base: 1 },
  { number: 37, name: 'The Family', hexagram: '\u4DE4', center: 6, aminoAcid: 'Cys', codon: 'TGC', dominantElement: 'S', line: 1, color: 1, tone: 1, base: 2 },
  { number: 38, name: 'Opposition', hexagram: '\u4DE5', center: 8, aminoAcid: 'Met', codon: 'ATG', dominantElement: 'N', line: 2, color: 2, tone: 2, base: 3 },
  { number: 39, name: 'Obstruction', hexagram: '\u4DE6', center: 8, aminoAcid: 'Asn', codon: 'AAC', dominantElement: 'O', line: 3, color: 3, tone: 3, base: 4 },
  { number: 40, name: 'Deliverance', hexagram: '\u4DE7', center: 4, aminoAcid: 'Thr', codon: 'ACA', dominantElement: 'O', line: 4, color: 4, tone: 4, base: 5 },
  { number: 41, name: 'Decrease', hexagram: '\u4DE8', center: 8, aminoAcid: 'Lys', codon: 'AAG', dominantElement: 'N', line: 5, color: 5, tone: 5, base: 1 },
  { number: 42, name: 'Increase', hexagram: '\u4DE9', center: 7, aminoAcid: 'Arg', codon: 'CGC', dominantElement: 'N', line: 6, color: 6, tone: 6, base: 2 },
  { number: 43, name: 'Breakthrough', hexagram: '\u4DEA', center: 1, aminoAcid: 'Ser', codon: 'TCC', dominantElement: 'O', line: 1, color: 1, tone: 1, base: 3 },
  { number: 44, name: 'Coming to Meet', hexagram: '\u4DEB', center: 5, aminoAcid: 'Leu', codon: 'CTA', dominantElement: 'C', line: 2, color: 2, tone: 2, base: 4 },
  { number: 45, name: 'Gathering Together', hexagram: '\u4DEC', center: 2, aminoAcid: 'Ala', codon: 'GCA', dominantElement: 'C', line: 3, color: 3, tone: 3, base: 5 },
  { number: 46, name: 'Pushing Upward', hexagram: '\u4DED', center: 3, aminoAcid: 'Gly', codon: 'GGC', dominantElement: 'C', line: 4, color: 4, tone: 4, base: 1 },
  { number: 47, name: 'Oppression', hexagram: '\u4DEE', center: 1, aminoAcid: 'Pro', codon: 'CCA', dominantElement: 'C', line: 5, color: 5, tone: 5, base: 2 },
  { number: 48, name: 'The Well', hexagram: '\u4DEF', center: 5, aminoAcid: 'Val', codon: 'GTA', dominantElement: 'C', line: 6, color: 6, tone: 6, base: 3 },
  { number: 49, name: 'Revolution', hexagram: '\u4DF0', center: 6, aminoAcid: 'Ile', codon: 'ATC', dominantElement: 'C', line: 1, color: 1, tone: 1, base: 4 },
  { number: 50, name: 'The Cauldron', hexagram: '\u4DF1', center: 5, aminoAcid: 'Phe', codon: 'TTT', dominantElement: 'C', line: 2, color: 2, tone: 2, base: 5 },
  { number: 51, name: 'The Arousing', hexagram: '\u4DF2', center: 4, aminoAcid: 'Tyr', codon: 'TAT', dominantElement: 'O', line: 3, color: 3, tone: 3, base: 1 },
  { number: 52, name: 'Keeping Still', hexagram: '\u4DF3', center: 8, aminoAcid: 'Asp', codon: 'GAT', dominantElement: 'O', line: 4, color: 4, tone: 4, base: 2 },
  { number: 53, name: 'Development', hexagram: '\u4DF4', center: 8, aminoAcid: 'His', codon: 'CAC', dominantElement: 'N', line: 5, color: 5, tone: 5, base: 3 },
  { number: 54, name: 'Marrying Maiden', hexagram: '\u4DF5', center: 8, aminoAcid: 'Gln', codon: 'CAA', dominantElement: 'O', line: 6, color: 6, tone: 6, base: 4 },
  { number: 55, name: 'Abundance', hexagram: '\u4DF6', center: 6, aminoAcid: 'Arg', codon: 'CGG', dominantElement: 'N', line: 1, color: 1, tone: 1, base: 5 },
  { number: 56, name: 'The Wanderer', hexagram: '\u4DF7', center: 2, aminoAcid: 'Trp', codon: 'TGG', dominantElement: 'N', line: 2, color: 2, tone: 2, base: 1 },
  { number: 57, name: 'The Gentle', hexagram: '\u4DF8', center: 5, aminoAcid: 'Glu', codon: 'GAG', dominantElement: 'O', line: 3, color: 3, tone: 3, base: 2 },
  { number: 58, name: 'The Joyous', hexagram: '\u4DF9', center: 8, aminoAcid: 'Met', codon: 'ATG', dominantElement: 'N', line: 4, color: 4, tone: 4, base: 3 },
  { number: 59, name: 'Dispersion', hexagram: '\u4DFA', center: 7, aminoAcid: 'Asn', codon: 'AAT', dominantElement: 'O', line: 5, color: 5, tone: 5, base: 4 },
  { number: 60, name: 'Limitation', hexagram: '\u4DFB', center: 0, aminoAcid: 'Thr', codon: 'ACG', dominantElement: 'O', line: 6, color: 6, tone: 6, base: 5 },
  { number: 61, name: 'Inner Truth', hexagram: '\u4DFC', center: 0, aminoAcid: 'Cys', codon: 'TGT', dominantElement: 'S', line: 1, color: 1, tone: 1, base: 1 },
  { number: 62, name: 'Small Exceeding', hexagram: '\u4DFD', center: 2, aminoAcid: 'Leu', codon: 'TTG', dominantElement: 'C', line: 2, color: 2, tone: 2, base: 2 },
  { number: 63, name: 'After Completion', hexagram: '\u4DFE', center: 0, aminoAcid: 'Ser', codon: 'AGC', dominantElement: 'O', line: 3, color: 3, tone: 3, base: 3 },
  { number: 64, name: 'Before Completion', hexagram: '\u4DFF', center: 0, aminoAcid: 'Gly', codon: 'GGG', dominantElement: 'C', line: 4, color: 4, tone: 4, base: 4 },
];

// Planetary positions (mock current positions)
export const PLANETARY_POSITIONS: PlanetaryPosition[] = [
  { body: 'Sun', gate: 48, line: 1, degree: 25, minute: 30, second: 0 },
  { body: 'Earth', gate: 21, line: 1, degree: 25, minute: 30, second: 0 },
  { body: 'Moon', gate: 24, line: 6, degree: 12, minute: 15, second: 30 },
  { body: 'North Node', gate: 57, line: 1, degree: 5, minute: 0, second: 0 },
  { body: 'South Node', gate: 51, line: 1, degree: 5, minute: 0, second: 0 },
  { body: 'Mercury', gate: 47, line: 2, degree: 18, minute: 45, second: 0 },
  { body: 'Venus', gate: 36, line: 3, degree: 8, minute: 20, second: 0 },
  { body: 'Mars', gate: 40, line: 2, degree: 22, minute: 10, second: 0 },
  { body: 'Jupiter', gate: 55, line: 1, degree: 15, minute: 0, second: 0 },
  { body: 'Saturn', gate: 10, line: 4, degree: 3, minute: 30, second: 0 },
  { body: 'Uranus', gate: 2, line: 5, degree: 28, minute: 0, second: 0 },
  { body: 'Neptune', gate: 63, line: 2, degree: 1, minute: 45, second: 0 },
  { body: 'Pluto', gate: 60, line: 3, degree: 7, minute: 0, second: 0 },
];
