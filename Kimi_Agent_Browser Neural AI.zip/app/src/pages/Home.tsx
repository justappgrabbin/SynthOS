import { useEffect } from 'react';
import { EngineProvider, useEngine } from '@/context/EngineContext';
import HelixScene from '@/components/three/HelixScene';
import TopBar from '@/components/TopBar';
import BodyGraph from '@/components/BodyGraph';
import CommandInterface from '@/components/CommandInterface';
import DimensionalControls from '@/components/DimensionalControls';
import FocusMode from '@/components/FocusMode';
import { DIMENSIONS } from '@/types';

function HomeContent() {
  const { setActiveDimension, dismissResult } = useEngine();

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      // Dismiss focus mode on Escape
      if (e.key === 'Escape') {
        dismissResult();
        return;
      }

      // Number keys 1-5 for dimensions
      const num = parseInt(e.key);
      if (num >= 1 && num <= 5) {
        setActiveDimension(DIMENSIONS[num - 1].name);
        return;
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [setActiveDimension, dismissResult]);

  return (
    <div
      style={{
        width: '100vw',
        height: '100vh',
        overflow: 'hidden',
        background: '#050508',
        position: 'relative',
      }}
    >
      {/* Layer 1: 3D Scene */}
      <HelixScene />

      {/* Layer 2: HUD Overlay */}
      <TopBar />
      <BodyGraph />
      <DimensionalControls />
      <CommandInterface />

      {/* Layer 3: Focus Mode */}
      <FocusMode />
    </div>
  );
}

export default function Home() {
  return (
    <EngineProvider>
      <HomeContent />
    </EngineProvider>
  );
}
