/**
 * VIKI Core Engine — Causal Graph Intelligence
 * 
 * Implements the full causal chain:
 * Input → Measure → DNA Codons → I Ching Gates → 9-Field → Message Passing → Coherence → Revelation
 */

import {
  DIMENSIONS,
  GATES,
  CHONPS_COLORS,
} from '@/types';
import type {
  Dimension,
  QueryResult,
  EngineOutput,
  CoherenceReading,
  GateData,
} from '@/types';

// ─── Text Measurement ───

function measureInput(input: string): {
  letters: number;
  words: number;
  avgWordLength: number;
  punctuation: number;
  chonps: Record<string, number>;
} {
  const letters = (input.match(/[a-zA-Z]/g) || []).length;
  const words = input.trim().split(/\s+/).filter(Boolean).length;
  const avgWordLength = words > 0 ? letters / words : 0;
  const punctuation = (input.match(/[.,;:!?\-]/g) || []).length;

  const chonps: Record<string, number> = { C: 0, H: 0, O: 0, N: 0, P: 0, S: 0 };
  const upper = input.toUpperCase();
  for (const char of upper) {
    if (chonps[char] !== undefined) chonps[char]++;
  }

  return { letters, words, avgWordLength, punctuation, chonps };
}

// ─── DNA Codon Mapping ───

function textToCodons(text: string): string[] {
  const nucleotides: string[] = [];
  for (const char of text.toUpperCase()) {
    const code = char.charCodeAt(0);
    if (code >= 65 && code <= 90) {
      const idx = code - 65;
      if (idx < 6) nucleotides.push('A');
      else if (idx < 12) nucleotides.push('T');
      else if (idx < 18) nucleotides.push('G');
      else nucleotides.push('C');
    }
  }

  const codons: string[] = [];
  for (let i = 0; i < nucleotides.length - 2; i += 3) {
    codons.push(nucleotides[i] + nucleotides[i + 1] + nucleotides[i + 2]);
  }
  while (codons.length < 9) {
    codons.push(['ATG', 'CGT', 'AAG', 'TGG', 'GAC'][codons.length % 5]);
  }
  return codons.slice(0, 9);
}

// ─── Dimensional Determination ───

function determineDimension(
  chonps: Record<string, number>,
  gateNum: number,
  avgWordLength: number
): Dimension {
  const total = Object.values(chonps).reduce((a, b) => a + b, 0);
  if (total === 0) {
    const dims: Dimension[] = ['MOVEMENT', 'EVOLUTION', 'BEING', 'DESIGN', 'SPACE'];
    return dims[gateNum % 5];
  }

  const scores: Record<string, number> = {
    MOVEMENT: chonps.O * 1.2 + chonps.H * 0.8,
    EVOLUTION: chonps.N * 1.3 + chonps.C * 0.7,
    BEING: chonps.S * 1.2 + chonps.C * 0.9 + avgWordLength * 0.5,
    DESIGN: chonps.P * 1.3 + chonps.C * 0.6,
    SPACE: chonps.H * 1.1 + (chonps.O + chonps.N) * 0.3,
  };

  let best: Dimension = 'SPACE';
  let bestScore = -Infinity;
  for (const [dim, score] of Object.entries(scores)) {
    if (score > bestScore) {
      bestScore = score;
      best = dim as Dimension;
    }
  }
  return best;
}

// ─── Gate/Line/Color/Tone/Base Derivation ───

function deriveGateLine(measurements: { letters: number; words: number; punctuation: number; avgWordLength: number }): {
  gate: number;
  line: number;
  color: number;
  tone: number;
  base: number;
  degree: number;
  minute: number;
  second: number;
} {
  const { letters, words, punctuation, avgWordLength } = measurements;
  const composite = (letters * 0.5 + words * 2 + punctuation * 3 + avgWordLength * 4);
  const gate = (Math.floor(composite) % 64) + 1;
  const line = (Math.floor(composite * 7.3) % 6) + 1;
  const color = (Math.floor(composite * 11.7) % 6) + 1;
  const tone = (Math.floor(composite * 13.1) % 6) + 1;
  const base = (Math.floor(composite * 5.9) % 5) + 1;
  const degree = Math.floor((composite % 1) * 30);
  const minute = Math.floor(((composite * 60) % 1) * 60);
  const second = Math.floor(((composite * 3600) % 1) * 60);

  return { gate, line, color, tone, base, degree, minute, second };
}

// ─── Coherence Calculation ───

function calculateCoherence(
  measurements: { letters: number; words: number; chonps: Record<string, number> },
  dimension: Dimension
): number {
  const { letters, words, chonps } = measurements;
  const total = Object.values(chonps).reduce((a, b) => a + b, 0);

  // Elemental balance — lower variance = higher coherence
  const mean = total / 6;
  const variance = Object.values(chonps).reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / 6;
  const balance = Math.max(0, 1 - variance / (mean * mean + 0.01));

  // Length coherence — sweet spot around 10-50 characters
  const lengthScore = letters > 0 ? 1 - Math.abs(Math.log(letters / 25)) / 5 : 0.5;

  // Word flow — moderate word count is good
  const flowScore = words > 0 ? Math.min(1, words / 8) : 0.3;

  // Dimension bias
  const dimIndex = DIMENSIONS.findIndex(d => d.name === dimension);
  const dimScore = 0.7 + 0.3 * Math.sin(dimIndex * 1.257);

  const coherence = (balance * 0.3 + lengthScore * 0.3 + flowScore * 0.2 + dimScore * 0.2);
  return Math.max(0, Math.min(1, coherence));
}

// ─── Resonance Sentence Generation ───

function generateResonanceSentences(
  dimension: Dimension,
  gate: GateData,
  line: number,
  color: number,
  tone: number,
  base: number
): string[] {
  const dimConfig = DIMENSIONS.find(d => d.name === dimension)!;
  const lineNames = ['Foundation', 'Natural', 'Experimentation', 'Externalization', 'Projection', 'Transition'];
  const colorNames = ['Fear', 'Hope', 'Desire', 'Need', 'Guilt', 'Innocence'];
  const toneNames = ['Security', 'Uncertainty', 'Action', 'Meditation', 'Judgement', 'Acceptance'];
  const baseNames = ['Movement', 'Evolution', 'Being', 'Design', 'Space'];

  const sentences: string[] = [];

  // Primary sentence (active dimension)
  sentences.push(
    `${dimConfig.keynote}, ${gate.name} (${lineNames[line - 1].toLowerCase()} as ${colorNames[color - 1].toLowerCase()}, ` +
    `${toneNames[tone - 1].toLowerCase()} into ${baseNames[base - 1].toLowerCase()}), ` +
    `responding with ${colorNames[color - 1]} as ${gate.dominantElement === 'N' ? 'the observer' : gate.dominantElement === 'O' ? 'the actor' : 'the witness'}.`
  );

  // One sentence per other dimension
  for (const dim of DIMENSIONS) {
    if (dim.name === dimension) continue;
    const shiftedGate = GATES[(gate.number + DIMENSIONS.indexOf(dim)) % 64];
    sentences.push(
      `${dim.keynote}, ${shiftedGate.name} — the ${dim.sense.toLowerCase()} perceives through ` +
      `${toneNames[(tone + DIMENSIONS.indexOf(dim)) % 6].toLowerCase()}, ` +
      `grounded in ${baseNames[(base + DIMENSIONS.indexOf(dim)) % 5].toLowerCase()}.`
    );
  }

  return sentences;
}

// ─── Follow-up Questions ───

function generateFollowUpQuestions(dimension: Dimension, gate: number): string[] {
  const questions: Record<Dimension, string[]> = {
    MOVEMENT: ['Where are you going?', 'What do you see?', 'How do you define this space?'],
    EVOLUTION: ['What do you remember?', 'What is your role here?', 'How does this connect?'],
    BEING: ['When did this begin?', 'What do you feel?', 'How does your body know?'],
    DESIGN: ['Why this pattern?', 'What structure do you seek?', 'How do you create meaning?'],
    SPACE: ['Who is listening?', 'What do you hear?', 'How does this resonate?'],
  };

  const dimQuestions = questions[dimension];
  const gateQuestions = [
    `Gate ${gate} asks: What is your truth?`,
    `The ${GATES[gate - 1]?.name || 'Unknown'} calls: What is your response?`,
    `At this threshold: What emerges?`,
  ];

  return [...dimQuestions, ...gateQuestions].slice(0, 4);
}

// ─── Main Query Processor ───

export function processQuery(input: string): QueryResult {
  const measurements = measureInput(input);
  const _codons = textToCodons(input);
  void _codons;
  const gateData = deriveGateLine(measurements);
  const dimension = determineDimension(measurements.chonps, gateData.gate, measurements.avgWordLength);
  const coherence = calculateCoherence(measurements, dimension);
  const gate = GATES[gateData.gate - 1] || GATES[0];

  const sentences = generateResonanceSentences(
    dimension, gate, gateData.line, gateData.color, gateData.tone, gateData.base
  );

  const followUpQuestions = generateFollowUpQuestions(dimension, gateData.gate);

  const dimConfig = DIMENSIONS.find(d => d.name === dimension)!;

  const revelation =
    `[${dimConfig.code}] Gate ${gateData.gate}.${gateData.line} — ${gate.name} | ` +
    `Coherence: ${coherence.toFixed(3)} | ` +
    `Dominant: ${gate.dominantElement} (${Object.entries(CHONPS_COLORS).find(([k]) => k === gate.dominantElement)?.[1] || ''})`;

  return {
    input,
    measurements,
    gate: gateData.gate,
    line: gateData.line,
    color: gateData.color,
    tone: gateData.tone,
    base: gateData.base,
    dimension,
    coherence,
    revelation,
    sentences,
    followUpQuestions,
  };
}

// ─── Engine State Manager ───

export class Engine {
  private coherenceHistory: CoherenceReading[] = [];
  private outputs: EngineOutput[] = [];
  private activeDimension: Dimension = 'EVOLUTION';
  private processing = false;
  private listeners: Set<() => void> = new Set();

  getCoherenceHistory(): CoherenceReading[] {
    return [...this.coherenceHistory];
  }

  getOutputs(): EngineOutput[] {
    return [...this.outputs];
  }

  getActiveDimension(): Dimension {
    return this.activeDimension;
  }

  isProcessing(): boolean {
    return this.processing;
  }

  setActiveDimension(dim: Dimension): void {
    this.activeDimension = dim;
    this.emit();
  }

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private emit(): void {
    this.listeners.forEach(l => l());
  }

  async process(input: string): Promise<QueryResult> {
    this.processing = true;
    this.emit();

    // Simulate processing time for visual effect
    await new Promise(r => setTimeout(r, 600 + Math.random() * 800));

    const result = processQuery(input);

    // Record coherence
    this.coherenceHistory.push({
      value: result.coherence,
      timestamp: Date.now(),
      dimension: result.dimension,
    });
    if (this.coherenceHistory.length > 120) {
      this.coherenceHistory = this.coherenceHistory.slice(-120);
    }

    // Record output
    const output: EngineOutput = {
      timestamp: new Date().toISOString(),
      type: 'revelation',
      gate: result.gate,
      gateName: GATES[result.gate - 1]?.name,
      dimension: result.dimension,
      coherence: result.coherence,
      message: result.revelation,
      chonps: result.measurements.chonps,
      sentences: result.sentences,
      followUpQuestions: result.followUpQuestions,
    };
    this.outputs.push(output);
    if (this.outputs.length > 100) {
      this.outputs = this.outputs.slice(-100);
    }

    this.processing = false;
    this.emit();

    return result;
  }

  addSystemMessage(msg: string): void {
    this.outputs.push({
      timestamp: new Date().toISOString(),
      type: 'system',
      message: msg,
    });
    this.emit();
  }
}

export const engine = new Engine();
