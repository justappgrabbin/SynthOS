import { useState } from 'react';
import { useEngine } from '@/context/EngineContext';
import { DIMENSIONS, PLANETARY_POSITIONS } from '@/types';
import { ChevronRight, ChevronLeft } from 'lucide-react';

export default function DimensionalControls() {
  const { activeDimension, setActiveDimension, coherenceHistory } = useEngine();
  const [collapsed, setCollapsed] = useState(false);

  const panelWidth = collapsed ? 40 : 280;

  // Build coherence history for the mini chart (last 60 points)
  const chartData = coherenceHistory.slice(-60);
  const maxC = 1;
  const chartHeight = 60;
  const chartWidth = 240;

  const dimConfig = DIMENSIONS.find(d => d.name === activeDimension)!;

  return (
    <aside
      className="fixed right-0 z-40 flex flex-col transition-all duration-300"
      style={{
        top: 56,
        bottom: 280,
        width: panelWidth,
        background: 'rgba(10,10,18,0.85)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        borderLeft: '1px solid #1A1A2E',
      }}
    >
      {/* Collapse Toggle */}
      <div
        className="flex items-center justify-between"
        style={{
          padding: '12px 16px',
          borderBottom: '1px solid #1A1A2E',
        }}
      >
        {!collapsed && (
          <span
            style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: 11,
              fontWeight: 500,
              letterSpacing: '0.08em',
              textTransform: 'uppercase' as const,
              color: '#4A4A6A',
            }}
          >
            Dimensions
          </span>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="flex items-center justify-center rounded hover:bg-white/5 transition-colors"
          style={{ width: 28, height: 28 }}
        >
          {collapsed ? (
            <ChevronLeft size={16} color="#4A4A6A" />
          ) : (
            <ChevronRight size={16} color="#4A4A6A" />
          )}
        </button>
      </div>

      {!collapsed && (
        <>
          {/* Dimension Selectors */}
          <div className="flex flex-col gap-1 p-3">
            {DIMENSIONS.map((dim) => {
              const isActive = activeDimension === dim.name;
              return (
                <button
                  key={dim.name}
                  onClick={() => setActiveDimension(dim.name)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded text-left transition-all duration-200 hover:bg-white/5"
                  style={{
                    borderLeft: `3px solid ${isActive ? dim.color : 'transparent'}`,
                    background: isActive ? `${dim.color}11` : 'transparent',
                  }}
                >
                  <span
                    style={{
                      fontFamily: "'Space Grotesk', sans-serif",
                      fontSize: 14,
                      fontWeight: 700,
                      color: isActive ? dim.color : '#4A4A6A',
                      width: 20,
                    }}
                  >
                    {dim.code}
                  </span>
                  <div className="flex flex-col">
                    <span
                      style={{
                        fontFamily: "'Space Grotesk', sans-serif",
                        fontSize: 12,
                        fontWeight: isActive ? 600 : 400,
                        color: isActive ? '#F0E6D3' : '#6A6A8A',
                      }}
                    >
                      {dim.name}
                    </span>
                    <span
                      style={{
                        fontFamily: "'Space Grotesk', sans-serif",
                        fontSize: 10,
                        color: isActive ? `${dim.color}AA` : '#4A4A6A',
                      }}
                    >
                      {dim.keynote}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Divider */}
          <div style={{ height: 1, background: '#1A1A2E', margin: '0 16px' }} />

          {/* Astrological Context */}
          <div className="flex-1 overflow-y-auto" style={{ padding: '12px 16px' }}>
            <span
              style={{
                fontFamily: "'Space Grotesk', sans-serif",
                fontSize: 11,
                fontWeight: 500,
                letterSpacing: '0.08em',
                textTransform: 'uppercase' as const,
                color: '#4A4A6A',
                display: 'block',
                marginBottom: 8,
              }}
            >
              Planetary
            </span>

            {PLANETARY_POSITIONS.map((pos, i) => {
              const gate = pos.gate;
              const dimIndex = gate % 5;
              const dim = DIMENSIONS[dimIndex];
              return (
                <div
                  key={i}
                  className="flex items-center justify-between py-1"
                >
                  <span
                    style={{
                      fontFamily: "'Space Grotesk', sans-serif",
                      fontSize: 12,
                      color: '#8A8AAA',
                    }}
                  >
                    {pos.body}
                  </span>
                  <span
                    style={{
                      fontFamily: "'JetBrains Mono', monospace",
                      fontSize: 11,
                      color: dim.color,
                    }}
                  >
                    {pos.gate}.{pos.line}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Coherence Graph */}
          <div style={{ padding: '12px 16px', borderTop: '1px solid #1A1A2E' }}>
            <span
              style={{
                fontFamily: "'Space Grotesk', sans-serif",
                fontSize: 11,
                fontWeight: 500,
                letterSpacing: '0.08em',
                textTransform: 'uppercase' as const,
                color: '#4A4A6A',
                display: 'block',
                marginBottom: 8,
              }}
            >
              Coherence History
            </span>

            <svg
              viewBox={`0 0 ${chartWidth} ${chartHeight}`}
              style={{ width: '100%', height: chartHeight }}
            >
              {/* Grid lines */}
              {[0.25, 0.5, 0.75].map((level) => (
                <line
                  key={level}
                  x1={0}
                  y1={chartHeight - (level / maxC) * chartHeight}
                  x2={chartWidth}
                  y2={chartHeight - (level / maxC) * chartHeight}
                  stroke="#1A1A2E"
                  strokeWidth={1}
                />
              ))}

              {/* Coherence line */}
              {chartData.length > 1 && (
                <polyline
                  fill="none"
                  stroke={dimConfig.color}
                  strokeWidth={1.5}
                  opacity={0.8}
                  points={chartData.map((d, i) => {
                    const x = (i / (Math.max(chartData.length, 2) - 1)) * chartWidth;
                    const y = chartHeight - (d.value / maxC) * chartHeight;
                    return `${x},${y}`;
                  }).join(' ')}
                />
              )}

              {/* Area fill */}
              {chartData.length > 1 && (
                <polygon
                  fill={dimConfig.color}
                  opacity={0.08}
                  points={`
                    0,${chartHeight}
                    ${chartData.map((d, i) => {
                      const x = (i / (Math.max(chartData.length, 2) - 1)) * chartWidth;
                      const y = chartHeight - (d.value / maxC) * chartHeight;
                      return `${x},${y}`;
                    }).join(' ')}
                    ${chartWidth},${chartHeight}
                  `}
                />
              )}
            </svg>
          </div>
        </>
      )}
    </aside>
  );
}
