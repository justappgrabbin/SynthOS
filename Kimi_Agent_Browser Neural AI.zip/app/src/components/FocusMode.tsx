import { useEffect } from 'react';
import { useEngine } from '@/context/EngineContext';
import { DIMENSIONS, GATES, CHONPS_COLORS, TONE_NAMES, COLOR_NAMES } from '@/types';
import { X } from 'lucide-react';

export default function FocusMode() {
  const { latestResult, dismissResult } = useEngine();

  // Auto-dismiss after 8 seconds
  useEffect(() => {
    if (!latestResult) return;
    const timer = setTimeout(() => {
      dismissResult();
    }, 8000);
    return () => clearTimeout(timer);
  }, [latestResult, dismissResult]);

  if (!latestResult) return null;

  const dimConfig = DIMENSIONS.find(d => d.name === latestResult.dimension)!;
  const gate = GATES[latestResult.gate - 1] || GATES[0];
  const toneInfo = TONE_NAMES[latestResult.tone];
  const colorInfo = COLOR_NAMES[latestResult.color];

  // Hexagram visualization (6 lines)
  const hexagramLines = [];
  for (let i = 5; i >= 0; i--) {
    const isYang = ((latestResult.gate - 1) >> i) & 1;
    hexagramLines.push(isYang);
  }

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center"
      style={{ background: 'rgba(5,5,8,0.7)', backdropFilter: 'blur(4px)' }}
      onClick={dismissResult}
    >
      <div
        className="relative"
        style={{
          width: 600,
          maxWidth: '90vw',
          maxHeight: '80vh',
          background: 'rgba(10,10,18,0.95)',
          border: '1px solid #1A1A2E',
          borderRadius: 8,
          boxShadow: `0 0 60px rgba(0,0,0,0.8), 0 0 30px ${dimConfig.color}15`,
          overflow: 'auto',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between"
          style={{ padding: '16px 20px', borderBottom: '1px solid #1A1A2E' }}
        >
          <div className="flex items-center gap-3">
            <span
              style={{
                fontFamily: "'Space Grotesk', sans-serif",
                fontSize: 11,
                fontWeight: 600,
                letterSpacing: '0.08em',
                color: dimConfig.color,
                padding: '2px 8px',
                border: `1px solid ${dimConfig.color}44`,
                borderRadius: 4,
              }}
            >
              {dimConfig.code}
            </span>
            <span
              style={{
                fontFamily: "'Space Grotesk', sans-serif",
                fontSize: 14,
                color: '#F0E6D3',
              }}
            >
              Revelation
            </span>
          </div>
          <button
            onClick={dismissResult}
            className="flex items-center justify-center rounded hover:bg-white/5 transition-colors"
            style={{ width: 32, height: 32 }}
          >
            <X size={16} color="#4A4A6A" />
          </button>
        </div>

        {/* Content */}
        <div style={{ padding: '20px 24px' }}>
          {/* Gate Number & Name */}
          <div className="flex items-end gap-4 mb-6">
            <span
              style={{
                fontFamily: "'Space Grotesk', sans-serif",
                fontSize: 48,
                fontWeight: 700,
                color: dimConfig.color,
                lineHeight: 1,
              }}
            >
              {latestResult.gate}
            </span>
            <div>
              <div
                style={{
                  fontFamily: "'Space Grotesk', sans-serif",
                  fontSize: 20,
                  fontWeight: 600,
                  color: '#F0E6D3',
                }}
              >
                {gate.name}
              </div>
              <div
                style={{
                  fontFamily: "'JetBrains Mono', monospace",
                  fontSize: 12,
                  color: '#4A4A6A',
                }}
              >
                {gate.hexagram} · Line {latestResult.line} · {gate.aminoAcid} · {gate.codon}
              </div>
            </div>
          </div>

          {/* Hexagram */}
          <div className="flex flex-col items-center gap-1 mb-6" style={{ padding: '12px 0' }}>
            {hexagramLines.map((isYang, i) => (
              <div key={i} className="flex items-center justify-center" style={{ gap: 4 }}>
                {isYang ? (
                  <div
                    style={{
                      width: 80,
                      height: 6,
                      background: dimConfig.color,
                      borderRadius: 3,
                      opacity: 0.8,
                    }}
                  />
                ) : (
                  <>
                    <div
                      style={{
                        width: 34,
                        height: 6,
                        background: dimConfig.color,
                        borderRadius: 3,
                        opacity: 0.6,
                      }}
                    />
                    <div style={{ width: 8 }} />
                    <div
                      style={{
                        width: 34,
                        height: 6,
                        background: dimConfig.color,
                        borderRadius: 3,
                        opacity: 0.6,
                      }}
                    />
                  </>
                )}
              </div>
            ))}
          </div>

          {/* CHONPS Breakdown */}
          <div
            className="mb-5"
            style={{
              padding: '12px 16px',
              background: 'rgba(26,26,46,0.5)',
              borderRadius: 6,
            }}
          >
            <span
              style={{
                fontFamily: "'Space Grotesk', sans-serif",
                fontSize: 11,
                fontWeight: 500,
                letterSpacing: '0.08em',
                textTransform: 'uppercase' as const,
                color: '#4A4A6A',
                display: 'block',
                marginBottom: 8,
              }}
            >
              CHONPS Elemental
            </span>
            <div className="flex items-center gap-4">
              {Object.entries(CHONPS_COLORS).map(([element, color]) => {
                const count = latestResult.measurements.chonps[element] || 0;
                const isDominant = gate.dominantElement === element;
                return (
                  <div key={element} className="flex flex-col items-center gap-1">
                    <div
                      className="rounded-full"
                      style={{
                        width: isDominant ? 16 : 12,
                        height: isDominant ? 16 : 12,
                        background: color,
                        boxShadow: isDominant ? `0 0 8px ${color}66` : 'none',
                      }}
                    />
                    <span
                      style={{
                        fontFamily: "'JetBrains Mono', monospace",
                        fontSize: 10,
                        color: isDominant ? color : '#4A4A6A',
                        fontWeight: isDominant ? 600 : 400,
                      }}
                    >
                      {element}
                    </span>
                    {count > 0 && (
                      <span
                        style={{
                          fontFamily: "'JetBrains Mono', monospace",
                          fontSize: 9,
                          color: '#6A6A8A',
                        }}
                      >
                        {count}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Color / Tone / Base */}
          <div className="grid grid-cols-3 gap-3 mb-5">
            <div style={{ padding: '10px 12px', background: 'rgba(26,26,46,0.5)', borderRadius: 6 }}>
              <span style={{ fontSize: 10, color: '#4A4A6A', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Color</span>
              <div style={{ fontSize: 13, color: '#F0E6D3', fontWeight: 600, marginTop: 2 }}>
                {colorInfo?.name || '—'}
              </div>
              <div style={{ fontSize: 10, color: '#6A6A8A', marginTop: 2 }}>
                {colorInfo?.mode || ''}
              </div>
            </div>
            <div style={{ padding: '10px 12px', background: 'rgba(26,26,46,0.5)', borderRadius: 6 }}>
              <span style={{ fontSize: 10, color: '#4A4A6A', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Tone</span>
              <div style={{ fontSize: 13, color: '#F0E6D3', fontWeight: 600, marginTop: 2 }}>
                {toneInfo?.name || '—'}
              </div>
              <div style={{ fontSize: 10, color: '#6A6A8A', marginTop: 2 }}>
                {toneInfo?.sense || ''}
              </div>
            </div>
            <div style={{ padding: '10px 12px', background: 'rgba(26,26,46,0.5)', borderRadius: 6 }}>
              <span style={{ fontSize: 10, color: '#4A4A6A', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Base</span>
              <div style={{ fontSize: 13, color: dimConfig.color, fontWeight: 600, marginTop: 2 }}>
                {dimConfig.name}
              </div>
              <div style={{ fontSize: 10, color: '#6A6A8A', marginTop: 2 }}>
                {dimConfig.keynote}
              </div>
            </div>
          </div>

          {/* Resonance Sentences */}
          <div>
            <span
              style={{
                fontFamily: "'Space Grotesk', sans-serif",
                fontSize: 11,
                fontWeight: 500,
                letterSpacing: '0.08em',
                textTransform: 'uppercase' as const,
                color: '#4A4A6A',
                display: 'block',
                marginBottom: 8,
              }}
            >
              Resonance
            </span>
            {latestResult.sentences.map((sentence, i) => {
              const isPrimary = i === 0;
              return (
                <div
                  key={i}
                  className="mb-2"
                  style={{
                    padding: '8px 12px',
                    background: isPrimary ? `${dimConfig.color}11` : 'transparent',
                    borderLeft: isPrimary ? `2px solid ${dimConfig.color}` : '2px solid transparent',
                    borderRadius: isPrimary ? 4 : 0,
                  }}
                >
                  <span
                    style={{
                      fontFamily: "'Space Grotesk', sans-serif",
                      fontSize: 13,
                      color: isPrimary ? '#F0E6D3' : '#8A8AAA',
                      lineHeight: 1.5,
                    }}
                  >
                    {sentence}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Coherence */}
          <div className="mt-4 flex items-center gap-3">
            <span style={{ fontSize: 11, color: '#4A4A6A', textTransform: 'uppercase' }}>Coherence</span>
            <div
              className="relative rounded-full overflow-hidden flex-1"
              style={{ height: 6, background: '#1A1A2E' }}
            >
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{
                  width: `${latestResult.coherence * 100}%`,
                  background: latestResult.coherence < 0.3 ? '#FF4444' : latestResult.coherence < 0.7 ? '#4466FF' : '#88CC00',
                }}
              />
            </div>
            <span
              style={{
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: 13,
                color: latestResult.coherence < 0.3 ? '#FF4444' : latestResult.coherence < 0.7 ? '#4466FF' : '#88CC00',
              }}
            >
              {latestResult.coherence.toFixed(3)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
