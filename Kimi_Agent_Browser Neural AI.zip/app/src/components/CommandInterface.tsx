import { useState, useRef, useEffect, useCallback } from 'react';
import { useEngine } from '@/context/EngineContext';
import { DIMENSIONS } from '@/types';

export default function CommandInterface() {
  const { outputs, processQuery, isProcessing } = useEngine();
  const [input, setInput] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isProcessing) return;
    const query = input.trim();
    setInput('');
    await processQuery(query);
  }, [input, isProcessing, processQuery]);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [outputs]);

  // Keyboard shortcut
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === '/' || (e.metaKey && e.key === 'k')) {
        e.preventDefault();
        inputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const formatTime = (iso: string) => {
    const d = new Date(iso);
    return d.toTimeString().slice(0, 12);
  };

  const dimColor = (dimName?: string) => {
    const dim = DIMENSIONS.find(d => d.name === dimName);
    return dim?.color || '#4A4A6A';
  };

  return (
    <footer
      className="fixed bottom-0 left-0 right-0 z-40 flex flex-col"
      style={{
        height: 280,
        background: 'rgba(5,5,8,0.9)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        borderTop: '1px solid #1A1A2E',
      }}
    >
      {/* Input Zone */}
      <form
        onSubmit={handleSubmit}
        className="flex items-center gap-3 px-6"
        style={{ height: 48, borderBottom: '1px solid #1A1A2E' }}
      >
        <span
          style={{
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: 20,
            color: '#FFAA00',
            userSelect: 'none',
          }}
        >
          {isProcessing ? '...' : '>'}
        </span>
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Enter query, gate coordinate, or command..."
          className="command-input"
          style={{
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: 15,
            color: '#F0E6D3',
            background: 'transparent',
            border: 'none',
            outline: 'none',
            width: '100%',
          }}
          disabled={isProcessing}
        />
      </form>

      {/* Output Zone */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto px-6 py-3"
        style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 13 }}
      >
        {outputs.length === 0 && (
          <div
            style={{
              color: '#4A4A6A',
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: 13,
              paddingTop: 8,
            }}
          >
            [SYSTEM] VIKI initialized. Enter a query to begin causal analysis.
          </div>
        )}

        {outputs.map((output, i) => (
          <div
            key={i}
            className="mb-2"
            style={{
              animation: 'fadeIn 0.3s ease-out',
            }}
          >
            <div className="flex items-start gap-2">
              <span style={{ color: '#4A4A6A', fontSize: 11, whiteSpace: 'nowrap', marginTop: 2 }}>
                [{formatTime(output.timestamp)}]
              </span>

              {output.type === 'revelation' && (
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      style={{
                        color: dimColor(output.dimension),
                        fontWeight: 600,
                        fontSize: 11,
                      }}
                    >
                      {output.dimension?.slice(0, 3)}
                    </span>
                    {output.gate && (
                      <span style={{ color: '#4A4A6A', fontSize: 11 }}>
                        Gate {output.gate}
                      </span>
                    )}
                    {output.coherence !== undefined && (
                      <span style={{ color: output.coherence > 0.7 ? '#88CC00' : output.coherence > 0.3 ? '#4466FF' : '#FF4444', fontSize: 11 }}>
                        C:{output.coherence.toFixed(3)}
                      </span>
                    )}
                  </div>
                  <div style={{ color: '#F0E6D3', lineHeight: 1.5 }}>
                    {output.message}
                  </div>
                  {output.sentences && output.sentences.length > 0 && (
                    <div className="mt-1" style={{ paddingLeft: 12, borderLeft: `2px solid ${dimColor(output.dimension)}33` }}>
                      {output.sentences.slice(0, 2).map((s, j) => (
                        <div key={j} style={{ color: '#8A8AAA', fontSize: 12, marginBottom: 2, lineHeight: 1.4 }}>
                          {s}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {output.type === 'system' && (
                <span style={{ color: '#4A4A6A', fontStyle: 'italic' }}>
                  {output.message}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(4px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </footer>
  );
}
