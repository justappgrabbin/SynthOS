import { useEngine } from '@/context/EngineContext';
import { DIMENSIONS } from '@/types';

export default function TopBar() {
  const { activeDimension, coherenceHistory, isProcessing } = useEngine();

  const coherence = coherenceHistory.length > 0
    ? coherenceHistory[coherenceHistory.length - 1].value
    : 0;

  const dimConfig = DIMENSIONS.find(d => d.name === activeDimension)!;

  const coherenceColor = coherence < 0.3
    ? '#FF4444'
    : coherence < 0.7
      ? '#4466FF'
      : '#88CC00';

  return (
    <header
      className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6"
      style={{
        height: 56,
        background: 'rgba(5,5,8,0.8)',
        backdropFilter: 'blur(8px)',
        WebkitBackdropFilter: 'blur(8px)',
        borderBottom: '1px solid #1A1A2E',
      }}
    >
      {/* Left: Title */}
      <div className="flex items-center gap-3">
        <h1
          style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: 28,
            fontWeight: 700,
            letterSpacing: '-0.02em',
            color: '#F0E6D3',
          }}
        >
          VIKI
        </h1>
        <div
          className="rounded-full"
          style={{
            width: 8,
            height: 8,
            backgroundColor: isProcessing ? '#FFAA00' : '#88CC00',
            opacity: isProcessing ? undefined : 0.5,
            animation: isProcessing ? 'pulse 1s infinite' : undefined,
          }}
        />
      </div>

      {/* Center: Dimension Indicator */}
      <div
        className="hidden md:flex items-center gap-2 px-4 py-1 rounded"
        style={{
          background: 'rgba(26,26,46,0.6)',
          border: `1px solid ${dimConfig.color}33`,
        }}
      >
        <span
          style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: 11,
            fontWeight: 500,
            letterSpacing: '0.08em',
            textTransform: 'uppercase' as const,
            color: dimConfig.color,
          }}
        >
          {dimConfig.code}
        </span>
        <span
          style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: 13,
            fontWeight: 400,
            color: '#F0E6D3',
          }}
        >
          {dimConfig.name} — {dimConfig.keynote}
        </span>
      </div>

      {/* Right: Coherence Meter */}
      <div className="flex items-center gap-3">
        <span
          className="label"
          style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: 11,
            fontWeight: 500,
            letterSpacing: '0.08em',
            textTransform: 'uppercase' as const,
            color: '#4A4A6A',
          }}
        >
          Coherence
        </span>
        <div
          className="relative rounded-full overflow-hidden"
          style={{ width: 120, height: 6, background: '#1A1A2E' }}
        >
          <div
            className="absolute top-0 left-0 h-full rounded-full transition-all duration-700"
            style={{
              width: `${coherence * 100}%`,
              background: coherenceColor,
            }}
          />
        </div>
        <span
          style={{
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: 13,
            letterSpacing: '0.02em',
            color: coherenceColor,
            minWidth: 48,
            textAlign: 'right',
          }}
        >
          {coherence.toFixed(3)}
        </span>
      </div>
    </header>
  );
}
