import { useRef, useMemo, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { useEngine } from '@/context/EngineContext';
import { DIMENSIONS, GATES, CHONPS_COLORS } from '@/types';

// ─── Helix Strand ───

function HelixStrand({ strandIndex, totalStrands, activeGates, activeDimension }: {
  strandIndex: number;
  totalStrands: number;
  activeGates: number[];
  activeDimension: string;
}) {
  const groupRef = useRef<THREE.Group>(null);
  const nodeCount = 64;
  const strandRadius = 5 + strandIndex * 0.35;
  const strandOffset = (strandIndex / totalStrands) * Math.PI * 2;

  const dimColor = DIMENSIONS.find(d => d.name === activeDimension)?.color || '#4466FF';

  const nodes = useMemo(() => {
    const result: { position: THREE.Vector3; gate: number; color: string; baseColor: string }[] = [];
    for (let n = 0; n < nodeCount; n++) {
      const theta = n * (Math.PI * 2 / nodeCount) * 3 + strandOffset;
      const y = (n / nodeCount) * 18 - 9;
      const x = strandRadius * Math.cos(theta);
      const z = strandRadius * Math.sin(theta);
      const gate = GATES[n] || GATES[0];
      const isActive = activeGates.includes(gate.number);
      const baseColor = CHONPS_COLORS[gate.dominantElement] || '#F0E6D3';
      const color = isActive ? dimColor : baseColor;
      result.push({ position: new THREE.Vector3(x, y, z), gate: gate.number, color, baseColor });
    }
    return result;
  }, [strandIndex, totalStrands, strandRadius, strandOffset, activeGates, dimColor]);

  useFrame(({ clock }) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = clock.elapsedTime * 0.05;
      groupRef.current.rotation.x = Math.sin(clock.elapsedTime * 0.1 + strandIndex) * 0.02;
    }
  });

  return (
    <group ref={groupRef}>
      {nodes.map((node, i) => (
        <NodeSphere
          key={i}
          position={node.position}
          color={node.color}
          baseColor={node.baseColor}
          isActive={activeGates.includes(node.gate)}
          index={i}
        />
      ))}
      <StrandConnections nodes={nodes} />
    </group>
  );
}

// ─── Node Sphere ───

function NodeSphere({ position, color, baseColor: _baseColor, isActive, index }: {
  position: THREE.Vector3;
  color: string;
  baseColor: string;
  isActive: boolean;
  index: number;
}) {
  const meshRef = useRef<THREE.Mesh>(null);
  const pulseRef = useRef<THREE.Mesh>(null);

  useFrame(({ clock }) => {
    if (meshRef.current) {
      const pulse = Math.sin(clock.elapsedTime * 2 + index * 0.3) * 0.15;
      const baseScale = isActive ? 1.6 : 1.0;
      const scale = baseScale + pulse * 0.3;
      meshRef.current.scale.setScalar(scale);

      const mat = meshRef.current.material as THREE.MeshStandardMaterial;
      if (isActive) {
        mat.emissiveIntensity = 0.6 + Math.sin(clock.elapsedTime * 3 + index) * 0.3;
      } else {
        mat.emissiveIntensity = 0.15 + pulse * 0.1;
      }
    }

    if (pulseRef.current) {
      if (isActive) {
        const progress = (clock.elapsedTime * 0.8 + index * 0.1) % 1;
        const scale = 1 + progress * 2.5;
        pulseRef.current.scale.setScalar(scale);
        const mat = pulseRef.current.material as THREE.MeshBasicMaterial;
        mat.opacity = 0.4 * (1 - progress);
        pulseRef.current.visible = true;
      } else {
        pulseRef.current.visible = false;
      }
    }
  });

  return (
    <group position={position}>
      <mesh ref={meshRef}>
        <icosahedronGeometry args={[0.22, 1]} />
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={0.15}
          roughness={0.4}
          metalness={0.6}
          transparent
          opacity={0.9}
        />
      </mesh>
      <mesh ref={pulseRef} visible={false}>
        <icosahedronGeometry args={[0.24, 1]} />
        <meshBasicMaterial
          color={color}
          transparent
          opacity={0}
          wireframe
        />
      </mesh>
    </group>
  );
}

// ─── Strand Connections ───

function StrandConnections({ nodes }: { nodes: { position: THREE.Vector3 }[] }) {
  const geometry = useMemo(() => {
    const points: THREE.Vector3[] = [];
    for (let i = 0; i < nodes.length - 1; i++) {
      points.push(nodes[i].position, nodes[i + 1].position);
    }
    const geo = new THREE.BufferGeometry().setFromPoints(points);
    return geo;
  }, [nodes]);

  return (
    <lineSegments geometry={geometry}>
      <lineBasicMaterial color="#2a2a3e" transparent opacity={0.25} />
    </lineSegments>
  );
}

// ─── Cross-Strand Connections ───

function CrossStrands({ activeCenters }: { activeCenters: number[] }) {
  const linesRef = useRef<THREE.Group>(null);
  const dimColor = '#4466FF';

  const lines = useMemo(() => {
    const result: { start: THREE.Vector3; end: THREE.Vector3; active: boolean }[] = [];
    const strands = 13;
    for (let s = 0; s < strands - 1; s++) {
      for (let n = 0; n < 64; n += 8) {
        const theta1 = n * (Math.PI * 2 / 64) * 3 + (s / strands) * Math.PI * 2;
        const theta2 = n * (Math.PI * 2 / 64) * 3 + ((s + 1) / strands) * Math.PI * 2;
        const r1 = 5 + s * 0.35;
        const r2 = 5 + (s + 1) * 0.35;
        const y = (n / 64) * 18 - 9;
        const start = new THREE.Vector3(r1 * Math.cos(theta1), y, r1 * Math.sin(theta1));
        const end = new THREE.Vector3(r2 * Math.cos(theta2), y, r2 * Math.sin(theta2));
        result.push({ start, end, active: activeCenters.length > 0 });
      }
    }
    return result;
  }, [activeCenters]);

  return (
    <group ref={linesRef}>
      {lines.map((line, i) => {
        const geo = new THREE.BufferGeometry().setFromPoints([line.start, line.end]);
        return (
          <lineSegments key={i} geometry={geo}>
            <lineBasicMaterial
              color={dimColor}
              transparent
              opacity={line.active ? 0.12 : 0.04}
            />
          </lineSegments>
        );
      })}
    </group>
  );
}

// ─── Message Particles ───

function MessageParticles() {
  const groupRef = useRef<THREE.Group>(null);
  const particles = useRef<{ mesh: THREE.Mesh; progress: number; speed: number; path: THREE.CatmullRomCurve3; color: THREE.Color }[]>([]);
  const { isProcessing } = useEngine();

  useEffect(() => {
    if (!isProcessing || !groupRef.current) return;

    // Create a new particle
    const strand1 = Math.floor(Math.random() * 13);
    const strand2 = Math.floor(Math.random() * 13);
    const node1 = Math.floor(Math.random() * 64);
    const node2 = Math.floor(Math.random() * 64);

    const r1 = 5 + strand1 * 0.35;
    const r2 = 5 + strand2 * 0.35;
    const theta1 = node1 * (Math.PI * 2 / 64) * 3 + (strand1 / 13) * Math.PI * 2;
    const theta2 = node2 * (Math.PI * 2 / 64) * 3 + (strand2 / 13) * Math.PI * 2;
    const y1 = (node1 / 64) * 18 - 9;
    const y2 = (node2 / 64) * 18 - 9;

    const p1 = new THREE.Vector3(r1 * Math.cos(theta1), y1, r1 * Math.sin(theta1));
    const p2 = new THREE.Vector3(r2 * Math.cos(theta2), y2, r2 * Math.sin(theta2));

    const offset = new THREE.Vector3(0, 2, 0);
    const cp1 = new THREE.Vector3().addVectors(
      new THREE.Vector3().lerpVectors(p1, p2, 0.3),
      offset
    );
    const cp2 = new THREE.Vector3().addVectors(
      new THREE.Vector3().lerpVectors(p1, p2, 0.7),
      offset
    );

    const path = new THREE.CatmullRomCurve3([p1, cp1, cp2, p2]);

    const geometry = new THREE.SphereGeometry(0.1, 8, 8);
    const material = new THREE.MeshBasicMaterial({
      color: '#F0E6D3',
      transparent: true,
      opacity: 0.8,
    });
    const mesh = new THREE.Mesh(geometry, material);
    groupRef.current.add(mesh);

    particles.current.push({
      mesh,
      progress: 0,
      speed: 0.3 + Math.random() * 0.4,
      path,
      color: new THREE.Color('#F0E6D3'),
    });

    if (particles.current.length > 50) {
      const old = particles.current.shift();
      if (old && groupRef.current) {
        groupRef.current.remove(old.mesh);
        old.mesh.geometry.dispose();
        (old.mesh.material as THREE.Material).dispose();
      }
    }
  }, [isProcessing]);

  useFrame((_, delta) => {
    particles.current = particles.current.filter(p => {
      p.progress += p.speed * delta;
      if (p.progress >= 1) {
        if (groupRef.current) groupRef.current.remove(p.mesh);
        p.mesh.geometry.dispose();
        (p.mesh.material as THREE.Material).dispose();
        return false;
      }
      const pos = p.path.getPointAt(Math.min(p.progress, 0.999));
      p.mesh.position.copy(pos);
      const mat = p.mesh.material as THREE.MeshBasicMaterial;
      mat.opacity = 0.8 * (1 - Math.abs(p.progress - 0.5) * 2);
      return true;
    });
  });

  return <group ref={groupRef} />;
}

// ─── Coherence Fog ───

function CoherenceFog() {
  const meshRef = useRef<THREE.Mesh>(null);
  const { coherenceHistory } = useEngine();
  const coherence = coherenceHistory.length > 0 ? coherenceHistory[coherenceHistory.length - 1].value : 0.5;

  const uniforms = useMemo(() => ({
    uTime: { value: 0 },
    uCoherence: { value: coherence },
    uLowColor: { value: new THREE.Color(0.3, 0.1, 0.2) },
    uMidColor: { value: new THREE.Color(0.15, 0.2, 0.35) },
    uHighColor: { value: new THREE.Color(0.8, 0.7, 0.4) },
  }), []);

  useFrame(({ clock }) => {
    uniforms.uTime.value = clock.elapsedTime;
    uniforms.uCoherence.value += (coherence - uniforms.uCoherence.value) * 0.05;
  });

  const vertexShader = `
    varying vec3 vPosition;
    void main() {
      vPosition = position;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `;

  const fragmentShader = `
    uniform float uTime;
    uniform float uCoherence;
    uniform vec3 uLowColor;
    uniform vec3 uMidColor;
    uniform vec3 uHighColor;
    varying vec3 vPosition;

    // Simplex 3D noise
    vec4 permute(vec4 x){ return mod(((x*34.0)+1.0)*x, 289.0); }
    vec4 taylorInvSqrt(vec4 r){ return 1.79284291400159 - 0.85373472095314 * r; }
    float snoise(vec3 v){
      const vec2 C = vec2(1.0/6.0, 1.0/3.0);
      const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
      vec3 i = floor(v + dot(v, C.yyy));
      vec3 x0 = v - i + dot(i, C.xxx);
      vec3 g = step(x0.yzx, x0.xyz);
      vec3 l = 1.0 - g;
      vec3 i1 = min(g.xyz, l.zxy);
      vec3 i2 = max(g.xyz, l.zxy);
      vec3 x1 = x0 - i1 + C.xxx;
      vec3 x2 = x0 - i2 + C.yyy;
      vec3 x3 = x0 - D.yyy;
      i = mod(i, 289.0);
      vec4 p = permute(permute(permute(
        i.z + vec4(0.0, i1.z, i2.z, 1.0))
        + i.y + vec4(0.0, i1.y, i2.y, 1.0))
        + i.x + vec4(0.0, i1.x, i2.x, 1.0));
      float n_ = 1.0/7.0;
      vec3 ns = n_ * D.wyz - D.xzx;
      vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
      vec4 x_ = floor(j * ns.z);
      vec4 y_ = floor(j - 7.0 * x_);
      vec4 x = x_ * ns.x + ns.yyyy;
      vec4 y = y_ * ns.x + ns.yyyy;
      vec4 h = 1.0 - abs(x) - abs(y);
      vec4 b0 = vec4(x.xy, y.xy);
      vec4 b1 = vec4(x.zw, y.zw);
      vec4 s0 = floor(b0)*2.0 + 1.0;
      vec4 s1 = floor(b1)*2.0 + 1.0;
      vec4 sh = -step(h, vec4(0.0));
      vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy;
      vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww;
      vec3 p0 = vec3(a0.xy, h.x);
      vec3 p1 = vec3(a0.zw, h.y);
      vec3 p2 = vec3(a1.xy, h.z);
      vec3 p3 = vec3(a1.zw, h.w);
      vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2,p2), dot(p3,p3)));
      p0 *= norm.x; p1 *= norm.y; p2 *= norm.z; p3 *= norm.w;
      vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
      m = m * m;
      return 42.0 * dot(m*m, vec4(dot(p0,x0), dot(p1,x1), dot(p2,x2), dot(p3,x3)));
    }

    void main() {
      float n = snoise(vPosition * 0.08 + uTime * 0.1);
      float n2 = snoise(vPosition * 0.15 - uTime * 0.07);
      float noiseVal = (n + n2) * 0.5 + 0.5;

      vec3 color;
      if (uCoherence < 0.3) {
        color = mix(uLowColor, uMidColor, uCoherence / 0.3);
      } else if (uCoherence < 0.7) {
        color = mix(uMidColor, uHighColor, (uCoherence - 0.3) / 0.4);
      } else {
        color = mix(uHighColor, vec3(1.0), (uCoherence - 0.7) / 0.3);
      }

      float alpha = noiseVal * 0.03 * (0.5 + uCoherence * 0.5);
      gl_FragColor = vec4(color, alpha);
    }
  `;

  return (
    <mesh ref={meshRef}>
      <sphereGeometry args={[30, 32, 32]} />
      <shaderMaterial
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={uniforms}
        transparent
        side={THREE.BackSide}
        depthWrite={false}
      />
    </mesh>
  );
}

// ─── Scene Content ───

function SceneContent() {
  const { activeGates, activeCenters } = useEngine();
  const strandCount = 13;

  return (
    <>
      <ambientLight intensity={0.15} />
      <directionalLight position={[10, 10, 5]} intensity={0.3} />
      <pointLight position={[0, 0, 0]} intensity={0.5} color="#F0E6D3" distance={20} />

      <CoherenceFog />

      {Array.from({ length: strandCount }, (_, i) => (
        <HelixStrand
          key={i}
          strandIndex={i}
          totalStrands={strandCount}
          activeGates={activeGates}
          activeDimension={useEngine().activeDimension}
        />
      ))}

      <CrossStrands activeCenters={activeCenters} />
      <MessageParticles />

      <OrbitControls
        enablePan={false}
        enableZoom={true}
        minDistance={10}
        maxDistance={40}
        autoRotate
        autoRotateSpeed={0.3}
      />
    </>
  );
}

// ─── Main Scene Export ───

export default function HelixScene() {
  return (
    <div style={{ position: 'absolute', inset: 0, zIndex: 1 }}>
      <Canvas
        camera={{ position: [12, 4, 12], fov: 60, near: 0.1, far: 100 }}
        gl={{ antialias: true, alpha: true }}
        style={{ background: 'transparent' }}
      >
        <SceneContent />
      </Canvas>
    </div>
  );
}
