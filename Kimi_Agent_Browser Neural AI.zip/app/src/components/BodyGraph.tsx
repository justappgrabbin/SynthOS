import { useState } from 'react';
import { useEngine } from '@/context/EngineContext';
import { CENTERS, GATES, CHONPS_COLORS } from '@/types';
import { ChevronLeft, ChevronRight } from 'lucide-react';

export default function BodyGraph() {
  const { activeCenters, toggleCenter } = useEngine();
  const [collapsed, setCollapsed] = useState(false);

  const panelWidth = collapsed ? 40 : 320;

  return (
    <aside
      className="fixed left-0 z-40 flex flex-col transition-all duration-300"
      style={{
        top: 56,
        bottom: 280,
        width: panelWidth,
        background: 'rgba(10,10,18,0.85)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        borderRight: '1px solid #1A1A2E',
      }}
    >
      {/* Header */}
      <div
        className="flex items-center justify-between"
        style={{
          padding: '12px 16px',
          borderBottom: '1px solid #1A1A2E',
        }}
      >
        {!collapsed && (
          <span
            style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: 11,
              fontWeight: 500,
              letterSpacing: '0.08em',
              textTransform: 'uppercase' as const,
              color: '#4A4A6A',
            }}
          >
            Body Graph
          </span>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="flex items-center justify-center rounded hover:bg-white/5 transition-colors"
          style={{ width: 28, height: 28 }}
        >
          {collapsed ? (
            <ChevronRight size={16} color="#4A4A6A" />
          ) : (
            <ChevronLeft size={16} color="#4A4A6A" />
          )}
        </button>
      </div>

      {/* Body Graph Visualization */}
      {!collapsed && (
        <div className="flex-1 relative overflow-hidden" style={{ padding: 16 }}>
          <svg
            viewBox="0 0 200 400"
            style={{ width: '100%', height: '100%' }}
            preserveAspectRatio="xMidYMid meet"
          >
            {/* Connection lines */}
            {generateConnections()}

            {/* Centers */}
            {CENTERS.map(center => {
              const isActive = activeCenters.includes(center.id);
              const cx = center.x * 200;
              const cy = center.y * 400;
              const gate = GATES.find(g => g.center === center.id);
              const elementColor = gate ? CHONPS_COLORS[gate.dominantElement] || '#F0E6D3' : '#4A4A6A';

              return (
                <g
                  key={center.id}
                  onClick={() => toggleCenter(center.id)}
                  style={{ cursor: 'pointer' }}
                >
                  {/* Glow for active */}
                  {isActive && (
                    <rect
                      x={cx - 28}
                      y={cy - 20}
                      width={56}
                      height={40}
                      rx={10}
                      fill={center.color}
                      opacity={0.15}
                    >
                      <animate
                        attributeName="opacity"
                        values="0.15;0.25;0.15"
                        dur="2s"
                        repeatCount="indefinite"
                      />
                    </rect>
                  )}

                  {/* Center rectangle */}
                  <rect
                    x={cx - 24}
                    y={cy - 16}
                    width={48}
                    height={32}
                    rx={8}
                    fill={isActive ? `${center.color}22` : '#11111A'}
                    stroke={isActive ? center.color : '#1A1A2E'}
                    strokeWidth={isActive ? 1.5 : 1}
                  />

                  {/* CHONPS dots */}
                  {gate && (
                    <>
                      <circle cx={cx - 12} cy={cy + 2} r={2.5} fill={CHONPS_COLORS['C'] || '#333'} />
                      <circle cx={cx - 4} cy={cy + 2} r={2.5} fill={CHONPS_COLORS['N'] || '#4466FF'} />
                      <circle cx={cx + 4} cy={cy + 2} r={2.5} fill={CHONPS_COLORS['O'] || '#FF4444'} />
                      <circle cx={cx + 12} cy={cy + 2} r={2.5} fill={elementColor} />
                    </>
                  )}

                  {/* Label */}
                  <text
                    x={cx}
                    y={cy - 5}
                    textAnchor="middle"
                    fill={isActive ? center.color : '#4A4A6A'}
                    fontSize={8}
                    fontFamily="'Space Grotesk', sans-serif"
                    fontWeight={isActive ? 600 : 500}
                    letterSpacing="0.05em"
                  >
                    {center.shortName}
                  </text>

                  {/* Gate indicator */}
                  {gate && (
                    <text
                      x={cx}
                      y={cy + 14}
                      textAnchor="middle"
                      fill="#4A4A6A"
                      fontSize={6}
                      fontFamily="'JetBrains Mono', monospace"
                    >
                      G{gate.number} {gate.aminoAcid}
                    </text>
                  )}
                </g>
              );
            })}
          </svg>
        </div>
      )}
    </aside>
  );
}

function generateConnections() {
  const connections: { from: typeof CENTERS[0]; to: typeof CENTERS[0] }[] = [
    { from: CENTERS[0], to: CENTERS[1] },
    { from: CENTERS[1], to: CENTERS[2] },
    { from: CENTERS[2], to: CENTERS[3] },
    { from: CENTERS[3], to: CENTERS[4] },
    { from: CENTERS[3], to: CENTERS[5] },
    { from: CENTERS[3], to: CENTERS[6] },
    { from: CENTERS[3], to: CENTERS[7] },
    { from: CENTERS[5], to: CENTERS[7] },
    { from: CENTERS[6], to: CENTERS[7] },
    { from: CENTERS[7], to: CENTERS[8] },
    { from: CENTERS[2], to: CENTERS[5] },
    { from: CENTERS[2], to: CENTERS[6] },
  ];

  return connections.map((conn, i) => {
    const x1 = conn.from.x * 200;
    const y1 = conn.from.y * 400;
    const x2 = conn.to.x * 200;
    const y2 = conn.to.y * 400;

    return (
      <line
        key={i}
        x1={x1}
        y1={y1}
        x2={x2}
        y2={y2}
        stroke="#2a2a3e"
        strokeWidth={1}
        opacity={0.5}
      />
    );
  });
}
