import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { engine } from '@/engine/core';
import type { Dimension, EngineOutput, CoherenceReading, QueryResult } from '@/types';

interface EngineContextValue {
  coherenceHistory: CoherenceReading[];
  outputs: EngineOutput[];
  activeDimension: Dimension;
  isProcessing: boolean;
  activeGates: number[];
  activeCenters: number[];
  latestResult: QueryResult | null;
  setActiveDimension: (dim: Dimension) => void;
  processQuery: (input: string) => Promise<QueryResult>;
  toggleCenter: (centerId: number) => void;
  dismissResult: () => void;
}

const EngineContext = createContext<EngineContextValue | null>(null);

export function EngineProvider({ children }: { children: React.ReactNode }) {
  const [coherenceHistory, setCoherenceHistory] = useState<CoherenceReading[]>([]);
  const [outputs, setOutputs] = useState<EngineOutput[]>([]);
  const [activeDimension, setActiveDimensionState] = useState<Dimension>('EVOLUTION');
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeGates, setActiveGates] = useState<number[]>([]);
  const [activeCenters, setActiveCenters] = useState<number[]>([]);
  const [latestResult, setLatestResult] = useState<QueryResult | null>(null);

  const sync = useCallback(() => {
    setCoherenceHistory(engine.getCoherenceHistory());
    setOutputs(engine.getOutputs());
    setActiveDimensionState(engine.getActiveDimension());
    setIsProcessing(engine.isProcessing());
  }, []);

  useEffect(() => {
    const unsub = engine.subscribe(sync);
    sync();
    return unsub;
  }, [sync]);

  const setActiveDimension = useCallback((dim: Dimension) => {
    engine.setActiveDimension(dim);
  }, []);

  const processQuery = useCallback(async (input: string): Promise<QueryResult> => {
    const result = await engine.process(input);
    setLatestResult(result);
    setActiveGates([result.gate]);
    const gateData = (await import('@/types')).GATES.find(g => g.number === result.gate);
    if (gateData) {
      setActiveCenters([gateData.center]);
    }
    return result;
  }, []);

  const toggleCenter = useCallback((centerId: number) => {
    setActiveCenters(prev =>
      prev.includes(centerId) ? prev.filter(id => id !== centerId) : [...prev, centerId]
    );
  }, []);

  const dismissResult = useCallback(() => {
    setLatestResult(null);
  }, []);

  const value: EngineContextValue = {
    coherenceHistory,
    outputs,
    activeDimension,
    isProcessing,
    activeGates,
    activeCenters,
    latestResult,
    setActiveDimension,
    processQuery,
    toggleCenter,
    dismissResult,
  };

  return (
    <EngineContext.Provider value={value}>
      {children}
    </EngineContext.Provider>
  );
}

export function useEngine(): EngineContextValue {
  const ctx = useContext(EngineContext);
  if (!ctx) throw new Error('useEngine must be used within EngineProvider');
  return ctx;
}
