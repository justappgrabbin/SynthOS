import { useRef, useEffect } from 'react';
import { useViki } from '@/context/VikiContext';
import { DIMENSIONS } from '@/types';
import { Brain, Zap, BookOpen, BarChart3 } from 'lucide-react';

export default function NeuralViz() {
  const { neuralState, neuralStats } = useViki();

  if (!neuralStats) return null;

  return (
    <div
      style={{
        width: 260,
        background: 'rgba(5,5,8,0.95)',
        borderLeft: '1px solid #1A1A2E',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
      }}
    >
      <div style={{ padding: '12px 16px', borderBottom: '1px solid #1A1A2E' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Brain size={14} color="#88CC00" />
          <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 11, fontWeight: 500, letterSpacing: '0.08em', textTransform: 'uppercase' as const, color: '#4A4A6A' }}>
            Neural Field
          </span>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '12px 16px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 16 }}>
          <StatBox label="Vocab" value={neuralStats.vocabSize} icon={<BookOpen size={12} />} />
          <StatBox label="Rules" value={neuralStats.grammarRules} icon={<Zap size={12} />} />
          <StatBox label="Context" value={neuralStats.contextSize} icon={<Brain size={12} />} />
          <StatBox label="Heads" value={2} icon={<BarChart3 size={12} />} />
        </div>

        {neuralState && (
          <div style={{ marginBottom: 16 }}>
            <p style={{ fontSize: 10, color: '#4A4A6A', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>
              Dimensional Activation
            </p>
            {DIMENSIONS.map((dim, i) => {
              const score = neuralState.dimensionScores[i] || 0;
              return (
                <div key={dim.name} style={{ marginBottom: 4 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 2 }}>
                    <span style={{ fontSize: 10, color: dim.color }}>{dim.code}</span>
                    <span style={{ fontSize: 10, color: '#6A6A8A', fontFamily: "'JetBrains Mono', monospace" }}>
                      {score.toFixed(3)}
                    </span>
                  </div>
                  <div style={{ height: 3, background: '#1A1A2E', borderRadius: 2, overflow: 'hidden' }}>
                    <div style={{ width: `${Math.min(100, score * 200)}%`, height: '100%', background: dim.color, borderRadius: 2, transition: 'width 0.3s' }} />
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {neuralState && (
          <div style={{ marginBottom: 16, padding: '8px 10px', background: 'rgba(26,26,46,0.4)', borderRadius: 6 }}>
            <p style={{ fontSize: 10, color: '#4A4A6A', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 4 }}>Intent</p>
            <p style={{ fontSize: 12, color: '#F0E6D3', fontWeight: 500 }}>{neuralState.intent}</p>
            <p style={{ fontSize: 10, color: '#5A5A7A', marginTop: 2 }}>Mode: {neuralState.mode}</p>
          </div>
        )}

        {neuralState && neuralState.attentionWeights.length > 0 && (
          <div style={{ marginBottom: 16 }}>
            <p style={{ fontSize: 10, color: '#4A4A6A', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>
              Attention Pattern
            </p>
            <div style={{ display: 'flex', gap: 2 }}>
              {neuralState.attentionWeights.slice(-6).map((pos, pi) => (
                <div key={pi} style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                  {pos.map((head, hi) => (
                    <div key={hi} style={{ display: 'flex', gap: 1 }}>
                      {head.slice(-8).map((w, wi) => (
                        <div
                          key={wi}
                          style={{
                            width: 6,
                            height: 6,
                            background: `rgba(68,102,255,${Math.min(1, w * 2)})`,
                            borderRadius: 1,
                          }}
                        />
                      ))}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        )}

        <div>
          <p style={{ fontSize: 10, color: '#4A4A6A', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>
            Learned Vocabulary
          </p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
            {neuralStats.topWords.filter(w => !w.startsWith('<') && w.length > 1).slice(0, 20).map((word, i) => (
              <span
                key={word + i}
                style={{
                  padding: '2px 6px',
                  borderRadius: 3,
                  background: 'rgba(26,26,46,0.5)',
                  color: '#6A6A8A',
                  fontSize: 10,
                  fontFamily: "'JetBrains Mono', monospace",
                }}
              >
                {word}
              </span>
            ))}
          </div>
        </div>

        {neuralState && neuralState.embeddings.length > 0 && (
          <div style={{ marginTop: 16 }}>
            <p style={{ fontSize: 10, color: '#4A4A6A', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>
              Embedding Cloud
            </p>
            <EmbeddingCanvas embeddings={neuralState.embeddings} />
          </div>
        )}
      </div>
    </div>
  );
}

function StatBox({ label, value, icon }: { label: string; value: number; icon: React.ReactNode }) {
  return (
    <div style={{ padding: '8px', background: 'rgba(26,26,46,0.3)', borderRadius: 6, textAlign: 'center' }}>
      <div style={{ color: '#4A4A6A', marginBottom: 4 }}>{icon}</div>
      <div style={{ fontSize: 18, fontWeight: 700, color: '#F0E6D3', fontFamily: "'JetBrains Mono', monospace" }}>{value}</div>
      <div style={{ fontSize: 9, color: '#4A4A6A', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}</div>
    </div>
  );
}

function EmbeddingCanvas({ embeddings }: { embeddings: Float32Array[] }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 220;
    canvas.height = 100;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const cx = canvas.width / 2;
    const cy = canvas.height / 2;

    embeddings.forEach((emb) => {
      const x = cx + emb[0] * 60;
      const y = cy + emb[1] * 30;
      const size = 1 + Math.abs(emb[2]) * 3;
      const alpha = 0.3 + Math.abs(emb[3]) * 0.5;

      ctx.beginPath();
      ctx.arc(x, y, size, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(68,102,255,${alpha})`;
      ctx.fill();
    });
  }, [embeddings]);

  return <canvas ref={canvasRef} style={{ width: '100%', height: 100 }} />;
}
