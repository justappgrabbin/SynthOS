import { useEffect } from 'react';
import { useViki } from '@/context/VikiContext';
import { Gamepad2, Globe, Video, Trash2, Code2 } from 'lucide-react';

const TYPE_ICONS: Record<string, typeof Gamepad2> = {
  game: Gamepad2,
  app: Globe,
  video: Video,
};

const TYPE_COLORS: Record<string, string> = {
  game: '#88CC00',
  app: '#4466FF',
  video: '#FFAA00',
};

export default function ProjectManager() {
  const { projects, loadProjects, deleteProject, viewCode } = useViki();

  useEffect(() => {
    loadProjects();
  }, [loadProjects]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Header */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '10px 16px',
          borderBottom: '1px solid #1A1A2E',
          background: 'rgba(5,5,8,0.8)',
        }}
      >
        <span
          style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: 11,
            fontWeight: 500,
            letterSpacing: '0.08em',
            textTransform: 'uppercase' as const,
            color: '#4A4A6A',
          }}
        >
          Projects ({projects.length})
        </span>
      </div>

      {/* Project Grid */}
      <div
        style={{
          flex: 1,
          overflow: 'auto',
          padding: '16px 20px',
        }}
      >
        {projects.length === 0 && <EmptyProjects />}

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 12 }}>
          {projects.map((proj) => {
            const Icon = TYPE_ICONS[proj.type] || Code2;
            const color = TYPE_COLORS[proj.type] || '#4A4A6A';

            return (
              <div
                key={proj.id}
                style={{
                  padding: '14px 16px',
                  background: 'rgba(26,26,46,0.3)',
                  borderRadius: 8,
                  border: '1px solid #1A1A2E',
                  transition: 'all 0.2s',
                  cursor: 'default',
                }}
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = `${color}33`; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = '#1A1A2E'; }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                  <div
                    style={{
                      width: 32,
                      height: 32,
                      borderRadius: 8,
                      background: `${color}15`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <Icon size={16} color={color} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p
                      style={{
                        fontFamily: "'Space Grotesk', sans-serif",
                        fontSize: 13,
                        fontWeight: 600,
                        color: '#F0E6D3',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                      }}
                    >
                      {proj.name}
                    </p>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 2 }}>
                      <span
                        style={{
                          fontSize: 10,
                          color,
                          textTransform: 'uppercase' as const,
                          letterSpacing: '0.05em',
                        }}
                      >
                        {proj.type}
                      </span>
                      <span style={{ fontSize: 10, color: '#3A3A5A' }}>|</span>
                      <span style={{ fontSize: 10, color: '#4A4A6A' }}>
                        {new Date(proj.created).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => deleteProject(proj.id)}
                    style={{
                      width: 24,
                      height: 24,
                      borderRadius: 4,
                      border: 'none',
                      background: 'transparent',
                      color: '#4A4A6A',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                    onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.color = '#FF4444'; }}
                    onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.color = '#4A4A6A'; }}
                  >
                    <Trash2 size={12} />
                  </button>
                </div>

                {proj.description && (
                  <p
                    style={{
                      fontFamily: "'Space Grotesk', sans-serif",
                      fontSize: 12,
                      color: '#5A5A7A',
                      lineHeight: 1.5,
                      marginBottom: 8,
                    }}
                  >
                    {proj.description}
                  </p>
                )}

                {proj.code && (
                  <button
                    onClick={() => viewCode(proj.code!)}
                    style={{
                      padding: '5px 10px',
                      borderRadius: 4,
                      border: '1px solid rgba(68,102,255,0.2)',
                      background: 'rgba(68,102,255,0.08)',
                      color: '#4466FF',
                      fontFamily: "'Space Grotesk', sans-serif",
                      fontSize: 11,
                      cursor: 'pointer',
                      transition: 'all 0.2s',
                    }}
                  >
                    View Code
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function EmptyProjects() {
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '60px 20px',
        color: '#4A4A6A',
      }}
    >
      <Code2 size={36} style={{ marginBottom: 12, opacity: 0.4 }} />
      <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 14, marginBottom: 4 }}>
        No projects yet
      </p>
      <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 12, textAlign: 'center', maxWidth: 300 }}>
        Ask the system to build games, apps, or tools. Everything you create is saved here.
      </p>
    </div>
  );
}
