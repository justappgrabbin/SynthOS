import { useViki } from '@/context/VikiContext';
import type { Mode } from '@/engine/viki';
import { MessageSquare, Code2, Video, FolderOpen, Brain, Waves } from 'lucide-react';

const TABS: { mode: Mode; label: string; icon: typeof MessageSquare }[] = [
  { mode: 'chat', label: 'Chat', icon: MessageSquare },
  { mode: 'code', label: 'Code', icon: Code2 },
  { mode: 'video', label: 'Video', icon: Video },
  { mode: 'projects', label: 'Projects', icon: FolderOpen },
];

const FIELD_COLORS: Record<string, string> = {
  SYNCHRONIZED: '#88CC00',
  HARMONIC: '#4466FF',
  DISSONANT: '#FFAA00',
  CHAOTIC: '#FF4444',
};

export default function Header() {
  const { activeMode, setActiveMode, isProcessing, neuralStats, fieldState, coherence } = useViki();
  const fieldColor = FIELD_COLORS[fieldState] || '#4A4A6A';

  return (
    <header style={{ height: 52, background: 'rgba(5,5,8,0.9)', backdropFilter: 'blur(12px)', borderBottom: '1px solid #1A1A2E', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 20px', position: 'fixed', top: 0, left: 0, right: 0, zIndex: 50 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <h1 style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 22, fontWeight: 700, color: '#F0E6D3', letterSpacing: '-0.02em' }}>VIKI</h1>
        <div style={{ width: 6, height: 6, borderRadius: '50%', background: isProcessing ? '#FFAA00' : '#88CC00', animation: isProcessing ? 'pulse 1s infinite' : undefined }} />
        {neuralStats && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginLeft: 4 }}>
            <Brain size={12} color="#88CC00" />
            <span style={{ fontSize: 10, color: '#4A4A6A', fontFamily: "'JetBrains Mono', monospace" }}>{neuralStats.vocabSize}w</span>
          </div>
        )}
      </div>

      <nav style={{ display: 'flex', gap: 4 }}>
        {TABS.map(({ mode, label, icon: Icon }) => (
          <button key={mode} onClick={() => setActiveMode(mode)} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 14px', borderRadius: 6, border: 'none', background: activeMode === mode ? 'rgba(68,102,255,0.12)' : 'transparent', color: activeMode === mode ? '#4466FF' : '#4A4A6A', fontFamily: "'Space Grotesk', sans-serif", fontSize: 12, fontWeight: activeMode === mode ? 600 : 500, letterSpacing: '0.03em', cursor: 'pointer', transition: 'all 0.2s' }}>
            <Icon size={14} />{label}
          </button>
        ))}
      </nav>

      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <Waves size={12} color={fieldColor} />
          <span style={{ fontSize: 10, color: fieldColor, fontFamily: "'JetBrains Mono', monospace" }}>{fieldState}</span>
          <div style={{ width: 50, height: 4, borderRadius: 2, background: '#1A1A2E', overflow: 'hidden' }}>
            <div style={{ width: `${coherence * 100}%`, height: '100%', borderRadius: 2, background: fieldColor, transition: 'all 0.5s' }} />
          </div>
          <span style={{ fontSize: 10, color: fieldColor, fontFamily: "'JetBrains Mono', monospace" }}>{coherence.toFixed(2)}</span>
        </div>
      </div>
    </header>
  );
}
