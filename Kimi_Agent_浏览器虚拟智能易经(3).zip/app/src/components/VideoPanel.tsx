import { useState } from 'react';
import { useViki } from '@/context/VikiContext';
import { Video, Wand2, Clock, Film } from 'lucide-react';

export default function VideoPanel() {
  const { isGeneratingVideo, messages } = useViki();
  const [description, setDescription] = useState('');

  // Find video-related messages
  const videoMessages = messages.filter(m => m.type === 'video');

  const handleGenerate = () => {
    if (!description.trim()) return;
    // This would trigger video generation through the engine
    // For now, show a placeholder
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Header */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '10px 16px',
          borderBottom: '1px solid #1A1A2E',
          background: 'rgba(5,5,8,0.8)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Film size={14} color="#4A4A6A" />
          <span
            style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: 11,
              fontWeight: 500,
              letterSpacing: '0.08em',
              textTransform: 'uppercase' as const,
              color: '#4A4A6A',
            }}
          >
            Video Generation
          </span>
        </div>
      </div>

      {/* Description Input */}
      <div style={{ padding: '16px 20px', borderBottom: '1px solid #1A1A2E' }}>
        <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 13, color: '#6A6A8A', marginBottom: 10 }}>
          Describe the scene you want to create. Be specific about mood, lighting, and subject.
        </p>
        <div style={{ display: 'flex', gap: 8 }}>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="e.g., A cyberpunk city street at night with neon reflections in rain puddles"
            onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
            style={{
              flex: 1,
              background: '#11111A',
              border: '1px solid #1A1A2E',
              borderRadius: 8,
              padding: '10px 14px',
              color: '#F0E6D3',
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: 14,
              outline: 'none',
            }}
          />
          <button
            onClick={handleGenerate}
            disabled={isGeneratingVideo || !description.trim()}
            style={{
              padding: '10px 20px',
              borderRadius: 8,
              border: 'none',
              background: description.trim() ? '#4466FF' : '#1A1A2E',
              color: '#fff',
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: 13,
              cursor: description.trim() ? 'pointer' : 'default',
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              transition: 'all 0.2s',
            }}
          >
            <Wand2 size={14} />
            Generate
          </button>
        </div>

        {/* Quick prompts */}
        <div style={{ display: 'flex', gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
          {[
            'Abstract flowing particles in dark space',
            'Moody forest with light rays through fog',
            'Neon cityscape with rain at night',
            'Ocean waves crashing on rocky shore',
            'Geometric shapes morphing and transforming',
          ].map((prompt) => (
            <button
              key={prompt}
              onClick={() => setDescription(prompt)}
              style={{
                padding: '4px 10px',
                borderRadius: 4,
                border: '1px solid #1A1A2E',
                background: 'rgba(26,26,46,0.3)',
                color: '#5A5A7A',
                fontFamily: "'Space Grotesk', sans-serif",
                fontSize: 11,
                cursor: 'pointer',
              }}
            >
              {prompt.length > 30 ? prompt.slice(0, 30) + '...' : prompt}
            </button>
          ))}
        </div>
      </div>

      {/* Generation Status */}
      {isGeneratingVideo && (
        <div
          style={{
            padding: '40px 20px',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: 16,
          }}
        >
          <div
            style={{
              width: 60,
              height: 60,
              borderRadius: '50%',
              border: '2px solid #1A1A2E',
              borderTopColor: '#4466FF',
              animation: 'spin 1s linear infinite',
            }}
          />
          <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 14, color: '#6A6A8A' }}>
            Generating video scene...
          </p>
          <p style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: '#4A4A6A' }}>
            This typically takes 30-60 seconds
          </p>
        </div>
      )}

      {/* Video History */}
      <div style={{ flex: 1, overflow: 'auto', padding: '16px 20px' }}>
        <p
          style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: 11,
            fontWeight: 500,
            letterSpacing: '0.08em',
            textTransform: 'uppercase' as const,
            color: '#4A4A6A',
            marginBottom: 12,
          }}
        >
          Recent Generations
        </p>

        {videoMessages.length === 0 && !isGeneratingVideo && (
          <div style={{ textAlign: 'center', padding: '40px 0', color: '#4A4A6A' }}>
            <Video size={32} style={{ margin: '0 auto 12px', opacity: 0.5 }} />
            <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 13 }}>
              No videos generated yet. Describe a scene above to begin.
            </p>
          </div>
        )}

        {videoMessages.map((msg) => (
          <div
            key={msg.id}
            style={{
              padding: '12px 16px',
              background: 'rgba(26,26,46,0.3)',
              borderRadius: 8,
              border: '1px solid #1A1A2E',
              marginBottom: 8,
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
              <Clock size={12} color="#4A4A6A" />
              <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: '#4A4A6A' }}>
                {new Date(msg.timestamp).toLocaleString()}
              </span>
            </div>
            <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 13, color: '#8A8AAA', lineHeight: 1.5 }}>
              {msg.content}
            </p>
          </div>
        ))}
      </div>

      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
