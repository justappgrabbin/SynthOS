import { useViki } from '@/context/VikiContext';
import { Copy, Download, Play } from 'lucide-react';
import type { ChatMessage } from '@/context/VikiContext';

export default function CodeViewer() {
  const { currentCode, messages, sendMessage } = useViki();

  // Find the most recent code in messages if no current code
  const findLastCode = (msgs: ChatMessage[]): string => {
    for (let i = msgs.length - 1; i >= 0; i--) {
      if (msgs[i].metadata?.code) return msgs[i].metadata!.code!;
    }
    return '';
  };
  const findLastFiles = (msgs: ChatMessage[]) => {
    for (let i = msgs.length - 1; i >= 0; i--) {
      if (msgs[i].metadata?.files) return msgs[i].metadata!.files;
    }
    return undefined;
  };
  const code = currentCode || findLastCode(messages);
  const files = findLastFiles(messages);

  const handleCopy = () => {
    if (code) navigator.clipboard.writeText(code);
  };

  const handleDownload = () => {
    if (!code) return;
    const blob = new Blob([code], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'index.html';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleRun = () => {
    if (!code) return;
    const blob = new Blob([code], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  };

  if (!code) {
    return (
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          height: '100%',
          gap: 16,
          color: '#4A4A6A',
        }}
      >
        <Code2Icon size={40} />
        <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 14 }}>
          No code generated yet. Ask the system to build something.
        </p>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'center' }}>
          {['Make a snake game', 'Build a calculator', 'Create a todo app', 'Make a paint canvas'].map(cmd => (
            <button
              key={cmd}
              onClick={() => sendMessage(cmd)}
              style={{
                padding: '6px 12px',
                borderRadius: 6,
                border: '1px solid #1A1A2E',
                background: 'rgba(26,26,46,0.3)',
                color: '#5A5A7A',
                fontFamily: "'Space Grotesk', sans-serif",
                fontSize: 12,
                cursor: 'pointer',
              }}
            >
              {cmd}
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Toolbar */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '10px 16px',
          borderBottom: '1px solid #1A1A2E',
          background: 'rgba(5,5,8,0.8)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span
            style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: 11,
              fontWeight: 500,
              letterSpacing: '0.08em',
              textTransform: 'uppercase' as const,
              color: '#4A4A6A',
            }}
          >
            Generated Code
          </span>
          <span
            style={{
              padding: '2px 8px',
              borderRadius: 4,
              background: 'rgba(68,102,255,0.1)',
              color: '#4466FF',
              fontSize: 10,
              fontFamily: "'JetBrains Mono', monospace",
            }}
          >
            HTML
          </span>
        </div>

        <div style={{ display: 'flex', gap: 6 }}>
          <ToolButton icon={<Copy size={14} />} label="Copy" onClick={handleCopy} />
          <ToolButton icon={<Download size={14} />} label="Download" onClick={handleDownload} />
          <ToolButton icon={<Play size={14} />} label="Run" onClick={handleRun} accent />
        </div>
      </div>

      {/* File tabs if multiple files */}
      {files && files.length > 1 && (
        <div style={{ display: 'flex', gap: 2, padding: '4px 16px', borderBottom: '1px solid #1A1A2E', background: 'rgba(5,5,8,0.5)' }}>
          {files.map((f: { path: string; content: string }) => (
            <button
              key={f.path}
              style={{
                padding: '4px 10px',
                borderRadius: 4,
                border: 'none',
                background: f.path === 'index.html' ? 'rgba(68,102,255,0.1)' : 'transparent',
                color: f.path === 'index.html' ? '#4466FF' : '#4A4A6A',
                fontSize: 11,
                fontFamily: "'JetBrains Mono', monospace",
                cursor: 'pointer',
              }}
            >
              {f.path}
            </button>
          ))}
        </div>
      )}

      {/* Code display */}
      <div style={{ flex: 1, overflow: 'auto', background: '#0A0A12' }}>
        <pre
          style={{
            margin: 0,
            padding: '16px 20px',
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: 12,
            lineHeight: 1.6,
            color: '#A0A0C0',
            whiteSpace: 'pre-wrap',
            wordBreak: 'break-all',
          }}
        >
          <code>{code}</code>
        </pre>
      </div>
    </div>
  );
}

function ToolButton({ icon, label, onClick, accent }: { icon: React.ReactNode; label: string; onClick: () => void; accent?: boolean }) {
  return (
    <button
      onClick={onClick}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 4,
        padding: '5px 10px',
        borderRadius: 4,
        border: accent ? 'none' : '1px solid #1A1A2E',
        background: accent ? '#4466FF' : 'transparent',
        color: accent ? '#fff' : '#6A6A8A',
        fontFamily: "'Space Grotesk', sans-serif",
        fontSize: 11,
        cursor: 'pointer',
        transition: 'all 0.2s',
      }}
    >
      {icon}
      {label}
    </button>
  );
}

function Code2Icon({ size = 24 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="16 18 22 12 16 6" />
      <polyline points="8 6 2 12 8 18" />
    </svg>
  );
}
