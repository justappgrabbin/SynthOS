import { useEffect } from 'react';
import { VikiProvider, useViki } from '@/context/VikiContext';
import Header from '@/components/Header';
import NeuralViz from '@/components/NeuralViz';
import Chat from '@/components/Chat';
import CodeViewer from '@/components/CodeViewer';
import VideoPanel from '@/components/VideoPanel';
import ProjectManager from '@/components/ProjectManager';

function AppContent() {
  const { activeMode } = useViki();

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        // Dismiss modals or panels
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  return (
    <div
      style={{
        width: '100vw',
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
        background: '#050508',
        overflow: 'hidden',
      }}
    >
      <Header />

      <main
        style={{
          flex: 1,
          marginTop: 52,
          display: 'flex',
          overflow: 'hidden',
        }}
      >
        {/* Main content */}
        <div style={{ flex: 1, overflow: 'hidden' }}>
          {activeMode === 'chat' && <Chat />}
          {activeMode === 'code' && <CodeViewer />}
          {activeMode === 'video' && <VideoPanel />}
          {activeMode === 'projects' && <ProjectManager />}
        </div>

        {/* Neural visualization sidebar */}
        {activeMode === 'chat' && <NeuralViz />}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <VikiProvider>
      <AppContent />
    </VikiProvider>
  );
}
