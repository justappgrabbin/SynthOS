/**
 * VIKI Neural Core
 * 
 * A small transformer that learns grammar, embeddings, and transformations
 * entirely in the browser. Uses Float32Arrays for speed.
 * 
 * Architecture:
 * - Embedding layer: word -> 5D dimensional vector (one per dimension)
 * - Self-attention: context-aware weighting of conversation history
 * - Feedforward: 2-layer MLP for processing
 * - Output heads: multiple generation modes (chat, code, video)
 * - Online learning: SGD updates from every conversation turn
 */

import { DIMENSIONS } from '@/types';

const EMBED_DIM = 5;       // 5 dimensions = 5D space
const HIDDEN_DIM = 64;     // 64 hidden neurons (64 gates)
const HEADS = 2;            // 2 attention heads (crystal binary)
const CONTEXT_LEN = 32;    // Max conversation context
const LEARNING_RATE = 0.01;
const TEMPERATURE = 0.7;

// ─── Utility ───

function randn(): number {
  // Box-Muller transform
  const u = 1 - Math.random();
  const v = Math.random();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

function softmax(arr: Float32Array): Float32Array {
  const max = Math.max(...arr);
  const exps = arr.map(v => Math.exp(v - max));
  const sum = exps.reduce((a, b) => a + b, 0);
  return new Float32Array(exps.map(v => v / sum));
}
function relu(x: number): number { return x > 0 ? x : 0; }

// ─── Vocabulary ───
// Starts minimal, grows as new words are encountered

export class Vocabulary {
  tokenToId = new Map<string, number>();
  idToToken: string[] = [];
  embeddings: Float32Array[] = []; // Each token's embedding vector
  usageCounts = new Map<number, number>(); // How often each token appears

  constructor() {
    // Special tokens
    this._add('<PAD>'); // 0
    this._add('<UNK>'); // 1
    this._add('<START>'); // 2
    this._add('<END>'); // 3
    this._add('<CODE>'); // 4
    this._add('<VIDEO>'); // 5
  }

  private _add(token: string): number {
    const id = this.idToToken.length;
    this.tokenToId.set(token, id);
    this.idToToken.push(token);
    // Initialize embedding: small random values with dimensional bias
    const emb = new Float32Array(EMBED_DIM);
    for (let i = 0; i < EMBED_DIM; i++) {
      emb[i] = randn() * 0.1;
    }
    this.embeddings.push(emb);
    return id;
  }

  getOrAdd(token: string): number {
    if (this.tokenToId.has(token)) {
      const id = this.tokenToId.get(token)!;
      this.usageCounts.set(id, (this.usageCounts.get(id) || 0) + 1);
      return id;
    }
    // New token: derive initial embedding from character patterns
    const id = this._add(token);
    const emb = this.embeddings[id];
    // Seed embedding based on character composition (dimensional bias)
    for (let i = 0; i < token.length; i++) {
      const charCode = token.charCodeAt(i);
      const dim = charCode % EMBED_DIM;
      emb[dim] += (charCode / 256) * 0.2;
    }
    // Normalize
    const norm = Math.sqrt(emb.reduce((s, v) => s + v * v, 0));
    if (norm > 0) for (let i = 0; i < EMBED_DIM; i++) emb[i] /= norm;
    this.usageCounts.set(id, 1);
    return id;
  }

  get(token: string): number {
    return this.tokenToId.get(token) || this.tokenToId.get('<UNK>')!;
  }

  getEmbedding(tokenId: number): Float32Array {
    return this.embeddings[tokenId] || this.embeddings[1]; // UNK fallback
  }

  // Tokenize text into words
  tokenize(text: string): number[] {
    const words = text.toLowerCase()
      .replace(/[^\w\s]/g, ' ')
      .split(/\s+/)
      .filter(Boolean);
    return words.map(w => this.getOrAdd(w));
  }

  size(): number {
    return this.idToToken.length;
  }

  // Get most-used tokens (learned vocabulary)
  topTokens(n: number): Array<{ token: string; id: number; count: number }> {
    const entries = Array.from(this.usageCounts.entries());
    entries.sort((a, b) => b[1] - a[1]);
    return entries.slice(0, n).map(([id, count]) => ({
      token: this.idToToken[id],
      id,
      count,
    }));
  }

  // Cosine similarity between two token embeddings
  similarity(tokenA: string, tokenB: string): number {
    const idA = this.get(tokenA);
    const idB = this.get(tokenB);
    const embA = this.embeddings[idA];
    const embB = this.embeddings[idB];
    let dot = 0, normA = 0, normB = 0;
    for (let i = 0; i < EMBED_DIM; i++) {
      dot += embA[i] * embB[i];
      normA += embA[i] * embA[i];
      normB += embB[i] * embB[i];
    }
    return dot / (Math.sqrt(normA) * Math.sqrt(normB) + 1e-8);
  }
}

// ─── Attention Layer ───

class AttentionLayer {
  Wq: Float32Array[]; // query weights per head
  Wk: Float32Array[]; // key weights per head
  Wv: Float32Array[]; // value weights per head
  Wo: Float32Array;   // output projection
  dHead: number;

  constructor(inDim: number, heads: number) {
    this.dHead = Math.floor(inDim / heads);
    this.Wq = Array.from({ length: heads }, () => new Float32Array(inDim * this.dHead).map(() => randn() * 0.02));
    this.Wk = Array.from({ length: heads }, () => new Float32Array(inDim * this.dHead).map(() => randn() * 0.02));
    this.Wv = Array.from({ length: heads }, () => new Float32Array(inDim * this.dHead).map(() => randn() * 0.02));
    this.Wo = new Float32Array(inDim * inDim).map(() => randn() * 0.02);
  }

  forward(inputs: Float32Array[]): { output: Float32Array[]; attentionWeights: number[][][] } {
    const seqLen = inputs.length;
    const outputs: Float32Array[] = [];
    const allWeights: number[][][] = [];

    for (let pos = 0; pos < seqLen; pos++) {
      let combined = new Float32Array(inputs[0].length);
      const positionWeights: number[][] = [];

      for (let h = 0; h < HEADS; h++) {
        // Q = input[pos] @ Wq
        const q = this._project(inputs[pos], this.Wq[h], this.dHead);
        const keys: Float32Array[] = [];
        const values: Float32Array[] = [];
        for (let j = 0; j <= pos; j++) {
          keys.push(this._project(inputs[j], this.Wk[h], this.dHead));
          values.push(this._project(inputs[j], this.Wv[h], this.dHead));
        }
        // Attention scores: q @ k^T
        const scores = keys.map(k => {
          let dot = 0;
          for (let i = 0; i < this.dHead; i++) dot += q[i] * k[i];
          return dot / Math.sqrt(this.dHead);
        });
        const weights = softmax(new Float32Array(scores));
        positionWeights.push(Array.from(weights));
        // Weighted sum of values
        const attnOut = new Float32Array(this.dHead);
        for (let j = 0; j <= pos; j++) {
          for (let i = 0; i < this.dHead; i++) attnOut[i] += weights[j] * values[j][i];
        }
        // Add to combined output (concatenate heads)
        for (let i = 0; i < this.dHead; i++) combined[h * this.dHead + i] = attnOut[i];
      }

      allWeights.push(positionWeights);
      // Output projection
      const final = new Float32Array(inputs[0].length);
      for (let i = 0; i < inputs[0].length; i++) {
        let sum = 0;
        for (let j = 0; j < inputs[0].length; j++) sum += combined[j] * this.Wo[j * inputs[0].length + i];
        final[i] = sum;
      }
      outputs.push(final);
    }

    return { output: outputs, attentionWeights: allWeights };
  }

  private _project(input: Float32Array, W: Float32Array, outDim: number): Float32Array {
    const out = new Float32Array(outDim);
    for (let i = 0; i < outDim; i++) {
      let sum = 0;
      for (let j = 0; j < input.length; j++) sum += input[j] * W[j * outDim + i];
      out[i] = sum;
    }
    return out;
  }
}

// ─── Feedforward Layer ───

class FeedForward {
  W1: Float32Array;
  b1: Float32Array;
  W2: Float32Array;
  b2: Float32Array;

  constructor(inDim: number, hiddenDim: number) {
    this.W1 = new Float32Array(inDim * hiddenDim).map(() => randn() * 0.02);
    this.b1 = new Float32Array(hiddenDim);
    this.W2 = new Float32Array(hiddenDim * inDim).map(() => randn() * 0.02);
    this.b2 = new Float32Array(inDim);
  }

  forward(input: Float32Array): Float32Array {
    // Hidden = relu(input @ W1 + b1)
    const hidden = new Float32Array(this.b1.length);
    for (let i = 0; i < hidden.length; i++) {
      let sum = this.b1[i];
      for (let j = 0; j < input.length; j++) sum += input[j] * this.W1[j * hidden.length + i];
      hidden[i] = relu(sum);
    }
    // Output = hidden @ W2 + b2
    const out = new Float32Array(this.b2.length);
    for (let i = 0; i < out.length; i++) {
      let sum = this.b2[i];
      for (let j = 0; j < hidden.length; j++) sum += hidden[j] * this.W2[j * out.length + i];
      out[i] = sum;
    }
    return out;
  }
}

// ─── Output Heads ───

class OutputHead {
  W: Float32Array;
  b: Float32Array;
  vocabSize: number;

  constructor(inDim: number, vocabSize: number) {
    this.W = new Float32Array(inDim * vocabSize).map(() => randn() * 0.02);
    this.b = new Float32Array(vocabSize);
    this.vocabSize = vocabSize;
  }

  forward(input: Float32Array): Float32Array {
    const out = new Float32Array(this.vocabSize);
    for (let i = 0; i < this.vocabSize; i++) {
      let sum = this.b[i];
      for (let j = 0; j < input.length; j++) sum += input[j] * this.W[j * this.vocabSize + i];
      out[i] = sum;
    }
    return out;
  }

  sample(logits: Float32Array, temperature: number): number {
    // Apply temperature and sample
    const scaled = logits.map(v => v / temperature);
    const probs = softmax(scaled);
    let r = Math.random();
    for (let i = 0; i < probs.length; i++) {
      r -= probs[i];
      if (r <= 0) return i;
    }
    return probs.length - 1;
  }
}

// ─── Main Neural Network ───

export interface NeuralState {
  embeddings: Float32Array[];
  contextVectors: Float32Array[];
  attentionWeights: number[][][];
  intent: string;
  dimensionScores: number[];
  mode: 'chat' | 'code' | 'video';
}

export class NeuralNetwork {
  vocab: Vocabulary;
  attention: AttentionLayer;
  feedforward: FeedForward;
  chatHead: OutputHead;
  codeHead: OutputHead;
  videoHead: OutputHead;
  context: Float32Array[] = []; // Conversation context
  mode: 'chat' | 'code' | 'video' = 'chat';
  grammarRules: Array<{ pattern: number[]; response: number[]; weight: number }> = [];

  constructor() {
    this.vocab = new Vocabulary();
    this.attention = new AttentionLayer(EMBED_DIM, HEADS);
    this.feedforward = new FeedForward(EMBED_DIM, HIDDEN_DIM);
    this.chatHead = new OutputHead(EMBED_DIM, this.vocab.size());
    this.codeHead = new OutputHead(EMBED_DIM, this.vocab.size());
    this.videoHead = new OutputHead(EMBED_DIM, this.vocab.size());
  }

  // Process input through the network
  process(input: string): NeuralState {
    // Tokenize
    const tokens = this.vocab.tokenize(input);
    // Get embeddings
    const embeddings = tokens.map(t => this.vocab.getEmbedding(t));
    // Self-attention
    const { output: attnOut, attentionWeights } = this.attention.forward(embeddings);
    // Feedforward
    const ffOut = attnOut.map(a => this.feedforward.forward(a));
    // Determine mode from input
    this.mode = this._classifyMode(input);
    // Get the right output head
    const head = this.mode === 'code' ? this.codeHead : this.mode === 'video' ? this.videoHead : this.chatHead;
    // Get logits for last position
    const lastHidden = ffOut[ffOut.length - 1];
    const logits = head.forward(lastHidden);
    // Dimension scores: project embedding onto dimensional axes
    const dimScores = DIMENSIONS.map((_, i) => {
      let score = 0;
      for (const emb of embeddings) score += Math.abs(emb[i]);
      return score / embeddings.length;
    });
    // Intent from highest activation
    const intentId = head.sample(logits, 0.3);
    const intent = this.vocab.idToToken[intentId] || 'chat';
    // Store in context
    this.context.push(lastHidden);
    if (this.context.length > CONTEXT_LEN) this.context.shift();
    return {
      embeddings,
      contextVectors: ffOut,
      attentionWeights,
      intent,
      dimensionScores: dimScores,
      mode: this.mode,
    };
  }

  // Generate text from neural state
  generate(state: NeuralState, maxTokens: number = 30): string {
    const head = state.mode === 'code' ? this.codeHead : state.mode === 'video' ? this.videoHead : this.chatHead;
    const tokens: number[] = [];
    let hidden = state.contextVectors[state.contextVectors.length - 1];
    for (let i = 0; i < maxTokens; i++) {
      const logits = head.forward(hidden);
      const token = head.sample(logits, TEMPERATURE);
      if (token <= 3) break; // PAD, UNK, START, END
      tokens.push(token);
      // Feed through network for next step
      const emb = this.vocab.getEmbedding(token);
      const { output } = this.attention.forward([...this.context.slice(-CONTEXT_LEN + 1), emb]);
      hidden = this.feedforward.forward(output[output.length - 1]);
    }
    return tokens.map(t => this.vocab.idToToken[t] || '').join(' ');
  }

  // Learn from a conversation turn (input -> expected output)
  learn(input: string, expectedOutput: string): void {
    const inputTokens = this.vocab.tokenize(input);
    const outputTokens = this.vocab.tokenize(expectedOutput);
    // Simple learning: reinforce embeddings that co-occur
    for (const inTok of inputTokens) {
      const inEmb = this.vocab.embeddings[inTok];
      for (const outTok of outputTokens) {
        const outEmb = this.vocab.embeddings[outTok];
        // Move input embedding toward output embedding (association)
        for (let i = 0; i < EMBED_DIM; i++) {
          inEmb[i] += LEARNING_RATE * (outEmb[i] - inEmb[i]);
        }
      }
    }
    // Store as grammar rule
    if (inputTokens.length > 0 && outputTokens.length > 0) {
      this.grammarRules.push({
        pattern: [...inputTokens.slice(-5)],
        response: [...outputTokens.slice(0, 10)],
        weight: 1.0,
      });
      // Keep max 500 rules, remove weakest
      if (this.grammarRules.length > 500) {
        this.grammarRules.sort((a, b) => b.weight - a.weight);
        this.grammarRules = this.grammarRules.slice(0, 500);
      }
    }
    // Strengthen frequently used rules
    for (const rule of this.grammarRules) {
      if (this._matchRule(rule.pattern, inputTokens)) {
        rule.weight = Math.min(5.0, rule.weight + 0.1);
      }
    }
  }

  // Find matching grammar rules
  findRules(inputTokens: number[]): Array<{ response: string; weight: number }> {
    const matches: Array<{ response: string; weight: number }> = [];
    for (const rule of this.grammarRules) {
      if (this._matchRule(rule.pattern, inputTokens)) {
        matches.push({
          response: rule.response.map(t => this.vocab.idToToken[t] || '').join(' '),
          weight: rule.weight,
        });
      }
    }
    matches.sort((a, b) => b.weight - a.weight);
    return matches.slice(0, 5);
  }

  private _matchRule(pattern: number[], input: number[]): boolean {
    // Check if any substring of input matches pattern
    for (let i = 0; i <= input.length - pattern.length; i++) {
      let match = true;
      for (let j = 0; j < pattern.length; j++) {
        if (input[i + j] !== pattern[j]) { match = false; break; }
      }
      if (match) return true;
    }
    return false;
  }

  private _classifyMode(input: string): 'chat' | 'code' | 'video' {
    const lower = input.toLowerCase();
    if (/(create|make|generate)\s+(a\s+|an\s+)?video/.test(lower) || /video of/.test(lower)) return 'video';
    if (/(create|make|build|generate|write)\s+(a\s+|an\s+)?(game|app|code|script|program)/.test(lower)) return 'code';
    if (/(snake|pong|platformer|shooter|calculator|todo|paint|clock)/.test(lower)) return 'code';
    return 'chat';
  }

  // Get learned grammar stats
  getStats(): { vocabSize: number; grammarRules: number; contextSize: number; topWords: string[] } {
    const top = this.vocab.topTokens(10);
    return {
      vocabSize: this.vocab.size(),
      grammarRules: this.grammarRules.length,
      contextSize: this.context.length,
      topWords: top.map(t => t.token),
    };
  }
}
