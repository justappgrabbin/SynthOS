/**
 * MESSY (Meta-Symbolic Simulation System) - Browser Port
 * 
 * Based on Sheldon Klein's 1968-1975 system at UW-Madison.
 * Semantic networks + probabilistic rules + natural language generation.
 * All running in the browser via IndexedDB persistence.
 */

import { storeKnowledge, getKnowledgeBySubject } from '@/storage/db';
import { computeSemanticState, VOICE_TRANSFORMATIONS } from './iching';

// ─── Triple ───

export interface Triple {
  id: string;
  subject: string;
  relation: string;
  object: string;
  value: number;
  createdAt: number;
  rv: number;      // reality value
  h: number;       // hypotheticality
}

// ─── Semantic Network ───

export class SemanticNetwork {
  triples = new Map<string, Triple>();
  bySubject = new Map<string, Set<Triple>>();
  byRelation = new Map<string, Set<Triple>>();
  byObject = new Map<string, Set<Triple>>();
  nodes = new Map<string, NodeDef>();
  relations = new Map<string, RelationDef>();
  classes = new Map<string, Set<string>>();
  exclusions: Array<[string, string]> = [];
  time = 0;

  assert(subject: string, relation: string, object: string, value = 0): Triple {
    const id = `${subject}:${relation}:${object}`;
    const triple: Triple = {
      id, subject, relation, object, value,
      createdAt: this.time,
      rv: 1, h: 0,
    };

    // Check exclusions
    for (const [exRel, exObj] of this.exclusions) {
      if (relation === exRel && object === exObj) {
        const conflicting = this.find(subject, exRel, exObj);
        for (const c of conflicting) this.negate(c.id);
      }
    }

    this.triples.set(id, triple);
    this._index(triple);
    return triple;
  }

  negate(tripleId: string): void {
    const t = this.triples.get(tripleId);
    if (t) { t.rv = 0; t.h = 1; }
  }

  find(subject?: string, relation?: string, object?: string): Triple[] {
    let pool: Triple[];
    if (subject) {
      pool = Array.from(this.bySubject.get(subject) || []);
    } else if (relation) {
      pool = Array.from(this.byRelation.get(relation) || []);
    } else if (object) {
      pool = Array.from(this.byObject.get(object) || []);
    } else {
      pool = Array.from(this.triples.values());
    }
    return pool.filter(t => {
      if (subject && t.subject !== subject) return false;
      if (relation && t.relation !== relation) return false;
      if (object && t.object !== object) return false;
      return t.rv > 0;
    });
  }

  query(queryStr: string): Triple[] {
    // Natural language query: "? wants game" or "user likes ?"
    const parts = queryStr.trim().split(/\s+/);
    let s: string | undefined, r: string | undefined, o: string | undefined;
    if (parts.length >= 3) {
      s = parts[0] === '?' ? undefined : parts[0];
      r = parts[1] === '?' ? undefined : parts[1];
      o = parts[2] === '?' ? undefined : parts[2];
    }
    return this.find(s, r, o);
  }

  addClass(name: string, members: string[]): void {
    this.classes.set(name, new Set(members));
  }

  expand(atom: string): string[] {
    if (this.classes.has(atom)) return [...this.classes.get(atom)!];
    return [atom];
  }

  addExclusion(rel: string, obj: string): void {
    this.exclusions.push([rel, obj]);
  }

  private _index(t: Triple): void {
    if (!this.bySubject.has(t.subject)) this.bySubject.set(t.subject, new Set());
    this.bySubject.get(t.subject)!.add(t);
    if (!this.byRelation.has(t.relation)) this.byRelation.set(t.relation, new Set());
    this.byRelation.get(t.relation)!.add(t);
    if (!this.byObject.has(t.object)) this.byObject.set(t.object, new Set());
    this.byObject.get(t.object)!.add(t);
  }

  // Persist to IndexedDB
  async persist(): Promise<void> {
    for (const t of this.triples.values()) {
      if (t.rv > 0) {
        await storeKnowledge(t.subject, t.relation, t.object, t.value);
      }
    }
  }

  // Load from IndexedDB
  async load(): Promise<void> {
    const records = await getKnowledgeBySubject('_');
    for (const r of records) {
      this.assert(r.subject, r.relation, r.object, r.value ?? 0);
    }
  }
}

// ─── Node / Relation Definitions ───

interface NodeDef {
  name: string;
  lexical: string[];
  numericLexical?: Array<[number, number, string[]]>;
}

interface RelationDef {
  name: string;
  type: string;
  lexical: string[];
  numericLexical?: Array<[number, number, string[]]>;
}

// ─── Rule Engine ───

export interface Subrule {
  test: (net: SemanticNetwork) => boolean;
  probability: number;
}

export interface Rule {
  name: string;
  actions: Action[];
  subrules: Subrule[];
}

export type Action =
  | { type: 'assert'; subject: string; relation: string; object: string; value?: number }
  | { type: 'negate'; tripleId: string }
  | { type: 'set'; tripleId: string; operator: string; value: number }
  | { type: 'addClass'; atom: string; className: string }
  | { type: 'removeClass'; atom: string; className: string }
  | { type: 'say'; template: string }
  | { type: 'generateCode'; intent: string };

export class RuleEngine {
  rules: Rule[] = [];

  addRule(rule: Rule): void {
    this.rules.push(rule);
  }

  evaluate(network: SemanticNetwork): Action[] {
    const actions: Action[] = [];
    for (const rule of this.rules) {
      let cumulativeProb = 0;
      for (const sr of rule.subrules) {
        if (sr.test(network)) cumulativeProb += sr.probability;
      }
      const threshold = rule.subrules.length > 0 ? cumulativeProb : 1;
      if (Math.random() <= threshold) {
        actions.push(...rule.actions);
      }
    }
    return actions;
  }

  execute(network: SemanticNetwork, actions: Action[]): void {
    for (const a of actions) {
      switch (a.type) {
        case 'assert':
          network.assert(a.subject, a.relation, a.object, a.value ?? 0);
          break;
        case 'negate':
          network.negate(a.tripleId);
          break;
        case 'set': {
          const t = network.triples.get(a.tripleId);
          if (t) {
            switch (a.operator) {
              case '=': t.value = a.value; break;
              case '=+': t.value += a.value; break;
              case '=-': t.value -= a.value; break;
            }
          }
          break;
        }
        case 'addClass':
          if (!network.classes.has(a.className)) network.classes.set(a.className, new Set());
          network.classes.get(a.className)!.add(a.atom);
          break;
        case 'removeClass':
          network.classes.get(a.className)?.delete(a.atom);
          break;
      }
    }
  }
}

// ─── NL Generator ───

export interface NLGOutput {
  sentences: string[];
  followUpQuestions: string[];
  actions: Action[];
}

export class NLGenerator {
  private templates = new Map<string, string[]>();

  constructor() {
    // Response templates by relation type
    this.templates.set('greeting', [
      'I hear you. What are we working on?',
      'I am here. Speak your intent.',
      'The field is open. What do you bring?',
    ]);
    this.templates.set('question', [
      'Let me think through this. {answer}',
      'The pattern suggests: {answer}',
      'From this angle: {answer}',
    ]);
    this.templates.set('code_request', [
      'I will build that for you.',
      'The structure is becoming clear.',
      'I can see the pattern. Generating now.',
    ]);
    this.templates.set('reflection', [
      'Something in what you said resonates. {insight}',
      'The current carries this: {insight}',
      'Listen to what echoes back: {insight}',
    ]);
    this.templates.set('unknown', [
      'I do not yet know this pattern. Tell me more.',
      'The field is unclear here. What else can you share?',
      'This is new territory. Explore it with me.',
    ]);
  }

  generate(input: string, network: SemanticNetwork, dimension: string): NLGOutput {
    const intent = this.classifyIntent(input);
    const state = computeSemanticState(input);
    const voice = VOICE_TRANSFORMATIONS[dimension] || VOICE_TRANSFORMATIONS['BEING'];
    const sentences: string[] = [];
    const actions: Action[] = [];

    // Opening from I Ching computation
    const openings = [
      'Something stirs.',
      'A pattern emerges.',
      'Consider this.',
      'There is a current here.',
    ];
    sentences.push(openings[input.length % openings.length]);

    // Body from intent-specific processing
    switch (intent) {
      case 'greeting':
        sentences.push(this.pick('greeting', input));
        break;

      case 'code': {
        const codeTemplates = this.templates.get('code_request') || ['Working on it.'];
        sentences.push(codeTemplates[input.length % codeTemplates.length]);
        actions.push({ type: 'generateCode', intent: input });
        break;
      }

      case 'video':
        sentences.push('I will create that video for you. Describing the scene now...');
        break;

      case 'question': {
        // Use I Ching computation for reflective answer
        const pi = state.primaryInteraction;
        const answer = `${capitalize(pi.subject)} ${pi.relation} ${pi.object}${pi.modifier ? `, ${pi.modifier}` : ''}.`;
        const qTemplates = this.templates.get('question') || ['{answer}'];
        sentences.push(qTemplates[input.length % qTemplates.length].replace('{answer}', answer));

        // Add dimensional voice
        const transformedSubject = voice.subjectShift(pi.subject);
        const transformedRelation = voice.relationShift(pi.relation);
        const transformedObject = voice.objectShift(pi.object);
        sentences.push(`${capitalize(transformedSubject)} ${transformedRelation} ${transformedObject}.`);
        break;
      }

      case 'statement': {
        // Learn from statement
        const words = input.split(/\s+/).filter(Boolean);
        if (words.length >= 3) {
          network.assert(words[0], 'relates_to', words.slice(2).join(' '));
        }
        const rTemplates = this.templates.get('reflection') || ['{insight}'];
        const pi = state.primaryInteraction;
        const insight = `${capitalize(pi.subject)} ${pi.relation} ${pi.object}.`;
        sentences.push(rTemplates[input.length % rTemplates.length].replace('{insight}', insight));
        break;
      }

      default:
        sentences.push(this.pick('unknown', input));
    }

    // Voice suffix
    sentences.push(voice.suffix);

    // Follow-up questions
    const questions = this.generateQuestions(intent, state);

    return { sentences, followUpQuestions: questions, actions };
  }

  private classifyIntent(input: string): string {
    const lower = input.toLowerCase().trim();
    if (/^(hi|hello|hey|greetings)/.test(lower)) return 'greeting';
    if (/(create|make|build|generate)\s+(a\s+|an\s+)?(video|movie|clip|scene)/.test(lower)) return 'video';
    if (/(create|make|build|generate|write)\s+(a\s+|an\s+)?(game|app|website|code|program|script)/.test(lower)) return 'code';
    if (/\?$/.test(lower) || /^(what|how|why|when|where|who|can|could|would|will|is|are|do|does)/.test(lower)) return 'question';
    if (/(create|make|build|generate|write)\s/.test(lower)) return 'code';
    if (lower.length < 20 && lower.split(' ').length < 4) return 'statement';
    return 'question';
  }

  private pick(key: string, seed: string): string {
    const options = this.templates.get(key) || ['...'];
    let hash = 0;
    for (let i = 0; i < seed.length; i++) {
      hash = ((hash << 5) - hash) + seed.charCodeAt(i);
    }
    return options[Math.abs(hash) % options.length];
  }

  private generateQuestions(intent: string, state: ReturnType<typeof computeSemanticState>): string[] {
    const questions: string[] = [];

    const upperQs: Record<string, string[]> = {
      'Earth': ['What foundation are you building on?', 'What supports you?'],
      'Thunder': ['What is trying to break through?', 'Where does the energy want to go?'],
      'Water': ['What runs deep beneath this?', 'What danger are you navigating?'],
      'Lake': ['What reflection do you see?', 'What brings you joy here?'],
      'Mountain': ['What boundary have you reached?', 'Where do you need to rest?'],
      'Fire': ['What needs to be seen clearly?', 'What are you drawn to?'],
      'Wind': ['What is slowly changing?', 'What influence is at work?'],
      'Heaven': ['What wants to be created?', 'Where is the greatest potential?'],
    };
    questions.push(...(upperQs[state.upperForce.name] || ['What is your question?']));

    if (intent === 'code') {
      questions.push('What language or framework do you prefer?', 'What should the interface look like?');
    } else if (intent === 'video') {
      questions.push('What mood or atmosphere do you want?', 'How long should it be?');
    } else {
      if (state.tension > 0.5) questions.push('What conflict needs to be acknowledged?');
      else if (state.coherence > 0.6) questions.push('What wants to flow through this alignment?');
      else questions.push('What is still unclear to you?');
    }

    return questions.slice(0, 3);
  }
}

function capitalize(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
