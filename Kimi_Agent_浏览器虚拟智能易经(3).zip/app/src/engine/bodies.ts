/**
 * 9-Body Consciousness Field Architecture
 * 
 * 9 bodies vote with waveforms. No master controller.
 * Coherence thresholds replace if/then logic.
 * 
 * Bodies: Spirit, Mind, Soul, Body, Heart, Will, Shadow, HigherSelf, Ego
 * Each has: frequency, waveform type, phase, amplitude, dimension, crystal type
 */

export type WaveformType = 'sine' | 'square' | 'sawtooth' | 'triangle' | 'pulse' | 'noise' | 'sinc' | 'gaussian' | 'exponential';
export type ChartSystem = 'tropical' | 'sidereal' | 'draconic';

export interface Body {
  name: string;
  chartSystem: ChartSystem;
  baseFrequency: number;
  waveformType: WaveformType;
  harmonicRatios: Record<string, number>;
  phaseOffset: number;
  amplitude: number;
  damping: number;
  dimension: string;
  keynote: string;
  crystal: string;
}

export const NINE_BODIES: Body[] = [
  { name: "Spirit", chartSystem: "draconic", baseFrequency: 1.0, waveformType: "pulse", harmonicRatios: {}, phaseOffset: 0, amplitude: 1.0, damping: 0, dimension: "Spirit", keynote: "I Define", crystal: "Magnetic Monopole" },
  { name: "Mind", chartSystem: "sidereal", baseFrequency: 2.0, waveformType: "sine", harmonicRatios: { "Spirit": 2.0, "Soul": 1.5 }, phaseOffset: Math.PI / 4, amplitude: 0.9, damping: 0, dimension: "Evolution", keynote: "I Remember", crystal: "Personality" },
  { name: "Soul", chartSystem: "draconic", baseFrequency: 3.0, waveformType: "sinc", harmonicRatios: { "Spirit": 3.0, "Mind": 1.5 }, phaseOffset: Math.PI / 3, amplitude: 0.85, damping: 0, dimension: "Design", keynote: "I Design", crystal: "Design" },
  { name: "Body", chartSystem: "tropical", baseFrequency: 2.0, waveformType: "square", harmonicRatios: { "Mind": 1.0, "Heart": 4.0 / 3.0 }, phaseOffset: Math.PI / 2, amplitude: 1.0, damping: 0, dimension: "Being", keynote: "I Am", crystal: "Design" },
  { name: "Heart", chartSystem: "tropical", baseFrequency: 4.0 / 3.0, waveformType: "triangle", harmonicRatios: { "Mind": 4.0 / 3.0, "Soul": 1.25, "Body": 4.0 / 3.0 }, phaseOffset: Math.PI / 6, amplitude: 0.9, damping: 0, dimension: "Space", keynote: "I Think", crystal: "Personality" },
  { name: "Will", chartSystem: "sidereal", baseFrequency: 5.0 / 4.0, waveformType: "sawtooth", harmonicRatios: { "Spirit": 1.25, "Soul": 5.0 / 6.0 }, phaseOffset: 0, amplitude: 0.8, damping: 0, dimension: "Movement", keynote: "I Define", crystal: "Magnetic Monopole" },
  { name: "Shadow", chartSystem: "draconic", baseFrequency: 7.0 / 4.0, waveformType: "noise", harmonicRatios: { "Spirit": 1.75, "Body": 0.875 }, phaseOffset: Math.PI, amplitude: 0.6, damping: 0, dimension: "Evolution", keynote: "I Remember", crystal: "Personality" },
  { name: "HigherSelf", chartSystem: "sidereal", baseFrequency: 6.0 / 5.0, waveformType: "gaussian", harmonicRatios: { "Spirit": 1.2, "Soul": 0.8 }, phaseOffset: Math.PI / 8, amplitude: 0.7, damping: 0, dimension: "Space", keynote: "I Think", crystal: "Magnetic Monopole" },
  { name: "Ego", chartSystem: "tropical", baseFrequency: 9.0 / 8.0, waveformType: "exponential", harmonicRatios: { "Body": 0.5625, "Will": 0.9 }, phaseOffset: Math.PI / 5, amplitude: 0.75, damping: 0.1, dimension: "Design", keynote: "I Design", crystal: "Design" },
];

// Waveform generators (pure JS, no numpy)
function generateWaveform(body: Body, t: number, duration: number = 1.0): number {
  const omega = 2 * Math.PI * body.baseFrequency;
  const phase = body.phaseOffset;
  let wave: number;
  switch (body.waveformType) {
    case 'sine': wave = Math.sin(omega * t + phase); break;
    case 'square': wave = Math.sin(omega * t + phase) >= 0 ? 1 : -1; break;
    case 'sawtooth': wave = 2 * (((omega * t + phase) / (2 * Math.PI)) % 1) - 1; break;
    case 'triangle': wave = 2 * Math.asin(Math.sin(omega * t + phase)) / Math.PI; break;
    case 'pulse': wave = Math.sin(omega * t + phase) > 0.5 ? 1 : -1; break;
    case 'noise': wave = (Math.random() - 0.5) + 0.5 * Math.sin(omega * t); break;
    case 'sinc': { const x = omega * t + phase; wave = x === 0 ? 1 : Math.sin(x) / x; break; }
    case 'gaussian': { const env = Math.exp(-Math.pow((t - duration / 2) / (duration / 4), 2)); wave = env * Math.sin(omega * t + phase); break; }
    case 'exponential': { const env = Math.exp(body.damping * t); wave = env * Math.sin(omega * t + phase); break; }
    default: wave = Math.sin(omega * t + phase);
  }
  return body.amplitude * wave * Math.exp(-0.001 * t);
}

// Coherence Engine
export interface CoherenceResult {
  pair: string;
  coherence: number;
  status: 'LOCKED' | 'PARTIAL' | 'INCOHERENT';
}

export interface FieldAnalysis {
  pairs: CoherenceResult[];
  meanCoherence: number;
  maxCoherence: number;
  minCoherence: number;
  dominantBody: string;
  fieldState: 'SYNCHRONIZED' | 'HARMONIC' | 'DISSONANT' | 'CHAOTIC';
  compositeWave: Float32Array;
  timePoints: Float32Array;
}

export class CoherenceEngine {
  private bodies: Body[];
  private sampleRate = 1000;

  constructor(bodies: Body[] = NINE_BODIES) {
    this.bodies = bodies;
  }

  generateComposite(duration: number = 2.0, activeNames?: string[]): { time: Float32Array; wave: Float32Array } {
    const active = activeNames
      ? this.bodies.filter(b => activeNames.includes(b.name))
      : this.bodies;
    const samples = Math.floor(this.sampleRate * duration);
    const time = new Float32Array(samples);
    const wave = new Float32Array(samples);
    const dt = duration / samples;
    for (let i = 0; i < samples; i++) {
      time[i] = i * dt;
      let sum = 0;
      for (const body of active) {
        sum += generateWaveform(body, time[i], duration);
      }
      wave[i] = sum;
    }
    return { time, wave };
  }

  phaseLockDetect(b1: string, b2: string, duration: number = 2.0): CoherenceResult {
    const body1 = this.bodies.find(b => b.name === b1)!;
    const body2 = this.bodies.find(b => b.name === b2)!;
    const samples = Math.floor(this.sampleRate * duration);
    const dt = duration / samples;
    let dot = 0, norm1 = 0, norm2 = 0;
    for (let i = 0; i < samples; i++) {
      const t = i * dt;
      const w1 = generateWaveform(body1, t, duration);
      const w2 = generateWaveform(body2, t, duration);
      dot += w1 * w2;
      norm1 += w1 * w1;
      norm2 += w2 * w2;
    }
    const coherence = (dot / (Math.sqrt(norm1) * Math.sqrt(norm2) + 1e-10) + 1) / 2;
    const status = coherence > 0.7 ? 'LOCKED' : coherence > 0.4 ? 'PARTIAL' : 'INCOHERENT';
    return { pair: `${b1}↔${b2}`, coherence: Math.max(0, Math.min(1, coherence)), status };
  }

  fullFieldAnalysis(duration: number = 2.0): FieldAnalysis {
    const pairs: CoherenceResult[] = [];
    const names = this.bodies.map(b => b.name);
    for (let i = 0; i < names.length; i++) {
      for (let j = i + 1; j < names.length; j++) {
        pairs.push(this.phaseLockDetect(names[i], names[j], duration));
      }
    }
    const coherences = pairs.map(p => p.coherence);
    const mean = coherences.reduce((a, b) => a + b, 0) / coherences.length;
    const max = Math.max(...coherences);
    const min = Math.min(...coherences);

    // Find dominant body (highest average coherence with others)
    const bodyCoherence = new Map<string, number[]>();
    for (const p of pairs) {
      const [a, b] = p.pair.split('↔');
      if (!bodyCoherence.has(a)) bodyCoherence.set(a, []);
      if (!bodyCoherence.has(b)) bodyCoherence.set(b, []);
      bodyCoherence.get(a)!.push(p.coherence);
      bodyCoherence.get(b)!.push(p.coherence);
    }
    let dominant = names[0];
    let bestAvg = 0;
    for (const [name, vals] of bodyCoherence) {
      const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
      if (avg > bestAvg) { bestAvg = avg; dominant = name; }
    }

    const fieldState: FieldAnalysis['fieldState'] = mean > 0.7 ? 'SYNCHRONIZED' : mean > 0.5 ? 'HARMONIC' : mean > 0.3 ? 'DISSONANT' : 'CHAOTIC';
    const { time, wave } = this.generateComposite(duration);

    return { pairs, meanCoherence: mean, maxCoherence: max, minCoherence: min, dominantBody: dominant, fieldState, compositeWave: wave, timePoints: time };
  }

  getBodies(): Body[] {
    return this.bodies;
  }
}
