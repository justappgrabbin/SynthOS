/**
 * I Ching as Pure Binary Computation
 * 
 * Hexagrams are 6-bit numbers. Trigrams are 3-bit numbers.
 * The computation happens through:
 * - Trigram interaction tables (what does Water over Fire mean?)
 * - Changing lines (which bits flip = transformation path)
 * - Nuclear hexagram (inner dynamics)
 * - XOR between hexagrams (interference patterns)
 * 
 * None of this is visible to the user. It produces semantic triples
 * that the sentence generator turns into natural language.
 */

// ─── Trigram Definitions (3-bit) ───

export interface Trigram {
  bits: number;      // 0-7
  name: string;
  nature: string;    // what it IS
  action: string;    // what it DOES
  quality: string;   // how it feels
}

export const TRIGRAMS: Trigram[] = [
  { bits: 0b000, name: 'Earth',  nature: 'substance',  action: 'receives',   quality: 'yielding' },
  { bits: 0b001, name: 'Thunder', nature: 'arousal',    action: 'shakes',     quality: 'sudden' },
  { bits: 0b010, name: 'Water',  nature: 'depth',      action: 'flows',      quality: 'dangerous' },
  { bits: 0b011, name: 'Lake',   nature: 'reflection', action: 'opens',      quality: 'joyous' },
  { bits: 0b100, name: 'Mountain', nature: 'stillness', action: 'stops',      quality: 'resting' },
  { bits: 0b101, name: 'Fire',   nature: 'clarity',    action: 'illuminates', quality: 'attached' },
  { bits: 0b110, name: 'Wind',   nature: 'penetration', action: 'enters',     quality: 'gentle' },
  { bits: 0b111, name: 'Heaven', nature: 'creation',   action: 'initiates',  quality: 'strong' },
];

export function getUpperTrigram(hexagram: number): Trigram {
  const bits = (hexagram >> 3) & 0b111;
  return TRIGRAMS[bits];
}

export function getLowerTrigram(hexagram: number): Trigram {
  const bits = hexagram & 0b111;
  return TRIGRAMS[bits];
}

export function getNuclearHexagram(hexagram: number): number {
  // Nuclear lines 2,3,4,5 → lower = lines 2,3,4 → upper = lines 3,4,5
  const nucLower = ((hexagram >> 1) & 0b111);
  const nucUpper = ((hexagram >> 2) & 0b111);
  return (nucUpper << 3) | nucLower;
}

export function getChangingLines(oldHex: number, newHex: number): number[] {
  const diff = oldHex ^ newHex;
  const lines: number[] = [];
  for (let i = 0; i < 6; i++) {
    if ((diff >> i) & 1) lines.push(i + 1);
  }
  return lines;
}

export function hexagramToBinary(hexagram: number): boolean[] {
  const lines: boolean[] = [];
  for (let i = 0; i < 6; i++) {
    lines.push(((hexagram >> i) & 1) === 1);
  }
  return lines;
}

// ─── Semantic Interaction Table ───
// What happens when upper trigram meets lower trigram

export interface SemanticInteraction {
  subject: string;     // what acts
  relation: string;    // what it does
  object: string;      // what it acts upon
  modifier: string;    // how it does it
  tone: string;        // emotional quality
}

// 8x8 interaction matrix: upper trigram × lower trigram
const INTERACTION_MATRIX: SemanticInteraction[][] = [
  // Upper = Earth (0)
  [
    { subject: 'the ground', relation: 'holds', object: 'what falls upon it', modifier: 'without judgment', tone: 'still' },
    { subject: 'the earth', relation: 'awakens to', object: 'thunder beneath', modifier: 'trembling', tone: 'uncertain' },
    { subject: 'depth', relation: 'rises through', object: 'the soil', modifier: 'slowly', tone: 'patient' },
    { subject: 'the valley', relation: 'reflects', object: 'the sky above', modifier: 'openly', tone: 'peaceful' },
    { subject: 'the mountain', relation: 'rests upon', object: 'the earth', modifier: 'firmly', tone: 'grounded' },
    { subject: 'hidden fire', relation: 'warms', object: 'the deep places', modifier: 'gently', tone: 'secret' },
    { subject: 'the wind', relation: 'moves across', object: 'open land', modifier: 'softly', tone: 'penetrating' },
    { subject: 'heaven', relation: 'descends to', object: 'earth', modifier: 'completely', tone: 'abundant' },
  ],
  // Upper = Thunder (1)
  [
    { subject: 'a shock', relation: 'breaks through', object: 'the surface', modifier: 'suddenly', tone: 'alarming' },
    { subject: 'repeated thunder', relation: 'echoes', object: 'through the valley', modifier: 'again and again', tone: 'persistent' },
    { subject: 'rain', relation: 'pours from', object: 'dark clouds', modifier: 'heavily', tone: 'overwhelming' },
    { subject: 'a call', relation: 'rings out across', object: 'still water', modifier: 'joyfully', tone: 'inviting' },
    { subject: 'thunder', relation: 'shakes', object: 'the mountain', modifier: 'violently', tone: 'fearful' },
    { subject: 'lightning', relation: 'burns', object: 'the dry grass', modifier: 'brightly', tone: 'transforming' },
    { subject: 'a storm', relation: 'moves through', object: 'the forest', modifier: 'powerfully', tone: 'cleansing' },
    { subject: 'thunder from heaven', relation: 'commands', object: 'all below', modifier: 'absolutely', tone: 'awe' },
  ],
  // Upper = Water (2)
  [
    { subject: 'dark water', relation: 'seeps into', object: 'the earth', modifier: 'silently', tone: 'dangerous' },
    { subject: 'a flood', relation: 'releases', object: 'trapped energy', modifier: 'chaotically', tone: 'destructive' },
    { subject: 'deep water', relation: 'meets', object: 'more water', modifier: 'endlessly', tone: 'profound' },
    { subject: 'a spring', relation: 'fills', object: 'the lake', modifier: 'steadily', tone: 'nourishing' },
    { subject: 'a waterfall', relation: 'pours down', object: 'rock face', modifier: 'relentlessly', tone: 'exhausting' },
    { subject: 'boiling water', relation: 'struggles against', object: 'the fire beneath', modifier: 'fiercely', tone: 'conflicted' },
    { subject: 'mist', relation: 'rises through', object: 'morning air', modifier: 'gently', tone: 'elusive' },
    { subject: 'rain from above', relation: 'blesses', object: 'the waiting land', modifier: 'abundantly', tone: 'grateful' },
  ],
  // Upper = Lake (3)
  [
    { subject: 'a mirror', relation: 'shows', object: 'the ground below', modifier: 'truly', tone: 'reflective' },
    { subject: 'laughter', relation: 'breaks through', object: 'tension', modifier: 'unexpectedly', tone: 'relieving' },
    { subject: 'the shore', relation: 'meets', object: 'the water', modifier: 'playfully', tone: 'intimate' },
    { subject: 'gathered friends', relation: 'share', object: 'their joy', modifier: 'openly', tone: 'celebratory' },
    { subject: 'a pond', relation: 'rests against', object: 'the hillside', modifier: 'calmly', tone: 'content' },
    { subject: 'firelight', relation: 'dances on', object: 'the water', modifier: 'beautifully', tone: 'warm' },
    { subject: 'a breeze', relation: 'ripples', object: 'the surface', modifier: 'softly', tone: 'playful' },
    { subject: 'the full moon', relation: 'reflects in', object: 'still water', modifier: 'perfectly', tone: 'sublime' },
  ],
  // Upper = Mountain (4)
  [
    { subject: 'a boundary', relation: 'marks', object: 'the edge', modifier: 'clearly', tone: 'limiting' },
    { subject: 'a landslide', relation: 'blocks', object: 'the path', modifier: 'suddenly', tone: 'obstructing' },
    { subject: 'a well', relation: 'draws from', object: 'deep water', modifier: 'carefully', tone: 'conserving' },
    { subject: 'a overlook', relation: 'sees', object: 'the valley below', modifier: 'distantly', tone: 'contemplative' },
    { subject: 'two peaks', relation: 'face', object: 'each other', modifier: 'mutually', tone: 'balanced' },
    { subject: 'a beacon', relation: 'burns atop', object: 'the summit', modifier: 'steadily', tone: 'guiding' },
    { subject: 'a cave', relation: 'breathes', object: 'cool air', modifier: 'rhythmically', tone: 'mysterious' },
    { subject: 'the highest point', relation: 'touches', object: 'the sky', modifier: 'reverently', tone: 'sacred' },
  ],
  // Upper = Fire (5)
  [
    { subject: 'hidden warmth', relation: 'rises from', object: 'dark earth', modifier: 'slowly', tone: 'expectant' },
    { subject: 'a flash', relation: 'illuminates', object: 'the storm', modifier: 'briefly', tone: 'startling' },
    { subject: 'fire and water', relation: 'struggle for', object: 'dominance', modifier: 'endlessly', tone: 'tense' },
    { subject: 'sunset', relation: 'colors', object: 'the lake', modifier: 'brilliantly', tone: 'beautiful' },
    { subject: 'a volcano', relation: 'builds within', object: 'the mountain', modifier: 'pressingly', tone: 'volatile' },
    { subject: 'pure fire', relation: 'feeds upon', object: 'itself', modifier: 'intensely', tone: 'consuming' },
    { subject: 'smoke', relation: 'rises through', object: 'the trees', modifier: 'thickly', tone: 'warning' },
    { subject: 'the sun', relation: 'shines upon', object: 'all things', modifier: 'equally', tone: 'illuminating' },
  ],
  // Upper = Wind (6)
  [
    { subject: 'a whisper', relation: 'moves across', object: 'open ground', modifier: 'barely heard', tone: 'subtle' },
    { subject: 'a message', relation: 'travels on', object: 'thunder\'s echo', modifier: 'quickly', tone: 'urgent' },
    { subject: 'a current', relation: 'stirs', object: 'deep water', modifier: 'persistently', tone: 'insistent' },
    { subject: 'a breath', relation: 'ripples', object: 'the surface', modifier: 'lightly', tone: 'intimate' },
    { subject: 'a path', relation: 'winds up', object: 'the mountainside', modifier: 'gradually', tone: 'patient' },
    { subject: 'a fan', relation: 'spreads', object: 'the fire', modifier: 'wisely', tone: 'nurturing' },
    { subject: 'the wind', relation: 'follows', object: 'the wind', modifier: 'endlessly', tone: 'wandering' },
    { subject: 'a decree', relation: 'reaches', object: 'all corners', modifier: 'thoroughly', tone: 'commanding' },
  ],
  // Upper = Heaven (7)
  [
    { subject: 'creative force', relation: 'enters', object: 'receptive ground', modifier: 'wholly', tone: 'generative' },
    { subject: 'the sky', relation: 'opens to', object: 'sudden change', modifier: 'vastly', tone: 'empowering' },
    { subject: 'rain', relation: 'falls from', object: 'the heavens', modifier: 'steadily', tone: 'blessing' },
    { subject: 'a gift', relation: 'descends to', object: 'open water', modifier: 'graciously', tone: 'bountiful' },
    { subject: 'a vision', relation: 'appears on', object: 'the mountaintop', modifier: 'clearly', tone: 'revealing' },
    { subject: 'the sun', relation: 'meets', object: 'the fire below', modifier: 'brilliantly', tone: 'magnificent' },
    { subject: 'a journey', relation: 'proceeds under', object: 'favorable skies', modifier: 'smoothly', tone: 'fortunate' },
    { subject: 'pure creation', relation: 'moves', object: 'through creation', modifier: 'powerfully', tone: 'transcendent' },
  ],
];

export function computeInteraction(upperBits: number, lowerBits: number): SemanticInteraction {
  return INTERACTION_MATRIX[upperBits][lowerBits];
}

// ─── Changing Line Transformations ───
// Each changing line produces a specific semantic transformation

export interface LineTransformation {
  position: number;
  theme: string;
  fromYin: string;   // what it was
  toYang: string;    // what it becomes
  fromYang: string;
  toYin: string;
}

export const LINE_TRANSFORMATIONS: LineTransformation[] = [
  { position: 1, theme: 'foundation', fromYin: 'hesitation', toYang: 'decisive action', fromYang: 'force', toYin: 'retreat' },
  { position: 2, theme: 'emergence', fromYin: 'hidden potential', toYang: 'visible talent', fromYang: 'display', toYin: 'cultivation' },
  { position: 3, theme: 'transition', fromYin: 'caution', toYang: 'bold crossing', fromYang: 'impulse', toYin: 'careful steps' },
  { position: 4, theme: 'relationship', fromYin: 'inner searching', toYang: 'outer connection', fromYang: 'dominance', toYin: 'listening' },
  { position: 5, theme: 'leadership', fromYin: 'questioning', toYang: 'commanding', fromYang: 'control', toYin: 'wisdom through humility' },
  { position: 6, theme: 'completion', fromYin: 'holding back', toYang: 'release', fromYang: 'final push', toYin: 'acceptance' },
];

// ─── Hexagram Names (only for internal reference, never shown to user) ───

export const HEXAGRAM_NAMES: string[] = [
  'Earth', 'Thunder in Earth', 'Water in Earth', 'Lake in Earth',
  'Mountain in Earth', 'Fire in Earth', 'Wind in Earth', 'Heaven in Earth',
  'Earth in Thunder', 'Thunder', 'Water in Thunder', 'Lake in Thunder',
  'Mountain in Thunder', 'Fire in Thunder', 'Wind in Thunder', 'Heaven in Thunder',
  'Earth in Water', 'Thunder in Water', 'Water', 'Lake in Water',
  'Mountain in Water', 'Fire in Water', 'Wind in Water', 'Heaven in Water',
  'Earth in Lake', 'Thunder in Lake', 'Water in Lake', 'Lake',
  'Mountain in Lake', 'Fire in Lake', 'Wind in Lake', 'Heaven in Lake',
  'Earth in Mountain', 'Thunder in Mountain', 'Water in Mountain', 'Lake in Mountain',
  'Mountain', 'Fire in Mountain', 'Wind in Mountain', 'Heaven in Mountain',
  'Earth in Fire', 'Thunder in Fire', 'Water in Fire', 'Lake in Fire',
  'Mountain in Fire', 'Fire', 'Wind in Fire', 'Heaven in Fire',
  'Earth in Wind', 'Thunder in Wind', 'Water in Wind', 'Lake in Wind',
  'Mountain in Wind', 'Fire in Wind', 'Wind', 'Heaven in Wind',
  'Earth in Heaven', 'Thunder in Heaven', 'Water in Heaven', 'Lake in Heaven',
  'Mountain in Heaven', 'Fire in Heaven', 'Wind in Heaven', 'Heaven',
];

// ─── Input → Hexagram Computation ───

export function textToHexagram(text: string): { primary: number; relating: number; changingLines: number[] } {
  // Hash text to seed
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    hash = ((hash << 5) - hash) + text.charCodeAt(i);
    hash = hash & 0xFFFFFFFF;
  }

  // Primary hexagram: 6 bits from hash
  const primary = Math.abs(hash) & 0b111111;

  // Relating hexagram: different bit pattern from hash
  const hash2 = Math.imul(hash, 0x9E3779B9);
  const relating = Math.abs(hash2) & 0b111111;

  const changingLines = getChangingLines(primary, relating);

  return { primary, relating, changingLines };
}

// ─── Full Semantic Computation ───
// Produces a rich semantic structure from I Ching computation

export interface SemanticState {
  primaryInteraction: SemanticInteraction;
  nuclearInteraction: SemanticInteraction;
  transformations: Array<{
    line: number;
    theme: string;
    change: string;
  }>;
  upperForce: Trigram;
  lowerForce: Trigram;
  nuclearUpper: Trigram;
  nuclearLower: Trigram;
  coherence: number;  // how aligned the forces are
  tension: number;    // how much conflict exists
}

export function computeSemanticState(text: string): SemanticState {
  const { primary, relating, changingLines } = textToHexagram(text);

  const upperForce = getUpperTrigram(primary);
  const lowerForce = getLowerTrigram(primary);
  const primaryInteraction = computeInteraction(upperForce.bits, lowerForce.bits);

  const nuclearHex = getNuclearHexagram(primary);
  const nuclearUpper = getUpperTrigram(nuclearHex);
  const nuclearLower = getLowerTrigram(nuclearHex);
  const nuclearInteraction = computeInteraction(nuclearUpper.bits, nuclearLower.bits);

  const transformations = changingLines.map(lineNum => {
    const lt = LINE_TRANSFORMATIONS[lineNum - 1];
    const wasYang = ((primary >> (lineNum - 1)) & 1) === 1;
    return {
      line: lineNum,
      theme: lt.theme,
      change: wasYang ? `${lt.fromYang} → ${lt.toYin}` : `${lt.fromYin} → ${lt.toYang}`,
    };
  });

  // Coherence: how similar are upper and lower trigrams
  const sharedBits = 7 - countSetBits(upperForce.bits ^ lowerForce.bits);
  const coherence = sharedBits / 3;

  // Tension: how different is relating from primary
  const tension = countSetBits(primary ^ relating) / 6;

  return {
    primaryInteraction,
    nuclearInteraction,
    transformations,
    upperForce,
    lowerForce,
    nuclearUpper,
    nuclearLower,
    coherence,
    tension,
  };
}

function countSetBits(n: number): number {
  let count = 0;
  while (n) { count += n & 1; n >>= 1; }
  return count;
}

// ─── Dimension-Specific Voice Transformations ───
// Each of the 5 dimensions speaks the same meaning differently

export interface VoiceTransformation {
  prefix: string;
  subjectShift: (s: string) => string;
  relationShift: (r: string) => string;
  objectShift: (o: string) => string;
  suffix: string;
}

export const VOICE_TRANSFORMATIONS: Record<string, VoiceTransformation> = {
  MOVEMENT: {
    prefix: 'There is motion here.',
    subjectShift: s => s,
    relationShift: r => r,
    objectShift: o => o,
    suffix: 'The direction matters more than the destination.',
  },
  EVOLUTION: {
    prefix: 'Something is remembering itself.',
    subjectShift: s => `the pattern of ${s}`,
    relationShift: r => `has always ${r}`,
    objectShift: o => o,
    suffix: 'This has happened before, in different forms.',
  },
  BEING: {
    prefix: 'Here, existence itself speaks.',
    subjectShift: s => s,
    relationShift: r => `simply ${r}`,
    objectShift: o => o,
    suffix: 'Nothing more is needed than what already is.',
  },
  DESIGN: {
    prefix: 'A structure reveals itself.',
    subjectShift: s => `the architecture of ${s}`,
    relationShift: r => `is designed to ${r}`,
    objectShift: o => o,
    suffix: 'Every element has its purpose and place.',
  },
  SPACE: {
    prefix: 'Listen to the resonance.',
    subjectShift: s => s,
    relationShift: r => r,
    objectShift: o => `the space where ${o} exists`,
    suffix: 'What is not said holds as much truth as what is.',
  },
};
