/**
 * Natural Language Generator
 * 
 * Takes semantic triples from I Ching computation and produces
 * fluent, natural English sentences. The user never sees
 * hexagram numbers, gate labels, or technical terminology.
 * 
 * Inspired by MESSY's lexical expression lists and
 * AUTOLING's semantic-to-surface generation.
 */

import {
  computeSemanticState,
  VOICE_TRANSFORMATIONS,
  type Trigram,
  type SemanticState,
  type SemanticInteraction,
} from './iching';

// ─── Sentence Templates ───
// These map semantic interactions to natural language patterns.
// They are designed to produce flowing, evocative prose.

const OPENING_TEMPLATES = [
  'Something stirs.',
  'A pattern emerges.',
  'Consider this moment.',
  'There is a current moving here.',
  'Pay attention to what arrives.',
  'A threshold presents itself.',
  'Listen to what the situation demands.',
  'The conditions are shaping themselves.',
];

const CLOSING_TEMPLATES = [
  'Wait for the right moment to act.',
  'What is needed will appear in time.',
  'The outcome depends on your sincerity.',
  'Movement now would be premature.',
  'Stillness reveals what action cannot.',
  'Follow what feels inevitable.',
  'The answer is already within the question.',
  'Trust the unfolding.',
];

// Variations of the core interaction as natural sentences
function renderInteraction(si: SemanticInteraction, _voice: string): string {
  // Build a natural sentence from subject-relation-object-modifier
  const patterns = [
    `${capitalize(si.subject)} ${si.relation} ${si.object}${si.modifier ? `, ${si.modifier}` : ''}.`,
    `In this place, ${si.subject} ${si.relation} ${si.object}.`,
    `${capitalize(si.relation)} ${si.object}, ${si.subject} moves ${si.modifier}.`,
    `${capitalize(si.subject)} — ${si.relation} ${si.object} ${si.modifier}.`,
    `Where ${si.subject} ${si.relation}s, ${si.object} responds.`,
  ];
  // Deterministic selection based on interaction content
  const idx = (si.subject.length + si.relation.length + si.object.length) % patterns.length;
  return patterns[idx];
}

function renderNuclearInteraction(si: SemanticInteraction): string {
  const patterns = [
    `Beneath the surface, ${si.subject} ${si.relation} ${si.object}.`,
    `What is not yet visible: ${si.subject} ${si.relation} ${si.object}${si.modifier ? `, ${si.modifier}` : ''}.`,
    `The hidden movement — ${si.subject} ${si.relation} ${si.object}.`,
    `Behind appearances, ${si.relation} ${si.object} waits.`,
  ];
  const idx = (si.tone.length * 3) % patterns.length;
  return patterns[idx];
}

function renderTransformation(line: number, _theme: string, change: string): string {
  const templates: Record<number, string[]> = {
    1: [
      `At the foundation, ${change}. The ground shifts beneath your feet.`,
      `What supports everything is changing: ${change}.`,
    ],
    2: [
      `Something emerges that was hidden: ${change}.`,
      `The second layer reveals itself — ${change}.`,
    ],
    3: [
      `A crossing is at hand: ${change}.`,
      `Between what was and what will be: ${change}.`,
    ],
    4: [
      `Relationships transform: ${change}.`,
      `The way you connect shifts: ${change}.`,
    ],
    5: [
      `Wisdom asks for humility: ${change}.`,
      `At the height of things, ${change}.`,
    ],
    6: [
      `Completion approaches: ${change}.`,
      `The final movement: ${change}.`,
    ],
  };
  const options = templates[line] || templates[3];
  const idx = change.length % options.length;
  return options[idx];
}

function renderForceQualities(upper: Trigram, lower: Trigram): string {
  const patterns = [
    `The quality of ${upper.nature} meets the ${lower.quality} nature of ${lower.nature}.`,
    `${capitalize(upper.action)} above, ${lower.action} below — this creates ${upper.quality} ${lower.nature}.`,
    `What ${upper.action}s from above encounters what ${lower.action}s from below.`,
  ];
  const idx = (upper.bits + lower.bits) % patterns.length;
  return patterns[idx];
}

// ─── Main Generation ───

export interface NaturalRevelation {
  opening: string;
  body: string[];
  closing: string;
  dimension: string;
  coherence: number;
  tension: number;
  followUpQuestions: string[];
}

function capitalize(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function selectOpening(text: string): string {
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    hash = ((hash << 5) - hash) + text.charCodeAt(i);
    hash = hash & 0xFFFFFFFF;
  }
  return OPENING_TEMPLATES[Math.abs(hash) % OPENING_TEMPLATES.length];
}

function selectClosing(coherence: number, tension: number): string {
  if (tension > 0.6) {
    return 'Conflict is present. Move carefully through what resists.';
  }
  if (coherence > 0.7) {
    return 'All elements align. What you seek is already forming.';
  }
  if (coherence < 0.3) {
    return 'The pieces have not yet found their place. Patience is the only action now.';
  }
  const idx = Math.floor((coherence + tension) * 4) % CLOSING_TEMPLATES.length;
  return CLOSING_TEMPLATES[idx];
}

function generateFollowUpQuestions(state: SemanticState): string[] {
  const questions: string[] = [];

  // Question based on upper force
  const upperQs: Record<string, string[]> = {
    'Earth': ['What are you waiting for?', 'What supports you right now?'],
    'Thunder': ['What is trying to break through?', 'Where is the energy building?'],
    'Water': ['What runs deep beneath this?', 'What danger are you avoiding?'],
    'Lake': ['What reflection do you see?', 'What brings you joy here?'],
    'Mountain': ['What boundary have you reached?', 'Where do you need to stop?'],
    'Fire': ['What needs to be seen clearly?', 'What are you clinging to?'],
    'Wind': ['What is slowly changing?', 'What influence is at work?'],
    'Heaven': ['What wants to be created?', 'Where is the greatest potential?'],
  };
  questions.push(...(upperQs[state.upperForce.name] || ['What is your question?']));

  // Question based on transformation
  if (state.transformations.length > 0) {
    const t = state.transformations[0];
    questions.push(`How does ${t.theme} show itself in your situation?`);
  }

  // Question based on coherence/tension
  if (state.tension > 0.5) {
    questions.push('What conflict needs to be acknowledged?');
  } else if (state.coherence > 0.6) {
    questions.push('What wants to flow through this alignment?');
  } else {
    questions.push('What is still unclear to you?');
  }

  return questions.slice(0, 3);
}

export function generateRevelation(text: string, dimension: string): NaturalRevelation {
  const state = computeSemanticState(text);
  const voice = VOICE_TRANSFORMATIONS[dimension] || VOICE_TRANSFORMATIONS['BEING'];

  const opening = selectOpening(text);
  const closing = selectClosing(state.coherence, state.tension);

  const body: string[] = [];

  // Primary interaction — the main statement
  const primarySentence = renderInteraction(state.primaryInteraction, dimension);
  body.push(voice.prefix);
  body.push(primarySentence);

  // Force qualities
  body.push(renderForceQualities(state.upperForce, state.lowerForce));

  // Nuclear — what's beneath
  if (state.tension > 0.3) {
    body.push(renderNuclearInteraction(state.nuclearInteraction));
  }

  // Transformations — what's changing
  for (const t of state.transformations.slice(0, 2)) {
    body.push(renderTransformation(t.line, t.theme, t.change));
  }

  // Dimensional voice suffix
  body.push(voice.suffix);

  // Closing
  body.push(closing);

  const followUpQuestions = generateFollowUpQuestions(state);

  return {
    opening,
    body,
    closing,
    dimension,
    coherence: state.coherence,
    tension: state.tension,
    followUpQuestions,
  };
}

// ─── Multi-Dimensional Revelation ───
// Produces 5 different readings of the same input, one per dimension

export interface MultiDimensionalRevelation {
  primary: NaturalRevelation;
  dimensions: NaturalRevelation[];
}

const DIMENSION_NAMES = ['MOVEMENT', 'EVOLUTION', 'BEING', 'DESIGN', 'SPACE'];

export function generateMultiDimensionalRevelation(text: string): MultiDimensionalRevelation {
  const primary = generateRevelation(text, 'BEING');
  const dimensions = DIMENSION_NAMES.map(dim => generateRevelation(text, dim));

  return {
    primary,
    dimensions,
  };
}
