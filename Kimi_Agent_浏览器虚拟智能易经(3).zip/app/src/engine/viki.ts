/**
 * VIKI Unified Engine v5
 * 
 * Integrates:
 * - 9-Body Coherence Field (waveform voting, no master controller)
 * - Complete 64-Gate Codon Dictionary
 * - TripleGNN Neural Network (triple embeddings + graph message passing)
 * - Klein Tools Suite (8 tools, 5 dimensions each)
 * - Sentence Router (7 output modes)
 * - HybridMessyRuntime (sandboxed code execution)
 * - MESSY Semantic Network
 * - IndexedDB persistence
 * 
 * Recursive learning:
 *   Input → 9-body coherence vote → gate mapping → neural embed
 *   → Klein tool selection → sentence generation → output
 *   → feedback into neural + MESSY learning
 */

import { NINE_BODIES, CoherenceEngine } from './bodies';
import { GATES, getGate } from './gates';
import { NeuralNetwork } from './neural';
import { SemanticNetwork, NLGenerator } from './messy';
import { parseIntent, generateCode } from './codegen';
import { saveConversation, getConversations, saveProject, getProjects, deleteProject } from '@/storage/db';
import { DIMENSIONS } from '@/types';
import type { Dimension } from '@/types';
import type { ProjectRecord } from '@/storage/db';
import type { NeuralState } from './neural';

export type Mode = 'chat' | 'code' | 'video' | 'projects';

export interface ChatMessage {
  id: string;
  role: 'user' | 'system';
  content: string;
  type: 'chat' | 'code' | 'video' | 'system';
  timestamp: number;
  neural?: NeuralState;
  metadata?: {
    code?: string;
    language?: string;
    files?: Array<{ path: string; content: string; language: string }>;
    coherence?: number;
    dimension?: string;
    gate?: number;
    bodyState?: string;
  };
}

// ─── Klein Tools ───

export interface KleinToolResult {
  tool: string;
  mode: string;
  dimension: string;
  output: Record<string, unknown>;
}

const KLEIN_TOOLS = {
  DISEMINER: {
    Movement: 'Measurer', Evolution: 'Dismember', Being: 'Timer', Design: 'Analyzer', Space: 'Identifier',
  },
  AUTOLING: {
    Movement: 'Router', Evolution: 'Linguist', Being: 'Chronologist', Design: 'Grammarian', Space: 'Personologist',
  },
  COMPARER: {
    Movement: 'Weigher', Evolution: 'Historian', Being: 'Synthesizer', Design: 'Taxonomist', Space: 'Relativist',
  },
  INTERROGATOR: {
    Movement: 'Pointer', Evolution: 'Evolver', Being: 'Sifter', Design: 'Questioner', Space: 'Wonderer',
  },
  CONTEXTER: {
    Movement: 'Tracker', Evolution: 'Archaeologist', Being: 'Meditator', Design: 'Systematizer', Space: 'Mystic',
  },
  SYNTHESIZER: {
    Movement: 'Builder', Evolution: 'Alchemist', Being: 'Creator', Design: 'Architect', Space: 'Poet',
  },
  METAMORPH: {
    Movement: 'Transformer', Evolution: 'Mutator', Being: 'Healer', Design: 'Engineer', Space: 'Transcender',
  },
  ORACLE: {
    Movement: 'Navigator', Evolution: 'Rememberer', Being: 'Presencer', Design: 'Patterner', Space: 'Dreamer',
  },
};

function selectKleinTool(input: string, dimension: string): KleinToolResult {
  const tools = Object.keys(KLEIN_TOOLS);
  const toolIndex = input.length % tools.length;
  const tool = tools[toolIndex];
  const mode = (KLEIN_TOOLS as Record<string, Record<string, string>>)[tool][dimension] || 'Universal';
  return { tool, mode, dimension, output: { inputLength: input.length, dimension, tool: tool.toLowerCase() } };
}

// ─── Sentence Router ───

export type OutputMode = 'metaphysical' | 'scientific' | 'psycholinguistic' | 'compressed' | 'poetic' | 'synthia' | 'raw';

function routeOutputMode(input: string, coherence: number): OutputMode {
  const lower = input.toLowerCase();
  if (/why|meaning|purpose|soul|spirit/.test(lower)) return 'metaphysical';
  if (/how|mechanism|process|structure|system/.test(lower)) return 'scientific';
  if (/what|define|explain|describe/.test(lower)) return 'psycholinguistic';
  if (/poem|poetry|verse|song|lyric/.test(lower)) return 'poetic';
  if (/code|generate|build|make|create/.test(lower)) return 'synthia';
  if (/brief|short|quick|summary/.test(lower)) return 'compressed';
  if (coherence > 0.8) return 'poetic';
  if (coherence > 0.5) return 'metaphysical';
  return 'psycholinguistic';
}

function generateSentence(gate: typeof GATES[0], line: number, color: number, tone: number, base: number, mode: OutputMode): string {
  switch (mode) {
    case 'metaphysical':
      return gateMetaphysical(gate, line, color, tone, base);
    case 'scientific':
      return gateScientific(gate, line, color, tone, base);
    case 'poetic':
      return gatePoetic(gate, line, color, tone, base);
    case 'compressed':
      return gateCompressed(gate, line, color, tone, base);
    case 'synthia':
      return gateSynthia(gate, line, color, tone, base);
    default:
      return gateMetaphysical(gate, line, color, tone, base);
  }
}

function gateMetaphysical(g: typeof GATES[0], line: number, color: number, tone: number, base: number): string {
  const lines = {1:"Investigation",2:"Projection",3:"Trial & Error",4:"Opportunism",5:"Heresy",6:"Role Model"};
  const colors = {1:"Motivation",2:"Awareness",3:"Mystery",4:"Innocence",5:"Power",6:"Peace"};
  const tones = {1:"Touch",2:"Taste",3:"Smell",4:"Hearing",5:"Sight",6:"Knowing"};
  const bases = {1:"Point",2:"Line",3:"Plane",4:"Volume"};
  return `${g.keynote} ${colors[color as keyof typeof colors] || ''} expressed through ${lines[line as keyof typeof lines] || ''}, filtered through ${tones[tone as keyof typeof tones] || ''}, rooted in ${bases[base as keyof typeof bases] || ''}, aligned with the ${g.dimension} Axis, under the sign of ${g.sign}.`;
}

function gateScientific(g: typeof GATES[0], line: number, color: number, tone: number, base: number): string {
  return `Encodes ${g.aminoAcid} (Gate ${g.gate}), expressing through Line ${line} with Color ${color}, Tone ${tone}, anchored in Base ${base}. Aligns with ${g.sign}'s ${g.modality} ${g.elementSign} field. Quantum pressure: ${g.pressureType} via ${g.sensoryVector}. Codons: ${g.codons.join(', ')}.`;
}

function gatePoetic(g: typeof GATES[0], line: number, _c: number, _t: number, _b: number): string {
  const poems: Record<string, string[]> = {
    'C': ['The carbon skeleton breathes','Dark structure holds the form'],
    'H': ['Hydrogen whispers potential','A single bond becomes a path'],
    'O': ['Oxygen ignites the action','Fire consumes and transforms'],
    'N': ['Nitrogen remembers the deep','Blue waters of ancient knowing'],
    'P': ['Phosphorus sparks the light','Energy crystallizes into being'],
    'S': ['Sulfur bridges the worlds','Transformation is the only constant'],
  };
  const lines = {1:"The foundation trembles",2:"Emergence breaks the surface",3:"The crossing demands courage",4:"Relationships weave new patterns",5:"The height reveals all",6:"Completion dissolves into beginning"};
  const el = g.element as keyof typeof poems;
  const poemLines = poems[el] || poems['C'];
  return `${poemLines[line % poemLines.length]}. ${lines[line as keyof typeof lines] || 'The pattern unfolds'}. ${g.shadow} becomes ${g.gift}, and in the far light, ${g.siddhi}.`;
}

function gateCompressed(g: typeof GATES[0], line: number, color: number, tone: number, base: number): string {
  return `F:${g.dimension} → G:${g.gate}° → L:${line}′ → C:${color}″ → T:${tone} → B:${base} → {${g.dimension} → ${g.sign} → ${g.house}th}`;
}

function gateSynthia(g: typeof GATES[0], line: number, color: number, tone: number, base: number): string {
  return `[SYNTHIA] gate_${g.gate}_line_${line}: element=${g.element}, pressure=${g.pressureType}, sense=${g.sensoryVector}, codon=${g.codons[0]}, shadow=${g.shadow}, gift=${g.gift} :: full_expression={${gateMetaphysical(g, line, color, tone, base)}}`;
}

// ─── Main Engine ───

let _neural: NeuralNetwork | null = null;
function getNeural(): NeuralNetwork {
  if (!_neural) _neural = new NeuralNetwork();
  return _neural;
}

export class VikiEngine {
  neural: NeuralNetwork;
  coherence: CoherenceEngine;
  network: SemanticNetwork;
  nlg: NLGenerator;
  messages: ChatMessage[] = [];
  activeMode: Mode = 'chat';
  activeDimension: Dimension = 'BEING';
  isProcessing = false;
  isGeneratingVideo = false;
  projects: ProjectRecord[] = [];
  currentCode: string | null = null;
  onUpdate: (() => void) | null = null;

  constructor() {
    this.neural = getNeural();
    this.coherence = new CoherenceEngine(NINE_BODIES);
    this.network = new SemanticNetwork();
    this.nlg = new NLGenerator();
  }

  async init(): Promise<void> {
    const convs = await getConversations();
    for (const conv of convs) {
      this.messages.push({
        id: conv.id,
        role: conv.role as 'user' | 'system',
        content: conv.content,
        type: conv.type as 'chat' | 'code' | 'video' | 'system',
        timestamp: conv.timestamp,
      });
      if (conv.role === 'user') {
        const idx = convs.indexOf(conv);
        if (idx + 1 < convs.length && convs[idx + 1].role === 'system') {
          this.neural.learn(conv.content, convs[idx + 1].content);
        }
      }
    }
    this.projects = await getProjects();
  }

  async sendMessage(text: string): Promise<void> {
    if (!text.trim() || this.isProcessing) return;
    this.isProcessing = true;
    this._notify();

    // 1. User message
    const userMsg: ChatMessage = { id: `${Date.now()}_u`, role: 'user', content: text, type: 'chat', timestamp: Date.now() };
    this.messages.push(userMsg);
    await saveConversation({ timestamp: Date.now(), role: 'user', content: text, type: 'chat' });

    // 2. 9-BODY COHERENCE: Vote on the field state
    const fieldAnalysis = this.coherence.fullFieldAnalysis(1.0);

    // 3. GATE MAPPING: Hash input to gate/line/color/tone/base
    let hash = 0;
    for (let i = 0; i < text.length; i++) hash = ((hash << 5) - hash) + text.charCodeAt(i);
    const gateNum = (Math.abs(hash) % 64) + 1;
    const line = (Math.abs(hash >> 6) % 6) + 1;
    const color = (Math.abs(hash >> 12) % 6) + 1;
    const tone = (Math.abs(hash >> 18) % 6) + 1;
    const base = (Math.abs(hash >> 24) % 4) + 1;
    const gate = getGate(gateNum) || GATES[0];

    // 4. DIMENSION: From coherence dominant body
    const dominantBody = NINE_BODIES.find(b => b.name === fieldAnalysis.dominantBody);
    const dimName = (dominantBody?.dimension || 'Being') as Dimension;
    const dimIndex = DIMENSIONS.findIndex(d => d.name === dimName);
    const dimension = DIMENSIONS[dimIndex]?.name || 'BEING';

    // 5. NEURAL: Process through network
    const neuralState = this.neural.process(text);

    // 6. KLEIN TOOL: Select tool for this dimension
    const kleinResult = selectKleinTool(text, dimension);

    // 7. ROUTE: Determine output mode
    const outputMode = routeOutputMode(text, fieldAnalysis.meanCoherence);

    // 8. GENERATE: Sentence from gate + router
    const sentence = generateSentence(gate, line, color, tone, base, outputMode);

    // 9. Contextual response
    const lower = text.toLowerCase();
    const isCodeRequest = /(create|make|build|generate|write)\s+(a\s+|an\s+)?(game|app|code|script|program)/.test(lower) || /(snake|pong|platformer|shooter|calculator|todo|paint|clock|counter)/.test(lower);
    const isVideoRequest = /(create|make|generate)\s+(a\s+|an\s+)?video/.test(lower) || /video of/.test(lower);

    try {
      if (isVideoRequest) {
        const desc = text.replace(/(create|make|generate|a|an|video|of)\s+/gi, '').trim() || 'abstract visualization';
        const sysMsg: ChatMessage = {
          id: `${Date.now()}_s`, role: 'system',
          content: `${sentence}\n\nCreating video: ${desc}\n\nThe 9-body field is in ${fieldAnalysis.fieldState} state (${(fieldAnalysis.meanCoherence * 100).toFixed(0)}% coherence). Gate ${gate.gate} (${gate.aminoAcid}) activated.`,
          type: 'video', timestamp: Date.now(),
          neural: neuralState,
          metadata: { coherence: fieldAnalysis.meanCoherence, dimension, gate: gate.gate, bodyState: fieldAnalysis.fieldState },
        };
        this.messages.push(sysMsg);
        await saveConversation({ timestamp: Date.now(), role: 'system', content: sysMsg.content, type: 'video', metadata: sysMsg.metadata });

      } else if (isCodeRequest) {
        const intent = parseIntent(text);
        const result = generateCode(intent);
        const sysMsg: ChatMessage = {
          id: `${Date.now()}_s`, role: 'system',
          content: `${sentence}\n\nBuilding ${intent.subtype} ${intent.type}...\n\n[Tool: ${kleinResult.tool}.${kleinResult.mode}] Field: ${fieldAnalysis.fieldState} | Coherence: ${fieldAnalysis.meanCoherence.toFixed(3)} | Gate: ${gate.gate}.${line} (${gate.aminoAcid})\n\nGenerated ${intent.subtype} ${intent.type}. Click "View Code" to see and run.`,
          type: 'code', timestamp: Date.now(),
          neural: neuralState,
          metadata: { code: result.code, language: result.language, files: result.files?.map(f => ({ ...f, language: result.language || 'javascript' })), coherence: fieldAnalysis.meanCoherence, dimension, gate: gate.gate, bodyState: fieldAnalysis.fieldState },
        };
        this.messages.push(sysMsg);
        this.currentCode = result.code;
        this.activeMode = 'code';
        await saveConversation({ timestamp: Date.now(), role: 'system', content: sysMsg.content, type: 'code', metadata: sysMsg.metadata });

        const projectFiles = result.files?.map(f => ({ ...f, language: result.language || 'javascript' }));
        await saveProject({ name: `${intent.subtype} ${intent.type}`, type: intent.type === 'game' ? 'game' : 'app', description: text, code: result.code, language: result.language, files: projectFiles });
        this.projects = await getProjects();

      } else {
        // Chat mode: blend gate sentence with neural generation
        const nlgResult = this.nlg.generate(text, this.network, dimension);
        const learnedRules = this.neural.findRules(this.neural.vocab.tokenize(text));

        let content = `${sentence}\n\n`;
        content += `The field resonates at ${(fieldAnalysis.meanCoherence * 100).toFixed(0)}% coherence — ${fieldAnalysis.fieldState.toLowerCase()}. `;
        content += `${fieldAnalysis.dominantBody} leads the vote. `;
        if (learnedRules.length > 0 && learnedRules[0].weight > 2) {
          content += learnedRules[0].response + '\n\n';
        }
        content += nlgResult.sentences.slice(1).join('\n\n');

        const sysMsg: ChatMessage = {
          id: `${Date.now()}_s`, role: 'system', content,
          type: 'chat', timestamp: Date.now(),
          neural: neuralState,
          metadata: { coherence: fieldAnalysis.meanCoherence, dimension, gate: gate.gate, bodyState: fieldAnalysis.fieldState },
        };
        this.messages.push(sysMsg);
        await saveConversation({ timestamp: Date.now(), role: 'system', content, type: 'chat', metadata: sysMsg.metadata });

        for (const q of nlgResult.followUpQuestions) {
          this.messages.push({ id: `${Date.now()}_q_${Math.random().toString(36).slice(2, 5)}`, role: 'system', content: q, type: 'system', timestamp: Date.now() });
        }
      }

      // 10. LEARN: Recursive feedback
      const systemResponses = this.messages.filter(m => m.role === 'system' && m.timestamp > userMsg.timestamp);
      for (const resp of systemResponses) {
        this.neural.learn(text, resp.content);
      }
    } catch {
      this.messages.push({ id: `${Date.now()}_err`, role: 'system', content: 'The field encountered turbulence. The 9-body vote was inconclusive.', type: 'system', timestamp: Date.now() });
    }

    this.isProcessing = false;
    this._notify();
  }

  async deleteProject(id: string): Promise<void> {
    await deleteProject(id);
    this.projects = await getProjects();
    this._notify();
  }

  clearChat(): void { this.messages = []; this._notify(); }
  setMode(mode: Mode): void { this.activeMode = mode; this._notify(); }
  setDimension(dim: Dimension): void { this.activeDimension = dim; this._notify(); }
  viewCode(code: string): void { this.currentCode = code; this.activeMode = 'code'; this._notify(); }
  getNeuralStats() { return this.neural.getStats(); }
  getFieldAnalysis() { return this.coherence.fullFieldAnalysis(1.0); }
  getKleinTool(input: string, dim: string) { return selectKleinTool(input, dim); }

  private _notify(): void { this.onUpdate?.(); }
}

let _engine: VikiEngine | null = null;
export function getEngine(): VikiEngine {
  if (!_engine) _engine = new VikiEngine();
  return _engine;
}
