/**
 * VIKI Core Engine v4 — Neural + MESSY Integration
 * 
 * The neural network processes language through embeddings and attention.
 * The MESSY semantic network maintains triples and rules.
 * They work together: neural guides generation, MESSY grounds meaning.
 * 
 * Recursive learning loop:
 * 1. User speaks → Neural embeds, MESSY parses into triples
 * 2. Neural attention weights context, MESSY resolves meaning
 * 3. Neural generates candidate text, MESSY filters through rules
 * 4. Output produced → Neural learns (feedback), MESSY asserts new triples
 * 5. Next turn → Network has learned from previous interactions
 */

import { NeuralNetwork, type NeuralState } from './neural';
import { SemanticNetwork, NLGenerator } from './messy';
import { parseIntent, generateCode } from './codegen';
import { computeSemanticState } from './iching';
import { saveConversation, getConversations, saveProject, getProjects, deleteProject, setMemory, getMemory } from '@/storage/db';
import { DIMENSIONS } from '@/types';
import type { Dimension } from '@/types';
import type { ProjectRecord } from '@/storage/db';

export type Mode = 'chat' | 'code' | 'video' | 'projects';

export interface ChatMessage {
  id: string;
  role: 'user' | 'system';
  content: string;
  type: 'chat' | 'code' | 'video' | 'system';
  timestamp: number;
  neural?: NeuralState;
  metadata?: {
    code?: string;
    language?: string;
    files?: Array<{ path: string; content: string; language: string }>;
    coherence?: number;
    dimension?: string;
  };
}

interface EngineConfig {
  activeDimension: Dimension;
  activeMode: Mode;
}

// Singleton neural network
let _neural: NeuralNetwork | null = null;
function getNeural(): NeuralNetwork {
  if (!_neural) _neural = new NeuralNetwork();
  return _neural;
}

export class VikiEngine {
  neural: NeuralNetwork;
  network: SemanticNetwork;
  nlg: NLGenerator;
  messages: ChatMessage[] = [];
  activeMode: Mode = 'chat';
  activeDimension: Dimension = 'BEING';
  isProcessing = false;
  isGeneratingVideo = false;
  projects: ProjectRecord[] = [];
  currentCode: string | null = null;
  onUpdate: (() => void) | null = null;

  constructor() {
    this.neural = getNeural();
    this.network = new SemanticNetwork();
    this.nlg = new NLGenerator();
  }

  async init(): Promise<void> {
    // Load previous conversations
    const convs = await getConversations();
    // Replay them through the neural network to rebuild state
    for (const conv of convs) {
      this.messages.push({
        id: conv.id,
        role: conv.role as 'user' | 'system',
        content: conv.content,
        type: conv.type as 'chat' | 'code' | 'video' | 'system',
        timestamp: conv.timestamp,
      });
      // Learn from history
      if (conv.role === 'user') {
        // Find next system response
        const idx = convs.indexOf(conv);
        if (idx + 1 < convs.length && convs[idx + 1].role === 'system') {
          this.neural.learn(conv.content, convs[idx + 1].content);
        }
      }
    }
    // Load config
    const config = await getMemory<EngineConfig>('engine_config');
    if (config) {
      this.activeDimension = config.activeDimension;
      this.activeMode = config.activeMode;
    }
    // Load projects
    this.projects = await getProjects();
  }

  async saveConfig(): Promise<void> {
    await setMemory('engine_config', {
      activeDimension: this.activeDimension,
      activeMode: this.activeMode,
    });
  }

  async sendMessage(text: string): Promise<void> {
    if (!text.trim() || this.isProcessing) return;
    this.isProcessing = true;
    this._notify();

    // 1. User message
    const userMsg: ChatMessage = {
      id: `${Date.now()}_u`,
      role: 'user',
      content: text,
      type: 'chat',
      timestamp: Date.now(),
    };
    this.messages.push(userMsg);
    await saveConversation({ timestamp: Date.now(), role: 'user', content: text, type: 'chat' });

    // 2. NEURAL: Process input through neural network
    const neuralState = this.neural.process(text);
    userMsg.neural = neuralState;

    // 3. MESSY: Parse into semantic triples
    const words = text.toLowerCase().split(/\s+/).filter(Boolean);
    if (words.length >= 3) {
      this.network.assert(words[0], 'relates_to', words.slice(2).join(' '));
    }

    // 4. Determine mode from neural classification
    const mode = neuralState.mode;

    // 5. Check grammar rules learned from past interactions
    const inputTokens = this.neural.vocab.tokenize(text);
    const learnedRules = this.neural.findRules(inputTokens);

    try {
      if (mode === 'video') {
        await this._handleVideoRequest(text);
      } else if (mode === 'code') {
        await this._handleCodeRequest(text, neuralState, learnedRules);
      } else {
        await this._handleChat(text, neuralState, learnedRules);
      }
    } catch {
      const errMsg: ChatMessage = {
        id: `${Date.now()}_err`,
        role: 'system',
        content: 'The neural field encountered turbulence. Please rephrase.',
        type: 'system',
        timestamp: Date.now(),
      };
      this.messages.push(errMsg);
    }

    // 6. LEARN: Feed back into neural network
    const systemResponses = this.messages.filter(m => m.role === 'system' && m.timestamp > userMsg.timestamp);
    for (const resp of systemResponses) {
      this.neural.learn(text, resp.content);
    }

    this.isProcessing = false;
    this._notify();
  }

  private async _handleChat(text: string, neuralState: NeuralState, learnedRules: Array<{ response: string; weight: number }>): Promise<void> {
    const dimIndex = text.length % 5;
    const dimension = DIMENSIONS[dimIndex].name;

    // Generate through MESSY
    const nlgResult = this.nlg.generate(text, this.network, dimension);

    // If learned rules exist with high confidence, blend them in
    let content = nlgResult.sentences.join('\n\n');
    if (learnedRules.length > 0 && learnedRules[0].weight > 2.0) {
      // Blend learned response with generated
      content = learnedRules[0].response + '\n\n' + content;
    }

    // Also try neural generation as alternative
    const neuralGen = this.neural.generate(neuralState, 20);
    if (neuralGen.length > 5 && neuralGen !== content.slice(0, 50)) {
      content += '\n\n' + neuralGen;
    }

    const state = computeSemanticState(text);

    const sysMsg: ChatMessage = {
      id: `${Date.now()}_s`,
      role: 'system',
      content,
      type: 'chat',
      timestamp: Date.now(),
      neural: neuralState,
      metadata: { coherence: state.coherence, dimension },
    };
    this.messages.push(sysMsg);
    await saveConversation({ timestamp: Date.now(), role: 'system', content, type: 'chat', metadata: sysMsg.metadata });

    // Follow-up questions
    for (const q of nlgResult.followUpQuestions) {
      this.messages.push({
        id: `${Date.now()}_q_${Math.random().toString(36).slice(2, 5)}`,
        role: 'system',
        content: q,
        type: 'system',
        timestamp: Date.now(),
      });
    }
  }

  private async _handleCodeRequest(text: string, neuralState: NeuralState, _learnedRules: Array<{ response: string; weight: number }>): Promise<void> {
    const intent = parseIntent(text);
    const result = generateCode(intent);
    const code = result.code;
    const language = result.language;
    const files = result.files;

    // Generate intro through neural + MESSY
    const nlgResult = this.nlg.generate(text, this.network, 'BEING');
    const intro = nlgResult.sentences[0];

    const sysMsg: ChatMessage = {
      id: `${Date.now()}_s`,
      role: 'system',
      content: `${intro}\n\nBuilding ${intent.subtype} ${intent.type}.\n\nGenerated ${intent.subtype} ${intent.type}. Click "View Code" to see and run it.`,
      type: 'code',
      timestamp: Date.now(),
      neural: neuralState,
      metadata: { code, language, files: files?.map(f => ({ ...f, language: language || 'javascript' })) },
    };
    this.messages.push(sysMsg);
    this.currentCode = code;
    this.activeMode = 'code';
    await saveConversation({ timestamp: Date.now(), role: 'system', content: sysMsg.content, type: 'code', metadata: sysMsg.metadata });

    // Save project
    const projectFiles = files?.map(f => ({ ...f, language: language || 'javascript' }));
    await saveProject({
      name: `${intent.subtype} ${intent.type}`,
      type: intent.type === 'game' ? 'game' : 'app',
      description: text,
      code,
      language,
      files: projectFiles,
    });
    this.projects = await getProjects();

    // Learn the code pattern
    this.neural.learn(text, code.slice(0, 200));
  }

  private async _handleVideoRequest(text: string): Promise<void> {
    const enhancedDesc = text.replace(/(create|make|generate|a|an|video|of)\s+/gi, '').trim() || 'abstract visualization';
    const sysMsg: ChatMessage = {
      id: `${Date.now()}_s`,
      role: 'system',
      content: `Creating video concept: "${enhancedDesc}".\n\nThe neural field is rendering this scene. In full deployment, the video pipeline generates from this description.`,
      type: 'video',
      timestamp: Date.now(),
    };
    this.messages.push(sysMsg);
    await saveConversation({ timestamp: Date.now(), role: 'system', content: sysMsg.content, type: 'video' });
  }

  async deleteProject(id: string): Promise<void> {
    await deleteProject(id);
    this.projects = await getProjects();
    this._notify();
  }

  async generateVideo(_desc: string): Promise<void> {
    this.isGeneratingVideo = true;
    this.activeMode = 'video';
    this._notify();
    await new Promise(r => setTimeout(r, 3000));
    this.isGeneratingVideo = false;
    this._notify();
  }

  viewCode(code: string): void {
    this.currentCode = code;
    this.activeMode = 'code';
    this._notify();
  }

  clearChat(): void {
    this.messages = [];
    this._notify();
  }

  setMode(mode: Mode): void {
    this.activeMode = mode;
    this.saveConfig();
    this._notify();
  }

  setDimension(dim: Dimension): void {
    this.activeDimension = dim;
    this.saveConfig();
    this._notify();
  }

  getNeuralStats() {
    return this.neural.getStats();
  }

  private _notify(): void {
    this.onUpdate?.();
  }
}

// Global singleton
let _engine: VikiEngine | null = null;
export function getEngine(): VikiEngine {
  if (!_engine) _engine = new VikiEngine();
  return _engine;
}
