import { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { getEngine } from '@/engine/viki';
import type { Mode, ChatMessage } from '@/engine/viki';
import type { Dimension } from '@/types';
import type { ProjectRecord } from '@/storage/db';
import type { NeuralState } from '@/engine/neural';

interface VikiContextValue {
  messages: ChatMessage[];
  activeMode: Mode;
  activeDimension: Dimension;
  isProcessing: boolean;
  isGeneratingVideo: boolean;
  projects: ProjectRecord[];
  currentCode: string | null;
  neuralState: NeuralState | null;
  neuralStats: { vocabSize: number; grammarRules: number; contextSize: number; topWords: string[] } | null;
  fieldState: string;
  coherence: number;
  setActiveMode: (mode: Mode) => void;
  setActiveDimension: (dim: Dimension) => void;
  sendMessage: (text: string) => Promise<void>;
  deleteProject: (id: string) => Promise<void>;
  loadProjects: () => Promise<void>;
  clearChat: () => void;
  viewCode: (code: string) => void;
  generateVideo: (desc: string) => Promise<void>;
}

const VikiContext = createContext<VikiContextValue | null>(null);

export function VikiProvider({ children }: { children: React.ReactNode }) {
  const engineRef = useRef(getEngine());
  const engine = engineRef.current;
  const [, forceUpdate] = useState(0);

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [activeMode, setActiveMode] = useState<Mode>('chat');
  const [activeDimension, setActiveDimension] = useState<Dimension>('BEING');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isGeneratingVideo, setIsGeneratingVideo] = useState(false);
  const [projects, setProjects] = useState<ProjectRecord[]>([]);
  const [currentCode, setCurrentCode] = useState<string | null>(null);
  const [neuralState, setNeuralState] = useState<NeuralState | null>(null);
  const [neuralStats, setNeuralStats] = useState<VikiContextValue['neuralStats']>(null);
  const [fieldState, setFieldState] = useState('SYNCHRONIZED');
  const [coherence, setCoherence] = useState(0);

  const sync = useCallback(() => {
    setMessages([...engine.messages]);
    setActiveMode(engine.activeMode);
    setActiveDimension(engine.activeDimension);
    setIsProcessing(engine.isProcessing);
    setIsGeneratingVideo(engine.isGeneratingVideo);
    setProjects([...engine.projects]);
    setCurrentCode(engine.currentCode);
    const lastMsg = engine.messages[engine.messages.length - 1];
    if (lastMsg?.neural) setNeuralState(lastMsg.neural);
    setNeuralStats(engine.getNeuralStats());
    setIsGeneratingVideo(engine.isGeneratingVideo);
    try {
      const fa = engine.getFieldAnalysis();
      setFieldState(fa.fieldState);
      setCoherence(fa.meanCoherence);
    } catch { /* ignore */ }
    forceUpdate(v => v + 1);
  }, [engine]);

  useEffect(() => {
    engine.onUpdate = sync;
    engine.init().then(sync);
    return () => { engine.onUpdate = null; };
  }, [engine, sync]);

  const sendMessage = useCallback(async (text: string) => { await engine.sendMessage(text); }, [engine]);
  const deleteProject = useCallback(async (id: string) => { await engine.deleteProject(id); }, [engine]);
  const loadProjects = useCallback(async () => { engine.projects = await engine.projects; sync(); }, [engine, sync]);
  const clearChat = useCallback(() => { engine.clearChat(); }, [engine]);
  const viewCode = useCallback((code: string) => { engine.viewCode(code); }, [engine]);
  const generateVideo = useCallback(async (desc: string) => { await engine.sendMessage(`create video of ${desc}`); }, [engine]);
  const setMode = useCallback((mode: Mode) => { engine.setMode(mode); }, [engine]);
  const setDimension = useCallback((dim: Dimension) => { engine.setDimension(dim); }, [engine]);

  const value: VikiContextValue = {
    messages, activeMode, activeDimension, isProcessing, isGeneratingVideo, projects, currentCode,
    neuralState, neuralStats, fieldState, coherence,
    setActiveMode: setMode, setActiveDimension: setDimension,
    sendMessage, deleteProject, loadProjects, clearChat, viewCode, generateVideo,
  };

  return <VikiContext.Provider value={value}>{children}</VikiContext.Provider>;
}

export function useViki(): VikiContextValue {
  const ctx = useContext(VikiContext);
  if (!ctx) throw new Error('useViki must be used within VikiProvider');
  return ctx;
}

export type { ChatMessage };
