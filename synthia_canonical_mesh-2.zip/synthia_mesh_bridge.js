// ============================================================
// SYNTHIA OS MESH BRIDGE
// Connects the existing SYNTHIA OS interface to the Canonical Mesh System
// ============================================================

class SynthiaMeshBridge {
    constructor() {
        // Initialize canonical mesh
        this.mesh = new Mesh({
            dimensions: 5,  // 5D for Human Design compatibility
            repulsion: 150,
            attraction: 0.02,
            damping: 0.92
        });

        // Initialize rule engine
        this.rules = new RuleEngine(this.mesh);

        // Initialize generative engine
        this.generator = new GenerativeEngine(this.mesh, this.rules);

        // Initialize inversion system
        this.inversion = new Inversion(this.mesh);

        // Surface managers
        this.surfaces = new SurfaceManager(this.mesh);

        // Human Design mappings
        this.gates = new Map();       // 1-64 gates
        this.channels = new Map();      // 36 channels
        this.circuits = new Map();      // 5 circuits
        this.centers = new Map();       // 9 centers

        // I Ching mappings
        this.hexagrams = new Map();     // 64 hexagrams
        this.trigrams = new Map();      // 8 trigrams

        // System state
        this.theta = {
            Movement: 0,
            Evolution: 72,
            Being: 144,
            Design: 216,
            Space: 288
        };

        this.rotationSpeeds = {
            Movement: 0.05,
            Evolution: 0.018,
            Being: 0.009,
            Design: 0.026,
            Space: 0.006
        };

        this.initHumanDesign();
        this.initIChing();
        this.initSystemRules();
        this.initSurfaces();
    }

    // ============================================================
    // HUMAN DESIGN INITIALIZATION
    // ============================================================

    initHumanDesign() {
        const DELTA_G = 360 / 64;

        // 64 Gates
        for (let i = 1; i <= 64; i++) {
            const angle = (i - 1) * DELTA_G;
            this.gates.set(i, {
                number: i,
                angle: angle,
                position: Vector.random(5, 10),
                channel: this.getGateChannel(i),
                circuit: this.getGateCircuit(i),
                center: this.getGateCenter(i),
                line: Math.floor((angle % 5.625) / 0.9375) + 1,
                color: Math.floor(((angle % 0.9375) / 0.15625)) + 1,
                tone: Math.floor(((angle % 0.15625) / 0.02604)) + 1,
                base: Math.floor(((angle % 0.02604) / 0.005208)) + 1
            });
        }

        // 36 Channels (partner gates)
        const channelPairs = [
            [1, 8], [2, 14], [3, 60], [4, 63], [5, 15], [6, 59],
            [7, 31], [9, 52], [10, 20], [11, 56], [12, 22], [13, 33],
            [16, 48], [17, 62], [18, 58], [19, 49], [21, 45], [23, 43],
            [24, 61], [25, 51], [26, 44], [27, 50], [28, 38], [29, 46],
            [30, 41], [32, 54], [34, 57], [35, 36], [37, 40], [39, 55],
            [42, 53], [47, 64], [10, 34], [20, 57], [25, 51], [59, 6]
        ];

        channelPairs.forEach(([a, b], i) => {
            this.channels.set(i + 1, { gateA: a, gateB: b });
        });

        // 5 Circuits
        this.circuits.set('U', { name: 'Understanding', color: '#d4a853', gates: [4, 17, 62, 18, 58, 48, 16, 9, 52, 15, 5, 31, 7] });
        this.circuits.set('K', { name: 'Knowing', color: '#a67b8a', gates: [3, 60, 61, 24, 43, 23, 28, 38, 55, 39, 12, 22, 2, 14, 8, 1] });
        this.circuits.set('S', { name: 'Sensing', color: '#8fb896', gates: [42, 53, 30, 41, 35, 36, 64, 47, 11, 56, 46, 29, 33, 13, 6, 59, 27, 50, 32, 54] });
        this.circuits.set('E', { name: 'Ego', color: '#c97b8a', gates: [25, 51, 21, 45, 26, 44, 37, 40, 19, 49] });
        this.circuits.set('I', { name: 'Integration', color: '#c9a96e', gates: [20, 10, 57, 34] });

        // 9 Centers
        this.centers.set('Head', { gates: [64, 61, 63], position: Vector.random(5, 5) });
        this.centers.set('Ajna', { gates: [47, 24, 4, 11], position: Vector.random(5, 5) });
        this.centers.set('Throat', { gates: [56, 62, 23, 16, 35, 12, 45, 33, 20], position: Vector.random(5, 5) });
        this.centers.set('G', { gates: [1, 13, 25, 46, 2, 15, 10], position: Vector.random(5, 5) });
        this.centers.set('Heart', { gates: [40, 37, 26, 51, 21], position: Vector.random(5, 5) });
        this.centers.set('Sacral', { gates: [5, 14, 29, 59, 9, 3, 42, 27, 34], position: Vector.random(5, 5) });
        this.centers.set('Solar Plexus', { gates: [36, 22, 6, 37, 49, 55, 30], position: Vector.random(5, 5) });
        this.centers.set('Root', { gates: [58, 38, 54, 19, 41, 53, 60, 52], position: Vector.random(5, 5) });
        this.centers.set('Spleen', { gates: [48, 57, 44, 50, 32, 28, 18, 10], position: Vector.random(5, 5) });

        // Assert Human Design triples into mesh
        for (const [num, gate] of this.gates) {
            this.mesh.assert(`GATE_${num}`, 'HAS_ANGLE', gate.angle.toFixed(3), {
                tripleType: 'system',
                domain: 'humandesign',
                position: gate.position,
                value: gate.number / 64
            });

            this.mesh.assert(`GATE_${num}`, 'BELONGS_TO', `CIRCUIT_${gate.circuit}`, {
                tripleType: 'system',
                domain: 'humandesign'
            });

            this.mesh.assert(`GATE_${num}`, 'IN_CENTER', `CENTER_${gate.center}`, {
                tripleType: 'system',
                domain: 'humandesign'
            });
        }
    }

    getGateChannel(gateNum) {
        const channels = [
            [1, 8], [2, 14], [3, 60], [4, 63], [5, 15], [6, 59],
            [7, 31], [9, 52], [10, 20], [11, 56], [12, 22], [13, 33],
            [16, 48], [17, 62], [18, 58], [19, 49], [21, 45], [23, 43],
            [24, 61], [25, 51], [26, 44], [27, 50], [28, 38], [29, 46],
            [30, 41], [32, 54], [34, 57], [35, 36], [37, 40], [39, 55],
            [42, 53], [47, 64]
        ];
        for (let i = 0; i < channels.length; i++) {
            if (channels[i].includes(gateNum)) return i + 1;
        }
        return null;
    }

    getGateCircuit(gateNum) {
        const circuits = {
            'U': [4, 17, 62, 18, 58, 48, 16, 9, 52, 15, 5, 31, 7],
            'K': [3, 60, 61, 24, 43, 23, 28, 38, 55, 39, 12, 22, 2, 14, 8, 1],
            'S': [42, 53, 30, 41, 35, 36, 64, 47, 11, 56, 46, 29, 33, 13, 6, 59, 27, 50, 32, 54],
            'E': [25, 51, 21, 45, 26, 44, 37, 40, 19, 49],
            'I': [20, 10, 57, 34]
        };
        for (const [c, gates] of Object.entries(circuits)) {
            if (gates.includes(gateNum)) return c;
        }
        return 'U';
    }

    getGateCenter(gateNum) {
        const centers = {
            'Head': [64, 61, 63],
            'Ajna': [47, 24, 4, 11],
            'Throat': [56, 62, 23, 16, 35, 12, 45, 33, 20],
            'G': [1, 13, 25, 46, 2, 15, 10],
            'Heart': [40, 37, 26, 51, 21],
            'Sacral': [5, 14, 29, 59, 9, 3, 42, 27, 34],
            'Solar Plexus': [36, 22, 6, 37, 49, 55, 30],
            'Root': [58, 38, 54, 19, 41, 53, 60, 52],
            'Spleen': [48, 57, 44, 50, 32, 28, 18, 10]
        };
        for (const [center, gates] of Object.entries(centers)) {
            if (gates.includes(gateNum)) return center;
        }
        return 'Head';
    }

    // ============================================================
    // I CHING INITIALIZATION
    // ============================================================

    initIChing() {
        const trigrams = [
            { name: 'Qian', symbol: '☰', element: 'heaven', quality: 'creative', lines: [1, 1, 1] },
            { name: 'Dui', symbol: '☱', element: 'lake', quality: 'joyful', lines: [0, 1, 1] },
            { name: 'Li', symbol: '☲', element: 'fire', quality: 'clinging', lines: [1, 0, 1] },
            { name: 'Zhen', symbol: '☳', element: 'thunder', quality: 'arousing', lines: [0, 0, 1] },
            { name: 'Xun', symbol: '☴', element: 'wind', quality: 'gentle', lines: [1, 1, 0] },
            { name: 'Kan', symbol: '☵', element: 'water', quality: 'abysmal', lines: [0, 1, 0] },
            { name: 'Gen', symbol: '☶', element: 'mountain', quality: 'keeping', lines: [1, 0, 0] },
            { name: 'Kun', symbol: '☷', element: 'earth', quality: 'receptive', lines: [0, 0, 0] }
        ];

        // 64 Hexagrams from trigram combinations
        const hexagramNames = [
            'Qián', 'Kūn', 'Zhūn', 'Méng', 'Xū', 'Sòng', 'Shī', 'Bǐ',
            'Xiǎo Chù', 'Lǚ', 'Tài', 'Pǐ', 'Tóng Rén', 'Dà Yǒu', 'Qiān', 'Yù',
            'Suí', 'Gǔ', 'Lín', 'Guān', 'Shì Hé', 'Bì', 'Bō', 'Fù',
            'Wú Wàng', 'Dà Chù', 'Yí', 'Dà Guò', 'Kǎn', 'Lí', 'Xián', 'Héng',
            'Dùn', 'Dà Zhuàng', 'Jìn', 'Míng Yí', 'Jiā Rén', 'Kuí', 'Jiǎn', 'Xiè',
            'Sǔn', 'Yì', 'Guài', 'Gòu', 'Cuì', 'Shēng', 'Kùn', 'Jǐng',
            'Gé', 'Dǐng', 'Zhèn', 'Gèn', 'Jiàn', 'Guī Mèi', 'Fēng', 'Lǚ',
            'Xùn', 'Duì', 'Huàn', 'Jié', 'Zhōng Fú', 'Xiǎo Guò', 'Jì Jì', 'Wèi Jì'
        ];

        for (let i = 0; i < 64; i++) {
            const lowerIdx = i % 8;
            const upperIdx = Math.floor(i / 8);
            const lower = trigrams[lowerIdx];
            const upper = trigrams[upperIdx];

            this.hexagrams.set(i + 1, {
                number: i + 1,
                name: hexagramNames[i],
                lower: lower,
                upper: upper,
                lines: [...upper.lines, ...lower.lines],
                changing: [],
                position: Vector.random(5, 20)
            });

            // Assert into mesh
            this.mesh.assert(`HEX_${i + 1}`, 'IS', hexagramNames[i], {
                tripleType: 'system',
                domain: 'iching',
                position: Vector.random(5, 20),
                value: (i + 1) / 64
            });
        }
    }

    // ============================================================
    // SYSTEM RULES
    // ============================================================

    initSystemRules() {
        // Theta rotation rule
        this.rules.addRule(new Rule(
            'theta_rotation',
            [(mesh, ctx, time) => true],
            [(mesh, ctx, time) => {
                for (const [key, speed] of Object.entries(this.rotationSpeeds)) {
                    this.theta[key] = (this.theta[key] + speed) % 360;
                }
                return { action: 'rotate', thetas: { ...this.theta } };
            }],
            { probability: 1.0, priority: 100, group: 'core' }
        ));

        // Gate activation rule
        this.rules.addRule(new Rule(
            'gate_activation',
            [(mesh, ctx, time) => {
                const beingGate = Math.floor(this.theta.Being / 5.625) + 1;
                return beingGate !== ctx.lastGate;
            }],
            [(mesh, ctx, time) => {
                const gate = Math.floor(this.theta.Being / 5.625) + 1;
                ctx.lastGate = gate;

                // Activate gate in mesh
                mesh.assert(`GATE_${gate}`, 'ACTIVE', 'true', {
                    tripleType: 'system',
                    domain: 'humandesign',
                    value: 1.0,
                    expiresAt: time + 1000
                });

                // Check for channel activation
                const channels = Array.from(this.channels.values())
                    .filter(ch => ch.gateA === gate || ch.gateB === gate);

                for (const ch of channels) {
                    const otherGate = ch.gateA === gate ? ch.gateB : ch.gateA;
                    const otherActive = mesh.query({
                        subject: `GATE_${otherGate}`,
                        relation: 'ACTIVE'
                    }).length > 0;

                    if (otherActive) {
                        mesh.assert(`CHANNEL_${ch.gateA}_${ch.gateB}`, 'ACTIVE', 'true', {
                            tripleType: 'system',
                            domain: 'humandesign',
                            value: 1.0
                        });
                    }
                }

                return { action: 'activate_gate', gate };
            }],
            { probability: 1.0, priority: 90, group: 'core' }
        ));

        // Hexagram casting rule
        this.rules.addRule(new Rule(
            'hexagram_cast',
            [(mesh, ctx, time) => time % 60 === 0],  // Every minute
            [(mesh, ctx, time) => {
                const hex = this.castHexagram();
                mesh.assert('SYSTEM', 'CAST', `HEX_${hex.number}`, {
                    tripleType: 'meta',
                    domain: 'system',
                    value: hex.number / 64
                });
                return { action: 'cast_hexagram', hexagram: hex };
            }],
            { probability: 0.3, priority: 50, group: 'divination' }
        ));

        // Generative trigger rule
        this.rules.addRule(new Rule(
            'generative_trigger',
            [(mesh, ctx, time) => {
                const activeChannels = mesh.query({
                    tripleType: 'system',
                    relation: 'ACTIVE'
                }).length;
                return activeChannels > 3 && Math.random() < 0.1;
            }],
            [(mesh, ctx, time) => {
                const type = ['game', 'app', 'story', 'code'][Math.floor(Math.random() * 4)];
                const generated = this.generator.generate(type, {}, {
                    title: `SYNTHIA_${type}_${Date.now()}`,
                    protagonist: 'USER',
                    goal: 'INTEGRATION'
                });

                mesh.assert('GENERATOR', 'PRODUCED', type.toUpperCase(), {
                    tripleType: 'code',
                    domain: 'generated',
                    code: JSON.stringify(generated),
                    language: 'json'
                });

                return { action: 'generate', type, generated };
            }],
            { probability: 0.5, priority: 30, group: 'generative' }
        ));
    }

    castHexagram() {
        // Traditional yarrow stalk algorithm
        const lines = [];
        for (let i = 0; i < 6; i++) {
            const stalks = this.yarrowStalk();
            lines.push(stalks);
        }

        // Convert to hexagram number
        const upper = this.linesToTrigram(lines.slice(0, 3));
        const lower = this.linesToTrigram(lines.slice(3, 6));
        const hexNum = upper * 8 + lower + 1;

        return this.hexagrams.get(hexNum) || this.hexagrams.get(1);
    }

    yarrowStalk() {
        // Simplified yarrow stalk
        const div1 = Math.floor(Math.random() * 49);
        const rem1 = 49 - div1;
        const div2 = Math.floor(Math.random() * rem1);
        const rem2 = rem1 - div2;
        const rem3 = rem2 - 1;
        const value = (rem3 % 4) + 4;

        return {
            value: value,
            changing: value === 6 || value === 9,
            yang: value === 9 || value === 7,
            old: value === 9 || value === 6
        };
    }

    linesToTrigram(lines) {
        // Convert 3 lines to trigram index (0-7)
        let val = 0;
        for (let i = 0; i < 3; i++) {
            val = val * 2 + (lines[i].yang ? 1 : 0);
        }
        return val;
    }

    // ============================================================
    // SURFACES
    // ============================================================

    initSurfaces() {
        // DOM Surface (for SYNTHIA OS UI)
        const domSurface = {
            handle: (event, data, mesh) => {
                if (event === 'assert') {
                    this.updateSynthiaUI(data);
                } else if (event === 'physics_step') {
                    this.updateSynthiaPositions(mesh);
                }
            }
        };
        this.mesh.registerSurface('synthia_dom', domSurface.handle);

        // Code Generation Surface
        const codeSurface = {
            handle: (event, data, mesh) => {
                if (event === 'assert' && data.tripleType === 'code') {
                    this.emitGeneratedCode(data);
                }
            }
        };
        this.mesh.registerSurface('code_gen', codeSurface.handle);

        // Neural Surface
        const neuralSurface = {
            handle: (event, data, mesh) => {
                if (event === 'physics_step' && mesh.time % 10 === 0) {
                    const embedding = mesh.getEmbedding({ dim: 512, method: 'spectral' });
                    // Send to neural network
                    this.emitToNeural(embedding);
                }
            }
        };
        this.mesh.registerSurface('neural', neuralSurface.handle);
    }

    updateSynthiaUI(triple) {
        // Update existing SYNTHIA OS DOM elements based on mesh changes
        if (triple.domain === 'humandesign') {
            const gateMatch = triple.subject.match(/GATE_(\d+)/);
            if (gateMatch) {
                const gateNum = parseInt(gateMatch[1]);
                const widget = document.getElementById('widgetGate');
                if (widget) widget.textContent = gateNum;

                const beingWidget = document.getElementById('widgetBeing');
                if (beingWidget) {
                    const angle = (gateNum - 1) * 5.625;
                    beingWidget.textContent = angle.toFixed(1) + '°';
                }
            }
        }
    }

    updateSynthiaPositions(mesh) {
        // Update visual positions of UI elements based on mesh physics
        const activeTriples = mesh.query({ activeOnly: true });
        for (const t of activeTriples) {
            if (t.surfaces.js && t.surfaces.js.elementId) {
                const el = document.getElementById(t.surfaces.js.elementId);
                if (el) {
                    el.style.transform = `translate3d(${t.position.v[0]}px, ${t.position.v[1]}px, 0)`;
                }
            }
        }
    }

    emitGeneratedCode(triple) {
        // Dispatch event for external code consumers
        window.dispatchEvent(new CustomEvent('synthia:code', {
            detail: {
                tripleId: triple.id,
                code: triple.code,
                language: triple.language
            }
        }));
    }

    emitToNeural(embedding) {
        window.dispatchEvent(new CustomEvent('synthia:embedding', {
            detail: { embedding, time: this.mesh.time }
        }));
    }

    // ============================================================
    // MAIN LOOP
    // ============================================================

    tick() {
        // Step physics
        this.mesh.stepPhysics();

        // Evaluate rules
        const fired = this.rules.evaluateAll({
            lastGate: this.lastGate,
            theta: this.theta
        });

        // Update Human Design state
        this.updateHumanDesignState();

        return { fired, theta: { ...this.theta } };
    }

    updateHumanDesignState() {
        // Update theta values
        for (const [key, speed] of Object.entries(this.rotationSpeeds)) {
            this.theta[key] = (this.theta[key] + speed) % 360;
        }
    }

    // ============================================================
    // GENERATIVE INTERFACE
    // ============================================================

    generate(type, options = {}) {
        return this.generator.generate(type, {}, options);
    }

    // Inhabit a pattern
    inhabit(inhabitantId, targetPattern) {
        return this.inversion.inhabit(inhabitantId, targetPattern);
    }

    exitInhabitation(inhabitantId) {
        return this.inversion.exit(inhabitantId);
    }

    // ============================================================
    // PERSISTENCE
    // ============================================================

    save() {
        return {
            mesh: this.mesh.serialize(),
            theta: this.theta,
            time: this.mesh.time
        };
    }

    load(data) {
        this.mesh = Mesh.deserialize(data.mesh);
        this.theta = data.theta || this.theta;
        this.mesh.time = data.time || 0;
    }
}

// ============================================================
// SYNTHIA OS INTEGRATION
// ============================================================

// Initialize when DOM is ready
function initSynthiaMesh() {
    const bridge = new SynthiaMeshBridge();

    // Connect to existing SYNTHIA OS
    window.synthiaMesh = bridge;

    // Override existing functions to use mesh
    if (window.launchApp) {
        const originalLaunch = window.launchApp;
        window.launchApp = function(id) {
            bridge.mesh.assert('USER', 'LAUNCHED', id, {
                tripleType: 'assertion',
                domain: 'user',
                value: 1.0
            });
            return originalLaunch(id);
        };
    }

    if (window.goBack) {
        const originalBack = window.goBack;
        window.goBack = function() {
            bridge.mesh.assert('USER', 'NAVIGATED', 'BACK', {
                tripleType: 'assertion',
                domain: 'user'
            });
            return originalBack();
        };
    }

    if (window.goHome) {
        const originalHome = window.goHome;
        window.goHome = function() {
            bridge.mesh.assert('USER', 'NAVIGATED', 'HOME', {
                tripleType: 'assertion',
                domain: 'user'
            });
            return originalHome();
        };
    }

    // Start simulation loop
    function loop() {
        bridge.tick();
        requestAnimationFrame(loop);
    }
    requestAnimationFrame(loop);

    return bridge;
}

// Auto-initialize if DOM is already ready
if (document.readyState === 'complete' || document.readyState === 'interactive') {
    initSynthiaMesh();
} else {
    document.addEventListener('DOMContentLoaded', initSynthiaMesh);
}

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { SynthiaMeshBridge, initSynthiaMesh };
}
