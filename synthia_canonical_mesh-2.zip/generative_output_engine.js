// ============================================================
// GENERATIVE OUTPUT ENGINE
// Produces games, apps, videos, and code from mesh triples
// ============================================================

class GenerativeOutputEngine {
    constructor(mesh, ruleEngine) {
        this.mesh = mesh;
        this.rules = ruleEngine;
        this.templates = new Map();
        this.outputs = new Map();
        this.initTemplates();
    }

    initTemplates() {
        // Game templates
        this.templates.set('roguelike', this.roguelikeTemplate);
        this.templates.set('visual_novel', this.visualNovelTemplate);
        this.templates.set('puzzle', this.puzzleTemplate);
        this.templates.set('rpg', this.rpgTemplate);
        this.templates.set('simulation', this.simulationTemplate);

        // App templates
        this.templates.set('dashboard', this.dashboardTemplate);
        this.templates.set('chat', this.chatTemplate);
        this.templates.set('editor', this.editorTemplate);
        this.templates.set('browser', this.browserTemplate);

        // Story templates
        this.templates.set('murder_mystery', this.murderMysteryTemplate);
        this.templates.set('hero_journey', this.heroJourneyTemplate);
        this.templates.set('tragedy', this.tragedyTemplate);
        this.templates.set('comedy', this.comedyTemplate);
    }

    // ============================================================
    // MAIN GENERATION INTERFACE
    // ============================================================

    generate(type, pattern, context = {}) {
        const generator = this.templates.get(type);
        if (!generator) {
            return this.fallbackGenerate(type, pattern, context);
        }

        const result = generator.call(this, pattern, context);
        this.outputs.set(result.id, result);
        return result;
    }

    fallbackGenerate(type, pattern, context) {
        return {
            id: `gen_${Date.now()}`,
            type: type,
            title: context.title || `Generated ${type}`,
            code: `// ${type} generation not yet implemented\n// Pattern: ${JSON.stringify(pattern)}`,
            language: 'javascript',
            metadata: { pattern, context }
        };
    }

    // ============================================================
    // GAME TEMPLATES
    // ============================================================

    roguelikeTemplate(pattern, context) {
        const characters = this.mesh.query({ tripleType: 'assertion' }, { limit: 20 });
        const locations = this.mesh.query({ relation: 'AT' }, { limit: 20 });
        const items = this.mesh.query({ relation: 'HAS' }, { limit: 20 });

        const code = this.generateRoguelikeCode(characters, locations, items, context);

        return {
            id: `roguelike_${Date.now()}`,
            type: 'game',
            subtype: 'roguelike',
            title: context.title || 'Mesh Dungeon',
            code: code,
            language: 'javascript',
            assets: this.generateAssetList(characters, locations, items),
            metadata: {
                seed: context.seed || Math.random(),
                difficulty: context.difficulty || 'normal',
                characters: characters.length,
                locations: locations.length,
                items: items.length
            }
        };
    }

    generateRoguelikeCode(characters, locations, items, context) {
        return `class MeshDungeon {
    constructor() {
        this.player = {
            x: 0, y: 0,
            hp: 100,
            inventory: []
        };
        this.rooms = ${JSON.stringify(locations.map((l, i) => ({
            id: i,
            name: l.object,
            x: Math.floor(l.position?.v?.[0] || Math.random() * 10),
            y: Math.floor(l.position?.v?.[1] || Math.random() * 10),
            connections: []
        })))};
        this.enemies = ${JSON.stringify(characters.filter(c => c.value < 0).map((c, i) => ({
            id: i,
            name: c.subject,
            hp: 50 + Math.abs(c.value) * 10,
            x: Math.floor(c.position?.v?.[0] || Math.random() * 10),
            y: Math.floor(c.position?.v?.[1] || Math.random() * 10),
            hostile: c.value < 0
        })))};
        this.items = ${JSON.stringify(items.map((it, i) => ({
            id: i,
            name: it.object,
            x: Math.floor(it.position?.v?.[0] || Math.random() * 10),
            y: Math.floor(it.position?.v?.[1] || Math.random() * 10),
            value: it.value || 1
        })))};
        this.turn = 0;
    }

    move(dx, dy) {
        const newX = this.player.x + dx;
        const newY = this.player.y + dy;
        const room = this.rooms.find(r => r.x === newX && r.y === newY);
        if (room) {
            this.player.x = newX;
            this.player.y = newY;
            return { moved: true, room: room.name };
        }
        return { moved: false };
    }

    interact() {
        const item = this.items.find(i => i.x === this.player.x && i.y === this.player.y);
        if (item) {
            this.player.inventory.push(item);
            this.items = this.items.filter(i => i !== item);
            return { pickedUp: item.name };
        }
        const enemy = this.enemies.find(e => e.x === this.player.x && e.y === this.player.y && e.hp > 0);
        if (enemy) {
            const damage = Math.floor(Math.random() * 20) + 10;
            enemy.hp -= damage;
            if (enemy.hp <= 0) {
                return { defeated: enemy.name, damage };
            }
            const enemyDamage = Math.floor(Math.random() * 10) + 5;
            this.player.hp -= enemyDamage;
            return { attacked: enemy.name, damage, taken: enemyDamage };
        }
        return { nothing: true };
    }

    render() {
        let map = '';
        for (let y = 0; y < 10; y++) {
            for (let x = 0; x < 10; x++) {
                if (x === this.player.x && y === this.player.y) {
                    map += '@';
                } else if (this.enemies.some(e => e.x === x && e.y === y && e.hp > 0)) {
                    map += 'E';
                } else if (this.items.some(i => i.x === x && i.y === y)) {
                    map += 'i';
                } else if (this.rooms.some(r => r.x === x && r.y === y)) {
                    map += '.';
                } else {
                    map += '#';
                }
            }
            map += '\n';
        }
        return map;
    }
}

// Auto-start if in browser
if (typeof window !== 'undefined') {
    window.MeshDungeon = MeshDungeon;
}`;
    }

    visualNovelTemplate(pattern, context) {
        const characters = this.mesh.query({ tripleType: 'assertion' }, { limit: 10 });
        const relationships = this.mesh.query({ relation: 'LOVES' }, { limit: 10 });
        const conflicts = this.mesh.query({ relation: 'HATES' }, { limit: 10 });

        const scenes = this.generateVNScenes(characters, relationships, conflicts);

        return {
            id: `vn_${Date.now()}`,
            type: 'game',
            subtype: 'visual_novel',
            title: context.title || 'Mesh Stories',
            code: this.generateVNCode(scenes, context),
            language: 'javascript',
            scenes: scenes,
            metadata: {
                characters: characters.map(c => c.subject),
                branches: scenes.length
            }
        };
    }

    generateVNScenes(characters, relationships, conflicts) {
        return characters.map((c, i) => ({
            id: i,
            character: c.subject,
            text: this.generateSceneText(c, relationships, conflicts),
            choices: [
                { text: 'Agree', next: i + 1, value: 1 },
                { text: 'Disagree', next: i + 1, value: -1 },
                { text: 'Ask more', next: i, value: 0 }
            ],
            background: `scene_${i % 5}.png`
        }));
    }

    generateSceneText(character, relationships, conflicts) {
        const loves = relationships.filter(r => r.subject === character.subject || r.object === character.subject);
        const hates = conflicts.filter(c => c.subject === character.subject || c.object === character.subject);

        let text = `${character.subject} stands before you. `;

        if (loves.length > 0) {
            const l = loves[0];
            const target = l.subject === character.subject ? l.object : l.subject;
            text += `Their eyes soften when ${target} is mentioned. `;
        }

        if (hates.length > 0) {
            const h = hates[0];
            const target = h.subject === character.subject ? h.object : h.subject;
            text += `But tension rises at the thought of ${target}. `;
        }

        text += `What do you do?`;
        return text;
    }

    generateVNCode(scenes, context) {
        return `class VisualNovel {
    constructor() {
        this.scenes = ${JSON.stringify(scenes)};
        this.currentScene = 0;
        this.choices = [];
        this.history = [];
    }

    getCurrentScene() {
        return this.scenes[this.currentScene] || this.scenes[this.scenes.length - 1];
    }

    makeChoice(choiceIndex) {
        const scene = this.getCurrentScene();
        const choice = scene.choices[choiceIndex];
        if (choice) {
            this.history.push({ scene: this.currentScene, choice: choiceIndex, value: choice.value });
            this.currentScene = choice.next;
            return this.getCurrentScene();
        }
        return null;
    }

    render() {
        const scene = this.getCurrentScene();
        return {
            character: scene.character,
            text: scene.text,
            choices: scene.choices.map((c, i) => ({ index: i, text: c.text }))
        };
    }

    getEnding() {
        const total = this.history.reduce((sum, h) => sum + h.value, 0);
        if (total > 5) return 'good';
        if (total < -5) return 'bad';
        return 'neutral';
    }
}

if (typeof window !== 'undefined') {
    window.MeshVisualNovel = VisualNovel;
}`;
    }

    rpgTemplate(pattern, context) {
        const entities = this.mesh.query({ activeOnly: true }, { limit: 30 });
        const code = this.generateRPGCode(entities, context);

        return {
            id: `rpg_${Date.now()}`,
            type: 'game',
            subtype: 'rpg',
            title: context.title || 'Mesh RPG',
            code: code,
            language: 'javascript',
            metadata: { entities: entities.length }
        };
    }

    generateRPGCode(entities, context) {
        const classes = entities.filter(e => e.value > 0).map((e, i) => ({
            name: e.subject,
            hp: 50 + e.value * 10,
            mp: 30 + e.value * 5,
            str: Math.floor(e.value * 2),
            int: Math.floor(e.certainty * 10)
        }));

        return `class MeshRPG {
    constructor() {
        this.party = [${classes.slice(0, 4).map(c => `new Character("${c.name}", ${c.hp}, ${c.mp}, ${c.str}, ${c.int})`).join(', ')}];
        this.world = new World();
        this.quests = [];
        this.inventory = [];
    }

    battle(enemies) {
        const log = [];
        while (enemies.some(e => e.hp > 0) && this.party.some(c => c.hp > 0)) {
            for (const char of this.party) {
                if (char.hp <= 0) continue;
                const target = enemies.find(e => e.hp > 0);
                if (target) {
                    const dmg = char.attack(target);
                    log.push(\`\${char.name} attacks \${target.name} for \${dmg} damage!\`);
                    if (target.hp <= 0) {
                        log.push(\`\${target.name} defeated!\`);
                    }
                }
            }
            for (const enemy of enemies) {
                if (enemy.hp <= 0) continue;
                const target = this.party.find(c => c.hp > 0);
                if (target) {
                    const dmg = enemy.attack(target);
                    log.push(\`\${enemy.name} attacks \${target.name} for \${dmg} damage!\`);
                }
            }
        }
        return { won: this.party.some(c => c.hp > 0), log };
    }
}

class Character {
    constructor(name, hp, mp, str, int) {
        this.name = name; this.hp = hp; this.maxHp = hp;
        this.mp = mp; this.maxMp = mp;
        this.str = str; this.int = int;
        this.xp = 0; this.level = 1;
    }

    attack(target) {
        const dmg = Math.floor(this.str * (0.8 + Math.random() * 0.4));
        target.hp -= dmg;
        return dmg;
    }

    heal(amount) {
        this.hp = Math.min(this.maxHp, this.hp + amount);
    }
}

class World {
    constructor() {
        this.maps = [];
        this.npcs = [];
    }
}

if (typeof window !== 'undefined') {
    window.MeshRPG = MeshRPG;
    window.MeshCharacter = Character;
}`;
    }

    simulationTemplate(pattern, context) {
        return {
            id: `sim_${Date.now()}`,
            type: 'game',
            subtype: 'simulation',
            title: context.title || 'Mesh Life',
            code: this.generateSimulationCode(pattern, context),
            language: 'javascript',
            metadata: { type: 'life_simulation' }
        };
    }

    generateSimulationCode(pattern, context) {
        return `class MeshLife {
    constructor() {
        this.agents = [];
        this.time = 0;
        this.grid = new Map();
        this.rules = [];
    }

    addAgent(name, traits) {
        const agent = {
            name, traits,
            x: Math.floor(Math.random() * 20),
            y: Math.floor(Math.random() * 20),
            needs: { hunger: 0, social: 0, rest: 0, fun: 0 },
            relationships: new Map()
        };
        this.agents.push(agent);
        return agent;
    }

    step() {
        this.time++;
        for (const agent of this.agents) {
            // Update needs
            agent.needs.hunger += 0.1;
            agent.needs.social += 0.05;
            agent.needs.rest += 0.08;
            agent.needs.fun += 0.03;

            // Choose action based on highest need
            const highest = Object.entries(agent.needs).sort((a, b) => b[1] - a[1])[0];

            switch (highest[0]) {
                case 'hunger':
                    this.moveTo(agent, 'kitchen');
                    agent.needs.hunger = 0;
                    break;
                case 'social':
                    this.interactWithRandom(agent);
                    agent.needs.social = 0;
                    break;
                case 'rest':
                    this.moveTo(agent, 'bedroom');
                    agent.needs.rest = 0;
                    break;
                case 'fun':
                    this.moveTo(agent, 'game_room');
                    agent.needs.fun = 0;
                    break;
            }
        }
    }

    moveTo(agent, location) {
        agent.x += (Math.random() - 0.5) * 2;
        agent.y += (Math.random() - 0.5) * 2;
        return { moved: true, to: location };
    }

    interactWithRandom(agent) {
        const other = this.agents.find(a => a !== agent);
        if (other) {
            const affinity = Math.random();
            agent.relationships.set(other.name, affinity);
            other.relationships.set(agent.name, affinity);
            return { interacted: other.name, affinity };
        }
        return null;
    }

    getState() {
        return {
            time: this.time,
            agents: this.agents.map(a => ({
                name: a.name,
                x: a.x, y: a.y,
                needs: a.needs,
                relationships: Object.fromEntries(a.relationships)
            }))
        };
    }
}

if (typeof window !== 'undefined') {
    window.MeshLife = MeshLife;
}`;
    }

    // ============================================================
    // APP TEMPLATES
    // ============================================================

    dashboardTemplate(pattern, context) {
        const metrics = this.mesh.query({ tripleType: 'system' }, { limit: 10 });

        return {
            id: `dash_${Date.now()}`,
            type: 'app',
            subtype: 'dashboard',
            title: context.title || 'Mesh Dashboard',
            code: this.generateDashboardCode(metrics, context),
            language: 'javascript',
            metadata: { metrics: metrics.length }
        };
    }

    generateDashboardCode(metrics, context) {
        return `class MeshDashboard {
    constructor(container) {
        this.container = container || document.body;
        this.metrics = ${JSON.stringify(metrics.map(m => ({
            name: m.relation,
            value: m.value || 0,
            target: 100
        })))};
        this.updateInterval = 1000;
        this.init();
    }

    init() {
        this.container.innerHTML = '<div class="mesh-dashboard"></div>';
        this.root = this.container.querySelector('.mesh-dashboard');
        this.render();
        setInterval(() => this.update(), this.updateInterval);
    }

    render() {
        this.root.innerHTML = this.metrics.map(m => \`
            <div class="metric-card">
                <div class="metric-name">\${m.name}</div>
                <div class="metric-value" id="metric-\${m.name}">\${m.value.toFixed(2)}</div>
                <div class="metric-bar">
                    <div class="metric-fill" style="width: \${(m.value / m.target * 100).toFixed(1)}%"></div>
                </div>
            </div>
        \`).join('');
    }

    update() {
        for (const m of this.metrics) {
            m.value += (Math.random() - 0.5) * 5;
            m.value = Math.max(0, Math.min(m.target, m.value));
            const el = document.getElementById(\`metric-\${m.name}\`);
            if (el) el.textContent = m.value.toFixed(2);
        }
    }
}

// CSS
const style = document.createElement('style');
style.textContent = \`
    .mesh-dashboard { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; padding: 20px; }
    .metric-card { background: #1a1a2e; border: 1px solid #00d4ff; border-radius: 8px; padding: 15px; color: #e0e0e0; }
    .metric-name { font-size: 0.8rem; color: #8899aa; text-transform: uppercase; }
    .metric-value { font-size: 2rem; color: #00d4ff; margin: 10px 0; }
    .metric-bar { height: 4px; background: rgba(0,212,255,0.2); border-radius: 2px; }
    .metric-fill { height: 100%; background: #00d4ff; border-radius: 2px; transition: width 0.3s; }
\`;
document.head.appendChild(style);

if (typeof window !== 'undefined') {
    window.MeshDashboard = MeshDashboard;
}`;
    }

    chatTemplate(pattern, context) {
        return {
            id: `chat_${Date.now()}`,
            type: 'app',
            subtype: 'chat',
            title: context.title || 'Mesh Chat',
            code: this.generateChatCode(pattern, context),
            language: 'javascript',
            metadata: { type: 'chat_interface' }
        };
    }

    generateChatCode(pattern, context) {
        return `class MeshChat {
    constructor(container) {
        this.container = container || document.body;
        this.messages = [];
        this.users = new Map();
        this.init();
    }

    init() {
        this.container.innerHTML = \`
            <div class="mesh-chat">
                <div class="chat-messages"></div>
                <div class="chat-input">
                    <input type="text" placeholder="Type a message...">
                    <button>Send</button>
                </div>
            </div>
        \`;
        this.messagesEl = this.container.querySelector('.chat-messages');
        this.inputEl = this.container.querySelector('input');
        this.buttonEl = this.container.querySelector('button');

        this.buttonEl.addEventListener('click', () => this.send());
        this.inputEl.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.send();
        });
    }

    send() {
        const text = this.inputEl.value.trim();
        if (!text) return;

        this.addMessage('user', text);
        this.inputEl.value = '';

        // Generate response based on mesh state
        setTimeout(() => {
            const response = this.generateResponse(text);
            this.addMessage('system', response);
        }, 500 + Math.random() * 1000);
    }

    addMessage(sender, text) {
        const msg = { sender, text, time: Date.now() };
        this.messages.push(msg);

        const el = document.createElement('div');
        el.className = \`message \${sender}\`;
        el.innerHTML = \`<span class="sender">\${sender}:</span> <span class="text">\${text}</span>\`;
        this.messagesEl.appendChild(el);
        this.messagesEl.scrollTop = this.messagesEl.scrollHeight;
    }

    generateResponse(input) {
        const responses = [
            'The mesh is listening.',
            'Pattern recognized.',
            'Continue.',
            'That resonates with gate ' + (Math.floor(Math.random() * 64) + 1) + '.',
            'The hexagram suggests patience.',
            'Your pattern is shifting.',
            'I feel that in the mesh.',
            'The system acknowledges.',
            'Interesting connection.',
            'The data aligns.'
        ];
        return responses[Math.floor(Math.random() * responses.length)];
    }
}

const style = document.createElement('style');
style.textContent = \`
    .mesh-chat { height: 100%; display: flex; flex-direction: column; background: #0a0a0c; }
    .chat-messages { flex: 1; overflow-y: auto; padding: 15px; }
    .message { margin-bottom: 10px; padding: 10px; border-radius: 8px; }
    .message.user { background: rgba(0,212,255,0.1); border-left: 3px solid #00d4ff; }
    .message.system { background: rgba(201,169,110,0.1); border-left: 3px solid #c9a96e; }
    .sender { font-weight: bold; color: #00d4ff; }
    .chat-input { display: flex; padding: 15px; gap: 10px; }
    .chat-input input { flex: 1; background: #1a1a2e; border: 1px solid #2a2a35; color: #e0e0e0; padding: 10px; border-radius: 6px; }
    .chat-input button { background: #00d4ff; color: #0a0a0c; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; }
\`;
document.head.appendChild(style);

if (typeof window !== 'undefined') {
    window.MeshChat = MeshChat;
}`;
    }

    editorTemplate(pattern, context) {
        return {
            id: `editor_${Date.now()}`,
            type: 'app',
            subtype: 'editor',
            title: context.title || 'Mesh Editor',
            code: this.generateEditorCode(pattern, context),
            language: 'javascript',
            metadata: { type: 'code_editor' }
        };
    }

    generateEditorCode(pattern, context) {
        return `class MeshEditor {
    constructor(container) {
        this.container = container || document.body;
        this.content = '';
        this.language = 'javascript';
        this.init();
    }

    init() {
        this.container.innerHTML = \`
            <div class="mesh-editor">
                <div class="editor-toolbar">
                    <button onclick="editor.format()">Format</button>
                    <button onclick="editor.run()">Run</button>
                    <select onchange="editor.setLanguage(this.value)">
                        <option value="javascript">JavaScript</option>
                        <option value="python">Python</option>
                        <option value="html">HTML</option>
                    </select>
                </div>
                <textarea class="editor-content" spellcheck="false"></textarea>
                <div class="editor-output"></div>
            </div>
        \`;
        this.textarea = this.container.querySelector('textarea');
        this.output = this.container.querySelector('.editor-output');
    }

    setLanguage(lang) {
        this.language = lang;
    }

    format() {
        const code = this.textarea.value;
        // Simple formatting
        this.textarea.value = code.replace(/;/g, ';\n').replace(/{/g, ' {\n').replace(/}/g, '\n}');
    }

    run() {
        const code = this.textarea.value;
        try {
            if (this.language === 'javascript') {
                const result = eval(code);
                this.output.innerHTML = '<pre>' + JSON.stringify(result, null, 2) + '</pre>';
            } else {
                this.output.innerHTML = '<pre>Execution requires backend for ' + this.language + '</pre>';
            }
        } catch (e) {
            this.output.innerHTML = '<pre style="color: #ff6b6b">' + e.message + '</pre>';
        }
    }

    setContent(code) {
        this.textarea.value = code;
    }
}

const style = document.createElement('style');
style.textContent = \`
    .mesh-editor { height: 100%; display: flex; flex-direction: column; background: #0a0a0c; }
    .editor-toolbar { display: flex; gap: 10px; padding: 10px; background: #1a1a2e; border-bottom: 1px solid #2a2a35; }
    .editor-toolbar button { background: #00d4ff; color: #0a0a0c; border: none; padding: 5px 15px; border-radius: 4px; cursor: pointer; }
    .editor-toolbar select { background: #1a1a2e; color: #e0e0e0; border: 1px solid #2a2a35; padding: 5px; border-radius: 4px; }
    .editor-content { flex: 1; background: #0a0a0c; color: #e0e0e0; border: none; padding: 15px; font-family: 'JetBrains Mono', monospace; font-size: 14px; resize: none; outline: none; }
    .editor-output { height: 150px; background: #1a1a2e; border-top: 1px solid #2a2a35; padding: 10px; overflow-y: auto; color: #e0e0e0; font-family: monospace; }
\`;
document.head.appendChild(style);

if (typeof window !== 'undefined') {
    window.MeshEditor = MeshEditor;
}`;
    }

    browserTemplate(pattern, context) {
        return {
            id: `browser_${Date.now()}`,
            type: 'app',
            subtype: 'browser',
            title: context.title || 'Mesh Browser',
            code: this.generateBrowserCode(pattern, context),
            language: 'javascript',
            metadata: { type: 'web_browser' }
        };
    }

    generateBrowserCode(pattern, context) {
        return `class MeshBrowser {
    constructor(container) {
        this.container = container || document.body;
        this.history = [];
        this.currentUrl = 'about:blank';
        this.init();
    }

    init() {
        this.container.innerHTML = \`
            <div class="mesh-browser">
                <div class="browser-bar">
                    <button onclick="browser.back()">←</button>
                    <button onclick="browser.forward()">→</button>
                    <input type="text" class="url-bar" value="about:blank">
                    <button onclick="browser.navigate()">Go</button>
                </div>
                <iframe class="browser-frame" src="about:blank"></iframe>
            </div>
        \`;
        this.urlBar = this.container.querySelector('.url-bar');
        this.frame = this.container.querySelector('iframe');

        this.urlBar.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') this.navigate();
        });
    }

    navigate() {
        let url = this.urlBar.value;
        if (!url.match(/^https?:\/\//)) url = 'https://' + url;
        this.frame.src = url;
        this.currentUrl = url;
        this.history.push(url);
    }

    back() {
        if (this.history.length > 1) {
            this.history.pop();
            this.frame.src = this.history[this.history.length - 1];
            this.urlBar.value = this.history[this.history.length - 1];
        }
    }

    forward() {
        // Simplified - would need forward history stack
    }
}

const style = document.createElement('style');
style.textContent = \`
    .mesh-browser { height: 100%; display: flex; flex-direction: column; background: #0a0a0c; }
    .browser-bar { display: flex; gap: 8px; padding: 10px; background: #1a1a2e; border-bottom: 1px solid #2a2a35; }
    .browser-bar button { background: #2a2a35; color: #e0e0e0; border: none; padding: 8px 12px; border-radius: 6px; cursor: pointer; }
    .browser-bar button:hover { background: #3a3a48; }
    .url-bar { flex: 1; background: #0a0a0c; border: 1px solid #2a2a35; color: #e0e0e0; padding: 8px 12px; border-radius: 6px; font-family: 'JetBrains Mono', monospace; }
    .browser-frame { flex: 1; border: none; background: #fff; }
\`;
document.head.appendChild(style);

if (typeof window !== 'undefined') {
    window.MeshBrowser = MeshBrowser;
}`;
    }

    // ============================================================
    // STORY TEMPLATES
    // ============================================================

    murderMysteryTemplate(pattern, context) {
        const characters = this.mesh.query({ tripleType: 'assertion' }, { limit: 15 });
        const relationships = this.mesh.query({ relation: 'LOVES' }, { limit: 10 });
        const conflicts = this.mesh.query({ relation: 'HATES' }, { limit: 10 });

        const story = this.generateMurderMystery(characters, relationships, conflicts, context);

        return {
            id: `murder_${Date.now()}`,
            type: 'story',
            subtype: 'murder_mystery',
            title: context.title || 'The Mesh Murder',
            text: story,
            code: this.generateStoryCode(story, context),
            language: 'javascript',
            metadata: {
                characters: characters.map(c => c.subject),
                wordCount: story.split(' ').length
            }
        };
    }

    generateMurderMystery(characters, relationships, conflicts, context) {
        const cast = characters.slice(0, 8).map(c => c.subject);
        const victim = cast[Math.floor(Math.random() * cast.length)];
        const killer = cast.find(c => c !== victim) || cast[0];

        let story = 'THE MESH MURDER\n\n';
        story += 'Chapter 1: The Gathering\n\n';

        // Introduction
        for (const name of cast) {
            const traits = characters.find(c => c.subject === name);
            story += `${name} arrived at the mansion. `;
            if (traits) {
                if (traits.value > 0) story += `They seemed at ease. `;
                else story += `Tension was visible in their posture. `;
            }
        }

        story += '\n\nThe evening began normally. ';

        // Relationships
        for (const rel of relationships) {
            if (cast.includes(rel.subject) && cast.includes(rel.object)) {
                story += `${rel.subject} watched ${rel.object} with unmistakable affection. `;
            }
        }

        // Conflicts
        for (const conf of conflicts) {
            if (cast.includes(conf.subject) && cast.includes(conf.object)) {
                story += `But ${conf.subject} could not hide their contempt for ${conf.object}. `;
            }
        }

        story += `\n\nThen, ${victim} was found dead.\n\n`;
        story += 'Chapter 2: The Investigation\n\n';
        story += `The detective arrived. The body lay in the library. ${victim} had been poisoned.\n\n`;

        // Accusations
        for (const name of cast) {
            if (name !== victim) {
                story += `${name} was questioned. `;
                if (name === killer) {
                    story += `Their alibi was thin. `;
                } else {
                    story += `They had nothing to hide. `;
                }
            }
        }

        story += `\n\nChapter 3: The Revelation\n\n`;
        story += `In the end, it was ${killer}. The motive was clear: the mesh had predicted it all along.\n\n`;
        story += `The pattern was complete.\n`;

        return story;
    }

    generateStoryCode(story, context) {
        return `class MurderMystery {
    constructor() {
        this.story = ${JSON.stringify(story)};
        this.chapters = this.story.split('Chapter ').slice(1).map(c => 'Chapter ' + c);
        this.currentChapter = 0;
    }

    getCurrentChapter() {
        return this.chapters[this.currentChapter] || 'The End';
    }

    nextChapter() {
        this.currentChapter++;
        return this.getCurrentChapter();
    }

    render() {
        return {
            chapter: this.currentChapter + 1,
            text: this.getCurrentChapter(),
            hasNext: this.currentChapter < this.chapters.length - 1
        };
    }
}

if (typeof window !== 'undefined') {
    window.MurderMystery = MurderMystery;
}`;
    }

    heroJourneyTemplate(pattern, context) {
        return {
            id: `hero_${Date.now()}`,
            type: 'story',
            subtype: 'hero_journey',
            title: context.title || 'The Hero's Path',
            text: this.generateHeroJourney(pattern, context),
            code: '',
            language: 'javascript',
            metadata: { type: 'hero_journey' }
        };
    }

    generateHeroJourney(pattern, context) {
        const hero = context.protagonist || 'The Wanderer';
        const goal = context.goal || 'The Integration';

        return `THE HERO'S PATH\n\n` +
            `Act I: Departure\n\n` +
            `${hero} lived in ordinary time. The mesh was background noise. Then the call came: ${goal} was needed.\n\n` +
            `Act II: Initiation\n\n` +
            `${hero} crossed the threshold. The pattern became visible. Gates opened. Channels hummed. The hexagrams spoke.\n\n` +
            `Act III: Return\n\n` +
            `${hero} returned with the elixir. The mesh was not separate from life. It was life, made legible.\n`;
    }

    // ============================================================
    // UTILITY METHODS
    // ============================================================

    generateAssetList(characters, locations, items) {
        return {
            sprites: characters.map((c, i) => ({
                id: `char_${i}`,
                name: c.subject,
                color: this.hashColor(c.subject)
            })),
            tiles: locations.map((l, i) => ({
                id: `loc_${i}`,
                name: l.object,
                type: 'floor'
            })),
            items: items.map((it, i) => ({
                id: `item_${i}`,
                name: it.object,
                value: it.value || 1
            }))
        };
    }

    hashColor(str) {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            hash = str.charCodeAt(i) + ((hash << 5) - hash);
        }
        const c = (hash & 0x00FFFFFF).toString(16).toUpperCase();
        return '#' + '00000'.substring(0, 6 - c.length) + c;
    }

    // ============================================================
    // EXPORT
    // ============================================================

    getOutputs() {
        return Array.from(this.outputs.values());
    }

    getOutput(id) {
        return this.outputs.get(id);
    }
}

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { GenerativeOutputEngine };
}

if (typeof window !== 'undefined') {
    window.GenerativeOutputEngine = GenerativeOutputEngine;
}
