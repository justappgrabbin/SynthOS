// ============================================================
// CANONICAL MESH SYSTEM (CMS)
// A unified semantic-network + generative + execution substrate
// ============================================================
//
// Core principles:
// 1. Everything is a triple: (subject, relation, object)
// 2. Triples have geometry: position, velocity, charge in n-dimensional space
// 3. Triples are executable: they can generate code, render UI, or modify themselves
// 4. The mesh is self-describing: system rules are also triples
// 5. Surfaces (JS, Python, Neural) are projections of the same mesh
//
// This file implements the canonical form that all other systems extend.

// ============================================================
// SECTION 1: CORE DATA STRUCTURES
// ============================================================

class Vector {
    constructor(dim = 3, values = null) {
        this.dim = dim;
        this.v = values || new Float64Array(dim);
    }

    static random(dim, scale = 1) {
        const v = new Float64Array(dim);
        for (let i = 0; i < dim; i++) v[i] = (Math.random() - 0.5) * 2 * scale;
        return new Vector(dim, v);
    }

    static zero(dim) {
        return new Vector(dim, new Float64Array(dim));
    }

    add(other) {
        const r = new Float64Array(this.dim);
        for (let i = 0; i < this.dim; i++) r[i] = this.v[i] + other.v[i];
        return new Vector(this.dim, r);
    }

    sub(other) {
        const r = new Float64Array(this.dim);
        for (let i = 0; i < this.dim; i++) r[i] = this.v[i] - other.v[i];
        return new Vector(this.dim, r);
    }

    scale(s) {
        const r = new Float64Array(this.dim);
        for (let i = 0; i < this.dim; i++) r[i] = this.v[i] * s;
        return new Vector(this.dim, r);
    }

    dot(other) {
        let sum = 0;
        for (let i = 0; i < this.dim; i++) sum += this.v[i] * other.v[i];
        return sum;
    }

    length() {
        return Math.sqrt(this.dot(this));
    }

    normalize() {
        const len = this.length();
        if (len === 0) return Vector.zero(this.dim);
        return this.scale(1 / len);
    }

    distance(other) {
        return this.sub(other).length();
    }

    toArray() {
        return Array.from(this.v);
    }

    clone() {
        return new Vector(this.dim, new Float64Array(this.v));
    }
}

// ============================================================
// SECTION 2: THE TRIPLE
// ============================================================

class Triple {
    constructor(subject, relation, object, meta = {}) {
        this.id = `${subject}::${relation}::${object}::${meta.createdAt || Date.now()}`;
        this.subject = subject;
        this.relation = relation;
        this.object = object;

        // Temporal properties
        this.createdAt = meta.createdAt || Date.now();
        this.deletedAt = null;
        this.expiresAt = meta.expiresAt || null;

        // Semantic properties
        this.value = meta.value !== undefined ? meta.value : 1.0;      // numeric weight
        this.rv = meta.rv !== undefined ? meta.rv : 1.0;               // reality value (0 = hypothetical)
        this.h = meta.h !== undefined ? meta.h : 0.0;                // hypotheticality
        this.certainty = meta.certainty !== undefined ? meta.certainty : 0.5;

        // Geometric properties (the mesh layer)
        this.position = meta.position || Vector.random(3, 10);
        this.velocity = meta.velocity || Vector.zero(3);
        this.mass = meta.mass !== undefined ? meta.mass : 1.0;
        this.charge = meta.charge !== undefined ? meta.charge : 0.0;   // positive = attract, negative = repel

        // Type properties
        this.tripleType = meta.tripleType || 'assertion';  // assertion, rule, code, surface, meta
        this.domain = meta.domain || 'general';             // general, system, user, generated

        // Execution properties (for code-generating triples)
        this.code = meta.code || null;                      // executable code string
        this.language = meta.language || null;              // js, python, shader, etc.
        this.compiled = meta.compiled || null;              // compiled function reference

        // Surface bindings (how this triple manifests in different interfaces)
        this.surfaces = meta.surfaces || {};
        // { js: { elementId, eventType, cssClass },
        //   python: { module, method, args },
        //   neural: { embedding, layer, activation } }

        // Secondary triples (MESSY-style modifiers)
        this.secondary = new Map();

        // Change tracking
        this.history = [{
            time: this.createdAt,
            action: 'created',
            value: this.value
        }];
    }

    // Check if triple is currently active
    isActive(time = Date.now()) {
        if (this.deletedAt && time >= this.deletedAt) return false;
        if (this.expiresAt && time >= this.expiresAt) return false;
        return true;
    }

    // Negate this triple (doesn't delete, just marks as ended)
    negate(time = Date.now()) {
        this.deletedAt = time;
        this.history.push({ time, action: 'negated', value: this.value });
    }

    // Update value with history tracking
    setValue(newValue, time = Date.now()) {
        this.history.push({ time, action: 'updated', value: newValue, oldValue: this.value });
        this.value = newValue;
    }

    // Add secondary triple (MESSY-style)
    addSecondary(key, triple) {
        this.secondary.set(key, triple);
    }

    // Get display string
    toString() {
        const status = this.deletedAt ? ' [NEGATED]' : '';
        const type = this.tripleType !== 'assertion' ? ` [${this.tripleType.toUpperCase()}]` : '';
        return `(${this.subject} ${this.relation} ${this.object})${type}${status}`;
    }

    // Serialize for storage/transmission
    serialize() {
        return {
            id: this.id,
            subject: this.subject,
            relation: this.relation,
            object: this.object,
            createdAt: this.createdAt,
            deletedAt: this.deletedAt,
            value: this.value,
            rv: this.rv,
            h: this.h,
            tripleType: this.tripleType,
            domain: this.domain,
            code: this.code,
            language: this.language,
            position: this.position.toArray(),
            velocity: this.velocity.toArray(),
            mass: this.mass,
            charge: this.charge
        };
    }

    static deserialize(data) {
        const meta = {
            ...data,
            position: new Vector(data.position?.length || 3, data.position),
            velocity: new Vector(data.velocity?.length || 3, data.velocity)
        };
        return new Triple(data.subject, data.relation, data.object, meta);
    }
}

// ============================================================
// SECTION 3: THE MESH
// ============================================================

class Mesh {
    constructor(options = {}) {
        this.dimensions = options.dimensions || 3;
        this.cellSize = options.cellSize || 10;
        this.time = 0;
        this.dt = options.dt || 0.016;  // 60fps default

        // Core storage
        this.triples = new Map();           // id -> Triple
        this.bySubject = new Map();         // subject -> Set<tripleId>
        this.byRelation = new Map();        // relation -> Set<tripleId>
        this.byObject = new Map();          // object -> Set<tripleId>
        this.byType = new Map();            // tripleType -> Set<tripleId>
        this.byDomain = new Map();          // domain -> Set<tripleId>

        // Spatial indexing
        this.spatialIndex = new Map();      // cellKey -> Set<tripleId>
        this.nodePositions = new Map();     // atom -> Vector (aggregated position)

        // Physics parameters
        this.repulsion = options.repulsion || 100;
        this.attraction = options.attraction || 0.01;
        this.damping = options.damping || 0.9;
        this.maxVelocity = options.maxVelocity || 50;

        // Semantic force parameters
        this.relationForces = new Map();    // relation -> { length, stiffness, type }
        this.defaultForce = { length: 5, stiffness: 0.1, type: 'spring' };

        // Surface callbacks
        this.surfaces = new Map();          // name -> callback function

        // System triples (self-describing)
        this.systemTriples = new Set();     // ids of triples that describe the system itself

        // Change log
        this.changelog = [];

        // Initialize with system triples
        this._initSystemTriples();
    }

    _initSystemTriples() {
        // The mesh describes itself
        const systemMeta = { tripleType: 'meta', domain: 'system', rv: 1 };

        this.assert('MESH', 'IS', 'CANONICAL_MESH', systemMeta);
        this.assert('MESH', 'HAS', 'TRIPLE_STORE', { ...systemMeta, value: 0 });
        this.assert('MESH', 'HAS', 'SPATIAL_INDEX', { ...systemMeta, value: 0 });
        this.assert('MESH', 'HAS', 'PHYSICS_ENGINE', { ...systemMeta, value: 0 });
        this.assert('MESH', 'HAS', 'SURFACE_BRIDGE', { ...systemMeta, value: 0 });
        this.assert('MESH', 'HAS', 'RULE_ENGINE', { ...systemMeta, value: 0 });
        this.assert('MESH', 'HAS', 'CODE_GENERATOR', { ...systemMeta, value: 0 });
        this.assert('MESH', 'HAS', 'NEURAL_INTERFACE', { ...systemMeta, value: 0 });

        // Physics parameters as triples
        this.assert('MESH', 'PARAM', 'REPULSION', { ...systemMeta, value: this.repulsion });
        this.assert('MESH', 'PARAM', 'ATTRACTION', { ...systemMeta, value: this.attraction });
        this.assert('MESH', 'PARAM', 'DAMPING', { ...systemMeta, value: this.damping });
    }

    // ============================================================
    // ASSERTION
    // ============================================================

    assert(subject, relation, object, meta = {}) {
        const triple = new Triple(subject, relation, object, meta);

        // Check exclusions (mutually exclusive triples)
        if (this._checkExclusion(triple)) {
            this._negateConflicting(triple);
        }

        // Store
        this.triples.set(triple.id, triple);
        this._indexTriple(triple);
        this._updateSpatialIndex(triple);
        this._updateNodePosition(triple);

        // Apply semantic forces
        this._applySemanticForce(triple);

        // Log
        this.changelog.push({ time: this.time, action: 'assert', triple: triple.id });

        // Notify surfaces
        this._notifySurfaces('assert', triple);

        return triple;
    }

    // Batch assertion for efficiency
    assertMany(tripleSpecs) {
        return tripleSpecs.map(spec =>
            this.assert(spec.subject, spec.relation, spec.object, spec.meta || {})
        );
    }

    // ============================================================
    // NEGATION
    // ============================================================

    negate(tripleId) {
        const triple = this.triples.get(tripleId);
        if (!triple) return null;

        triple.negate(this.time);
        this._removeFromSpatialIndex(triple);
        this.changelog.push({ time: this.time, action: 'negate', triple: tripleId });
        this._notifySurfaces('negate', triple);
        return triple;
    }

    negateByPattern(pattern) {
        const matches = this.query(pattern);
        return matches.map(t => this.negate(t.id));
    }

    // ============================================================
    // QUERY
    // ============================================================

    query(pattern, options = {}) {
        const {
            time = this.time,
            activeOnly = true,
            spatial = null,       // { center: Vector, radius: number }
            sortBy = null,         // 'value', 'certainty', 'distance'
            limit = Infinity
        } = options;

        let candidates;

        // Start with most specific index
        if (pattern.subject) {
            candidates = this._getBySubject(pattern.subject);
        } else if (pattern.relation) {
            candidates = this._getByRelation(pattern.relation);
        } else if (pattern.object) {
            candidates = this._getByObject(pattern.object);
        } else if (pattern.tripleType) {
            candidates = this._getByType(pattern.tripleType);
        } else if (pattern.domain) {
            candidates = this._getByDomain(pattern.domain);
        } else {
            candidates = Array.from(this.triples.values());
        }

        // Filter
        let results = candidates.filter(t => {
            if (activeOnly && !t.isActive(time)) return false;
            if (pattern.subject && t.subject !== pattern.subject) return false;
            if (pattern.relation && t.relation !== pattern.relation) return false;
            if (pattern.object && t.object !== pattern.object) return false;
            if (pattern.tripleType && t.tripleType !== pattern.tripleType) return false;
            if (pattern.domain && t.domain !== pattern.domain) return false;
            if (pattern.minValue !== undefined && t.value < pattern.minValue) return false;
            if (pattern.maxValue !== undefined && t.value > pattern.maxValue) return false;
            if (pattern.code !== undefined && !t.code) return false;
            return true;
        });

        // Spatial filter
        if (spatial) {
            results = results.filter(t => {
                const dist = t.position.distance(spatial.center);
                return dist <= spatial.radius;
            });
        }

        // Sort
        if (sortBy === 'value') {
            results.sort((a, b) => b.value - a.value);
        } else if (sortBy === 'certainty') {
            results.sort((a, b) => b.certainty - a.certainty);
        } else if (sortBy === 'distance' && spatial) {
            results.sort((a, b) => {
                const da = a.position.distance(spatial.center);
                const db = b.position.distance(spatial.center);
                return da - db;
            });
        }

        // Limit
        if (limit !== Infinity) {
            results = results.slice(0, limit);
        }

        return results;
    }

    // Query by path (is there a path from A to B through specific relations?)
    queryPath(from, to, options = {}) {
        const { allowedRels = null, forbiddenRels = null, maxDepth = 10 } = options;

        const visited = new Set();
        const queue = [{ node: from, path: [], depth: 0 }];

        while (queue.length > 0) {
            const { node, path, depth } = queue.shift();

            if (node === to) return path;
            if (depth >= maxDepth) continue;
            if (visited.has(node)) continue;
            visited.add(node);

            const outgoing = this._getBySubject(node);
            for (const triple of outgoing) {
                if (!triple.isActive()) continue;
                if (allowedRels && !allowedRels.includes(triple.relation)) continue;
                if (forbiddenRels && forbiddenRels.includes(triple.relation)) continue;

                queue.push({
                    node: triple.object,
                    path: [...path, triple],
                    depth: depth + 1
                });
            }
        }

        return null; // No path found
    }

    // ============================================================
    // SPATIAL QUERIES
    // ============================================================

    queryRadius(center, radius, options = {}) {
        return this.query({}, { ...options, spatial: { center, radius } });
    }

    queryNearest(center, k = 5, options = {}) {
        const all = this.query({}, { ...options, activeOnly: true });
        all.sort((a, b) => {
            const da = a.position.distance(center);
            const db = b.position.distance(center);
            return da - db;
        });
        return all.slice(0, k);
    }

    queryCone(center, direction, angle, maxDistance, options = {}) {
        const all = this.query({}, { ...options, activeOnly: true });
        const dirNorm = direction.normalize();

        return all.filter(t => {
            const diff = t.position.sub(center);
            const dist = diff.length();
            if (dist > maxDistance) return false;
            const cosAngle = diff.normalize().dot(dirNorm);
            return cosAngle >= Math.cos(angle);
        });
    }

    // ============================================================
    // PHYSICS
    // ============================================================

    stepPhysics() {
        this.time += this.dt;

        const activeTriples = this.query({}, { activeOnly: true });
        const nodes = this._aggregateNodePositions(activeTriples);

        // Repulsion between all nodes
        const nodeList = Array.from(nodes.entries());
        for (let i = 0; i < nodeList.length; i++) {
            for (let j = i + 1; j < nodeList.length; j++) {
                const [id1, n1] = nodeList[i];
                const [id2, n2] = nodeList[j];

                const diff = n1.position.sub(n2.position);
                const dist = diff.length() + 0.1;
                const force = (this.repulsion * n1.charge * n2.charge) / (dist * dist);

                const push = diff.normalize().scale(force * this.dt);
                n1.velocity = n1.velocity.add(push);
                n2.velocity = n2.velocity.sub(push);
            }
        }

        // Attraction along edges (triples)
        for (const triple of activeTriples) {
            if (!triple.object) continue; // unary triples have no edge attraction

            const s = nodes.get(triple.subject);
            const o = nodes.get(triple.object);
            if (!s || !o) continue;

            const forceParams = this.relationForces.get(triple.relation) || this.defaultForce;
            const diff = o.position.sub(s.position);
            const dist = diff.length();

            if (forceParams.type === 'spring') {
                // Hooke's law
                const displacement = dist - forceParams.length;
                const force = forceParams.stiffness * displacement * triple.value;

                const pull = diff.normalize().scale(force * this.dt);
                s.velocity = s.velocity.add(pull);
                o.velocity = o.velocity.sub(pull);
            } else if (forceParams.type === 'gravity') {
                // Inverse square attraction
                const force = this.attraction * triple.mass / (dist * dist + 0.1);
                const pull = diff.normalize().scale(force * this.dt);
                s.velocity = s.velocity.add(pull);
                o.velocity = o.velocity.sub(pull);
            }
        }

        // Update positions
        for (const [id, node] of nodes) {
            // Clamp velocity
            const vLen = node.velocity.length();
            if (vLen > this.maxVelocity) {
                node.velocity = node.velocity.normalize().scale(this.maxVelocity);
            }

            // Apply damping
            node.velocity = node.velocity.scale(this.damping);

            // Update position
            node.position = node.position.add(node.velocity.scale(this.dt));

            // Sync back to triples
            this._syncNodePosition(id, node.position);
        }

        // Update spatial index
        this._rebuildSpatialIndex();

        // Notify
        this._notifySurfaces('physics_step', { time: this.time, nodes: nodes.size });
    }

    // ============================================================
    // SURFACE REGISTRATION
    // ============================================================

    registerSurface(name, callback) {
        this.surfaces.set(name, callback);
    }

    unregisterSurface(name) {
        this.surfaces.delete(name);
    }

    _notifySurfaces(event, data) {
        for (const [name, callback] of this.surfaces) {
            try {
                callback(event, data, this);
            } catch (e) {
                console.error(`Surface ${name} error:`, e);
            }
        }
    }

    // ============================================================
    // CODE GENERATION INTERFACE
    // ============================================================

    // Generate code from a triple pattern
    generateCode(pattern, options = {}) {
        const matches = this.query(pattern, { activeOnly: true });
        const { language = 'javascript', template = 'function' } = options;

        let code = '';

        if (template === 'function') {
            code = this._generateFunction(matches, language);
        } else if (template === 'class') {
            code = this._generateClass(matches, language);
        } else if (template === 'rule') {
            code = this._generateRules(matches, language);
        }

        return code;
    }

    _generateFunction(triples, language) {
        if (language === 'javascript') {
            const funcName = triples[0]?.relation || 'generatedFunction';
            let code = `function ${funcName}(ctx) {\n`;
            code += `  const mesh = ctx.mesh;\n`;
            code += `  const results = [];\n\n`;

            for (const t of triples) {
                if (t.code) {
                    code += `  ${t.code}\n`;
                } else {
                    code += `  mesh.assert('${t.subject}', '${t.relation}', '${t.object}', { value: ${t.value} });\n`;
                }
            }

            code += `\n  return results;\n}`;
            return code;
        }

        return '// Code generation for ${language} not yet implemented';
    }

    _generateClass(triples, language) {
        // Generate a class from a pattern of triples
        const className = triples[0]?.subject || 'GeneratedClass';

        if (language === 'javascript') {
            let code = `class ${className} {\n`;
            code += `  constructor(mesh) {\n`;
            code += `    this.mesh = mesh;\n`;

            // Properties from triples
            for (const t of triples) {
                if (t.relation === 'HAS') {
                    code += `    this.${t.object} = ${t.value !== undefined ? t.value : 'null'};\n`;
                }
            }

            code += `  }\n\n`;

            // Methods from code triples
            for (const t of triples) {
                if (t.code && t.relation === 'CAN') {
                    code += `  ${t.object}() {\n`;
                    code += `    ${t.code}\n`;
                    code += `  }\n\n`;
                }
            }

            code += `}`;
            return code;
        }

        return '// Class generation for ${language} not yet implemented';
    }

    _generateRules(triples, language) {
        // Generate MESSY-style rules
        let code = '';

        for (const t of triples) {
            if (t.tripleType === 'rule') {
                code += `// Rule: ${t.subject} ${t.relation} ${t.object}\n`;
                code += `if (ctx.condition('${t.subject}', '${t.relation}', '${t.object}')) {\n`;
                code += `  ctx.action('${t.relation}', '${t.object}', { value: ${t.value} });\n`;
                code += `}\n\n`;
            }
        }

        return code;
    }

    // Execute code triples in a sandbox
    execute(tripleId, context = {}) {
        const triple = this.triples.get(tripleId);
        if (!triple || !triple.code) return { error: 'No code to execute' };

        // Create sandboxed environment
        const sandbox = {
            mesh: this,
            assert: (s, r, o, m) => this.assert(s, r, o, m),
            query: (p, o) => this.query(p, o),
            negate: (id) => this.negate(id),
            console: { log: (...args) => console.log(...args) },
            Math,
            Date,
            JSON,
            ...context
        };

        try {
            // For JavaScript, use Function constructor for sandbox
            const fn = new Function('ctx', `\n"use strict";\n${triple.code}\n`);
            const result = fn(sandbox);
            return { success: true, result };
        } catch (e) {
            return { success: false, error: e.message };
        }
    }

    // ============================================================
    // NEURAL INTERFACE
    // ============================================================

    // Get embedding representation of the mesh (for neural nets)
    getEmbedding(options = {}) {
        const { dim = 512, method = 'spectral' } = options;

        if (method === 'spectral') {
            // Simple spectral embedding: adjacency matrix eigenvectors
            return this._spectralEmbedding(dim);
        } else if (method === 'random') {
            // Random projection for testing
            return this._randomEmbedding(dim);
        }

        return null;
    }

    _spectralEmbedding(dim) {
        // Build adjacency matrix
        const activeTriples = this.query({}, { activeOnly: true });
        const nodes = new Set();
        activeTriples.forEach(t => { nodes.add(t.subject); nodes.add(t.object); });
        const nodeList = Array.from(nodes);
        const n = nodeList.length;

        if (n === 0) return new Float64Array(dim);

        // Simple degree-based embedding (placeholder for full spectral)
        const embedding = new Float64Array(dim);
        for (let i = 0; i < Math.min(dim, n); i++) {
            const node = nodeList[i];
            const degree = this._getBySubject(node).length + this._getByObject(node).length;
            embedding[i] = degree / n;
        }

        return embedding;
    }

    _randomEmbedding(dim) {
        const emb = new Float64Array(dim);
        for (let i = 0; i < dim; i++) {
            emb[i] = (Math.random() - 0.5) * 2;
        }
        return emb;
    }

    // ============================================================
    // SELF-MODIFICATION
    // ============================================================

    // The mesh can modify itself by asserting system triples
    selfModify(command) {
        if (command.type === 'adjust_param') {
            const param = command.param;
            const value = command.value;

            if (param === 'repulsion') this.repulsion = value;
            if (param === 'attraction') this.attraction = value;
            if (param === 'damping') this.damping = value;

            // Update system triple
            this.negateByPattern({ subject: 'MESH', relation: 'PARAM', object: param.toUpperCase() });
            this.assert('MESH', 'PARAM', param.toUpperCase(), {
                tripleType: 'meta',
                domain: 'system',
                value: value
            });

            return { success: true, param, value };
        }

        if (command.type === 'add_relation_force') {
            this.relationForces.set(command.relation, {
                length: command.length || 5,
                stiffness: command.stiffness || 0.1,
                type: command.forceType || 'spring'
            });
            return { success: true };
        }

        return { success: false, error: 'Unknown command type' };
    }

    // ============================================================
    // SERIALIZATION
    // ============================================================

    serialize() {
        return {
            dimensions: this.dimensions,
            time: this.time,
            physics: {
                repulsion: this.repulsion,
                attraction: this.attraction,
                damping: this.damping
            },
            triples: Array.from(this.triples.values()).map(t => t.serialize()),
            relationForces: Object.fromEntries(this.relationForces)
        };
    }

    static deserialize(data) {
        const mesh = new Mesh({
            dimensions: data.dimensions,
            repulsion: data.physics?.repulsion,
            attraction: data.physics?.attraction,
            damping: data.physics?.damping
        });

        mesh.time = data.time || 0;

        for (const tData of data.triples) {
            const triple = Triple.deserialize(tData);
            mesh.triples.set(triple.id, triple);
            mesh._indexTriple(triple);
            mesh._updateSpatialIndex(triple);
            mesh._updateNodePosition(triple);
        }

        if (data.relationForces) {
            for (const [rel, force] of Object.entries(data.relationForces)) {
                mesh.relationForces.set(rel, force);
            }
        }

        return mesh;
    }

    // ============================================================
    // PRIVATE HELPERS
    // ============================================================

    _indexTriple(triple) {
        // Subject index
        if (!this.bySubject.has(triple.subject)) this.bySubject.set(triple.subject, new Set());
        this.bySubject.get(triple.subject).add(triple.id);

        // Relation index
        if (!this.byRelation.has(triple.relation)) this.byRelation.set(triple.relation, new Set());
        this.byRelation.get(triple.relation).add(triple.id);

        // Object index
        if (!this.byObject.has(triple.object)) this.byObject.set(triple.object, new Set());
        this.byObject.get(triple.object).add(triple.id);

        // Type index
        if (!this.byType.has(triple.tripleType)) this.byType.set(triple.tripleType, new Set());
        this.byType.get(triple.tripleType).add(triple.id);

        // Domain index
        if (!this.byDomain.has(triple.domain)) this.byDomain.set(triple.domain, new Set());
        this.byDomain.get(triple.domain).add(triple.id);
    }

    _getBySubject(subject) {
        const ids = this.bySubject.get(subject);
        if (!ids) return [];
        return Array.from(ids).map(id => this.triples.get(id)).filter(Boolean);
    }

    _getByRelation(relation) {
        const ids = this.byRelation.get(relation);
        if (!ids) return [];
        return Array.from(ids).map(id => this.triples.get(id)).filter(Boolean);
    }

    _getByObject(object) {
        const ids = this.byObject.get(object);
        if (!ids) return [];
        return Array.from(ids).map(id => this.triples.get(id)).filter(Boolean);
    }

    _getByType(type) {
        const ids = this.byType.get(type);
        if (!ids) return [];
        return Array.from(ids).map(id => this.triples.get(id)).filter(Boolean);
    }

    _getByDomain(domain) {
        const ids = this.byDomain.get(domain);
        if (!ids) return [];
        return Array.from(ids).map(id => this.triples.get(id)).filter(Boolean);
    }

    _updateSpatialIndex(triple) {
        const cellKey = this._getCellKey(triple.position);
        if (!this.spatialIndex.has(cellKey)) this.spatialIndex.set(cellKey, new Set());
        this.spatialIndex.get(cellKey).add(triple.id);
    }

    _removeFromSpatialIndex(triple) {
        const cellKey = this._getCellKey(triple.position);
        const cell = this.spatialIndex.get(cellKey);
        if (cell) cell.delete(triple.id);
    }

    _getCellKey(position) {
        const x = Math.floor(position.v[0] / this.cellSize);
        const y = Math.floor(position.v[1] / this.cellSize);
        const z = Math.floor(position.v[2] / this.cellSize);
        return `${x},${y},${z}`;
    }

    _rebuildSpatialIndex() {
        this.spatialIndex.clear();
        for (const triple of this.triples.values()) {
            if (triple.isActive()) {
                this._updateSpatialIndex(triple);
            }
        }
    }

    _updateNodePosition(triple) {
        // Aggregate position for each atom
        for (const atom of [triple.subject, triple.object]) {
            if (!atom) continue;
            const existing = this.nodePositions.get(atom);
            if (existing) {
                // Weighted average
                const weight = triple.value || 1;
                existing.position = existing.position.add(triple.position.scale(weight));
                existing.count += weight;
            } else {
                this.nodePositions.set(atom, {
                    position: triple.position.clone(),
                    charge: triple.charge,
                    mass: triple.mass,
                    count: 1
                });
            }
        }
    }

    _syncNodePosition(atom, position) {
        // Update all triples involving this atom
        const triples = [
            ...this._getBySubject(atom),
            ...this._getByObject(atom)
        ];
        for (const t of triples) {
            if (t.isActive()) {
                t.position = position.clone();
            }
        }
    }

    _aggregateNodePositions(activeTriples) {
        const nodes = new Map();

        for (const triple of activeTriples) {
            for (const atom of [triple.subject, triple.object]) {
                if (!atom) continue;
                if (!nodes.has(atom)) {
                    nodes.set(atom, {
                        position: Vector.zero(this.dimensions),
                        velocity: Vector.zero(this.dimensions),
                        charge: 0,
                        mass: 0,
                        count: 0
                    });
                }
                const node = nodes.get(atom);
                node.position = node.position.add(triple.position);
                node.velocity = node.velocity.add(triple.velocity);
                node.charge += triple.charge;
                node.mass += triple.mass;
                node.count++;
            }
        }

        // Average
        for (const [atom, node] of nodes) {
            if (node.count > 0) {
                node.position = node.position.scale(1 / node.count);
                node.velocity = node.velocity.scale(1 / node.count);
                node.charge /= node.count;
                node.mass /= node.count;
            }
        }

        return nodes;
    }

    _applySemanticForce(triple) {
        // Apply relation-specific forces when triple is asserted
        const force = this.relationForces.get(triple.relation);
        if (force && force.type === 'constraint') {
            // Immediate position constraint
            if (triple.object && this.nodePositions.has(triple.object)) {
                const targetPos = this.nodePositions.get(triple.object).position;
                triple.position = targetPos.clone();
            }
        }
    }

    _checkExclusion(triple) {
        // Check if this triple conflicts with existing exclusions
        // Exclusions are stored as triples with relation 'EXCLUDES'
        const exclusions = this._getByRelation('EXCLUDES');
        for (const ex of exclusions) {
            if (ex.object === triple.relation || ex.subject === triple.relation) {
                return true;
            }
        }
        return false;
    }

    _negateConflicting(triple) {
        // Find and negate conflicting triples
        const conflicts = this.query({
            subject: triple.subject,
            relation: triple.relation,
            object: triple.object
        });
        for (const c of conflicts) {
            if (c.id !== triple.id) {
                this.negate(c.id);
            }
        }
    }
}

// ============================================================
// SECTION 4: THE RULE ENGINE
// ============================================================

class Rule {
    constructor(name, conditions, actions, options = {}) {
        this.name = name;
        this.conditions = conditions;       // array of functions: (mesh, context) => boolean|number
        this.actions = actions;             // array of functions: (mesh, context) => result
        this.probability = options.probability || 1.0;
        this.priority = options.priority || 0;
        this.enabled = options.enabled !== undefined ? options.enabled : true;
        this.group = options.group || 'default';
        this.maxExecutions = options.maxExecutions || Infinity;
        this.executions = 0;
        this.lastExecuted = 0;
    }

    evaluate(mesh, context, time) {
        if (!this.enabled) return false;
        if (this.executions >= this.maxExecutions) return false;

        let cumulativeProb = this.probability;

        for (const condition of this.conditions) {
            const result = condition(mesh, context, time);
            if (result === false) return false;
            if (typeof result === 'number') {
                cumulativeProb += result;  // Klein-style probability adjustment
            }
        }

        cumulativeProb = Math.max(0, Math.min(1, cumulativeProb));
        return Math.random() < cumulativeProb;
    }

    execute(mesh, context, time) {
        const results = [];
        for (const action of this.actions) {
            try {
                const result = action(mesh, context, time);
                results.push(result);
            } catch (e) {
                results.push({ error: e.message });
            }
        }
        this.executions++;
        this.lastExecuted = time;
        return results;
    }
}

class RuleEngine {
    constructor(mesh) {
        this.mesh = mesh;
        this.rules = [];
        this.groups = new Map();  // group name -> { interval, active, rules }
        this.time = 0;
        this.executionLog = [];
    }

    addRule(rule) {
        this.rules.push(rule);
        if (!this.groups.has(rule.group)) {
            this.groups.set(rule.group, { interval: 1, active: true, rules: [] });
        }
        this.groups.get(rule.group).rules.push(rule);
    }

    evaluateAll(context = {}) {
        const fired = [];

        // Sort by priority
        const sorted = [...this.rules].sort((a, b) => b.priority - a.priority);

        for (const rule of sorted) {
            if (rule.evaluate(this.mesh, context, this.time)) {
                const results = rule.execute(this.mesh, context, this.time);
                fired.push({ rule: rule.name, results });
                this.executionLog.push({
                    time: this.time,
                    rule: rule.name,
                    results
                });
            }
        }

        this.time++;
        return fired;
    }

    evaluateGroup(groupName, context = {}) {
        const group = this.groups.get(groupName);
        if (!group || !group.active) return [];

        const fired = [];
        for (const rule of group.rules) {
            if (rule.evaluate(this.mesh, context, this.time)) {
                const results = rule.execute(this.mesh, context, this.time);
                fired.push({ rule: rule.name, results });
            }
        }

        return fired;
    }
}

// ============================================================
// SECTION 5: THE SURFACE MANAGER
// ============================================================

class SurfaceManager {
    constructor(mesh) {
        this.mesh = mesh;
        this.surfaces = new Map();  // name -> Surface instance
    }

    register(name, surface) {
        this.surfaces.set(name, surface);
        this.mesh.registerSurface(name, (event, data, mesh) => {
            surface.handle(event, data, mesh);
        });
    }

    unregister(name) {
        this.surfaces.delete(name);
        this.mesh.unregisterSurface(name);
    }

    broadcast(event, data) {
        for (const [name, surface] of this.surfaces) {
            surface.handle(event, data, this.mesh);
        }
    }
}

// Base Surface class
class Surface {
    constructor(name) {
        this.name = name;
    }

    handle(event, data, mesh) {
        // Override in subclasses
        console.log(`[${this.name}] ${event}:`, data);
    }
}

// JavaScript/DOM Surface
class JSSurface extends Surface {
    constructor(name, rootElement) {
        super(name);
        this.root = rootElement;
        this.elements = new Map();  // tripleId -> DOMElement
    }

    handle(event, data, mesh) {
        switch (event) {
            case 'assert':
                this.renderTriple(data);
                break;
            case 'negate':
                this.removeTriple(data);
                break;
            case 'physics_step':
                this.updatePositions(mesh);
                break;
        }
    }

    renderTriple(triple) {
        const el = document.createElement('div');
        el.className = `triple-${triple.tripleType}`;
        el.dataset.tripleId = triple.id;
        el.style.position = 'absolute';
        el.style.left = `${triple.position.v[0]}px`;
        el.style.top = `${triple.position.v[1]}px`;
        el.textContent = triple.toString();
        this.root.appendChild(el);
        this.elements.set(triple.id, el);
    }

    removeTriple(triple) {
        const el = this.elements.get(triple.id);
        if (el) {
            el.remove();
            this.elements.delete(triple.id);
        }
    }

    updatePositions(mesh) {
        for (const [id, el] of this.elements) {
            const triple = mesh.triples.get(id);
            if (triple && triple.isActive()) {
                el.style.transform = `translate(${triple.position.v[0]}px, ${triple.position.v[1]}px)`;
            }
        }
    }
}

// Code Generation Surface
class CodeSurface extends Surface {
    constructor(name, options = {}) {
        super(name);
        this.language = options.language || 'javascript';
        this.generated = [];
    }

    handle(event, data, mesh) {
        if (event === 'assert' && data.tripleType === 'code') {
            this.generateCode(data, mesh);
        }
    }

    generateCode(triple, mesh) {
        if (!triple.code) return;

        const code = {
            tripleId: triple.id,
            language: triple.language || this.language,
            source: triple.code,
            generated: Date.now()
        };

        this.generated.push(code);

        // Emit for external execution
        this.emit('code_generated', code);
    }

    emit(event, data) {
        // Override for external listeners
    }
}

// Neural Network Surface
class NeuralSurface extends Surface {
    constructor(name, options = {}) {
        super(name);
        this.embeddingDim = options.embeddingDim || 512;
        this.updateFrequency = options.updateFrequency || 10;
        this.tickCount = 0;
    }

    handle(event, data, mesh) {
        if (event === 'physics_step') {
            this.tickCount++;
            if (this.tickCount % this.updateFrequency === 0) {
                this.updateEmbedding(mesh);
            }
        }
    }

    updateEmbedding(mesh) {
        const embedding = mesh.getEmbedding({
            dim: this.embeddingDim,
            method: 'spectral'
        });

        this.emit('embedding_updated', {
            time: mesh.time,
            embedding: embedding,
            tripleCount: mesh.triples.size
        });
    }

    emit(event, data) {
        // Override for external listeners
    }
}

// ============================================================
// SECTION 6: THE GENERATIVE ENGINE
// ============================================================

class GenerativeEngine {
    constructor(mesh, ruleEngine) {
        this.mesh = mesh;
        this.rules = ruleEngine;
        this.generators = new Map();  // type -> generator function
        this.templates = new Map();   // name -> template string

        this._initGenerators();
    }

    _initGenerators() {
        // Game generator
        this.generators.set('game', (pattern, context) => this.generateGame(pattern, context));

        // App generator
        this.generators.set('app', (pattern, context) => this.generateApp(pattern, context));

        // Video/story generator
        this.generators.set('story', (pattern, context) => this.generateStory(pattern, context));

        // Code generator
        this.generators.set('code', (pattern, context) => this.generateCode(pattern, context));
    }

    generate(type, pattern, context = {}) {
        const generator = this.generators.get(type);
        if (!generator) {
            return { error: `Unknown generator type: ${type}` };
        }
        return generator(pattern, context);
    }

    generateGame(pattern, context) {
        // Extract game elements from mesh
        const characters = this.mesh.query({ tripleType: 'assertion', relation: 'IS' }, { limit: 10 });
        const locations = this.mesh.query({ tripleType: 'assertion', relation: 'AT' }, { limit: 10 });
        const items = this.mesh.query({ tripleType: 'assertion', relation: 'HAS' }, { limit: 10 });

        return {
            type: 'game',
            title: context.title || 'Generated Game',
            characters: characters.map(c => ({
                name: c.subject,
                role: c.object,
                position: c.position.toArray()
            })),
            locations: locations.map(l => ({
                name: l.object,
                connected: this.mesh.queryPath(l.subject, l.object, { maxDepth: 2 }) || []
            })),
            items: items.map(i => ({
                name: i.object,
                owner: i.subject
            })),
            rules: this.rules.rules.map(r => ({
                name: r.name,
                probability: r.probability
            })),
            // Generated code
            code: this.mesh.generateCode(pattern, { template: 'class', language: 'javascript' })
        };
    }

    generateApp(pattern, context) {
        // Generate app structure from mesh patterns
        const components = this.mesh.query({ tripleType: 'assertion', relation: 'RENDERS' }, { limit: 20 });
        const events = this.mesh.query({ tripleType: 'assertion', relation: 'TRIGGERS' }, { limit: 20 });
        const data = this.mesh.query({ tripleType: 'assertion', relation: 'STORES' }, { limit: 20 });

        return {
            type: 'app',
            name: context.name || 'GeneratedApp',
            components: components.map(c => ({
                name: c.subject,
                renders: c.object,
                position: c.position.toArray()
            })),
            events: events.map(e => ({
                trigger: e.subject,
                action: e.object
            })),
            data: data.map(d => ({
                store: d.subject,
                schema: d.object
            })),
            code: this.mesh.generateCode(pattern, { template: 'class', language: 'javascript' })
        };
    }

    generateStory(pattern, context) {
        // Generate narrative from mesh topology
        const plot = this.mesh.queryPath(context.protagonist, context.goal, { maxDepth: 10 });

        return {
            type: 'story',
            title: context.title || 'Generated Story',
            protagonist: context.protagonist,
            goal: context.goal,
            plot: plot ? plot.map(t => t.toString()) : [],
            scenes: this._generateScenes(plot),
            code: this.mesh.generateCode(pattern, { template: 'function', language: 'javascript' })
        };
    }

    _generateScenes(plot) {
        if (!plot) return [];

        return plot.map((triple, i) => ({
            scene: i + 1,
            setting: triple.subject,
            action: triple.relation,
            target: triple.object,
            tension: triple.value,
            description: this._sceneDescription(triple)
        }));
    }

    _sceneDescription(triple) {
        const templates = {
            'MEETS': `In ${triple.subject}, a figure approaches. It is ${triple.object}.`,
            'FIGHTS': `${triple.subject} and ${triple.object} clash. The air shatters.`,
            'LOVES': `${triple.subject} sees ${triple.object} and the world narrows.`,
            'FEARS': `${triple.subject} cannot look at ${triple.object}. Something is wrong.`,
            'FINDS': `${triple.subject} discovers ${triple.object} where it should not be.`,
            'DEFAULT': `${triple.subject} ${triple.relation.toLowerCase()}s ${triple.object}.`
        };
        return templates[triple.relation] || templates.DEFAULT;
    }

    generateCode(pattern, context) {
        return {
            type: 'code',
            language: context.language || 'javascript',
            source: this.mesh.generateCode(pattern, {
                template: context.template || 'function',
                language: context.language || 'javascript'
            })
        };
    }
}

// ============================================================
// SECTION 7: THE INVERSION (Pattern Inhabitation)
// ============================================================

class Inversion {
    constructor(mesh) {
        this.mesh = mesh;
        this.inhabitations = new Map();  // inhabitantId -> { targetPattern, session }
    }

    // Extract a pattern from a set of triples (a person's "mesh signature")
    extractPattern(triples, options = {}) {
        const {
            gravityWells = true,
            tensionBridges = true,
            exclusions = true,
            anchors = true,
            negativeSpace = true
        } = options;

        const pattern = {
            source: null,
            triples: triples,
            gravityWells: [],
            tensionBridges: [],
            exclusions: [],
            anchors: [],
            negativeSpace: []
        };

        if (gravityWells) {
            pattern.gravityWells = this._extractGravityWells(triples);
        }

        if (tensionBridges) {
            pattern.tensionBridges = this._extractTensionBridges(triples);
        }

        if (anchors) {
            pattern.anchors = this._extractAnchors(triples);
        }

        return pattern;
    }

    _extractGravityWells(triples) {
        const nodeScores = new Map();

        for (const t of triples) {
            const intensity = Math.abs(t.value) + (t.rv === 0 ? 2 : 0);
            for (const atom of [t.subject, t.object]) {
                if (!atom) continue;
                const score = (nodeScores.get(atom) || 0) + intensity;
                nodeScores.set(atom, score);
            }
        }

        return [...nodeScores.entries()]
            .sort((a, b) => b[1] - a[1])
            .slice(0, 7)
            .map(([node, score]) => ({
                node,
                gravity: score,
                quality: triples.filter(t => t.subject === node).reduce((s, t) => s + t.value, 0) > 0
                    ? 'ATTRACTION' : 'AVOIDANCE'
            }));
    }

    _extractTensionBridges(triples) {
        // Find edges with high oscillation or repeated assertion/negation
        const edgeHistory = new Map();

        for (const t of triples) {
            const key = `${t.subject}:${t.relation}:${t.object}`;
            if (!edgeHistory.has(key)) edgeHistory.set(key, []);
            edgeHistory.get(key).push(t);
        }

        return [...edgeHistory.entries()]
            .map(([key, events]) => {
                const values = events.map(e => e.value);
                const oscillation = Math.max(...values) - Math.min(...values);
                const cycles = events.filter(e => e.deletedAt).length;
                return { key, oscillation, cycles, tension: cycles * oscillation };
            })
            .filter(b => b.tension > 0.5)
            .sort((a, b) => b.tension - a.tension)
            .slice(0, 6);
    }

    _extractAnchors(triples) {
        // Find nodes that persist through all time periods
        const timeSlices = this._sliceByTime(triples, 3);
        if (timeSlices.length === 0) return [];

        const persistent = new Set(timeSlices[0].map(t => t.subject));
        for (const slice of timeSlices.slice(1)) {
            const nodes = new Set(slice.map(t => t.subject));
            for (const p of persistent) {
                if (!nodes.has(p)) persistent.delete(p);
            }
        }

        return [...persistent].map(node => ({
            node,
            relations: triples.filter(t => t.subject === node).map(t => t.relation)
        }));
    }

    _sliceByTime(triples, numSlices) {
        if (triples.length === 0) return [];
        const min = Math.min(...triples.map(t => t.createdAt));
        const max = Math.max(...triples.map(t => t.createdAt));
        const range = max - min;
        const sliceSize = range / numSlices;

        const slices = [];
        for (let i = 0; i < numSlices; i++) {
            const start = min + i * sliceSize;
            const end = start + sliceSize;
            slices.push(triples.filter(t => t.createdAt >= start && t.createdAt < end));
        }
        return slices;
    }

    // Inhabit a pattern: create a session where you wear someone else's mesh
    inhabit(inhabitantId, targetPattern, options = {}) {
        const session = {
            inhabitant: inhabitantId,
            pattern: targetPattern,
            startTime: Date.now(),
            traces: [],
            active: true
        };

        this.inhabitations.set(inhabitantId, session);

        // Create a sub-mesh from the pattern
        const subMesh = new Mesh({ dimensions: this.mesh.dimensions });

        // Add pattern triples to sub-mesh with "inhabitation" markers
        for (const t of targetPattern.triples) {
            subMesh.assert(t.subject, t.relation, t.object, {
                ...t,
                domain: 'inhabited',
                tripleType: 'inhabited',
                h: 0.5  // partially real, partially ghost
            });
        }

        session.subMesh = subMesh;

        return session;
    }

    // Exit inhabitation, return traces
    exit(inhabitantId) {
        const session = this.inhabitations.get(inhabitantId);
        if (!session) return null;

        session.active = false;
        session.endTime = Date.now();

        // Extract traces: what the inhabitant experienced
        const traces = session.subMesh.query({ domain: 'inhabited', activeOnly: true });

        // Add traces to main mesh as "learned" triples
        for (const t of traces) {
            this.mesh.assert(inhabitantId, 'LEARNED_FROM', t.subject, {
                value: t.value,
                h: 0.3,  // still somewhat hypothetical
                tripleType: 'learned'
            });
        }

        return {
            traces: traces.map(t => ({
                subject: t.subject,
                relation: t.relation,
                object: t.object,
                value: t.value
            })),
            duration: session.endTime - session.startTime
        };
    }
}

// ============================================================
// SECTION 8: EXPORT
// ============================================================

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        Vector,
        Triple,
        Mesh,
        Rule,
        RuleEngine,
        SurfaceManager,
        Surface,
        JSSurface,
        CodeSurface,
        NeuralSurface,
        GenerativeEngine,
        Inversion
    };
}

// Browser global
if (typeof window !== 'undefined') {
    window.CanonicalMesh = {
        Vector,
        Triple,
        Mesh,
        Rule,
        RuleEngine,
        SurfaceManager,
        Surface,
        JSSurface,
        CodeSurface,
        NeuralSurface,
        GenerativeEngine,
        Inversion
    };
}
