# SYNTHIA OS · Canonical Mesh System

## What This Is

A unified system that combines:

1. **SYNTHIA OS** - Mobile OS interface with Human Design / esoteric computing themes
2. **Canonical Mesh System** - Semantic network with spatial physics, self-describing triples, and multi-surface projection
3. **Generative Engine** - Produces games, apps, stories, and code from mesh patterns
4. **Inversion System** - Pattern inhabitation: wear someone else's mesh
5. **Neural Interface** - Embeddings and code generation from triples

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     SYNTHIA OS UI                          │
│         (Mobile interface, home screen, apps)               │
├─────────────────────────────────────────────────────────────┤
│                  Canonical Mesh System                       │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────────┐   │
│  │ Triple  │  │ Spatial │  │  Rule   │  │ Generative  │   │
│  │ Store   │  │ Physics │  │ Engine  │  │   Engine    │   │
│  └────┬────┘  └────┬────┘  └────┬────┘  └──────┬──────┘   │
│       └─────────────┴──────────┴──────────────┘            │
│                         │                                   │
│                  ┌──────┴──────┐                            │
│                  │  Surfaces   │                            │
│                  │ JS/Python/  │                            │
│                  │ Neural/Mesh │                            │
│                  └─────────────┘                            │
├─────────────────────────────────────────────────────────────┤
│              Human Design · I Ching · MESSY                 │
│         (64 gates, 64 hexagrams, semantic grammar)        │
└─────────────────────────────────────────────────────────────┘
```

## Core Concepts

### The Triple
Everything is a triple: `(subject, relation, object)`

Triples have:
- **Semantic properties**: value, reality (rv), hypotheticality (h), certainty
- **Geometric properties**: position (Vector), velocity, mass, charge
- **Executable properties**: code, language, compiled function
- **Surface bindings**: how they manifest in JS DOM, Python, neural nets

### The Mesh
Not a database. A **physical system** where triples have geometry and semantics simultaneously.

- Nodes repel/attract based on charge
- Edges (triples) have spring forces based on relation type
- Spatial queries: radius, nearest, cone, path
- Self-describing: system rules are also triples

### Surfaces
The mesh projects onto multiple surfaces simultaneously:
- **JS Surface**: DOM elements, events, CSS transforms
- **Python Surface**: Execution, state management
- **Neural Surface**: Embeddings, vector representations
- **Code Surface**: Generated programs

### The Inversion
Extract a pattern from a set of triples, then **inhabit** it:
- Wear someone else's mesh
- Feel their gravity wells, tension bridges, anchors
- Learn what they couldn't hold
- Return with traces

## Files

| File | Description |
|------|-------------|
| `canonical_mesh_system.js` | Core mesh, triple, vector, rule engine |
| `synthia_mesh_bridge.js` | Bridge between OS and mesh |
| `generative_output_engine.js` | Game/app/story/code generators |
| `synthia_os_unified.html` | Complete working system (all-in-one) |

## Usage

### Basic Mesh Operations
```javascript
const mesh = new Mesh({ dimensions: 5 });

// Assert triples
mesh.assert('USER', 'LOVES', 'MORNING', { value: 3 });
mesh.assert('USER', 'AVOIDS', 'CONFLICT', { value: -2, h: 1 });

// Query
const loves = mesh.query({ subject: 'USER', relation: 'LOVES' });

// Spatial query
const near = mesh.queryRadius(new Vector(3, [0,0,0]), 10);

// Step physics
mesh.stepPhysics();
```

### Generative Output
```javascript
const engine = new GenerativeOutputEngine(mesh, rules);

// Generate a game
const game = engine.generate('roguelike', pattern, {
    title: 'My Dungeon',
    difficulty: 'hard'
});

// Generate an app
const app = engine.generate('dashboard', pattern, {
    title: 'My Dashboard'
});

// Generate a story
const story = engine.generate('murder_mystery', pattern, {
    title: 'The Mesh Murder'
});
```

### Pattern Inhabitation
```javascript
const inversion = new Inversion(mesh);

// Extract someone's pattern
const pattern = inversion.extractPattern(theirTriples);

// Inhabit it
const session = inversion.inhabit('ME', pattern);

// Move through their mesh
// Feel their gravity wells
// Pay their tolls

// Exit with traces
const traces = inversion.exit('ME');
```

## Human Design Integration

The system includes:
- 64 gates with angular positions
- 36 channels (partner gate pairs)
- 5 circuits (Understanding, Knowing, Sensing, Ego, Integration)
- 9 centers (Head, Ajna, Throat, G, Heart, Sacral, Solar Plexus, Root, Spleen)
- Real-time theta rotation (Movement, Evolution, Being, Design, Space)
- Gate activation based on Being vector

## I Ching Integration

- 64 hexagrams from trigram combinations
- Yarrow stalk casting algorithm
- Changing line detection
- Hexagram transformation

## The MESSY Connection

This system extends Sheldon Klein's MESSY (1973):
- Semantic triples with timestamps
- Probabilistic rule evaluation
- Natural language generation from state
- Self-modifying rule sets
- Grammar synthesis from examples

But adds:
- Spatial geometry (the mesh)
- Multi-surface projection
- Neural embeddings
- Code generation
- Pattern inhabitation

## License

This is a research/art project. Use freely, attribute if you build on it.
