// ═══════════════════════════════════════════════════════════════════
//  AUTO-PARAPHRASER DEMO (Klein, 1965)
// ═══════════════════════════════════════════════════════════════════

import { useState } from 'react';
import { paraphraser } from '@/systems/paraphraser';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RefreshCw, FileText, Code2, Sparkles } from 'lucide-react';

type Mode = 'essay' | 'simplify' | 'explain-code' | 'expand' | 'summarize';

export function ParaphraserDemo() {
  const [mode, setMode] = useState<Mode>('simplify');
  const [input, setInput] = useState(
    'The quick brown fox jumps over the lazy dog. This pangram sentence contains every letter of the English alphabet at least once, making it a useful tool for testing fonts and keyboard layouts.'
  );
  const [output, setOutput] = useState<any>(null);
  const [codeLevel, setCodeLevel] = useState<'beginner' | 'intermediate' | 'advanced'>('beginner');
  const [loading, setLoading] = useState(false);

  const process = () => {
    setLoading(true);
    setTimeout(() => {
      try {
        if (mode === 'explain-code') {
          const result = paraphraser.explainCode(input, codeLevel);
          setOutput({ type: 'code-explanation', content: result });
        } else {
          const result = paraphraser.paraphrase(input, {
            mode,
            readingLevel: mode === 'simplify' ? 'elementary' : 'highSchool',
            format: 'paragraph',
            preserveTone: true
          });
          setOutput({ type: 'paraphrase', content: result });
        }
      } catch (e) {
        setOutput({ type: 'error', content: String(e) });
      }
      setLoading(false);
    }, 400);
  };

  const modes: { id: Mode; label: string; icon: typeof FileText; description: string }[] = [
    { id: 'essay', label: 'Essay', icon: FileText, description: 'Generate essay-format paraphrase' },
    { id: 'simplify', label: 'Simplify', icon: RefreshCw, description: 'Reduce reading level' },
    { id: 'explain-code', label: 'Explain Code', icon: Code2, description: 'Explain code at chosen level' },
    { id: 'expand', label: 'Expand', icon: FileText, description: 'Add detail and depth' },
    { id: 'summarize', label: 'Summarize', icon: FileText, description: 'Condense to key points' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-blue-500/10 border border-blue-500/30">
          <RefreshCw className="w-5 h-5 text-blue-400" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-blue-400">Auto-Paraphraser (1965)</h2>
          <p className="text-sm text-slate-400">Essay-format paraphrasing with dependency analysis — now with code explanation</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
        {modes.map((m) => (
          <button
            key={m.id}
            onClick={() => setMode(m.id)}
            className={`p-2 rounded-lg border text-xs text-left transition-all ${
              mode === m.id 
                ? 'bg-blue-500/20 border-blue-500/50 text-blue-400' 
                : 'bg-white/5 border-white/10 text-slate-400 hover:bg-white/10'
            }`}
          >
            <m.icon className="w-3 h-3 mb-1" />
            <div className="font-medium">{m.label}</div>
          </button>
        ))}
      </div>

      <Card className="bg-black/30 border-white/10">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-white">Input</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="bg-white/5 border-white/10 text-white placeholder:text-slate-600 min-h-[120px] font-mono text-sm"
          />
          
          {mode === 'explain-code' && (
            <div>
              <label className="text-xs text-slate-400 mb-1 block">Explanation Level</label>
              <Select value={codeLevel} onValueChange={(v) => setCodeLevel(v as any)}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="beginner">Beginner (line-by-line)</SelectItem>
                  <SelectItem value="intermediate">Intermediate (architectural)</SelectItem>
                  <SelectItem value="advanced">Advanced (complexity + patterns)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          <Button 
            onClick={process} 
            disabled={loading}
            className="bg-blue-500 hover:bg-blue-600 text-white w-full"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            {loading ? 'Processing...' : mode === 'explain-code' ? 'Explain Code' : 'Paraphrase'}
          </Button>
        </CardContent>
      </Card>

      {output && output.type === 'paraphrase' && (
        <Card className="bg-black/30 border-white/10">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-white">Paraphrase Result</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
              <p className="text-sm text-slate-300 leading-relaxed">{output.content.paraphrase}</p>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white/5 rounded-lg p-3">
                <div className="text-xs text-slate-500 mb-1">Reading Level</div>
                <div className="text-sm text-blue-400 font-mono">{output.content.readingLevel.toFixed(1)}</div>
              </div>
              <div className="bg-white/5 rounded-lg p-3">
                <div className="text-xs text-slate-500 mb-1">Dependencies Found</div>
                <div className="text-sm text-blue-400 font-mono">{output.content.dependencies.length}</div>
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-500 mb-2">Outline</div>
              <div className="space-y-1">
                {output.content.outline.map((item: string, i: number) => (
                  <div key={i} className="text-xs text-slate-400 pl-2 border-l border-blue-500/30">
                    {item}
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {output && output.type === 'code-explanation' && (
        <Card className="bg-black/30 border-white/10">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-white">Code Explanation ({codeLevel})</CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="bg-black/50 rounded-lg p-4 text-sm text-green-400 overflow-x-auto whitespace-pre-wrap font-mono leading-relaxed">
              {output.content}
            </pre>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
