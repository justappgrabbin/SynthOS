// ═══════════════════════════════════════════════════════════════════
//  NOVEL WRITER DEMO (Klein, 1973)
// ═══════════════════════════════════════════════════════════════════

import { useState } from 'react';
import { novelWriter } from '@/systems/novel-writer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { BookOpen, Code2, Gamepad2, Film, Sparkles, Terminal } from 'lucide-react';

type Mode = 'story' | 'code' | 'game' | 'video-script';

export function NovelWriterDemo() {
  const [mode, setMode] = useState<Mode>('story');
  const [genre, setGenre] = useState('murder-mystery');
  const [complexity, setComplexity] = useState<'simple' | 'medium' | 'complex'>('medium');
  const [output, setOutput] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [customInput, setCustomInput] = useState('');

  const generate = () => {
    setLoading(true);
    setTimeout(() => {
      try {
        let result = '';
        
        switch (mode) {
          case 'story': {
            const chapters = novelWriter.generate({
              genre: genre as any,
              length: 'short',
              characters: 4,
              style: 'classic',
              modernMode: 'story'
            });
            result = chapters.map(ch => 
              `## ${ch.title}\n${ch.nodes.map(n => n.content).join('\n\n')}`
            ).join('\n\n---\n\n');
            break;
          }
          case 'code': {
            const code = novelWriter.generateCodeNarrative('javascript', complexity);
            result = code;
            break;
          }
          case 'game': {
            const game = novelWriter.generateGameConcept(genre);
            result = `## ${game.title}\n\n### Core Mechanics\n${game.mechanics.map(m => `- ${m}`).join('\n')}\n\n### Story\n${game.story}`;
            break;
          }
          case 'video-script': {
            const script = novelWriter.generateVideoScript('cinematic');
            result = `## Video Script\n\n### Scenes\n${script.scenes.map(s => `\`${s}\``).join('\n')}\n\n### Dialogue\n${script.dialogue.map(d => `> ${d}`).join('\n\n')}\n\n### Camera Shots\n${script.shots.map(s => `- ${s}`).join('\n')}`;
            break;
          }
        }
        
        setOutput(result);
      } catch (e) {
        setOutput(`Error: ${String(e)}`);
      }
      setLoading(false);
    }, 500);
  };

  const modes: { id: Mode; label: string; icon: typeof BookOpen; description: string }[] = [
    { id: 'story', label: 'Story', icon: BookOpen, description: 'Generate narrative fiction' },
    { id: 'code', label: 'Code', icon: Code2, description: 'Generate code with narrative' },
    { id: 'game', label: 'Game', icon: Gamepad2, description: 'Design game concepts' },
    { id: 'video-script', label: 'Video', icon: Film, description: 'Write video scripts' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-purple-500/10 border border-purple-500/30">
          <BookOpen className="w-5 h-5 text-purple-400" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-purple-400">Novel Writer (1973)</h2>
          <p className="text-sm text-slate-400">The first computer program to generate stories — now with code, game, and video capabilities</p>
        </div>
      </div>

      {/* Mode Selection */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {modes.map((m) => (
          <button
            key={m.id}
            onClick={() => setMode(m.id)}
            className={`p-3 rounded-lg border text-left transition-all ${
              mode === m.id 
                ? 'bg-purple-500/20 border-purple-500/50 text-purple-400' 
                : 'bg-white/5 border-white/10 text-slate-400 hover:bg-white/10'
            }`}
          >
            <m.icon className="w-4 h-4 mb-1" />
            <div className="text-sm font-medium">{m.label}</div>
            <div className="text-xs opacity-70">{m.description}</div>
          </button>
        ))}
      </div>

      {/* Controls */}
      <Card className="bg-black/30 border-white/10">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-white flex items-center gap-2">
            <Terminal className="w-4 h-4 text-purple-400" />
            Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {(mode === 'story' || mode === 'game') && (
              <div>
                <label className="text-xs text-slate-400 mb-1 block">Genre</label>
                <Select value={genre} onValueChange={setGenre}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="murder-mystery">Murder Mystery</SelectItem>
                    <SelectItem value="sci-fi">Science Fiction</SelectItem>
                    <SelectItem value="romance">Romance</SelectItem>
                    <SelectItem value="adventure">Adventure</SelectItem>
                    <SelectItem value="noir">Film Noir</SelectItem>
                    <SelectItem value="rpg">RPG</SelectItem>
                    <SelectItem value="fps">FPS</SelectItem>
                    <SelectItem value="puzzle">Puzzle</SelectItem>
                    <SelectItem value="strategy">Strategy</SelectItem>
                    <SelectItem value="roguelike">Roguelike</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            
            {mode === 'code' && (
              <div>
                <label className="text-xs text-slate-400 mb-1 block">Complexity</label>
                <Select value={complexity} onValueChange={(v) => setComplexity(v as any)}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="simple">Simple</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="complex">Complex</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <div>
            <label className="text-xs text-slate-400 mb-1 block">Custom Context (optional)</label>
            <Textarea 
              value={customInput}
              onChange={(e) => setCustomInput(e.target.value)}
              placeholder="Enter custom context, characters, or requirements..."
              className="bg-white/5 border-white/10 text-white placeholder:text-slate-600 min-h-[80px]"
            />
          </div>

          <Button 
            onClick={generate} 
            disabled={loading}
            className="bg-purple-500 hover:bg-purple-600 text-white w-full"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            {loading ? 'Generating...' : 'Generate'}
          </Button>
        </CardContent>
      </Card>

      {/* Output */}
      {output && (
        <Card className="bg-black/30 border-white/10">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-white flex items-center justify-between">
              <span className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-purple-400" />
                Generated Output
              </span>
              <span className="text-xs text-slate-500 font-mono">{output.split(' ').length} words</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="bg-black/50 rounded-lg p-4 text-sm text-slate-300 overflow-x-auto whitespace-pre-wrap font-mono leading-relaxed">
              {output}
            </pre>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
