// ═══════════════════════════════════════════════════════════════════
//  STYLE CONTROLLER DEMO (Klein, 1965)
// ═══════════════════════════════════════════════════════════════════

import { useState } from 'react';
import { styleController } from '@/systems/style-controller';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Palette, Sparkles, BarChart3 } from 'lucide-react';

const PROFILES = [
  { id: 'formal', name: 'Academic Formal', desc: 'Precise, objective, hedged', color: 'text-amber-400' },
  { id: 'casual', name: 'Conversational', desc: 'Relaxed, personal, simple', color: 'text-green-400' },
  { id: 'poetic', name: 'Poetic/Lyrical', desc: 'Evocative, metaphorical', color: 'text-pink-400' },
  { id: 'noir', name: 'Film Noir', desc: 'Hard-boiled, terse, cynical', color: 'text-gray-400' },
  { id: 'code', name: 'Clean Code', desc: 'Documented, typed, handled', color: 'text-cyan-400' },
  { id: 'game-design', name: 'Game Design Doc', desc: 'Mechanics-focused, quantitative', color: 'text-orange-400' },
];

const CODE_PROFILES = [
  { id: 'imperative', name: 'Imperative', desc: 'Loops, conditionals, mutable state' },
  { id: 'functional', name: 'Functional', desc: 'Pure functions, immutability, composition' },
  { id: 'oop', name: 'Object-Oriented', desc: 'Classes, inheritance, encapsulation' },
];

export function StyleControllerDemo() {
  const [text, setText] = useState(
    'The system processes input data efficiently. It uses advanced algorithms to analyze patterns and generate meaningful results. Users can interact with the interface to customize their experience.'
  );
  const [selectedProfile, setSelectedProfile] = useState('formal');
  const [output, setOutput] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  
  const [codeText, setCodeText] = useState(`function processData(data) {\n  let result = [];\n  for (let i = 0; i < data.length; i++) {\n    if (data[i].active) {\n      result.push(transform(data[i]));\n    }\n  }\n  return result;\n}`);
  const [fromParadigm, setFromParadigm] = useState('imperative');
  const [toParadigm, setToParadigm] = useState('functional');
  const [codeOutput, setCodeOutput] = useState('');

  const transform = () => {
    setLoading(true);
    setTimeout(() => {
      const result = styleController.transform(text, selectedProfile);
      setOutput(result);
      setLoading(false);
    }, 300);
  };

  const transformCode = () => {
    const result = styleController.transformCodeStyle(codeText, fromParadigm, toParadigm);
    setCodeOutput(result);
  };

  const metrics = output ? styleController.analyzeStyle(output.transformed) : null;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-pink-500/10 border border-pink-500/30">
          <Palette className="w-5 h-5 text-pink-400" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-pink-400">Style Controller (1965)</h2>
          <p className="text-sm text-slate-400">Control style through grammar rule frequency — now with code paradigm transformation</p>
        </div>
      </div>

      {/* Text Style Transformation */}
      <Card className="bg-black/30 border-white/10">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-white">Text Style Transformation</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea 
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="bg-white/5 border-white/10 text-white min-h-[80px]"
          />
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {PROFILES.map((p) => (
              <button
                key={p.id}
                onClick={() => setSelectedProfile(p.id)}
                className={`p-2 rounded-lg border text-left transition-all ${
                  selectedProfile === p.id 
                    ? 'bg-pink-500/20 border-pink-500/50' 
                    : 'bg-white/5 border-white/10 hover:bg-white/10'
                }`}
              >
                <div className={`text-sm font-medium ${selectedProfile === p.id ? p.color : 'text-slate-300'}`}>
                  {p.name}
                </div>
                <div className="text-xs text-slate-500">{p.desc}</div>
              </button>
            ))}
          </div>

          <Button 
            onClick={transform} 
            disabled={loading}
            className="bg-pink-500 hover:bg-pink-600 text-white w-full"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Transform Style
          </Button>
        </CardContent>
      </Card>

      {output && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="bg-black/30 border-white/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-slate-400">Original</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-slate-300">{output.original}</p>
            </CardContent>
          </Card>
          <Card className="bg-black/30 border-pink-500/20">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-pink-400">Transformed ({PROFILES.find(p => p.id === selectedProfile)?.name})</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-slate-200">{output.transformed}</p>
            </CardContent>
          </Card>
        </div>
      )}

      {metrics && (
        <Card className="bg-black/30 border-white/10">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-white flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-pink-400" />
              Style Metrics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              {Object.entries(metrics).map(([key, value]) => (
                <div key={key} className="bg-white/5 rounded-lg p-3">
                  <div className="text-xs text-slate-500 mb-1">{key.replace(/([A-Z])/g, ' $1').trim()}</div>
                  <div className="text-lg font-mono text-pink-400">{typeof value === 'number' ? value.toFixed(3) : value}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Code Paradigm Transformation */}
      <Card className="bg-black/30 border-white/10">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-white">Code Paradigm Transformation</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea 
            value={codeText}
            onChange={(e) => setCodeText(e.target.value)}
            className="bg-black/50 border-white/10 text-green-400 font-mono text-sm min-h-[140px]"
          />
          
          <div className="flex items-center gap-3">
            <div className="flex-1">
              <label className="text-xs text-slate-400 mb-1 block">From</label>
              <div className="grid grid-cols-3 gap-1">
                {CODE_PROFILES.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setFromParadigm(p.id)}
                    className={`px-2 py-1 rounded text-xs ${
                      fromParadigm === p.id 
                        ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30' 
                        : 'bg-white/5 text-slate-400 border border-white/10'
                    }`}
                  >
                    {p.name}
                  </button>
                ))}
              </div>
            </div>
            <div className="text-slate-500">→</div>
            <div className="flex-1">
              <label className="text-xs text-slate-400 mb-1 block">To</label>
              <div className="grid grid-cols-3 gap-1">
                {CODE_PROFILES.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setToParadigm(p.id)}
                    className={`px-2 py-1 rounded text-xs ${
                      toParadigm === p.id 
                        ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30' 
                        : 'bg-white/5 text-slate-400 border border-white/10'
                    }`}
                  >
                    {p.name}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <Button 
            onClick={transformCode}
            className="bg-cyan-500 hover:bg-cyan-600 text-white w-full"
          >
            Transform Paradigm
          </Button>

          {codeOutput && (
            <pre className="bg-black/50 rounded-lg p-4 text-sm text-green-400 font-mono overflow-x-auto whitespace-pre-wrap">
              {codeOutput}
            </pre>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
