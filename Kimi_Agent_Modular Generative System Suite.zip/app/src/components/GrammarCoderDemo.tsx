// ═══════════════════════════════════════════════════════════════════
//  GRAMMAR CODER DEMO (Klein & Simmons, 1963)
// ═══════════════════════════════════════════════════════════════════

import { useState } from 'react';
import { grammarCoder } from '@/systems/grammar-coder';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Code2, TreePine, BarChart3, Sparkles } from 'lucide-react';

export function GrammarCoderDemo() {
  const [text, setText] = useState(
    'The quick brown fox jumps over the lazy dog. A pangram contains every letter.'
  );
  const [code, setCode] = useState(`function calculateSum(numbers) {
  let total = 0;
  for (const num of numbers) {
    total += num;
  }
  return total;
}`);
  const [output, setOutput] = useState<any>(null);
  const [complexityMetrics, setComplexityMetrics] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('text');

  const analyzeText = () => {
    const result = grammarCoder.code(text);
    setOutput(result);
  };

  const analyzeCode = () => {
    const result = grammarCoder.code(code);
    setOutput(result);
    const metrics = grammarCoder.calculateComplexity(code);
    setComplexityMetrics(metrics);
  };

  const posColors: Record<string, string> = {
    'DET': 'text-amber-400 bg-amber-500/10',
    'N': 'text-blue-400 bg-blue-500/10',
    'V': 'text-green-400 bg-green-500/10',
    'ADJ': 'text-pink-400 bg-pink-500/10',
    'ADV': 'text-cyan-400 bg-cyan-500/10',
    'PREP': 'text-purple-400 bg-purple-500/10',
    'PRON': 'text-orange-400 bg-orange-500/10',
    'CONJ': 'text-red-400 bg-red-500/10',
    'AUX': 'text-teal-400 bg-teal-500/10',
    'KEYWORD': 'text-violet-400 bg-violet-500/10',
    'IDENTIFIER': 'text-sky-400 bg-sky-500/10',
    'LITERAL': 'text-emerald-400 bg-emerald-500/10',
    'OPERATOR': 'text-rose-400 bg-rose-500/10',
    'COMMENT': 'text-slate-500 bg-slate-500/10',
    'TYPE': 'text-indigo-400 bg-indigo-500/10',
    'UNK': 'text-gray-400 bg-gray-500/10',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-violet-500/10 border border-violet-500/30">
          <Code2 className="w-5 h-5 text-violet-400" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-violet-400">Grammar Coder (1963)</h2>
          <p className="text-sm text-slate-400">Computational grammatical coding — now with code structure analysis</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-black/30 border border-white/10">
          <TabsTrigger value="text" className="data-[state=active]:bg-violet-500/20 data-[state=active]:text-violet-400">
            Text Analysis
          </TabsTrigger>
          <TabsTrigger value="code" className="data-[state=active]:bg-violet-500/20 data-[state=active]:text-violet-400">
            Code Analysis
          </TabsTrigger>
        </TabsList>

        <TabsContent value="text" className="space-y-4 mt-4">
          <Card className="bg-black/30 border-white/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-white">Input Text</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea 
                value={text}
                onChange={(e) => setText(e.target.value)}
                className="bg-white/5 border-white/10 text-white min-h-[80px]"
              />
              <Button 
                onClick={analyzeText}
                className="bg-violet-500 hover:bg-violet-600 text-white w-full"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Analyze Grammar
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="code" className="space-y-4 mt-4">
          <Card className="bg-black/30 border-white/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-white">Input Code</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea 
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="bg-black/50 border-white/10 text-green-400 font-mono text-sm min-h-[150px]"
              />
              <Button 
                onClick={analyzeCode}
                className="bg-violet-500 hover:bg-violet-600 text-white w-full"
              >
                <Code2 className="w-4 h-4 mr-2" />
                Analyze Code Structure
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {output && (
        <div className="space-y-4">
          {/* Coded Words */}
          <Card className="bg-black/30 border-white/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-white flex items-center gap-2">
                <Code2 className="w-4 h-4 text-violet-400" />
                Tokenized Output
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-1">
                {output.codedWords.slice(0, 30).map((cw: any, i: number) => (
                  <div 
                    key={i} 
                    className={`px-2 py-1 rounded text-xs font-mono ${posColors[cw.pos] || 'text-slate-400'}`}
                    title={`${cw.token} → ${cw.pos} (${JSON.stringify(cw.features)})`}
                  >
                    {cw.token}
                    <span className="opacity-60 ml-1">[{cw.pos}]</span>
                  </div>
                ))}
                {output.codedWords.length > 30 && (
                  <div className="text-xs text-slate-600 px-2 py-1">
                    +{output.codedWords.length - 30} more
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Parse Tree */}
          <Card className="bg-black/30 border-white/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-white flex items-center gap-2">
                <TreePine className="w-4 h-4 text-violet-400" />
                Parse Tree (Depth: {output.parseTree.depth})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-black/50 rounded-lg p-4 font-mono text-sm">
                <div className="text-violet-400 mb-2">Root: {output.parseTree.root}</div>
                <div className="space-y-1">
                  {output.parseTree.nodes.slice(0, 15).map((node: any) => (
                    <div key={node.id} className="flex items-center gap-2 text-slate-400">
                      <span className="text-slate-600">{node.id}</span>
                      <span>{node.label}</span>
                      {node.children.length > 0 && (
                        <span className="text-xs text-slate-600">({node.children.length} children)</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Structural Pattern */}
          <Card className="bg-black/30 border-violet-500/20">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-violet-400">Structural Pattern</CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="text-sm text-slate-300 font-mono">{output.structuralPattern}</pre>
            </CardContent>
          </Card>

          {/* Complexity Metrics */}
          {complexityMetrics && (
            <Card className="bg-black/30 border-white/10">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-white flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-violet-400" />
                  Code Complexity Metrics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {Object.entries(complexityMetrics).map(([key, value]) => (
                    <div key={key} className="bg-white/5 rounded-lg p-3">
                      <div className="text-xs text-slate-500 mb-1">
                        {key.replace(/([A-Z])/g, ' $1').trim()}
                      </div>
                      <div className="text-lg font-mono text-violet-400">
                        {typeof value === 'number' ? value.toFixed(1) : String(value)}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
