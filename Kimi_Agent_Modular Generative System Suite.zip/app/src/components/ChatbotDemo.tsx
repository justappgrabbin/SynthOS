// ═══════════════════════════════════════════════════════════════════
//  KLEIN CHATBOT DEMO
// ═══════════════════════════════════════════════════════════════════

import { useState, useRef, useEffect } from 'react';
import { chatbot } from '@/systems/chatbot';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { MessageSquare, Send, User, Bot, Sparkles, BookOpen, Code2, Brain, HelpCircle } from 'lucide-react';

type Msg = { role: 'user' | 'assistant'; content: string; systemUsed?: string };

const QUICK_COMMANDS = [
  { label: 'Write a story', command: 'Write me a murder mystery story', icon: BookOpen },
  { label: 'Generate code', command: 'Write code for a sorting algorithm', icon: Code2 },
  { label: 'Explain code', command: 'Explain this code: function fib(n) { return n <= 1 ? n : fib(n-1) + fib(n-2); }', icon: Code2 },
  { label: 'Analyze semantics', command: 'What is the relationship between recursion and iteration?', icon: Brain },
  { label: 'Help', command: 'help', icon: HelpCircle },
];

export function ChatbotDemo() {
  const [messages, setMessages] = useState<Msg[]>([
    { role: 'assistant', content: chatbot.getGreeting() }
  ]);
  const [input, setInput] = useState('');
  const [personality, setPersonality] = useState('helpful');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    
    const userMsg: Msg = { role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const response = await chatbot.processMessage(userMsg.content);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: response.content,
        systemUsed: response.metadata?.systemUsed
      }]);
    } catch (e) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `Error: ${String(e)}`
      }]);
    }
    setLoading(false);
  };

  const handlePersonalityChange = (p: string) => {
    setPersonality(p);
    chatbot.setPersonality(p);
    const personalities = chatbot.getPersonalities();
    const selected = personalities.find(per => per.key === p);
    if (selected) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `[Switched to ${selected.name} personality]\n\n${selected.greeting}`
      }]);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-teal-500/10 border border-teal-500/30">
          <MessageSquare className="w-5 h-5 text-teal-400" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-teal-400">Klein Chatbot</h2>
          <p className="text-sm text-slate-400">Conversational interface to all 8 Klein frameworks</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Sidebar */}
        <div className="lg:col-span-1 space-y-4">
          <Card className="bg-black/30 border-white/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-xs text-white">Personality</CardTitle>
            </CardHeader>
            <CardContent>
              <Select value={personality} onValueChange={handlePersonalityChange}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="helpful">Klein Assistant</SelectItem>
                  <SelectItem value="technical">Klein Engineer</SelectItem>
                  <SelectItem value="creative">Klein Creator</SelectItem>
                  <SelectItem value="analytical">Klein Analyst</SelectItem>
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          <Card className="bg-black/30 border-white/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-xs text-white">Quick Commands</CardTitle>
            </CardHeader>
            <CardContent className="space-y-1.5">
              {QUICK_COMMANDS.map((cmd) => (
                <button
                  key={cmd.label}
                  onClick={() => { setInput(cmd.command); }}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-left text-xs text-slate-300 hover:text-white transition-all"
                >
                  <cmd.icon className="w-3 h-3 text-teal-400" />
                  {cmd.label}
                </button>
              ))}
            </CardContent>
          </Card>

          <Card className="bg-black/30 border-white/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-xs text-white">System Access</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-1.5 text-xs">
                {[
                  { name: 'Novel Writer', color: 'text-purple-400' },
                  { name: 'Paraphraser', color: 'text-blue-400' },
                  { name: 'Style Ctrl', color: 'text-pink-400' },
                  { name: 'DISEMINER', color: 'text-cyan-400' },
                  { name: 'AUTOLING', color: 'text-green-400' },
                  { name: 'Simulator', color: 'text-red-400' },
                  { name: 'Grammar Coder', color: 'text-violet-400' },
                  { name: 'Network', color: 'text-indigo-400' },
                ].map((sys) => (
                  <div key={sys.name} className="flex items-center gap-1.5 text-slate-400">
                    <div className={`w-1.5 h-1.5 rounded-full ${sys.color.replace('text-', 'bg-')}`} />
                    {sys.name}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Chat Area */}
        <div className="lg:col-span-3">
          <Card className="bg-black/30 border-white/10 h-[600px] flex flex-col">
            <CardHeader className="pb-3 border-b border-white/10 shrink-0">
              <CardTitle className="text-sm text-white flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Bot className="w-4 h-4 text-teal-400" />
                  Klein Chat
                </span>
                {loading && (
                  <span className="flex items-center gap-1 text-xs text-teal-400">
                    <Sparkles className="w-3 h-3 animate-spin" />
                    Processing...
                  </span>
                )}
              </CardTitle>
            </CardHeader>
            
            <CardContent className="flex-1 flex flex-col p-0 overflow-hidden">
              <div 
                ref={scrollRef}
                className="flex-1 overflow-y-auto p-4 space-y-4"
              >
                {messages.map((msg, i) => (
                  <div key={i} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    {msg.role === 'assistant' && (
                      <div className="w-7 h-7 rounded-lg bg-teal-500/20 flex items-center justify-center shrink-0 mt-0.5">
                        <Bot className="w-4 h-4 text-teal-400" />
                      </div>
                    )}
                    <div className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${
                      msg.role === 'user'
                        ? 'bg-teal-500/20 text-teal-100'
                        : 'bg-white/5 text-slate-300'
                    }`}>
                      <pre className="whitespace-pre-wrap font-sans leading-relaxed">{msg.content}</pre>
                      {msg.systemUsed && (
                        <div className="mt-1 pt-1 border-t border-white/10">
                          <span className="text-xs text-teal-500/70">
                            via {msg.systemUsed}
                          </span>
                        </div>
                      )}
                    </div>
                    {msg.role === 'user' && (
                      <div className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center shrink-0 mt-0.5">
                        <User className="w-4 h-4 text-slate-400" />
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <div className="p-3 border-t border-white/10 shrink-0">
                <div className="flex gap-2">
                  <Textarea 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        sendMessage();
                      }
                    }}
                    placeholder="Ask anything... (try 'help' for commands)"
                    className="bg-white/5 border-white/10 text-white min-h-[44px] max-h-[120px] resize-none"
                  />
                  <Button 
                    onClick={sendMessage}
                    disabled={loading || !input.trim()}
                    className="bg-teal-500 hover:bg-teal-600 text-white px-4"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
