// ═══════════════════════════════════════════════════════════════════
//  DISEMINER DEMO (Klein, 1968)
// ═══════════════════════════════════════════════════════════════════

import { useState } from 'react';
import { diseminer } from '@/systems/diseminer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Brain, Search, Code2, Lightbulb } from 'lucide-react';

type Mode = 'semantic' | 'code' | 'complete';

export function DiseminerDemo() {
  const [mode, setMode] = useState<Mode>('semantic');
  const [input, setInput] = useState('What is the relationship between functions and classes in programming?');
  const [output, setOutput] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const analyze = () => {
    setLoading(true);
    setTimeout(() => {
      try {
        let result;
        switch (mode) {
          case 'semantic':
            result = diseminer.answerQuestion(input);
            break;
          case 'code':
            result = diseminer.analyzeCodeSemantics(input);
            break;
          case 'complete':
            result = diseminer.suggestCompletion(input, input);
            break;
        }
        setOutput(result);
      } catch (e) {
        setOutput({ error: String(e) });
      }
      setLoading(false);
    }, 400);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/30">
          <Brain className="w-5 h-5 text-cyan-400" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-cyan-400">DISEMINER (1968)</h2>
          <p className="text-sm text-slate-400">Distributional-Semantics Inference Maker — now with code analysis</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        {[
          { id: 'semantic' as Mode, label: 'Semantic QA', icon: Search },
          { id: 'code' as Mode, label: 'Code Analysis', icon: Code2 },
          { id: 'complete' as Mode, label: 'Completion', icon: Lightbulb },
        ].map((m) => (
          <button
            key={m.id}
            onClick={() => setMode(m.id)}
            className={`p-2 rounded-lg border text-xs text-center transition-all ${
              mode === m.id 
                ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-400' 
                : 'bg-white/5 border-white/10 text-slate-400 hover:bg-white/10'
            }`}
          >
            <m.icon className="w-3 h-3 mx-auto mb-1" />
            <div className="font-medium">{m.label}</div>
          </button>
        ))}
      </div>

      <Card className="bg-black/30 border-white/10">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-white">
            {mode === 'semantic' ? 'Ask a Question' : mode === 'code' ? 'Enter Code' : 'Partial Input'}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={mode === 'semantic' ? 'Ask about meaning...' : mode === 'code' ? 'Paste code...' : 'Type partial word...'}
            className="bg-white/5 border-white/10 text-white min-h-[100px] font-mono text-sm"
          />
          <Button 
            onClick={analyze} 
            disabled={loading}
            className="bg-cyan-500 hover:bg-cyan-600 text-white w-full"
          >
            <Brain className="w-4 h-4 mr-2" />
            {loading ? 'Analyzing...' : mode === 'complete' ? 'Suggest Completions' : 'Analyze'}
          </Button>
        </CardContent>
      </Card>

      {output && !output.error && (
        <Card className="bg-black/30 border-cyan-500/20">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-cyan-400">Analysis Result</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {'answer' in output && (
              <div className="bg-cyan-500/10 rounded-lg p-4">
                <p className="text-sm text-slate-200 leading-relaxed">{output.answer}</p>
              </div>
            )}
            
            {'confidence' in output && (
              <div className="flex items-center gap-3">
                <div className="text-xs text-slate-500">Confidence</div>
                <div className="flex-1 bg-white/10 rounded-full h-2">
                  <div 
                    className="bg-cyan-400 h-2 rounded-full transition-all"
                    style={{ width: `${(output.confidence as number) * 100}%` }}
                  />
                </div>
                <div className="text-xs text-cyan-400 font-mono">
                  {((output.confidence as number) * 100).toFixed(1)}%
                </div>
              </div>
            )}

            {'inferenceChain' in output && (output.inferenceChain as string[]).length > 0 && (
              <div>
                <div className="text-xs text-slate-500 mb-2">Inference Chain</div>
                <div className="space-y-1">
                  {(output.inferenceChain as string[]).slice(0, 8).map((step: string, i: number) => (
                    <div key={i} className="text-xs text-slate-400 pl-2 border-l border-cyan-500/30">
                      {step}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {'evidence' in output && (output.evidence as any[]).length > 0 && (
              <div>
                <div className="text-xs text-slate-500 mb-2">Evidence</div>
                <div className="grid grid-cols-2 gap-2">
                  {(output.evidence as any[]).slice(0, 6).map((ev, i) => (
                    <div key={i} className="bg-white/5 rounded p-2">
                      <div className="text-xs font-medium text-cyan-400">{ev.stem}</div>
                      <div className="text-xs text-slate-500">{ev.class}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {Array.isArray(output) && (
              <div className="space-y-1">
                {output.map((suggestion, i) => (
                  <div key={i} className="bg-white/5 rounded p-2 text-sm text-cyan-400 font-mono">
                    {suggestion}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
