// ═══════════════════════════════════════════════════════════════════
//  KLEIN NETWORK DEMO - Neural Connector
// ═══════════════════════════════════════════════════════════════════

import { useState } from 'react';
import { kleinNetwork } from '@/systems/klein-network';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Network, Activity, Zap, ArrowRight, Circle } from 'lucide-react';

const NODE_POSITIONS: Record<string, { x: number; y: number; color: string }> = {
  'novel-writer': { x: 20, y: 15, color: '#a855f7' },
  'paraphraser': { x: 50, y: 10, color: '#3b82f6' },
  'style-controller': { x: 80, y: 15, color: '#ec4899' },
  'diseminer': { x: 35, y: 40, color: '#06b6d4' },
  'autoling': { x: 65, y: 40, color: '#22c55e' },
  'simulator': { x: 15, y: 65, color: '#ef4444' },
  'grammar-coder': { x: 85, y: 65, color: '#8b5cf6' },
  'chatbot': { x: 50, y: 85, color: '#14b8a6' },
};

export function KleinNetworkDemo() {
  const [network] = useState(() => kleinNetwork.getNetwork());
  const [activeNodes, setActiveNodes] = useState<Set<string>>(new Set());
  const [activeEdges, setActiveEdges] = useState<Set<string>>(new Set());
  const [pulseNode, setPulseNode] = useState<string | null>(null);

  const simulatePulse = (nodeId: string) => {
    setPulseNode(nodeId);
    
    const newActive = new Set([nodeId]);
    const newEdges = new Set<string>();
    
    // Activate connected edges and nodes
    network.edges.forEach((edge, i) => {
      if (edge.source === nodeId) {
        newEdges.add(`${edge.source}-${edge.target}`);
        setTimeout(() => {
          newActive.add(edge.target);
          setActiveNodes(new Set(newActive));
        }, 300 + i * 50);
      }
    });
    
    setActiveEdges(newEdges);
    setActiveNodes(newActive);
    
    setTimeout(() => {
      setActiveNodes(new Set());
      setActiveEdges(new Set());
      setPulseNode(null);
    }, 2000);
  };

  const simulateQuery = () => {
    setPulseNode('chatbot');
    const newActive = new Set(['chatbot']);
    const newEdges = new Set<string>();
    
    // Chatbot activates multiple systems
    const targets = ['novel-writer', 'diseminer', 'paraphraser', 'grammar-coder'];
    targets.forEach((target, i) => {
      setTimeout(() => {
        newActive.add(target);
        newEdges.add(`chatbot-${target}`);
        setActiveNodes(new Set(newActive));
        setActiveEdges(new Set(newEdges));
      }, 200 + i * 150);
    });
    
    setActiveNodes(newActive);
    
    setTimeout(() => {
      setActiveNodes(new Set());
      setActiveEdges(new Set());
      setPulseNode(null);
    }, 3000);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-indigo-500/10 border border-indigo-500/30">
          <Network className="w-5 h-5 text-indigo-400" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-indigo-400">Klein Network</h2>
          <p className="text-sm text-slate-400">Neural network connecting all 8 Klein systems with the chatbot</p>
        </div>
      </div>

      <Card className="bg-black/30 border-white/10">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-white flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-indigo-400" />
              Network Topology
            </span>
            <div className="flex gap-2">
              <Button 
                size="sm" 
                onClick={simulateQuery}
                className="bg-indigo-500 hover:bg-indigo-600 text-white"
              >
                <Zap className="w-3 h-3 mr-1" />
                Simulate Query
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative bg-black/50 rounded-lg border border-white/10" style={{ height: '400px' }}>
            <svg className="absolute inset-0 w-full h-full">
              {/* Edges */}
              {network.edges.map((edge, i) => {
                const src = NODE_POSITIONS[edge.source];
                const tgt = NODE_POSITIONS[edge.target];
                if (!src || !tgt) return null;
                
                const isActive = activeEdges.has(`${edge.source}-${edge.target}`);
                
                return (
                  <line
                    key={i}
                    x1={`${src.x}%`}
                    y1={`${src.y}%`}
                    x2={`${tgt.x}%`}
                    y2={`${tgt.y}%`}
                    stroke={isActive ? src.color : 'rgba(255,255,255,0.08)'}
                    strokeWidth={isActive ? 2 : 1}
                    strokeDasharray={edge.type === 'feedback' ? '4,4' : edge.type === 'control' ? '2,2' : 'none'}
                    style={{ transition: 'all 0.3s ease' }}
                  />
                );
              })}
            </svg>
            
            {/* Nodes */}
            {Object.entries(NODE_POSITIONS).map(([id, pos]) => {
              const isActive = activeNodes.has(id);
              const isPulsing = pulseNode === id;
              
              return (
                <button
                  key={id}
                  onClick={() => simulatePulse(id)}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2 transition-all"
                  style={{ 
                    left: `${pos.x}%`, 
                    top: `${pos.y}%`,
                  }}
                >
                  <div 
                    className={`relative px-3 py-2 rounded-lg border text-xs font-medium whitespace-nowrap transition-all ${
                      isActive 
                        ? 'scale-110 shadow-lg' 
                        : 'hover:scale-105'
                    }`}
                    style={{
                      backgroundColor: isActive ? `${pos.color}30` : `${pos.color}15`,
                      borderColor: isActive ? pos.color : `${pos.color}40`,
                      color: pos.color,
                      boxShadow: isPulsing ? `0 0 20px ${pos.color}50` : 'none',
                    }}
                  >
                    <div className="flex items-center gap-1.5">
                      <Circle 
                        className="w-2 h-2" 
                        fill={isActive ? pos.color : 'transparent'}
                      />
                      {id.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
          
          <div className="flex items-center gap-4 mt-3 text-xs text-slate-500">
            <span className="flex items-center gap-1">
              <div className="w-4 h-px bg-white/20" /> Solid: Data
            </span>
            <span className="flex items-center gap-1">
              <div className="w-4 h-px border-t border-dashed border-white/20" /> Dashed: Control
            </span>
            <span className="flex items-center gap-1">
              <div className="w-4 h-px border-t border-dashed border-white/10" style={{ borderWidth: '2px' }} /> Dotted: Feedback
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Connection Details */}
      <Card className="bg-black/30 border-white/10">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-white">Connection Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {network.edges.slice(0, 12).map((edge, i) => (
              <div key={i} className="flex items-center gap-2 text-xs py-1 px-2 bg-white/5 rounded">
                <span className="text-slate-400">{edge.source}</span>
                <ArrowRight className="w-3 h-3 text-slate-600" />
                <span className="text-slate-400">{edge.target}</span>
                <span className="ml-auto text-slate-600">{edge.type}</span>
                <span className="text-indigo-400 font-mono">{(edge.weight * 100).toFixed(0)}%</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
