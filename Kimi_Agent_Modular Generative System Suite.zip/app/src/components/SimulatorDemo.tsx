// ═══════════════════════════════════════════════════════════════════
//  HISTORICAL CHANGE SIMULATOR DEMO (Klein, 1966)
// ═══════════════════════════════════════════════════════════════════

import { useState, useCallback, useEffect, useRef } from 'react';
import { simulator } from '@/systems/simulator';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { History, Play, Pause, RotateCcw, Activity, Users, BookOpen, TrendingUp, GitBranch } from 'lucide-react';

export function SimulatorDemo() {
  const [mode, setMode] = useState<'language' | 'code-evolution' | 'pattern-drift'>('code-evolution');
  const [running, setRunning] = useState(false);
  const [stats, setStats] = useState<any>(null);
  const [events, setEvents] = useState<any[]>([]);
  const [tick, setTick] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const step = useCallback(() => {
    const state = simulator.step();
    setStats(simulator.getStats());
    setEvents(prev => [...state.events, ...prev].slice(0, 50));
    setTick(state.tick);
  }, []);

  const toggleRun = () => {
    if (running) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      setRunning(false);
    } else {
      setRunning(true);
      intervalRef.current = setInterval(step, 200);
    }
  };

  const reset = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setRunning(false);
    // Reset simulator state
    simulator['state'] = {
      tick: 0,
      speakers: [],
      events: [],
      communityGrammar: [],
      stability: 1.0
    };
    simulator['eventLog'] = [];
    setStats(null);
    setEvents([]);
    setTick(0);
  };

  useEffect(() => {
    // Get initial stats
    setStats(simulator.getStats());
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  const eventColors: Record<string, string> = {
    'rule-adoption': 'text-blue-400',
    'rule-loss': 'text-red-400',
    'innovation': 'text-amber-400',
    'frequency-shift': 'text-green-400',
    'merge': 'text-purple-400'
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-red-500/10 border border-red-500/30">
          <History className="w-5 h-5 text-red-400" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-red-400">Historical Change Simulator (1966)</h2>
          <p className="text-sm text-slate-400">Monte Carlo simulation of language/code evolution</p>
        </div>
      </div>

      <Card className="bg-black/30 border-white/10">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-white">Simulation Parameters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div>
              <label className="text-xs text-slate-400 mb-1 block">Mode</label>
              <Select value={mode} onValueChange={(v) => setMode(v as any)}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="language">Language Evolution</SelectItem>
                  <SelectItem value="code-evolution">Code Evolution</SelectItem>
                  <SelectItem value="pattern-drift">Pattern Drift</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end gap-2">
              <Button 
                onClick={toggleRun}
                className={`${running ? 'bg-amber-500 hover:bg-amber-600' : 'bg-red-500 hover:bg-red-600'} text-white flex-1`}
              >
                {running ? <Pause className="w-4 h-4 mr-1" /> : <Play className="w-4 h-4 mr-1" />}
                {running ? 'Pause' : 'Run'}
              </Button>
              <Button 
                onClick={step}
                disabled={running}
                variant="outline"
                className="border-white/20"
              >
                <GitBranch className="w-4 h-4" />
              </Button>
              <Button 
                onClick={reset}
                variant="outline"
                className="border-white/20"
              >
                <RotateCcw className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'Tick', value: stats.tick, icon: Activity, color: 'text-red-400' },
            { label: 'Speakers', value: stats.population, icon: Users, color: 'text-blue-400' },
            { label: 'Community Rules', value: stats.communityRules, icon: BookOpen, color: 'text-green-400' },
            { label: 'Stability', value: stats.stability, icon: TrendingUp, color: 'text-amber-400' },
          ].map((stat) => (
            <Card key={stat.label} className="bg-black/30 border-white/10">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-1">
                  <stat.icon className={`w-4 h-4 ${stat.color}`} />
                  <span className="text-xs text-slate-500">{stat.label}</span>
                </div>
                <div className="text-2xl font-bold text-white font-mono">{stat.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-black/30 border-white/10">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-red-400" />
              Event Log
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] overflow-y-auto space-y-1">
              {events.length === 0 && (
                <div className="text-center text-slate-600 py-8">No events yet. Start the simulation.</div>
              )}
              {events.map((evt, i) => (
                <div key={i} className="text-xs flex items-start gap-2 py-1 border-b border-white/5">
                  <span className="text-slate-600 font-mono min-w-[40px]">T{evt.tick}</span>
                  <span className={eventColors[evt.type] || 'text-slate-400'}>
                    {evt.type}
                  </span>
                  <span className="text-slate-500 flex-1 truncate">{evt.description}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-black/30 border-white/10">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-green-400" />
              Detailed Stats
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {stats && [
              { label: 'Avg Rules/Speaker', value: stats.avgRulesPerSpeaker },
              { label: 'Avg Age', value: stats.avgAge },
              { label: 'Diversity Index', value: stats.diversity },
              { label: 'Total Events', value: stats.totalEvents },
            ].map((s) => (
              <div key={s.label} className="flex items-center justify-between py-1 border-b border-white/5">
                <span className="text-xs text-slate-400">{s.label}</span>
                <span className="text-sm font-mono text-white">{s.value}</span>
              </div>
            ))}
            
            <div className="pt-2">
              <div className="text-xs text-slate-500 mb-2">Grammar Distribution</div>
              <div className="flex gap-1">
                {Array.from({ length: 20 }, (_, i) => (
                  <div 
                    key={i}
                    className="flex-1 rounded-sm"
                    style={{
                      height: `${20 + Math.sin(i * 0.8 + tick * 0.1) * 15 + Math.random() * 10}px`,
                      backgroundColor: `hsl(${280 + i * 5}, 70%, ${40 + Math.sin(i) * 20}%)`,
                      transition: 'height 0.2s ease'
                    }}
                  />
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
