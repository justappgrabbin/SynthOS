// ═══════════════════════════════════════════════════════════════════
//  SYSTEM HUB - Landing page for all Klein systems
// ═══════════════════════════════════════════════════════════════════

import { 
  BookOpen, RefreshCw, Palette, Brain, 
  Languages, History, Code2, Network, MessageSquare,
  ArrowRight, Sparkles, Zap, Globe, GitBranch
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface SystemHubProps {
  onNavigate: (tab: string) => void;
}

const SYSTEMS = [
  {
    id: 'novel',
    title: 'Novel Writer (1973)',
    description: 'The first computer program to generate stories. Now expanded to create code, game narratives, and video scripts.',
    icon: BookOpen,
    color: 'text-purple-400',
    bgColor: 'bg-purple-500/10',
    borderColor: 'border-purple-500/30',
    features: ['Story Generation', 'Code Narratives', 'Game Concepts', 'Video Scripts'],
    year: 1973
  },
  {
    id: 'paraphrase',
    title: 'Auto-Paraphraser (1965)',
    description: 'Essay-format paraphrasing system. Now includes code explanation at multiple skill levels.',
    icon: RefreshCw,
    color: 'text-blue-400',
    bgColor: 'bg-blue-500/10',
    borderColor: 'border-blue-500/30',
    features: ['Text Paraphrasing', 'Code Explanation', 'Reading Level Adjustment', 'Summarization'],
    year: 1965
  },
  {
    id: 'style',
    title: 'Style Controller (1965)',
    description: 'Control syntactic style through grammar rule frequency manipulation. Now adapts code paradigms.',
    icon: Palette,
    color: 'text-pink-400',
    bgColor: 'bg-pink-500/10',
    borderColor: 'border-pink-500/30',
    features: ['Style Profiles', 'Tone Transformation', 'Code Paradigm Shift', 'Metrics Analysis'],
    year: 1965
  },
  {
    id: 'diseminer',
    title: 'DISEMINER (1968)',
    description: 'Distributional-Semantics Inference Maker. Now analyzes code semantics and suggests completions.',
    icon: Brain,
    color: 'text-cyan-400',
    bgColor: 'bg-cyan-500/10',
    borderColor: 'border-cyan-500/30',
    features: ['Semantic Analysis', 'Code Pattern Detection', 'Auto-Completion', 'Inference Chains'],
    year: 1968
  },
  {
    id: 'autoling',
    title: 'AUTOLING (1968)',
    description: 'Automated linguistic fieldworker. Now learns code patterns from examples interactively.',
    icon: Languages,
    color: 'text-green-400',
    bgColor: 'bg-green-500/10',
    borderColor: 'border-green-500/30',
    features: ['Pattern Learning', 'Grammar Inference', 'Code Idiom Detection', 'Interactive Learning'],
    year: 1968
  },
  {
    id: 'simulator',
    title: 'Historical Change Simulator (1966)',
    description: 'Monte Carlo simulation of language change. Now tracks code pattern evolution.',
    icon: History,
    color: 'text-red-400',
    bgColor: 'bg-red-500/10',
    borderColor: 'border-red-500/30',
    features: ['Language Evolution', 'Code Pattern Drift', 'Social Dynamics', 'Stability Metrics'],
    year: 1966
  },
  {
    id: 'grammar',
    title: 'Grammar Coder (1963)',
    description: 'Computational grammatical coding of English. Now parses and analyzes code structure.',
    icon: Code2,
    color: 'text-violet-400',
    bgColor: 'bg-violet-500/10',
    borderColor: 'border-violet-500/30',
    features: ['POS Tagging', 'Parse Trees', 'Code Tokenization', 'Complexity Metrics'],
    year: 1963
  },
  {
    id: 'network',
    title: 'Klein Network',
    description: 'Neural network connecting all systems. Routes queries and enables cross-system collaboration.',
    icon: Network,
    color: 'text-indigo-400',
    bgColor: 'bg-indigo-500/10',
    borderColor: 'border-indigo-500/30',
    features: ['System Routing', 'Cross-System Activation', 'Visual Network Map', 'Unified Interface'],
    year: 2025
  },
  {
    id: 'chatbot',
    title: 'Klein Chatbot',
    description: 'Conversational interface to all frameworks. Natural language access to every system.',
    icon: MessageSquare,
    color: 'text-teal-400',
    bgColor: 'bg-teal-500/10',
    borderColor: 'border-teal-500/30',
    features: ['Intent Recognition', 'Multi-System Queries', 'Personality Modes', 'Context Memory'],
    year: 2025
  }
];

export function SystemHub({ onNavigate }: SystemHubProps) {
  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="text-center py-8 space-y-4">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-sm mb-4">
          <Sparkles className="w-4 h-4" />
          <span>9 Integrated AI Systems</span>
          <Sparkles className="w-4 h-4" />
        </div>
        <h2 className="text-4xl font-bold text-white">
          The Complete <span className="text-amber-400">Klein</span> Framework
        </h2>
        <p className="text-lg text-slate-400 max-w-2xl mx-auto">
          Sheldon Klein pioneered computational linguistics at the University of Wisconsin 
          from 1963 to 1979. These modern implementations preserve his original architectures 
          while adding generative capabilities for code, games, apps, and video.
        </p>
        <div className="flex items-center justify-center gap-4 pt-4">
          <Button 
            onClick={() => onNavigate('chatbot')}
            className="bg-amber-500 hover:bg-amber-600 text-black font-semibold px-6"
          >
            <MessageSquare className="w-4 h-4 mr-2" />
            Try the Chatbot
          </Button>
          <Button 
            variant="outline"
            onClick={() => onNavigate('network')}
            className="border-white/20 hover:bg-white/10"
          >
            <Network className="w-4 h-4 mr-2" />
            View Network
          </Button>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Systems', value: '9', icon: Zap },
          { label: 'Years of Research', value: '16', icon: History },
          { label: 'Papers Published', value: '25+', icon: BookOpen },
          { label: 'Modern Capabilities', value: '4', icon: Globe },
        ].map((stat) => (
          <div key={stat.label} className="bg-white/5 border border-white/10 rounded-lg p-4 text-center">
            <stat.icon className="w-5 h-5 text-amber-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{stat.value}</div>
            <div className="text-xs text-slate-400">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Systems Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {SYSTEMS.map((system) => (
          <Card 
            key={system.id}
            className={`bg-black/30 ${system.borderColor} hover:bg-white/5 transition-all cursor-pointer group`}
            onClick={() => onNavigate(system.id)}
          >
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className={`p-2 rounded-lg ${system.bgColor}`}>
                  <system.icon className={`w-5 h-5 ${system.color}`} />
                </div>
                <span className="text-xs text-slate-500 font-mono">{system.year}</span>
              </div>
              <CardTitle className={`text-lg ${system.color} group-hover:text-white transition-colors`}>
                {system.title}
              </CardTitle>
              <CardDescription className="text-slate-400 text-xs leading-relaxed">
                {system.description}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-1.5">
                {system.features.map((feature) => (
                  <span 
                    key={feature}
                    className={`text-xs px-2 py-0.5 rounded-full ${system.bgColor} ${system.color} border ${system.borderColor}`}
                  >
                    {feature}
                  </span>
                ))}
              </div>
              <div className="flex items-center gap-1 mt-3 text-xs text-slate-500 group-hover:text-slate-300 transition-colors">
                <span>Launch Demo</span>
                <ArrowRight className="w-3 h-3" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Connection Diagram Preview */}
      <div className="bg-black/30 border border-white/10 rounded-lg p-6">
        <div className="flex items-center gap-3 mb-4">
          <GitBranch className="w-5 h-5 text-indigo-400" />
          <h3 className="text-lg font-semibold text-white">Klein Network Architecture</h3>
        </div>
        <p className="text-sm text-slate-400 mb-4">
          All systems are interconnected through the Klein Network, enabling cross-system collaboration 
          and intelligent query routing. The chatbot serves as the unified interface.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-3">
          {SYSTEMS.slice(0, 7).map((s, i) => (
            <div key={s.id} className="flex items-center gap-3">
              <div className={`px-3 py-1.5 rounded-lg ${s.bgColor} ${s.color} text-xs font-medium border ${s.borderColor}`}>
                {s.title.split(' ')[0]}
              </div>
              {i < 6 && <div className="w-4 h-px bg-white/20" />}
            </div>
          ))}
          <div className="w-4 h-px bg-white/20" />
          <div className="px-3 py-1.5 rounded-lg bg-teal-500/10 text-teal-400 text-xs font-medium border border-teal-500/30">
            Chatbot
          </div>
        </div>
        <div className="text-center mt-4">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => onNavigate('network')}
            className="border-indigo-500/30 text-indigo-400 hover:bg-indigo-500/10"
          >
            <Network className="w-3 h-3 mr-1" />
            View Full Network
          </Button>
        </div>
      </div>
    </div>
  );
}
