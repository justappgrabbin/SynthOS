// ═══════════════════════════════════════════════════════════════════
//  AUTOLING DEMO (Klein, 1968)
// ═══════════════════════════════════════════════════════════════════

import { useState } from 'react';
import { autoling } from '@/systems/autoling';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Languages, MessageSquare, BookOpen, Code2, GraduationCap } from 'lucide-react';

type Mode = 'chat' | 'code-learn';

export function AutolingDemo() {
  const [mode, setMode] = useState<Mode>('chat');
  const [input, setInput] = useState('');
  const [history, setHistory] = useState<Array<{ role: 'user' | 'bot'; text: string; patterns?: any[] }>>([
    { role: 'bot', text: 'AUTOLING initialized. I learn patterns from your inputs. Try saying something!' }
  ]);
  const [codeExamples, setCodeExamples] = useState(`// Example 1
users.map(u => u.name).filter(n => n.length > 0);

// Example 2
items.map(item => item.price).filter(p => p > 0);

// Example 3
data.map(d => d.value).filter(v => v !== null);`);
  const [learnedPatterns, setLearnedPatterns] = useState<any[]>([]);
  const [session, setSession] = useState<any>(null);

  const sendMessage = () => {
    if (!input.trim()) return;
    
    if (!session) {
      const s = autoling.startSession('english');
      setSession(s);
    }

    const userMsg = { role: 'user' as const, text: input };
    const result = autoling.processInput(input);
    
    setHistory(prev => [...prev, userMsg, { 
      role: 'bot', 
      text: result.response,
      patterns: result.learned
    }]);
    setInput('');
  };

  const learnCode = () => {
    const examples = codeExamples.split('\n// Example').map(e => e.trim()).filter(Boolean);
    const patterns = autoling.learnCodePatterns(examples);
    setLearnedPatterns(patterns);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-green-500/10 border border-green-500/30">
          <Languages className="w-5 h-5 text-green-400" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-green-400">AUTOLING (1968)</h2>
          <p className="text-sm text-slate-400">Automated linguistic fieldworker — now learns code patterns</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        {[
          { id: 'chat' as Mode, label: 'Interactive Learning', icon: MessageSquare },
          { id: 'code-learn' as Mode, label: 'Code Pattern Learning', icon: Code2 },
        ].map((m) => (
          <button
            key={m.id}
            onClick={() => setMode(m.id)}
            className={`p-2 rounded-lg border text-xs text-center transition-all ${
              mode === m.id 
                ? 'bg-green-500/20 border-green-500/50 text-green-400' 
                : 'bg-white/5 border-white/10 text-slate-400 hover:bg-white/10'
            }`}
          >
            <m.icon className="w-3 h-3 mx-auto mb-1" />
            <div className="font-medium">{m.label}</div>
          </button>
        ))}
      </div>

      {mode === 'chat' ? (
        <>
          <Card className="bg-black/30 border-white/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-white flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-green-400" />
                Interactive Session
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-black/50 rounded-lg p-4 h-[300px] overflow-y-auto space-y-3 mb-4">
                {history.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${
                      msg.role === 'user' 
                        ? 'bg-green-500/20 text-green-300' 
                        : 'bg-white/10 text-slate-300'
                    }`}>
                      <pre className="whitespace-pre-wrap font-sans">{msg.text}</pre>
                      {msg.patterns && msg.patterns.length > 0 && (
                        <div className="mt-2 pt-2 border-t border-white/10">
                          <div className="text-xs text-green-400">
                            Learned: {msg.patterns.map((p: any) => p.pattern).join(', ')}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex gap-2">
                <Textarea 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), sendMessage())}
                  placeholder="Say something or paste text..."
                  className="bg-white/5 border-white/10 text-white min-h-[50px] flex-1"
                />
                <Button 
                  onClick={sendMessage}
                  className="bg-green-500 hover:bg-green-600 text-white"
                >
                  <Languages className="w-4 h-4" />
                </Button>
              </div>

              {session && (
                <div className="mt-3 flex items-center gap-4 text-xs text-slate-500">
                  <span>Interactions: {session.interactions}</span>
                  <span>Rules: {session.rules.length}</span>
                  <span>Patterns: {session.patterns.length}</span>
                  <span>Accuracy: {(session.accuracy * 100).toFixed(1)}%</span>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-black/30 border-white/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-white flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-green-400" />
                Try These Examples
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-2">
                {[
                  'Hello, how are you today?',
                  'The quick brown fox jumps.',
                  'function calculateTotal(items) { return items.reduce((a, b) => a + b.price, 0); }',
                  'What is the meaning of life?',
                  'const result = data.map(x => x * 2).filter(x => x > 0);',
                  'async function fetchData() { const res = await fetch(url); return res.json(); }'
                ].map((example) => (
                  <button
                    key={example}
                    onClick={() => { setInput(example); }}
                    className="text-left text-xs bg-white/5 hover:bg-white/10 rounded p-2 text-slate-400 hover:text-slate-300 transition-colors font-mono"
                  >
                    {example.length > 50 ? example.substring(0, 50) + '...' : example}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </>
      ) : (
        <>
          <Card className="bg-black/30 border-white/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-white">Code Examples (one per block)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea 
                value={codeExamples}
                onChange={(e) => setCodeExamples(e.target.value)}
                className="bg-black/50 border-white/10 text-green-400 font-mono text-sm min-h-[200px]"
              />
              <Button 
                onClick={learnCode}
                className="bg-green-500 hover:bg-green-600 text-white w-full"
              >
                <GraduationCap className="w-4 h-4 mr-2" />
                Learn Patterns
              </Button>
            </CardContent>
          </Card>

          {learnedPatterns.length > 0 && (
            <Card className="bg-black/30 border-green-500/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-green-400">
                  Learned Patterns ({learnedPatterns.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {learnedPatterns.map((pattern, i) => (
                  <div key={i} className="bg-white/5 rounded-lg p-3">
                    <div className="flex items-center justify-between mb-1">
                      <div className="text-sm font-medium text-green-400">{pattern.pattern}</div>
                      <div className="text-xs text-slate-500">
                        Confidence: {(pattern.confidence * 100).toFixed(0)}%
                      </div>
                    </div>
                    <div className="text-xs text-slate-400 mb-2">
                      {pattern.rule?.rhs[0]}
                    </div>
                    <div className="text-xs text-slate-500">
                      Found in {pattern.rule?.frequency || 0} examples
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
