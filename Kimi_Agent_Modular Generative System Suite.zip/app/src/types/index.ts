// ═══════════════════════════════════════════════════════════════════
//  SHELDON KLEIN AI SYSTEMS - TYPE DEFINITIONS
// ═══════════════════════════════════════════════════════════════════

// ── 1. NOVEL WRITER SYSTEM (1973) ────────────────────────────────
export interface StoryNode {
  id: string;
  type: 'character' | 'action' | 'setting' | 'dialogue' | 'conflict' | 'resolution';
  content: string;
  dependencies: string[];
  depth: number;
}

export interface NovelChapter {
  title: string;
  nodes: StoryNode[];
  wordCount: number;
  theme: string;
}

export interface NovelConfig {
  genre: 'murder-mystery' | 'sci-fi' | 'romance' | 'adventure' | 'code-drama' | 'game-narrative';
  length: 'short' | 'medium' | 'long';
  characters: number;
  style: 'classic' | 'modern' | 'technical' | 'noir';
  modernMode: 'story' | 'code' | 'game' | 'video-script';
}

// ── 2. AUTO-PARAPHRASER SYSTEM (1965) ────────────────────────────
export interface DependencyLink {
  source: string;
  target: string;
  relation: string;
  strength: number;
}

export interface ParaphraseResult {
  original: string;
  paraphrase: string;
  outline: string[];
  dependencies: DependencyLink[];
  mode: 'essay' | 'simplify' | 'explain-code' | 'expand' | 'summarize';
  readingLevel: number;
}

export interface ParaphraseConfig {
  mode: 'essay' | 'simplify' | 'explain-code' | 'expand' | 'summarize';
  readingLevel: 'elementary' | 'highSchool' | 'college' | 'expert';
  format: 'paragraph' | 'bullet' | 'outline' | 'code-comments';
  preserveTone: boolean;
}

// ── 3. STYLE CONTROLLER SYSTEM (1965) ────────────────────────────
export interface StyleRule {
  id: string;
  parameter: string;
  value: number;
  description: string;
  category: 'syntax' | 'vocabulary' | 'structure' | 'tone';
}

export interface StyleProfile {
  name: string;
  rules: StyleRule[];
  description: string;
  target: 'code' | 'fiction' | 'technical' | 'casual' | 'formal' | 'poetic';
}

export interface StyleTransformResult {
  original: string;
  transformed: string;
  appliedRules: StyleRule[];
  styleMetrics: Record<string, number>;
}

// ── 4. DISEMINER SYSTEM (1968) ───────────────────────────────────
export interface DistributionClass {
  stem: string;
  class: string;
  cooccurrences: string[];
  frequency: number;
  contexts: string[];
}

export interface SemanticInference {
  query: string;
  answer: string;
  confidence: number;
  evidence: DistributionClass[];
  inferenceChain: string[];
}

export interface DISEMINERConfig {
  analysisDepth: 'surface' | 'deep' | 'full-context';
  corpusSize: number;
  domain: 'general' | 'technical' | 'code' | 'scientific';
}

// ── 5. AUTOLING SYSTEM (1968) ────────────────────────────────────
export interface GrammarRule {
  id: string;
  lhs: string;
  rhs: string[];
  frequency: number;
  confirmed: boolean;
  context?: string;
}

export interface LearnedPattern {
  pattern: string;
  category: 'morphology' | 'phrase-structure' | 'transformation' | 'code-pattern';
  confidence: number;
  examples: string[];
  rule?: GrammarRule;
}

export interface AutolingSession {
  id: string;
  language: string;
  rules: GrammarRule[];
  patterns: LearnedPattern[];
  interactions: number;
  accuracy: number;
}

// ── 6. HISTORICAL CHANGE SIMULATOR (1966) ────────────────────────
export interface Speaker {
  id: string;
  age: number;
  status: number;
  grammar: GrammarRule[];
  socialGroup: string;
  birthTick: number;
}

export interface LanguageChangeEvent {
  tick: number;
  speaker: string;
  type: 'rule-adoption' | 'rule-loss' | 'frequency-shift' | 'innovation' | 'merge';
  description: string;
  magnitude: number;
}

export interface SimulationState {
  tick: number;
  speakers: Speaker[];
  events: LanguageChangeEvent[];
  communityGrammar: GrammarRule[];
  stability: number;
}

export interface SimulatorConfig {
  population: number;
  generations: number;
  initialRules: number;
  socialGroups: number;
  mutationRate: number;
  mode: 'language' | 'code-evolution' | 'pattern-drift';
}

// ── 7. GRAMMAR CODER SYSTEM (1963) ───────────────────────────────
export interface CodedWord {
  token: string;
  pos: string;
  features: Record<string, string>;
  dependencies: string[];
  code: string;
}

export interface ParseTree {
  root: string;
  nodes: ParseNode[];
  depth: number;
  confidence: number;
}

export interface ParseNode {
  id: string;
  label: string;
  children: string[];
  start: number;
  end: number;
}

export interface GrammarCodeResult {
  input: string;
  codedWords: CodedWord[];
  parseTree: ParseTree;
  structuralPattern: string;
}

// ── 8. NEURAL NETWORK CONNECTOR ──────────────────────────────────
export interface KleinNode {
  id: string;
  system: string;
  state: 'active' | 'idle' | 'processing' | 'error';
  input: unknown;
  output: unknown;
  connections: string[];
}

export interface KleinEdge {
  source: string;
  target: string;
  weight: number;
  type: 'data' | 'control' | 'feedback';
  active: boolean;
}

export interface KleinNetwork {
  nodes: KleinNode[];
  edges: KleinEdge[];
  running: boolean;
  tick: number;
}

// ── 9. CHATBOT SYSTEM ────────────────────────────────────────────
export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  metadata?: {
    systemUsed?: string;
    confidence?: number;
    processingTime?: number;
  };
}

export interface ChatContext {
  messages: ChatMessage[];
  activeSystems: string[];
  personality: 'helpful' | 'technical' | 'creative' | 'analytical';
  memory: Record<string, unknown>;
}

// ── SHARED ─────────────────────────────────────────────────────────
export interface SystemStatus {
  id: string;
  name: string;
  description: string;
  year: number;
  status: 'active' | 'idle' | 'processing' | 'error';
  lastOutput?: unknown;
}

export type KleinSystem = 
  | 'novel-writer'
  | 'paraphraser'
  | 'style-controller'
  | 'diseminer'
  | 'autoling'
  | 'simulator'
  | 'grammar-coder'
  | 'network'
  | 'chatbot';
