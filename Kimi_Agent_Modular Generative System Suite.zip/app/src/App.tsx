// ═══════════════════════════════════════════════════════════════════
//  SHELDON KLEIN AI SYSTEMS HUB
//  Interactive demo of all Klein systems with modern twists
// ═══════════════════════════════════════════════════════════════════

import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { NovelWriterDemo } from '@/components/NovelWriterDemo';
import { ParaphraserDemo } from '@/components/ParaphraserDemo';
import { StyleControllerDemo } from '@/components/StyleControllerDemo';
import { DiseminerDemo } from '@/components/DiseminerDemo';
import { AutolingDemo } from '@/components/AutolingDemo';
import { SimulatorDemo } from '@/components/SimulatorDemo';
import { GrammarCoderDemo } from '@/components/GrammarCoderDemo';
import { KleinNetworkDemo } from '@/components/KleinNetworkDemo';
import { ChatbotDemo } from '@/components/ChatbotDemo';
import { SystemHub } from '@/components/SystemHub';

function App() {
  const [activeTab, setActiveTab] = useState('hub');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 text-white">
      {/* Header */}
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
              Sheldon Klein AI Systems
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Pioneering Computational Linguistics (1963-1979) — Modernized
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs px-2 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              All Systems Online
            </span>
            <span className="text-xs px-2 py-1 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
              1963—2025
            </span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="w-full flex flex-wrap h-auto bg-black/30 border border-white/10 p-1 gap-1">
            <TabsTrigger value="hub" className="flex-1 min-w-[100px] data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-400">
              Hub
            </TabsTrigger>
            <TabsTrigger value="novel" className="flex-1 min-w-[100px] data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
              Novel Writer
            </TabsTrigger>
            <TabsTrigger value="paraphrase" className="flex-1 min-w-[100px] data-[state=active]:bg-blue-500/20 data-[state=active]:text-blue-400">
              Paraphraser
            </TabsTrigger>
            <TabsTrigger value="style" className="flex-1 min-w-[100px] data-[state=active]:bg-pink-500/20 data-[state=active]:text-pink-400">
              Style Ctrl
            </TabsTrigger>
            <TabsTrigger value="diseminer" className="flex-1 min-w-[100px] data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
              DISEMINER
            </TabsTrigger>
            <TabsTrigger value="autoling" className="flex-1 min-w-[100px] data-[state=active]:bg-green-500/20 data-[state=active]:text-green-400">
              AUTOLING
            </TabsTrigger>
            <TabsTrigger value="simulator" className="flex-1 min-w-[100px] data-[state=active]:bg-red-500/20 data-[state=active]:text-red-400">
              Simulator
            </TabsTrigger>
            <TabsTrigger value="grammar" className="flex-1 min-w-[100px] data-[state=active]:bg-violet-500/20 data-[state=active]:text-violet-400">
              Grammar Coder
            </TabsTrigger>
            <TabsTrigger value="network" className="flex-1 min-w-[100px] data-[state=active]:bg-indigo-500/20 data-[state=active]:text-indigo-400">
              Network
            </TabsTrigger>
            <TabsTrigger value="chatbot" className="flex-1 min-w-[100px] data-[state=active]:bg-teal-500/20 data-[state=active]:text-teal-400">
              Chatbot
            </TabsTrigger>
          </TabsList>

          <TabsContent value="hub">
            <SystemHub onNavigate={setActiveTab} />
          </TabsContent>

          <TabsContent value="novel">
            <NovelWriterDemo />
          </TabsContent>

          <TabsContent value="paraphrase">
            <ParaphraserDemo />
          </TabsContent>

          <TabsContent value="style">
            <StyleControllerDemo />
          </TabsContent>

          <TabsContent value="diseminer">
            <DiseminerDemo />
          </TabsContent>

          <TabsContent value="autoling">
            <AutolingDemo />
          </TabsContent>

          <TabsContent value="simulator">
            <SimulatorDemo />
          </TabsContent>

          <TabsContent value="grammar">
            <GrammarCoderDemo />
          </TabsContent>

          <TabsContent value="network">
            <KleinNetworkDemo />
          </TabsContent>

          <TabsContent value="chatbot">
            <ChatbotDemo />
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 bg-black/20 mt-12">
        <div className="max-w-7xl mx-auto px-4 py-6 text-center text-sm text-slate-500">
          <p>
            Built on the pioneering work of <span className="text-amber-400">Sheldon Klein</span> — 
            Novel Writer (1973), Auto-Paraphraser (1965), Style Controller (1965), 
            DISEMINER (1968), AUTOLING (1968), Historical Change Simulator (1966), 
            Grammar Coder (1963)
          </p>
          <p className="mt-2 text-xs">
            Modern implementations with generative capabilities for code, games, apps, and video
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
