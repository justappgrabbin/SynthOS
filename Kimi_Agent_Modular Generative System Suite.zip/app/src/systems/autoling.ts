// ═══════════════════════════════════════════════════════════════════
//  5. AUTOLING ENGINE (Sheldon Klein, 1968)
//  Automated Linguistic Fieldworker
//  Modern twist: Interactive language/code pattern learner
// ═══════════════════════════════════════════════════════════════════

import type { GrammarRule, LearnedPattern, AutolingSession } from '@/types';

// ── ENGINE ────────────────────────────────────────────────────────
export class AutolingEngine {
  private sessions: Map<string, AutolingSession> = new Map();
  private currentSession: AutolingSession | null = null;
  
  // Built-in pattern database for demonstration
  private knownPatterns: Map<string, { pattern: RegExp; category: string; response: string }> = new Map([
    ['greeting', { 
      pattern: /^(hello|hi|hey|greetings)/i, 
      category: 'social', 
      response: 'Greeting detected: Opening exchange pattern' 
    }],
    ['question', { 
      pattern: /^(what|who|where|when|why|how)\b/i, 
      category: 'interrogative', 
      response: 'Question pattern: Information-seeking speech act' 
    }],
    ['imperative', { 
      pattern: /^(please|can you|will you|could you)/i, 
      category: 'directive', 
      response: 'Directive pattern: Request/command structure' 
    }],
    ['declaration', { 
      pattern: /^(I am|it is|this is|that is|we are)/i, 
      category: 'assertive', 
      response: 'Declaration pattern: Assertive speech act' 
    }],
    ['negation', { 
      pattern: /\b(not|no|never|nothing|nobody|nowhere)\b/i, 
      category: 'negative', 
      response: 'Negation pattern: Polarity reversal detected' 
    }],
    ['past tense', { 
      pattern: /\b(was|were|had|did|went|said|made|took|came|saw|knew|thought|got|found|gave|told|felt|became|left|put|meant|kept|let|began|seemed|helped|turned|started|heard|played|moved|lived|believed|brought|happened|wrote|stood|lost|paid|met|included|continued|set|learned|changed|led|understood|watched|followed|stopped|created|spoke|read|spent|grew|opened|walked|offered|remembered|loved|considered|appeared|bought|waited|served|died|sent|expected|built|stayed|fell|cut|reached|killed|remained)\b/i, 
      category: 'temporal', 
      response: 'Past tense marker: Anterior temporal reference' 
    }],
    ['future', { 
      pattern: /\b(will|shall|going to|about to)\b/i, 
      category: 'temporal', 
      response: 'Future tense marker: Posterior temporal reference' 
    }],
    ['code function', {
      pattern: /\bfunction\s+(\w+)\s*\(/i,
      category: 'code-pattern',
      response: 'Function declaration: Named subroutine definition'
    }],
    ['code variable', {
      pattern: /\b(const|let|var)\s+(\w+)\s*=/i,
      category: 'code-pattern',
      response: 'Variable binding: Mutable or immutable assignment'
    }],
    ['code class', {
      pattern: /\bclass\s+(\w+)/i,
      category: 'code-pattern',
      response: 'Class definition: Object-oriented type declaration'
    }],
    ['code import', {
      pattern: /\b(import|require)\b/i,
      category: 'code-pattern',
      response: 'Module dependency: External library inclusion'
    }],
    ['code loop', {
      pattern: /\b(for|while|do)\b/i,
      category: 'code-pattern',
      response: 'Iteration pattern: Repetition control structure'
    }],
    ['code conditional', {
      pattern: /\b(if|else|switch)\b/i,
      category: 'code-pattern',
      response: 'Conditional pattern: Branching control structure'
    }],
    ['code async', {
      pattern: /\b(async|await|Promise)\b/i,
      category: 'code-pattern',
      response: 'Asynchronous pattern: Non-blocking execution'
    }]
  ]);

  startSession(language: string): AutolingSession {
    const session: AutolingSession = {
      id: `session_${Date.now()}`,
      language,
      rules: [],
      patterns: [],
      interactions: 0,
      accuracy: 0
    };
    this.sessions.set(session.id, session);
    this.currentSession = session;
    return session;
  }

  processInput(input: string): { response: string; learned: LearnedPattern[]; confidence: number } {
    if (!this.currentSession) {
      this.startSession('auto-detect');
    }
    
    const session = this.currentSession!;
    session.interactions++;

    const learned: LearnedPattern[] = [];
    let totalConfidence = 0;
    let matchCount = 0;

    // Apply heuristics
    this.knownPatterns.forEach((def, name) => {
      if (def.pattern.test(input)) {
        const match = input.match(def.pattern);
        const confidence = match ? match[0].length / input.length : 0.5;
        
        const pattern: LearnedPattern = {
          pattern: name,
          category: def.category as any,
          confidence: Math.min(confidence * 2, 0.95),
          examples: [input.substring(0, 100)],
          rule: {
            id: `rule_${session.rules.length}`,
            lhs: name,
            rhs: [def.category, def.response],
            frequency: 1,
            confirmed: confidence > 0.5,
            context: input.substring(0, 50)
          }
        };

        learned.push(pattern);
        session.patterns.push(pattern);
        if (pattern.rule) session.rules.push(pattern.rule);
        
        totalConfidence += pattern.confidence;
        matchCount++;
      }
    });

    // Update accuracy
    session.accuracy = matchCount > 0 ? totalConfidence / matchCount : 0;

    // Generate response
    const response = this.generateResponse(input, learned);

    return { response, learned, confidence: session.accuracy };
  }

  private generateResponse(input: string, learned: LearnedPattern[]): string {
    if (learned.length === 0) {
      return `Input: "${input.substring(0, 50)}" - No pattern match. This represents novel data for my grammar.\n\nCan you provide another example? I learn from multiple instances.`;
    }

    const mainPattern = learned[0];
    const responses = [
      `Pattern recognized: ${mainPattern.pattern} (${mainPattern.category})\nConfidence: ${(mainPattern.confidence * 100).toFixed(1)}%`,
      `Analysis: "${mainPattern.rule?.rhs[1] || 'Pattern identified'}"`,
      learned.length > 1 ? `Additional patterns: ${learned.slice(1).map(l => l.pattern).join(', ')}` : ''
    ];

    return responses.filter(r => r).join('\n');
  }

  // Heuristic learning: attempt to generalize from examples
  learnFromExamples(examples: string[]): GrammarRule[] {
    const newRules: GrammarRule[] = [];

    // Find common patterns across examples
    if (examples.length >= 2) {
      // Heuristic 2: Two items in identical environments → same class
      const commonWords = this.findCommonElements(examples);
      
      if (commonWords.length > 0) {
        const rule: GrammarRule = {
          id: `generalized_${Date.now()}`,
          lhs: `CLASS_${commonWords[0].toUpperCase()}`,
          rhs: commonWords,
          frequency: examples.length,
          confirmed: false,
          context: `Learned from ${examples.length} examples`
        };
        newRules.push(rule);
      }

      // Heuristic 3: Terminal + non-terminal in same environment → add to class
      const structuralPattern = this.inferStructure(examples);
      if (structuralPattern) {
        newRules.push(structuralPattern);
      }
    }

    if (this.currentSession) {
      newRules.forEach(r => this.currentSession!.rules.push(r));
    }

    return newRules;
  }

  private findCommonElements(examples: string[]): string[] {
    const wordsByExample = examples.map(e => 
      new Set(e.toLowerCase().match(/\b[a-z]+\b/g) || [])
    );

    if (wordsByExample.length === 0) return [];

    const common = [...wordsByExample[0]].filter(word => 
      wordsByExample.every(set => set.has(word))
    );

    return common;
  }

  private inferStructure(examples: string[]): GrammarRule | null {
    // Look for common structural patterns
    const starts = examples.map(e => e.trim().split(' ')[0].toLowerCase());
    const commonStart = this.mode(starts);
    
    if (commonStart && starts.filter(s => s === commonStart).length >= examples.length * 0.5) {
      return {
        id: `structure_${Date.now()}`,
        lhs: 'SENTENCE',
        rhs: [commonStart, '...'],
        frequency: starts.filter(s => s === commonStart).length,
        confirmed: false,
        context: `Common start pattern: "${commonStart}"`
      };
    }

    return null;
  }

  private mode(arr: string[]): string | null {
    const counts: Record<string, number> = {};
    arr.forEach(item => { counts[item] = (counts[item] || 0) + 1; });
    const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
    return sorted.length > 0 && sorted[0][1] > 1 ? sorted[0][0] : null;
  }

  // Modern twist: Learn code patterns from examples
  learnCodePatterns(codeExamples: string[]): LearnedPattern[] {
    const patterns: LearnedPattern[] = [];

    // Detect common code idioms
    const idiomPatterns = [
      { pattern: /\.map\(.*=>/g, name: 'array-map', desc: 'Functional mapping over collections' },
      { pattern: /\.filter\(.*=>/g, name: 'array-filter', desc: 'Predicate-based filtering' },
      { pattern: /\.reduce\(/g, name: 'array-reduce', desc: 'Accumulator-based reduction' },
      { pattern: /async\s+function|const\s+\w+\s*=\s*async/g, name: 'async-function', desc: 'Asynchronous function definition' },
      { pattern: /try\s*\{[^}]*\}\s*catch/g, name: 'error-handling', desc: 'Exception handling block' },
      { pattern: /class\s+\w+\s*\{[^}]*constructor/g, name: 'class-constructor', desc: 'OOP class with constructor' },
      { pattern: /useEffect\(|useState\(|useCallback\(/g, name: 'react-hooks', desc: 'React hook usage' },
      { pattern: /fetch\(|axios\.|\.get\(/g, name: 'http-request', desc: 'HTTP client request' }
    ];

    idiomPatterns.forEach(({ pattern, name, desc }) => {
      const matches = codeExamples.filter(ex => pattern.test(ex));
      if (matches.length >= Math.max(1, codeExamples.length * 0.3)) {
        patterns.push({
          pattern: name,
          category: 'code-pattern',
          confidence: matches.length / codeExamples.length,
          examples: matches.slice(0, 3),
          rule: {
            id: `idiom_${name}`,
            lhs: name,
            rhs: [desc],
            frequency: matches.length,
            confirmed: matches.length >= 2
          }
        });
      }
    });

    return patterns;
  }

  getCurrentSession(): AutolingSession | null {
    return this.currentSession;
  }

  getAllSessions(): AutolingSession[] {
    return Array.from(this.sessions.values());
  }
}

export const autoling = new AutolingEngine();
