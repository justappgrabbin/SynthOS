// ═══════════════════════════════════════════════════════════════════
//  1. NOVEL WRITER ENGINE (Sheldon Klein, 1973)
//  Modern twist: Generates stories, code, game narratives, video scripts
// ═══════════════════════════════════════════════════════════════════

import type { NovelConfig, NovelChapter, StoryNode } from '@/types';

// ── TEMPLATES ─────────────────────────────────────────────────────
const MURDER_MYSTERY_TEMPLATES = {
  characters: [
    'Lady Buxley', 'James', 'Marion', 'Inspector Grey', 'Dr. Blackwood',
    'Miss Scarlet', 'Colonel Mustard', 'Professor Plum', 'Mrs. Peacock',
    'Reverend Green', 'Captain Azure', 'Duchess Violet'
  ],
  settings: [
    'the manor house', 'the garden maze', 'the library', 'the dining room',
    'the conservatory', 'the study', 'the ballroom', 'the kitchen',
    'the east wing', 'the clock tower', 'the wine cellar', 'the observatory'
  ],
  actions: [
    'discovered a clue', 'heard a strange noise', 'found a letter',
    'noticed bloodstains', 'hid behind curtains', 'followed footprints',
    'broke down a door', 'extinguished the lights', 'searched pockets',
    'questioned the staff', 'examined the weapon', 'read a diary'
  ],
  motives: ['jealousy', 'inheritance', 'revenge', 'blackmail', 'love', 'greed'],
  resolutions: [
    'The butler did it', 'It was a suicide made to look like murder',
    'The victim was never dead', 'It was an accident after all',
    'The least likely suspect confessed'
  ]
};

const CODE_DRAMA_TEMPLATES = {
  characters: [
    'The Kernel', 'The Compiler', 'Process Alpha', 'Thread Beta',
    'Memory Manager', 'Garbage Collector', 'The Debugger',
    'API Gateway', 'Microservice Omega', 'The Load Balancer',
    'Cache Invalidator', 'Event Listener'
  ],
  settings: [
    'the main memory heap', 'the stack frame', 'the system bus',
    'the thread pool', 'the event loop', 'the registry',
    'the bytecode forest', 'the dependency graph', 'the container namespace',
    'the cloud cluster', 'the edge node', 'the database shard'
  ],
  actions: [
    'threw a segmentation fault', 'entered a race condition',
    'triggered a garbage collection cycle', 'encountered a deadlock',
    'spawned a child process', 'allocated memory',
    'sent a SIGKILL signal', 'buffered I/O streams',
    'marshalled data structures', 'established a socket connection',
    'optimized the query plan', 'flushed the cache'
  ],
  motives: ['resource starvation', 'infinite loops', 'memory leaks', 'deadlocks', 'race conditions', 'buffer overflows'],
  resolutions: [
    'A try-catch block saved the day',
    'The garbage collector reclaimed everything',
    'Refactoring eliminated the race condition',
    'The mutex was released in the finally block',
    'Kubernetes restarted the pod automatically'
  ]
};

const GAME_NARRATIVE_TEMPLATES = {
  characters: [
    'The Player Character', 'The NPC Merchant', 'The Quest Giver',
    'The Dungeon Master', 'The Guild Leader', 'The Rival Player',
    'The Hidden Boss', 'The Tutorial Fairy', 'The Speedrunner',
    'The Modder', 'The Lore Keeper', 'The Achievement Hunter'
  ],
  settings: [
    'the starting village', 'the corrupted forest', 'the sky dungeon',
    'the underwater temple', 'the lava fortress', 'the crystal cave',
    'the floating islands', 'the mirror dimension', 'the abandoned server',
    'the prologue zone', 'the endgame arena', 'the secret level'
  ],
  actions: [
    'activated a hidden trigger', 'found a speedrun exploit',
    'completed a combo chain', 'discovered an Easter egg',
    'rage-quit at the boss', 'crafted a legendary item',
    'joined a raid party', 'unlocked a secret ending',
    'broke the fourth wall', 'achieved a world record',
    'modded the game files', 'triggered a softlock'
  ],
  motives: ['high score', '100% completion', 'speedrun glory', 'lore discovery', 'social status', 'creative expression'],
  resolutions: [
    'The final boss was defeated in record time',
    'The true ending was unlocked through sequence breaking',
    'A collaborative multiplayer effort saved the world',
    'The developer room revealed the ultimate secret',
    'New Game Plus offered infinite replayability'
  ]
};

const VIDEO_SCRIPT_TEMPLATES = {
  characters: [
    'The Director', 'The Cinematographer', 'The VFX Artist',
    'The Sound Designer', 'The Colorist', 'The Editor',
    'The Motion Capture Actor', 'The Voice Actor',
    'The Storyboard Artist', 'The Composer', 'The Producer',
    'The AI Assistant'
  ],
  settings: [
    'the green screen studio', 'the virtual set',
    'the motion capture volume', 'the render farm',
    'the color grading suite', 'the foley stage',
    'the editing timeline', 'the particle simulation',
    'the lighting rig', 'the camera tracking room',
    'the Unreal Engine scene', 'the neural rendering pipeline'
  ],
  actions: [
    'set up the key light', 'tracked the camera movement',
    'simulated the explosion', 'mixed the surround sound',
    'applied the LUT', 'cut to the reverse angle',
    'keyed out the background', 'rendered the depth pass',
    'animated the character rig', 'recorded the voiceover',
    'composited the CGI elements', 'exported the final cut'
  ],
  motives: ['visual spectacle', 'emotional impact', 'technical innovation', 'storytelling clarity', 'audience engagement', 'artistic vision'],
  resolutions: [
    'The seamless VFX integration fooled every viewer',
    'The one-shot sequence became iconic',
    'The AI-upscaled footage looked indistinguishable from reality',
    'The virtual production pipeline reduced costs by 80%',
    'The film won the VFX Oscar'
  ]
};

const GENRE_TEMPLATES: Record<string, typeof MURDER_MYSTERY_TEMPLATES> = {
  'murder-mystery': MURDER_MYSTERY_TEMPLATES,
  'code-drama': CODE_DRAMA_TEMPLATES,
  'game-narrative': GAME_NARRATIVE_TEMPLATES,
  'video-script': VIDEO_SCRIPT_TEMPLATES,
  'sci-fi': MURDER_MYSTERY_TEMPLATES,
  'romance': MURDER_MYSTERY_TEMPLATES,
  'adventure': MURDER_MYSTERY_TEMPLATES,
};

// ── ENGINE ────────────────────────────────────────────────────────
export class NovelWriterEngine {
  private rng: () => number;

  constructor(seed: number = Date.now()) {
    // Simple seeded RNG
    let s = seed;
    this.rng = () => { s = (s * 16807 + 0) % 2147483647; return (s - 1) / 2147483646; };
  }

  private pick<T>(arr: T[]): T {
    return arr[Math.floor(this.rng() * arr.length)];
  }

  private shuffle<T>(arr: T[]): T[] {
    const result = [...arr];
    for (let i = result.length - 1; i > 0; i--) {
      const j = Math.floor(this.rng() * (i + 1));
      [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
  }

  generate(config: NovelConfig): NovelChapter[] {
    const templates = GENRE_TEMPLATES[config.genre] || MURDER_MYSTERY_TEMPLATES;
    const chapters: NovelChapter[] = [];

    const lengthMap = { short: 3, medium: 5, long: 8 };
    const numChapters = lengthMap[config.length] || 3;

    const shuffledChars = this.shuffle(templates.characters);
    const characters = shuffledChars.slice(0, Math.min(config.characters, shuffledChars.length));

    const victim = this.pick(characters);
    let murderer = this.pick(characters.filter(c => c !== victim));
    const detective = this.pick(characters.filter(c => c !== victim && c !== murderer));
    const motive = this.pick(templates.motives);

    // Chapter 1: Setup
    chapters.push(this.generateSetupChapter(characters, victim, templates, config));

    // Middle chapters: Development
    for (let i = 1; i < numChapters - 1; i++) {
      chapters.push(this.generateDevelopmentChapter(i, characters, detective, templates, config, motive));
    }

    // Final chapter: Resolution
    chapters.push(this.generateResolutionChapter(characters, murderer, detective, motive, templates, config));

    return chapters;
  }

  private generateSetupChapter(
    characters: string[],
    victim: string,
    templates: typeof MURDER_MYSTERY_TEMPLATES,
    config: NovelConfig
  ): NovelChapter {
    const nodes: StoryNode[] = [];
    const setting = this.pick(templates.settings);

    nodes.push({
      id: 'setup-1',
      type: 'setting',
      content: `The scene opens at ${setting}. ${characters.slice(0, 3).join(', ')} ${characters.length > 3 ? 'and others' : ''} are present.`,
      dependencies: [],
      depth: 0
    });

    characters.forEach((char, i) => {
      nodes.push({
        id: `char-${i}`,
        type: 'character',
        content: `${char} enters the scene. ${this.pick([
          'There is tension in their posture.',
          'They seem nervous about something.',
          'They glance around suspiciously.',
          'They maintain an air of confidence.'
        ])}`,
        dependencies: ['setup-1'],
        depth: 1
      });
    });

    const action = this.pick(templates.actions);
    nodes.push({
      id: 'inciting',
      type: 'conflict',
      content: `Suddenly, ${victim} ${action}. The atmosphere shifts dramatically. Something is terribly wrong.`,
      dependencies: characters.map((_, i) => `char-${i}`),
      depth: 2
    });

    const title = config.modernMode === 'code'
      ? 'Initialization'
      : config.modernMode === 'game'
      ? 'The Tutorial Zone'
      : config.modernMode === 'video-script'
      ? 'Scene 1: Establishing Shot'
      : 'The Gathering';

    return {
      title,
      nodes,
      wordCount: nodes.reduce((acc, n) => acc + n.content.split(' ').length, 0),
      theme: 'setup'
    };
  }

  private generateDevelopmentChapter(
    index: number,
    characters: string[],
    detective: string,
    templates: typeof MURDER_MYSTERY_TEMPLATES,
    config: NovelConfig,
    motive: string
  ): NovelChapter {
    const nodes: StoryNode[] = [];
    const setting = this.pick(templates.settings);

    nodes.push({
      id: `dev-${index}-1`,
      type: 'setting',
      content: `Chapter ${index + 1}: ${setting}. The investigation deepens.`,
      dependencies: [],
      depth: 0
    });

    const clues = [
      `A torn photograph reveals a hidden connection.`,
      `An overheard conversation hints at ${motive}.`,
      `A discovered letter changes everything.`,
      `Fingerprints on an unlikely surface.`,
      `A timeline that does not quite match.`
    ];

    const clue = this.pick(clues);
    nodes.push({
      id: `clue-${index}`,
      type: 'action',
      content: `${detective} ${this.pick(templates.actions)}. ${clue}`,
      dependencies: [`dev-${index}-1`],
      depth: 1
    });

    const suspect = this.pick(characters.filter(c => c !== detective));
    nodes.push({
      id: `suspect-${index}`,
      type: 'dialogue',
      content: `"I didn't do it!" ${suspect} exclaims. But their eyes tell a different story. The motive of ${motive} hangs in the air.`,
      dependencies: [`clue-${index}`],
      depth: 2
    });

    const title = config.modernMode === 'code'
      ? `Function Call ${index}: Recursion`
      : config.modernMode === 'game'
      ? `Level ${index + 1}: The Dungeon`
      : config.modernMode === 'video-script'
      ? `Scene ${index + 1}: Montage Sequence`
      : `The Investigation Part ${index}`;

    return {
      title,
      nodes,
      wordCount: nodes.reduce((acc, n) => acc + n.content.split(' ').length, 0),
      theme: 'development'
    };
  }

  private generateResolutionChapter(
    characters: string[],
    murderer: string,
    detective: string,
    motive: string,
    templates: typeof MURDER_MYSTERY_TEMPLATES,
    config: NovelConfig
  ): NovelChapter {
    const nodes: StoryNode[] = [];

    nodes.push({
      id: 'res-1',
      type: 'setting',
      content: `The final confrontation. All suspects gathered in ${this.pick(templates.settings)}.`,
      dependencies: [],
      depth: 0
    });

    nodes.push({
      id: 'accusation',
      type: 'dialogue',
      content: `"${murderer}," ${detective} announces, "you committed this crime driven by ${motive}."`,
      dependencies: ['res-1'],
      depth: 1
    });

    nodes.push({
      id: 'confession',
      type: 'conflict',
      content: `${murderer} breaks down. "Yes, it was me! The ${motive} was too much to bear!"`,
      dependencies: ['accusation'],
      depth: 2
    });

    const resolution = this.pick(templates.resolutions);
    nodes.push({
      id: 'resolution',
      type: 'resolution',
      content: `${resolution}. Justice is served. The story of ${this.pick(characters)} and ${this.pick(characters)} comes to a close.`,
      dependencies: ['confession'],
      depth: 3
    });

    const title = config.modernMode === 'code'
      ? 'Final Return: Stack Unwinding'
      : config.modernMode === 'game'
      ? 'The Final Boss'
      : config.modernMode === 'video-script'
      ? 'Scene Final: The Reveal'
      : 'The Resolution';

    return {
      title,
      nodes,
      wordCount: nodes.reduce((acc, n) => acc + n.content.split(' ').length, 0),
      theme: 'resolution'
    };
  }

  // Modern twist: Generate code narrative
  generateCodeNarrative(_language: string, complexity: 'simple' | 'medium' | 'complex'): string {
    const patterns: Record<string, string[]> = {
      simple: [
        `function main() {\n  // Initialize the system\n  const data = fetchData();\n  return process(data);\n}`,
        `class HelloWorld {\n  greet() {\n    return "Hello, World!";\n  }\n}`
      ],
      medium: [
        `async function processQueue(jobs) {\n  const results = [];\n  for (const job of jobs) {\n    try {\n      const result = await job.execute();\n      results.push(result);\n    } catch (error) {\n      console.error('Job failed:', error);\n    }\n  }\n  return results;\n}`,
        `class DataProcessor extends EventEmitter {\n  constructor(config) {\n    super();\n    this.cache = new Map();\n    this.config = config;\n  }\n  \n  async transform(data) {\n    const key = this.hash(data);\n    if (this.cache.has(key)) {\n      return this.cache.get(key);\n    }\n    const result = await this.process(data);\n    this.cache.set(key, result);\n    return result;\n  }\n}`
      ],
      complex: [
        `class DistributedSystem {\n  private nodes: Node[];\n  private consensus: RaftConsensus;\n  private stateMachine: StateMachine;\n  \n  async proposeTransaction(tx: Transaction): Promise<Result> {\n    const prepared = await this.consensus.prepare(tx);\n    if (!prepared.quorum) {\n      throw new QuorumException('Failed to reach consensus');\n    }\n    const committed = await this.consensus.commit(prepared);\n    return this.stateMachine.apply(committed);\n  }\n  \n  handlePartition(event: NetworkEvent) {\n    this.nodes = this.nodes.filter(n => n.partition === event.partitionId);\n    this.consensus.reconfigure(this.nodes);\n  }\n}`,
        `const neuralNetwork = (layers: Layer[]) => ({\n  forward: (input: Tensor) => \n    layers.reduce((acc, layer) => \n      layer.activate(\n        matmul(acc, layer.weights).add(layer.bias)\n      ), input),\n  \n  backward: (grad: Tensor, lr: number) => {\n    let delta = grad;\n    for (let i = layers.length - 1; i >= 0; i--) {\n      const layer = layers[i];\n      layer.weights.sub(layer.weights.grad.mul(lr));\n      delta = matmul(delta, layer.weights.T);\n    }\n  }\n});`
      ]
    };

    const codeOptions = patterns[complexity] || patterns.simple;
    return this.pick(codeOptions);
  }

  // Modern twist: Generate game concept
  generateGameConcept(genre: string): { title: string; mechanics: string[]; story: string } {
    const titles: Record<string, string[]> = {
      rpg: ['Chrono Weavers', 'Soulforge Saga', 'The Crystal Codex'],
      fps: ['Neural Override', 'Zero Point', 'Fracture Zone'],
      puzzle: ['Quantum Loops', 'Entropy Garden', 'Pattern Mind'],
      strategy: ['Empire of Algorithms', 'Stellar Dominions', 'Cortex Wars'],
      roguelike: ['Abyssal Bytes', 'Permadeath Protocol', 'Shuffled Realms']
    };

    const mechanics: Record<string, string[]> = {
      rpg: ['Skill tree evolution', 'Companion bonding', 'Moral choices affecting world state'],
      fps: ['Wall-running combat', 'Time dilation abilities', 'Destructible environments'],
      puzzle: ['Reality bending mechanics', 'Cooperative paradox solving', 'Pattern memorization under pressure'],
      strategy: ['Dynamic faction alliances', 'Resource warfare', 'Tech tree randomization'],
      roguelike: ['Procedural narrative generation', 'Legacy item inheritance', 'Adaptive difficulty']
    };

    const title = this.pick(titles[genre] || titles.roguelike);
    const gameMechanics = this.shuffle(mechanics[genre] || mechanics.roguelike).slice(0, 3);

    return {
      title,
      mechanics: gameMechanics,
      story: `In ${title}, players navigate a world where ${this.pick([
        'reality itself is procedurally generated',
        'memories can be traded as currency',
        'every death creates a parallel timeline',
        'emotions manifest as physical forces',
        'code and magic are indistinguishable'
      ])}. The journey requires mastering ${gameMechanics[0].toLowerCase()} while uncovering the truth about ${this.pick(['the simulation', 'the ancient AI', 'the fractured multiverse', 'the forgotten protocol'])}.`
    };
  }

  // Modern twist: Generate video script
  generateVideoScript(_style: string): { scenes: string[]; dialogue: string[]; shots: string[] } {
    const scenes = [
      `EXT. FUTURISTIC CITY - DAWN`,
      `INT. LABORATORY - NIGHT`,
      `EXT. DESERT LANDSCAPE - SUNSET`,
      `INT. SPACECRAFT BRIDGE - CONTINUOUS`,
      `EXT. UNDERWATER FACILITY - DAY`
    ];

    const dialogues = [
      `CHARACTER A\nWe've crossed the threshold. There's no going back.`,
      `CHARACTER B\n(looking at data)\nThe readings are off the charts.`,
      `CHARACTER A\nThen we do this together.`,
      `CHARACTER C (V.O.)\nSome doors, once opened, change everything.`
    ];

    const shots = [
      `DRONE SHOT ascending over the cityscape, revealing the scale`,
      `CLOSE UP on Character A's eyes - resolve and fear`,
      `MATCH CUT from glowing data to Character B's face`,
      `SLOW MOTION as the mechanism activates`,
      `EXTREME WIDE shot - isolation in vastness`
    ];

    return {
      scenes: this.shuffle(scenes).slice(0, 3),
      dialogue: this.shuffle(dialogues).slice(0, 3),
      shots: this.shuffle(shots).slice(0, 3)
    };
  }
}

export const novelWriter = new NovelWriterEngine();
