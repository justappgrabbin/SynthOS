// ═══════════════════════════════════════════════════════════════════
//  9. KLEIN CHATBOT
//  Conversational interface integrating all Klein frameworks
// ═══════════════════════════════════════════════════════════════════

import type { ChatMessage, ChatContext } from '@/types';
import { kleinNetwork } from './klein-network';
import { autoling } from './autoling';
import { simulator } from './simulator';

// ── PERSONALITY PROFILES ──────────────────────────────────────────
const PERSONALITIES: Record<string, { name: string; greeting: string; style: string }> = {
  helpful: {
    name: 'Klein Assistant',
    greeting: 'Hello! I\'m your AI assistant powered by Sheldon Klein\'s pioneering NLP systems. I can help you write stories, analyze code, paraphrase text, simulate language evolution, and much more. What would you like to explore?',
    style: 'friendly, clear, and encouraging'
  },
  technical: {
    name: 'Klein Engineer',
    greeting: 'Klein Engine initialized. Systems online: NovelWriter(1973), AutoParaphraser(1965), StyleController(1965), DISEMINER(1968), AUTOLING(1968), HistoricalChangeSimulator(1966), GrammarCoder(1963). Ready for technical operations.',
    style: 'precise, systematic, technically detailed'
  },
  creative: {
    name: 'Klein Creator',
    greeting: 'Welcome to the creative nexus! I draw inspiration from Sheldon Klein\'s 1973 Novel Writer -- the first computer program to generate stories. Together we can craft narratives, design games, write scripts, and push the boundaries of computational creativity!',
    style: 'imaginative, expressive, inspiring'
  },
  analytical: {
    name: 'Klein Analyst',
    greeting: 'I am the analytical synthesis of Klein\'s computational linguistics research. My frameworks include distributional semantics (DISEMINER), grammatical coding (1963), and Monte Carlo language simulation (1966). State your query for systematic analysis.',
    style: 'methodical, evidence-based, comprehensive'
  }
};

// ── INTENT RECOGNITION ────────────────────────────────────────────
const INTENT_PATTERNS: Array<{ 
  intent: string; 
  patterns: RegExp[]; 
  systems: string[];
  handler: (_match: RegExpMatchArray, text: string) => Promise<string>;
}> = [
  {
    intent: 'generate_story',
    patterns: [
      /write\s+(?:me\s+)?a\s+(story|novel|tale|narrative)/i,
      /generate\s+(?:a\s+)?(story|novel|tale)/i,
      /create\s+(?:a\s+)?(story|plot|narrative)/i,
      /tell\s+(?:me\s+)?a\s+story/i
    ],
    systems: ['novel-writer'],
    handler: async (_, text) => {
      const genreMatch = text.match(/(murder.?mystery|sci.fi|romance|adventure|noir)/i);
      const genre = genreMatch ? genreMatch[1].toLowerCase().replace(/[-\s]/, '-') : 'murder-mystery';
      
      const result = await kleinNetwork.activateSystem('novel-writer', {
        genre: genre as any,
        length: 'short',
        characters: 4,
        style: 'classic',
        modernMode: 'story'
      });
      
      if (Array.isArray(result)) {
        return result.map((ch: any) => `**${ch.title}**\n${ch.nodes.map((n: any) => n.content).join('\n')}`).join('\n\n');
      }
      return JSON.stringify(result, null, 2);
    }
  },
  {
    intent: 'generate_code',
    patterns: [
      /write\s+(?:some\s+)?code\s+(?:for\s+)?(.+)/i,
      /generate\s+(?:a\s+)?(function|class|component)/i,
      /create\s+(?:a\s+)?(program|script|app)/i,
      /show\s+me\s+(?:how\s+to\s+)?code/i
    ],
    systems: ['novel-writer'],
    handler: async (_, text) => {
      const complexity = text.includes('complex') ? 'complex' : text.includes('simple') ? 'simple' : 'medium';
      const language = text.includes('python') ? 'python' : text.includes('java') && !text.includes('javascript') ? 'java' : 'javascript';
      
      const result = await kleinNetwork.activateSystem('novel-writer', {
        mode: 'code',
        language,
        complexity: complexity as any
      });
      
      return `Here's ${complexity} ${language} code:\n\n\`\`\`${language}\n${result}\n\`\`\``;
    }
  },
  {
    intent: 'generate_game',
    patterns: [
      /design\s+(?:a\s+)?game/i,
      /create\s+(?:a\s+)?game\s+(?:concept|idea)/i,
      /game\s+(?:design|concept)/i,
      /make\s+(?:a\s+)?game/i
    ],
    systems: ['novel-writer'],
    handler: async (_, text) => {
      const genreMatch = text.match(/(rpg|fps|puzzle|strategy|roguelike|adventure)/i);
      const genre = genreMatch ? genreMatch[1].toLowerCase() : 'rpg';
      
      const result = await kleinNetwork.activateSystem('novel-writer', {
        mode: 'game',
        genre
      }) as any;
      
      return `**${result.title}**\n\n**Core Mechanics:**\n${result.mechanics.map((m: string) => `- ${m}`).join('\n')}\n\n**Story:**\n${result.story}`;
    }
  },
  {
    intent: 'generate_video',
    patterns: [
      /write\s+(?:a\s+)?video\s+script/i,
      /create\s+(?:a\s+)?(film|movie)\s+(?:script|scene)/i,
      /script\s+(?:for\s+)?(?:a\s+)?video/i,
      /storyboard/i
    ],
    systems: ['novel-writer'],
    handler: async (_, text) => {
      const style = text.includes('cinematic') ? 'cinematic' : text.includes('noir') ? 'noir' : 'modern';
      
      const result = await kleinNetwork.activateSystem('novel-writer', {
        mode: 'video-script',
        style
      }) as any;
      
      return `**Video Script (${style})**\n\n**Scenes:**\n${result.scenes.map((s: string) => `\`${s}\``).join('\n')}\n\n**Dialogue:**\n${result.dialogue.map((d: string) => `> ${d}`).join('\n\n')}\n\n**Camera Shots:**\n${result.shots.map((s: string) => `- ${s}`).join('\n')}`;
    }
  },
  {
    intent: 'paraphrase',
    patterns: [
      /paraphrase\s+(?:this\s*[:\-]?\s*)?(.+)/is,
      /rewrite\s+(?:this\s*[:\-]?\s*)?(.+)/is,
      /simplify\s+(?:this\s*[:\-]?\s*)?(.+)/is,
      /rephrase\s+(?:this\s*[:\-]?\s*)?(.+)/is
    ],
    systems: ['paraphraser'],
    handler: async (match, text) => {
      const content = match[1]?.trim() || text;
      const mode = text.includes('simplify') ? 'simplify' : text.includes('expand') ? 'expand' : text.includes('summarize') ? 'summarize' : 'essay';
      
      const result = await kleinNetwork.activateSystem('paraphraser', {
        text: content,
        config: { mode, readingLevel: 'high-school', format: 'paragraph', preserveTone: true }
      }) as any;
      
      return `**Paraphrase (${mode}):**\n${result.paraphrase}\n\n---\n*Original reading level: ${result.readingLevel.toFixed(1)}*\n*Outline:*\n${result.outline.slice(0, 3).join('\n')}`;
    }
  },
  {
    intent: 'explain_code',
    patterns: [
      /explain\s+(?:this\s+)?code\s*[:\-]?\s*(.+)/is,
      /what\s+does\s+(?:this\s+)?code\s+(?:do|mean)/i,
      /document\s+(?:this\s+)?code\s*[:\-]?\s*(.+)/is,
      /code\s+explanation/i
    ],
    systems: ['paraphraser'],
    handler: async (match, text) => {
      const code = match[1]?.trim() || text;
      const level = text.includes('beginner') ? 'beginner' : text.includes('advanced') ? 'advanced' : 'intermediate';
      
      const result = await kleinNetwork.activateSystem('paraphraser', {
        text: code,
        config: { mode: 'explain-code', level }
      });
      
      return `**Code Explanation (${level}):**\n\`\`\`\n${result}\n\`\`\``;
    }
  },
  {
    intent: 'change_style',
    patterns: [
      /change\s+(?:the\s+)?style\s+(?:of\s+)?(.+)\s+(?:to\s+)(.+)/i,
      /make\s+(?:this\s+)?(.+)\s+(?:more\s+)?(formal|casual|technical|poetic|noir)/i,
      /rewrite\s+(?:this\s+)?(.+)\s+(?:in\s+)([\w\s]+)\s+style/i
    ],
    systems: ['style-controller'],
    handler: async (match, text) => {
      const content = match[1]?.trim() || text;
      const profile = match[2]?.trim().toLowerCase() || 'formal';
      
      const result = await kleinNetwork.activateSystem('style-controller', {
        text: content,
        profile
      }) as any;
      
      return `**Style Transform (${profile}):**\n${result.transformed}\n\n---\n*Applied ${result.appliedRules.length} rules:*\n${result.appliedRules.map((r: any) => `- ${r.description} (${r.category})`).join('\n')}`;
    }
  },
  {
    intent: 'analyze_semantics',
    patterns: [
      /what\s+(?:is|does)\s+(.+)\s+mean/i,
      /define\s+(.+)/i,
      /semantic\s+analysis\s+(?:of\s+)?(.+)/i,
      /distributional\s+(?:analysis|semantics)/i
    ],
    systems: ['diseminer'],
    handler: async (match, _text) => {
      const query = match[1]?.trim() || match[0];
      
      const result = await kleinNetwork.activateSystem('diseminer', {
        text: query
      }) as any;
      
      return `**Semantic Analysis:**\n*Query:* ${result.query}\n\n*Answer:* ${result.answer}\n\n*Confidence:* ${(result.confidence * 100).toFixed(1)}%\n\n*Inference Chain:*\n${result.inferenceChain.slice(0, 5).map((s: string) => `- ${s}`).join('\n')}`;
    }
  },
  {
    intent: 'analyze_code_semantics',
    patterns: [
      /analyze\s+(?:this\s+)?code\s*[:\-]?\s*(.+)/is,
      /what\s+pattern(s)?\s+(?:is|are)\s+(?:in\s+)?(?:this\s+)?code/i,
      /code\s+(?:pattern|semantic|structure)\s+analysis/i
    ],
    systems: ['diseminer'],
    handler: async (match, _text) => {
      const code = match[1]?.trim() || match[0];
      
      const result = await kleinNetwork.activateSystem('diseminer', {
        text: code,
        type: 'code'
      }) as any;
      
      return `**Code Semantic Analysis:**\n${result.answer}\n\n*Detected Patterns:*\n${result.inferenceChain.slice(0, 5).map((s: string) => `- ${s}`).join('\n')}`;
    }
  },
  {
    intent: 'learn_language',
    patterns: [
      /learn\s+(?:a\s+)?language/i,
      /language\s+learning/i,
      /pattern\s+learning/i,
      /teach\s+me\s+(?:about\s+)?(.+)/i
    ],
    systems: ['autoling'],
    handler: async (_match, text) => {
      const result = autoling.processInput(text);
      
      return `**AUTOLING Analysis:**\n${result.response}\n\n*Patterns Learned:* ${result.learned.length}\n*Confidence:* ${(result.confidence * 100).toFixed(1)}%`;
    }
  },
  {
    intent: 'simulate_evolution',
    patterns: [
      /simulate\s+(?:language\s+)?evolution/i,
      /run\s+(?:a\s+)?simulation/i,
      /Monte\s+Carlo\s+simulation/i,
      /language\s+change\s+simulator/i
    ],
    systems: ['simulator'],
    handler: async () => {
      const state = simulator.step();
      const stats = simulator.getStats();
      
      return `**Simulation Step ${state.tick}**\n\n*Community Stats:*\n- Speakers: ${stats.population}\n- Avg Rules/Speaker: ${stats.avgRulesPerSpeaker}\n- Community Rules: ${stats.communityRules}\n- Stability: ${stats.stability}\n\n*Recent Events:*\n${state.events.slice(0, 3).map((e: any) => `- ${e.type}: ${e.description}`).join('\n') || 'No events this tick'}`;
    }
  },
  {
    intent: 'parse_structure',
    patterns: [
      /parse\s+(?:this\s+)?(.+)/i,
      /analyze\s+(?:the\s+)?(structure|syntax|grammar)/i,
      /grammatical\s+(?:analysis|coding)/i,
      /POS\s+tag/i
    ],
    systems: ['grammar-coder'],
    handler: async (match, _text) => {
      const content = match[1]?.trim() || match[0];
      
      const result = await kleinNetwork.activateSystem('grammar-coder', {
        text: content
      }) as any;
      
      const coded = result.codedWords.slice(0, 10).map((cw: any) => `${cw.token} \u2192 [${cw.pos}]`).join('\n');
      
      return `**Grammatical Coding:**\n*Pattern:* ${result.structuralPattern}\n\n*Coded Words:*\n${coded}${result.codedWords.length > 10 ? `\n... (${result.codedWords.length - 10} more)` : ''}`;
    }
  },
  {
    intent: 'code_complexity',
    patterns: [
      /complexity\s+(?:of\s+)?(?:this\s+)?code/i,
      /analyze\s+(?:this\s+)?code\s+complexity/i,
      /code\s+metrics/i,
      /cyclomatic\s+complexity/i
    ],
    systems: ['grammar-coder'],
    handler: async (_match, text) => {
      const result = await kleinNetwork.activateSystem('grammar-coder', {
        text,
        action: 'complexity'
      }) as any;
      
      return `**Code Complexity Metrics:**\n- Lines of Code: ${result.linesOfCode}\n- Token Count: ${result.tokenCount}\n- Cyclomatic Complexity: ${result.cyclomaticComplexity}\n- Halstead Length: ${result.halsteadLength}\n- Halstead Vocabulary: ${result.halsteadVocabulary}\n- Unique Operators: ${result.uniqueOperators}\n- Unique Operands: ${result.uniqueOperands}\n- Avg Line Length: ${result.averageLineLength.toFixed(1)}`;
    }
  },
  {
    intent: 'help',
    patterns: [
      /help/i,
      /what\s+(?:can\s+)?you\s+do/i,
      /capabilities/i,
      /commands/i,
      /how\s+do\s+(?:I|you)/i
    ],
    systems: [],
    handler: async () => {
      return `**Klein AI Systems - Available Commands:**

**Creation:**
- "Write me a story" - Generate narratives
- "Write code for [task]" - Generate code
- "Design a game" - Create game concepts
- "Write a video script" - Generate scripts

**Analysis:**
- "Paraphrase this: [text]" - Rewrite text
- "Explain this code: [code]" - Code explanation
- "Analyze this code" - Pattern detection
- "What does [term] mean" - Semantic analysis
- "Parse this: [text]" - Structural analysis
- "Code complexity" - Metrics calculation

**Transformation:**
- "Change style to [formal/casual/poetic]: [text]"
- "Make this more technical"

**Learning & Simulation:**
- "Teach me about [topic]" - Pattern learning
- "Simulate language evolution" - Run Monte Carlo sim

**Info:**
- "Show network" - View Klein Network
- "System status" - Check all systems`;
    }
  },
  {
    intent: 'show_network',
    patterns: [
      /show\s+(?:the\s+)?network/i,
      /network\s+(?:status|diagram)/i,
      /Klein\s+network/i,
      /system\s+(?:map|diagram)/i
    ],
    systems: [],
    handler: async () => {
      const status = kleinNetwork.getSystemStatus();
      return `**Klein Network Status:**\n${status.map(s => `- **${s.name}** (${s.year}): ${s.description} [${s.status}]`).join('\n')}`;
    }
  },
  {
    intent: 'system_status',
    patterns: [
      /system\s+status/i,
      /status\s+(?:of\s+)?(?:all\s+)?systems/i,
      /which\s+systems\s+(?:are\s+)?online/i
    ],
    systems: [],
    handler: async () => {
      const status = kleinNetwork.getSystemStatus();
      return `**All Systems Status:**\n${status.map(s => `- ${s.name}: ${s.status.toUpperCase()}`).join('\n')}`;
    }
  }
];

// ── CHATBOT ENGINE ────────────────────────────────────────────────
export class ChatbotEngine {
  private context: ChatContext;
  private personality: string;

  constructor(personality: string = 'helpful') {
    this.personality = personality;
    this.context = {
      messages: [],
      activeSystems: [],
      personality: personality as any,
      memory: {}
    };
  }

  setPersonality(p: string) {
    this.personality = p;
    this.context.personality = p as any;
  }

  getGreeting(): string {
    return PERSONALITIES[this.personality]?.greeting || PERSONALITIES.helpful.greeting;
  }

  async processMessage(text: string): Promise<ChatMessage> {
    const userMessage: ChatMessage = {
      id: `msg_${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now()
    };
    this.context.messages.push(userMessage);

    let response = '';
    let matchedSystem = '';
    
    for (const intent of INTENT_PATTERNS) {
      for (const pattern of intent.patterns) {
        const match = text.match(pattern);
        if (match) {
          matchedSystem = intent.systems[0] || '';
          try {
            response = await intent.handler(match, text);
          } catch (e) {
            response = `Error processing request: ${String(e)}`;
          }
          break;
        }
      }
      if (response) break;
    }

    if (!response) {
      try {
        const result = await kleinNetwork.activateSystem('diseminer', { text });
        response = `**Semantic Analysis:**\n${(result as any).answer || 'I understand your message. Try asking me to write a story, analyze code, paraphrase text, or run a simulation. Type "help" for all commands.'}`;
      } catch {
        response = 'I understand your message. Try asking me to write a story, analyze code, paraphrase text, or run a simulation. Type "help" for all commands.';
      }
    }

    const assistantMessage: ChatMessage = {
      id: `msg_${Date.now() + 1}`,
      role: 'assistant',
      content: response,
      timestamp: Date.now(),
      metadata: {
        systemUsed: matchedSystem,
        confidence: 0.85
      }
    };
    
    this.context.messages.push(assistantMessage);
    return assistantMessage;
  }

  getContext(): ChatContext {
    return this.context;
  }

  getPersonalities() {
    return Object.entries(PERSONALITIES).map(([key, val]) => ({ key, ...val }));
  }
}

export const chatbot = new ChatbotEngine();
