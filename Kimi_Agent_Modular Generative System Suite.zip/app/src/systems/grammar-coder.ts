// ═══════════════════════════════════════════════════════════════════
//  7. GRAMMAR CODER ENGINE (Klein & Simmons, 1963)
//  A Computational Approach to Grammatical Coding of English Words
//  Modern twist: Structure analyzer for code and natural language
// ═══════════════════════════════════════════════════════════════════

import type { CodedWord, GrammarCodeResult, ParseTree, ParseNode } from '@/types';

// ── PART OF SPEECH PATTERNS ───────────────────────────────────────
const POS_PATTERNS: Array<{ pattern: RegExp; pos: string; features: Record<string, string> }> = [
  // Articles/Determiners
  { pattern: /^(the|a|an)$/i, pos: 'DET', features: { type: 'article', definiteness: 'detect' } },
  // Pronouns
  { pattern: /^(I|me|my|mine)$/i, pos: 'PRON', features: { person: '1', number: 'singular', case: 'nominative' } },
  { pattern: /^(you|your|yours)$/i, pos: 'PRON', features: { person: '2', number: 'singular/plural' } },
  { pattern: /^(he|him|his|she|her|hers|it|its)$/i, pos: 'PRON', features: { person: '3', number: 'singular' } },
  { pattern: /^(we|us|our|ours|they|them|their|theirs)$/i, pos: 'PRON', features: { person: '1/3', number: 'plural' } },
  // Prepositions
  { pattern: /^(in|on|at|to|from|with|by|for|of|about|through|over|under|between|into|onto|off|up|down)$/i, pos: 'PREP', features: { type: 'spatial/temporal/relational' } },
  // Conjunctions
  { pattern: /^(and|but|or|nor|so|yet|for)$/i, pos: 'CONJ', features: { type: 'coordinating' } },
  { pattern: /^(because|although|though|while|since|if|unless|when|where|that|which|who|whom|whose)$/i, pos: 'CONJ', features: { type: 'subordinating' } },
  // Auxiliary verbs
  { pattern: /^(is|am|are|was|were|be|been|being)$/i, pos: 'AUX', features: { type: 'copula', tense: 'present/past' } },
  { pattern: /^(have|has|had|do|does|did|will|would|shall|should|can|could|may|might|must)$/i, pos: 'AUX', features: { type: 'modal/perfective' } },
  // Common nouns (detected by position and morphology)
  { pattern: /.*(tion|ment|ness|ity|er|or|ist|ism|hood|ship|dom|th)$/i, pos: 'N', features: { type: 'derived', countability: 'variable' } },
  // Adverbs
  { pattern: /.*ly$/i, pos: 'ADV', features: { type: 'manner', degree: 'positive' } },
  // Adjectives
  { pattern: /.*(ful|ous|ive|able|ible|al|ic|ish|less|like|ly)$/i, pos: 'ADJ', features: { type: 'descriptive', degree: 'positive' } },
  // Present tense verbs (3rd person)
  { pattern: /.*(s|es|ies)$/i, pos: 'V', features: { tense: 'present', person: '3', number: 'singular' } },
  // Past tense verbs
  { pattern: /.*(ed|ied)$/i, pos: 'V', features: { tense: 'past' } },
  // Present participle
  { pattern: /.*ing$/i, pos: 'V', features: { tense: 'present_participle', aspect: 'progressive' } },
  // Base form verbs (common)
  { pattern: /^(run|walk|go|come|see|take|make|get|know|think|say|tell|give|find|feel|become|leave|put|mean|keep|let|begin|seem|help|turn|start|hear|play|move|live|believe|bring|happen|write|stand|lose|pay|meet|include|continue|set|learn|change|lead|understand|watch|follow|stop|create|speak|read|spend|grow|open|walk|offer|remember|love|consider|appear|buy|wait|serve|die|send|expect|build|stay|fall|cut|reach|kill|remain|want|like|need|use|work|try|call|ask|show|look|use|find|give|tell|get|make|come|know|think|take|see|go|do|say|have|be)$/i, pos: 'V', features: { tense: 'base_form' } }
];

// ── CODE PATTERNS ─────────────────────────────────────────────────
const CODE_PATTERNS: Array<{ pattern: RegExp; pos: string; features: Record<string, string> }> = [
  // Keywords
  { pattern: /\b(function|def|fn)\b/, pos: 'KEYWORD', features: { type: 'function_declaration', scope: 'block' } },
  { pattern: /\b(const|let|var|val|final)\b/, pos: 'KEYWORD', features: { type: 'variable_declaration', mutability: 'variable' } },
  { pattern: /\b(class|struct|interface|trait|enum)\b/, pos: 'KEYWORD', features: { type: 'type_declaration', paradigm: 'oop' } },
  { pattern: /\b(if|else|elif|switch|case|match)\b/, pos: 'KEYWORD', features: { type: 'conditional', control_flow: 'branching' } },
  { pattern: /\b(for|while|do|loop|foreach|iter)\b/, pos: 'KEYWORD', features: { type: 'iteration', control_flow: 'looping' } },
  { pattern: /\b(return|yield|break|continue|throw)\b/, pos: 'KEYWORD', features: { type: 'control_transfer', scope: 'local' } },
  { pattern: /\b(import|require|use|include|from)\b/, pos: 'KEYWORD', features: { type: 'module_system', scope: 'file' } },
  { pattern: /\b(async|await|Promise|Future|Task)\b/, pos: 'KEYWORD', features: { type: 'async_construct', paradigm: 'concurrent' } },
  { pattern: /\b(try|catch|finally|except)\b/, pos: 'KEYWORD', features: { type: 'error_handling', safety: 'guarded' } },
  { pattern: /\b(new|this|self|super|static|virtual|override)\b/, pos: 'KEYWORD', features: { type: 'oop_construct', paradigm: 'object_oriented' } },
  { pattern: /\b(export|public|private|protected|internal)\b/, pos: 'KEYWORD', features: { type: 'visibility_modifier', scope: 'module' } },
  // Types
  { pattern: /\b(string|str|int|float|double|bool|char|void|any|number|String|Number|Boolean|Array|Object|Map|Set|Date|RegExp)\b/, pos: 'TYPE', features: { category: 'primitive/composite', system: 'static/dynamic' } },
  // Operators
  { pattern: /[=!]==?|[<>]=?|&&|\|\||[\+\-\*\/\%]=?|\+\+|\-\-|[\&\|\^\~\<\<\>\>]=?|=>/, pos: 'OPERATOR', features: { type: 'arithmetic/comparison/logical/assignment', arity: 'binary/unary' } },
  // Literals
  { pattern: /"[^"]*"|'[^']*'|`[^`]*`/, pos: 'LITERAL', features: { type: 'string', encoding: 'unicode' } },
  { pattern: /\b\d+\.?\d*\b/, pos: 'LITERAL', features: { type: 'numeric', format: 'decimal' } },
  { pattern: /\b(true|false|null|undefined|nil|None)\b/, pos: 'LITERAL', features: { type: 'boolean/null', value: 'constant' } },
  // Comments
  { pattern: /\/\/.*|\/\*[\s\S]*?\*\//, pos: 'COMMENT', features: { type: 'inline/block', executable: 'no' } },
  // Identifiers (function names)
  { pattern: /\b([a-zA-Z_][a-zA-Z0-9_]*)\s*\(/, pos: 'IDENTIFIER', features: { type: 'function_call', binding: 'dynamic/static' } },
  // Identifiers (general)
  { pattern: /\b[a-zA-Z_][a-zA-Z0-9_]*\b/, pos: 'IDENTIFIER', features: { type: 'variable', binding: 'lexical' } }
];

// ── ENGINE ────────────────────────────────────────────────────────
export class GrammarCoderEngine {
  private nounList: Set<string> = new Set([
    'man', 'woman', 'child', 'dog', 'cat', 'house', 'car', 'tree', 'book', 'table',
    'computer', 'program', 'system', 'language', 'word', 'sentence', 'idea', 'time',
    'place', 'person', 'thing', 'way', 'day', 'year', 'work', 'world', 'life', 'hand',
    'part', 'eye', 'head', 'problem', 'question', 'answer', 'number', 'group', 'company'
  ]);

  code(input: string): GrammarCodeResult {
    const isCode = this.detectCode(input);
    
    if (isCode) {
      return this.analyzeCode(input);
    }

    return this.analyzeText(input);
  }

  private detectCode(input: string): boolean {
    const codeIndicators = [
      /\bfunction\b|\bconst\b|\blet\b|\bvar\b|\bclass\b/,
      /\bif\s*\(|\bfor\s*\(|\bwhile\s*\(/,
      /[{};]\s*$/m,
      /=>|\+\+|--|\|\||&&/,
      /\/\/.*|\/\*.*\*\//
    ];
    
    return codeIndicators.some(pattern => pattern.test(input));
  }

  private analyzeText(input: string): GrammarCodeResult {
    const tokens = input.match(/\b[\w']+\b|[.,!?;:]|[(){}[\]]/g) || [];
    const codedWords: CodedWord[] = [];

    tokens.forEach((token, index) => {
      const coded = this.codeWord(token, index, tokens);
      codedWords.push(coded);
    });

    const parseTree = this.buildParseTree(codedWords);
    const structuralPattern = this.inferStructuralPattern(codedWords);

    return {
      input,
      codedWords,
      parseTree,
      structuralPattern
    };
  }

  private codeWord(token: string, index: number, allTokens: string[]): CodedWord {
    const lower = token.toLowerCase();
    
    // Check patterns
    for (const { pattern, pos, features } of POS_PATTERNS) {
      if (pattern.test(token)) {
        return {
          token,
          pos,
          features: { ...features, position: String(index) },
          dependencies: this.findDependencies(token, index, allTokens),
          code: `${pos}.${Object.entries(features).map(([k, v]) => `${k}=${v}`).join('.')}`
        };
      }
    }

    // Check noun list
    if (this.nounList.has(lower)) {
      return {
        token,
        pos: 'N',
        features: { type: 'common', countability: 'countable' },
        dependencies: this.findDependencies(token, index, allTokens),
        code: `N.common.countable.pos=${index}`
      };
    }

    // Default
    return {
      token,
      pos: 'UNK',
      features: { inferred: 'true' },
      dependencies: this.findDependencies(token, index, allTokens),
      code: `UNK.inferred.pos=${index}`
    };
  }

  private findDependencies(_token: string, index: number, allTokens: string[]): string[] {
    const deps: string[] = [];
    
    // Look for adjacent dependencies
    if (index > 0) deps.push(allTokens[index - 1]);
    if (index < allTokens.length - 1) deps.push(allTokens[index + 1]);
    
    return deps;
  }

  private buildParseTree(codedWords: CodedWord[]): ParseTree {
    const nodes: ParseNode[] = [];
    
    // Build flat structure first
    codedWords.forEach((cw, i) => {
      nodes.push({
        id: `node_${i}`,
        label: `${cw.token} [${cw.pos}]`,
        children: [],
        start: i,
        end: i + 1
      });
    });

    // Attempt phrase grouping (simplified)
    const phraseGroups: ParseNode[] = [];
    let currentPhrase: CodedWord[] = [];
    
    codedWords.forEach((cw) => {
      if (cw.pos === 'DET' || cw.pos === 'ADJ' || cw.pos === 'N') {
        currentPhrase.push(cw);
      } else {
        if (currentPhrase.length > 0) {
          const start = codedWords.indexOf(currentPhrase[0]);
          phraseGroups.push({
            id: `np_${phraseGroups.length}`,
            label: `NP (${currentPhrase.map(p => p.token).join(' ')})`,
            children: currentPhrase.map((_, i) => `node_${start + i}`),
            start,
            end: start + currentPhrase.length
          });
          currentPhrase = [];
        }
      }
    });

    nodes.push(...phraseGroups);

    return {
      root: 'S',
      nodes,
      depth: phraseGroups.length > 0 ? 2 : 1,
      confidence: 0.7
    };
  }

  private inferStructuralPattern(codedWords: CodedWord[]): string {
    const pattern = codedWords.map(cw => cw.pos).join(' ');
    
    // Detect common patterns
    if (pattern.includes('DET N V')) return 'S -> NP VP (declarative)';
    if (pattern.includes('V N')) return 'S -> VP NP (imperative/inverted)';
    if (pattern.startsWith('AUX')) return 'S -> Aux NP VP (interrogative)';
    if (pattern.includes('PREP DET N')) return 'S -> NP PP (prepositional)';
    
    return `S -> ${pattern}`;
  }

  private analyzeCode(input: string): GrammarCodeResult {
    const tokens: Array<{ text: string; type: string }> = [];
    
    // Tokenize code
    let remaining = input;
    while (remaining.length > 0) {
      remaining = remaining.trimStart();
      if (remaining.length === 0) break;

      let matched = false;
      
      // Try to match code patterns
      for (const { pattern, pos } of CODE_PATTERNS) {
        const match = remaining.match(pattern);
        if (match && match.index === 0) {
          tokens.push({ text: match[0], type: pos });
          remaining = remaining.slice(match[0].length);
          matched = true;
          break;
        }
      }

      if (!matched) {
        // Skip unknown character
        tokens.push({ text: remaining[0], type: 'UNKNOWN' });
        remaining = remaining.slice(1);
      }
    }

    const codedWords: CodedWord[] = tokens.map((t, i) => ({
      token: t.text,
      pos: t.type,
      features: this.getCodeFeatures(t.type, t.text),
      dependencies: i > 0 ? [tokens[i - 1].text] : [],
      code: `${t.type}.${t.text}`
    }));

    const parseTree = this.buildCodeParseTree(tokens);
    const structuralPattern = this.inferCodePattern(tokens);

    return {
      input,
      codedWords,
      parseTree,
      structuralPattern
    };
  }

  private getCodeFeatures(type: string, _text: string): Record<string, string> {
    const featureMap: Record<string, Record<string, string>> = {
      KEYWORD: { reserved: 'true', syntactic: 'true' },
      IDENTIFIER: { user_defined: 'true', semantic: 'true' },
      LITERAL: { constant: 'true', evaluable: 'true' },
      OPERATOR: { operation: 'true', precedence: 'varies' },
      COMMENT: { executable: 'false', documentation: 'true' },
      TYPE: { type_system: 'true', annotation: 'true' }
    };

    return featureMap[type] || { unknown: 'true' };
  }

  private buildCodeParseTree(tokens: Array<{ text: string; type: string }>): ParseTree {
    const nodes: ParseNode[] = [];
    const blockStack: ParseNode[] = [];

    tokens.forEach((t, i) => {
      const node: ParseNode = {
        id: `token_${i}`,
        label: `${t.text} [${t.type}]`,
        children: [],
        start: i,
        end: i + 1
      };

      if (t.text === '{' || t.text === '(') {
        blockStack.push(node);
      } else if ((t.text === '}' || t.text === ')') && blockStack.length > 0) {
        const block = blockStack.pop()!;
        block.end = i + 1;
        block.label = `BLOCK (${block.start}-${block.end})`;
        nodes.push(block);
      } else {
        nodes.push(node);
      }
    });

    return {
      root: 'PROGRAM',
      nodes,
      depth: 3,
      confidence: 0.85
    };
  }

  private inferCodePattern(tokens: Array<{ text: string; type: string }>): string {
    const keywordSequence = tokens
      .filter(t => t.type === 'KEYWORD')
      .map(t => t.text)
      .join(' ');

    if (keywordSequence.includes('function') && keywordSequence.includes('return')) {
      return 'FUNC_DEF -> PARAMS -> BODY -> RETURN';
    }
    if (keywordSequence.includes('class') && keywordSequence.includes('constructor')) {
      return 'CLASS_DEF -> CONSTRUCTOR -> METHODS';
    }
    if (keywordSequence.includes('if') && keywordSequence.includes('else')) {
      return 'IF_THEN_ELSE -> CONDITIONAL_BRANCHING';
    }
    if (keywordSequence.includes('for') || keywordSequence.includes('while')) {
      return 'LOOP -> ITERATION -> BODY';
    }
    if (keywordSequence.includes('async') && keywordSequence.includes('await')) {
      return 'ASYNC_FUNC -> AWAIT_CALLS -> PROMISE_CHAIN';
    }
    if (keywordSequence.includes('try') && keywordSequence.includes('catch')) {
      return 'TRY_BLOCK -> CATCH_HANDLER -> FINALLY';
    }
    if (keywordSequence.includes('import') || keywordSequence.includes('require')) {
      return 'MODULE_IMPORT -> DEPENDENCY_RESOLUTION';
    }

    return `SEQUENCE -> ${keywordSequence || 'STATEMENTS'}`;
  }

  // Modern twist: Complexity metrics
  calculateComplexity(input: string): Record<string, number> {
    const lines = input.split('\n').filter(l => l.trim());
    const tokens = input.match(/\b\w+\b/g) || [];
    
    // Cyclomatic complexity approximation
    const decisions = (input.match(/\b(if|else|while|for|case|&&|\|\|)\b/g) || []).length;
    
    // Halstead metrics approximation
    const operators = new Set(input.match(/[\+\-\*\/=<>!&|:]+/g) || []);
    const operands = new Set(tokens);
    const halsteadLength = operators.size + operands.size;
    const halsteadVocabulary = new Set([...Array.from(operators), ...Array.from(operands)]).size;
    
    return {
      linesOfCode: lines.length,
      tokenCount: tokens.length,
      cyclomaticComplexity: decisions + 1,
      halsteadLength,
      halsteadVocabulary,
      uniqueOperators: operators.size,
      uniqueOperands: operands.size,
      averageLineLength: lines.reduce((sum, l) => sum + l.length, 0) / Math.max(lines.length, 1)
    };
  }
}

export const grammarCoder = new GrammarCoderEngine();
