// ═══════════════════════════════════════════════════════════════════
//  2. AUTO-PARAPHRASER ENGINE (Sheldon Klein, 1965)
//  Modern twist: Text paraphrasing with code explanation, simplification
// ═══════════════════════════════════════════════════════════════════

import type { ParaphraseConfig, ParaphraseResult, DependencyLink } from '@/types';

// ── DEPENDENCY PARSER (Simplified) ────────────────────────────────
class DependencyParser {
  parse(text: string): DependencyLink[] {
    const links: DependencyLink[] = [];
    const sentences = text.split(/[.!?]+/).filter(s => s.trim());

    sentences.forEach(sentence => {
      const words = sentence.trim().split(/\s+/);
      const subject = this.findSubject(sentence);
      const verb = this.findVerb(sentence);
      const object = this.findObject(sentence);

      if (subject && verb) {
        links.push({ source: subject, target: verb, relation: 'subject-verb', strength: 1.0 });
      }
      if (verb && object) {
        links.push({ source: verb, target: object, relation: 'verb-object', strength: 0.9 });
      }

      // Find modifiers
      words.forEach((word, i) => {
        if (word.length > 4 && !this.isStopWord(word)) {
          const prev = words[i - 1];
          if (prev && this.isAdjective(prev)) {
            links.push({ source: word, target: prev, relation: 'modification', strength: 0.7 });
          }
        }
      });
    });

    return links;
  }

  private findSubject(sentence: string): string {
    const match = sentence.match(/(?:^|\s)(?:the|a|an|this|that)?\s*([A-Z][a-z]+)/);
    return match ? match[1] : '';
  }

  private findVerb(sentence: string): string {
    const match = sentence.match(/\b(is|was|are|were|has|had|does|did|goes|went|makes|made|takes|took|runs|ran|sees|saw|knows|knew|thinks|thought|says|said|wants|wanted|gives|gave|finds|found|tells|told|feels|felt|becomes|became|shows|showed|leaves|left|puts|put|means|meant|keeps|kept|lets|let|begins|began|seems|seemed|helps|helped|turns|turned|starts|started|hears|heard|plays|played|moves|moved|lives|lived|believes|believed|brings|brought|happens|happened|stands|stood|loses|lost|pays|paid|meets|met|includes|included|continues|continued|remains|remained|follows|followed|stops|stopped|creates|created|speaks|spoke|reads|read|spends|spent|grows|grew|opens|opened|walks|walked|offers|offered|remembers|remembered|loves|loved|considers|considered|appears|appeared|buys|bought|waits|waited|serves|served|dies|died|sends|sent|expects|expected|builds|built|stays|stayed|falls|fell|cuts|cut|reaches|reached|kills|killed|remains|stayed)\b/i);
    return match ? match[1] : '';
  }

  private findObject(sentence: string): string {
    const match = sentence.match(/\b(?:the|a|an|this|that)\s+([a-z]+(?:\s+[a-z]+){0,2})\s*(?:$|[.!?])/i);
    return match ? match[1] : '';
  }

  private isStopWord(word: string): boolean {
    const stops = new Set(['the', 'a', 'an', 'is', 'was', 'are', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'must', 'shall', 'can', 'need', 'dare', 'ought', 'used', 'to', 'of', 'in', 'for', 'on', 'with', 'at', 'by', 'from', 'as', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'between', 'out', 'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 'just', 'and', 'but', 'if', 'or', 'because', 'until', 'while']);
    return stops.has(word.toLowerCase());
  }

  private isAdjective(word: string): boolean {
    const adjs = ['big', 'small', 'large', 'tiny', 'great', 'good', 'bad', 'new', 'old', 'young', 'long', 'short', 'high', 'low', 'early', 'late', 'rich', 'poor', 'dark', 'light', 'strong', 'weak', 'fast', 'slow', 'hot', 'cold', 'warm', 'cool', 'clean', 'dirty', 'deep', 'shallow', 'wide', 'narrow', 'thick', 'thin', 'heavy', 'light', 'full', 'empty', 'beautiful', 'ugly', 'smart', 'dumb', 'happy', 'sad', 'angry', 'calm', 'brave', 'afraid', 'loud', 'quiet', 'sharp', 'dull', 'smooth', 'rough', 'soft', 'hard', 'sweet', 'bitter', 'bright', 'dim'];
    return adjs.includes(word.toLowerCase());
  }
}

// ── PARAPHRASE TEMPLATES ─────────────────────────────────────────
const TEMPLATES = {
  essay: {
    elementary: (text: string) => `Here is what this means in simple words:\n\n${text}\n\nTo put it simply, the main idea is about understanding how things work together.`,
    highSchool: (text: string) => `This passage discusses several important concepts. ${text.substring(0, 100)}... The key points involve understanding relationships between different elements and how they interact.`,
    college: (text: string) => `An analysis of the provided text reveals complex interdependencies. ${text.substring(0, 80)}... These phenomena suggest broader implications for the field of study.`,
    expert: (text: string) => `The discourse presents a multifaceted examination of the subject matter, particularly noting ${text.substring(0, 60)}... These findings corroborate existing theoretical frameworks while introducing novel perspectives.`
  },
  simplify: {
    elementary: (text: string) => text
      .replace(/utilize/g, 'use').replace(/demonstrate/g, 'show').replace(/approximately/g, 'about')
      .replace(/significant/g, 'big').replace(/implementation/g, 'doing').replace(/methodology/g, 'way')
      .replace(/nevertheless/g, 'but').replace(/furthermore/g, 'also').replace(/consequently/g, 'so'),
    highSchool: (text: string) => text
      .replace(/utilize/g, 'use').replace(/demonstrate/g, 'show').replace(/approximately/g, 'about')
      .replace(/significant/g, 'important').replace(/implementation/g, 'putting into practice'),
    college: (text: string) => text,
    expert: (text: string) => text
  },
  'explain-code': {
    elementary: (text: string) => `// This code does the following:\n// 1. It takes some information\n// 2. It changes that information\n// 3. It gives back a result\n\n${text}`,
    highSchool: (text: string) => `/*\n * This function processes input data by:\n * - Receiving parameters\n * - Applying transformations\n * - Returning the computed result\n */\n${text}`,
    college: (text: string) => `/**\n * @description Implements a transformation pipeline that accepts\n * structured input, applies domain-specific operations, and\n * yields the processed output according to specification.\n */\n${text}`,
    expert: (text: string) => `/**\n * @complexity O(n log n) amortized\n * @param {T[]} input - Generic typed array conforming to IterableProtocol\n * @returns {Promise<R>} - Async result wrapped in monadic container\n * @throws {DomainException} On invariant violation\n * @note Thread-safe under RCU read-side critical sections\n */\n${text}`
  },
  expand: {
    elementary: (text: string) => `${text}\n\nLet me explain more. ${text} This is important because it helps us understand how things are connected. When we look closer, we see even more details that matter.`,
    highSchool: (text: string) => `${text}\n\nExpanding on this point, it is worth noting that ${text.toLowerCase()} represents a significant development in the field. The implications extend beyond the immediate context, suggesting broader applications and theoretical contributions that merit further investigation.`,
    college: (text: string) => `${text}\n\nA more comprehensive examination reveals that ${text.toLowerCase()} operates within a complex ecosystem of interrelated variables. The theoretical underpinnings suggest a need for multidisciplinary approaches, incorporating insights from adjacent fields to fully apprehend the scope and limitations of these findings.`,
    expert: (text: string) => `${text}\n\nThe preceding analysis, while substantive, warrants epistemological scrutiny. ${text.substring(0, 50)}... constitutes merely a surface-level treatment of phenomena whose ontological status remains contested. A parsimonious yet theoretically robust framework demands integration of constructivist, positivist, and critical realist paradigms to adequately capture the recursive nature of these processes.`
  },
  summarize: {
    elementary: (text: string) => `The main point is: ${text.split('.')[0]}.`,
    highSchool: (text: string) => `In summary, the text addresses ${text.split('.')[0].toLowerCase()}, highlighting key aspects that contribute to our understanding of the subject.`,
    college: (text: string) => `The foregoing analysis consolidates several key findings: (1) ${text.split('.')[0]}, (2) the interdependence of constituent elements, and (3) implications for future research trajectories.`,
    expert: (text: string) => `Synthesizing the extant literature, this work advances a theoretically grounded conceptualization wherein ${text.split('.')[0].toLowerCase()} emerges as a contingent, recursively constituted phenomenon requiring situated, practice-based inquiry.`
  }
};

// ── ENGINE ────────────────────────────────────────────────────────
export class ParaphraserEngine {
  private parser: DependencyParser;

  constructor() {
    this.parser = new DependencyParser();
  }

  paraphrase(text: string, config: ParaphraseConfig): ParaphraseResult {
    const dependencies = this.parser.parse(text);
    const level = config.readingLevel;
    const mode = config.mode;

    const template = TEMPLATES[mode]?.[level] || TEMPLATES.simplify.highSchool;
    const paraphrase = template(text);

    // Generate outline
    const sentences = text.match(/[^.!?]+[.!?]+/g) || [text];
    const outline = sentences.map((s, i) => `${i + 1}. ${s.trim().substring(0, 50)}${s.length > 50 ? '...' : ''}`);

    // Calculate reading level (Flesch-Kincaid inspired)
    const words = text.split(/\s+/).length;
    const sentences_count = sentences.length;
    const syllables = text.split(/\s+/).reduce((acc, w) => acc + this.countSyllables(w), 0);
    const readingLevel = Math.max(1, Math.min(20, 
      0.39 * (words / Math.max(sentences_count, 1)) + 
      11.8 * (syllables / Math.max(words, 1)) - 15.59
    ));

    return {
      original: text,
      paraphrase,
      outline,
      dependencies,
      mode,
      readingLevel
    };
  }

  private countSyllables(word: string): number {
    const vowels = 'aeiouy';
    let count = 0;
    let prevWasVowel = false;
    for (const char of word.toLowerCase()) {
      const isVowel = vowels.includes(char);
      if (isVowel && !prevWasVowel) count++;
      prevWasVowel = isVowel;
    }
    return Math.max(1, count);
  }

  // Modern twist: Explain code
  explainCode(code: string, level: 'beginner' | 'intermediate' | 'advanced'): string {
    const explanations: Record<string, string> = {
      beginner: this.explainForBeginner(code),
      intermediate: this.explainForIntermediate(code),
      advanced: this.explainForAdvanced(code)
    };
    return explanations[level] || explanations.beginner;
  }

  private explainForBeginner(code: string): string {
    const lines = code.split('\n');
    let explanation = '// STEP-BY-STEP EXPLANATION:\n';
    
    lines.forEach((line, i) => {
      const trimmed = line.trim();
      if (trimmed.startsWith('//') || trimmed.startsWith('*')) {
        explanation += `// Line ${i + 1}: This is a comment (notes for humans)\n`;
      } else if (trimmed.includes('function') || trimmed.includes('=>')) {
        explanation += `// Line ${i + 1}: This creates an action the computer can do\n`;
      } else if (trimmed.includes('const ') || trimmed.includes('let ') || trimmed.includes('var ')) {
        explanation += `// Line ${i + 1}: This stores information in a labeled box\n`;
      } else if (trimmed.includes('if ') || trimmed.includes('else')) {
        explanation += `// Line ${i + 1}: This makes a decision\n`;
      } else if (trimmed.includes('for ') || trimmed.includes('while')) {
        explanation += `// Line ${i + 1}: This repeats something\n`;
      } else if (trimmed.includes('return')) {
        explanation += `// Line ${i + 1}: This sends back a result\n`;
      } else if (trimmed.includes('class ')) {
        explanation += `// Line ${i + 1}: This defines a blueprint for objects\n`;
      } else if (trimmed.trim()) {
        explanation += `// Line ${i + 1}: This does something with the data\n`;
      }
    });
    
    return explanation;
  }

  private explainForIntermediate(code: string): string {
    const lines = code.split('\n');
    let explanation = '/*\n * ARCHITECTURAL OVERVIEW:\n';
    
    let inFunction = false;
    
    lines.forEach((line) => {
      const trimmed = line.trim();
      if (trimmed.includes('class ')) {
        explanation += ` * - Defines a ${this.extractName(trimmed, 'class')} class (encapsulation boundary)\n`;
      } else if (trimmed.includes('constructor')) {
        explanation += ` * - Constructor initializes instance state\n`;
      } else if (trimmed.match(/\b(function|=>)\b/) && !inFunction) {
        inFunction = true;
        explanation += ` * - ${this.extractName(trimmed, 'function')} handles ${this.inferPurpose(trimmed)}\n`;
      } else if (trimmed.includes('async')) {
        explanation += ` * - Uses async/await for non-blocking I/O\n`;
      } else if (trimmed.includes('try') || trimmed.includes('catch')) {
        explanation += ` * - Implements error handling for resilience\n`;
      }
    });
    
    explanation += ' */';
    return explanation;
  }

  private explainForAdvanced(code: string): string {
    return `/**\n * @analysis\n * Time Complexity: ${this.inferComplexity(code)}\n * Space Complexity: ${this.inferSpaceComplexity(code)}\n * Pattern: ${this.inferPattern(code)}\n * Potential Optimizations: ${this.suggestOptimizations(code)}\n */`;
  }

  private extractName(line: string, type: string): string {
    const match = line.match(new RegExp(`${type}\\s+(\\w+)`));
    return match ? match[1] : 'anonymous';
  }

  private inferPurpose(line: string): string {
    const purposes: Record<string, string> = {
      'fetch': 'data retrieval', 'get': 'data access', 'set': 'data mutation',
      'create': 'resource creation', 'delete': 'resource removal', 'update': 'state synchronization',
      'process': 'data transformation', 'render': 'view generation', 'handle': 'event processing',
      'validate': 'input verification', 'parse': 'structure extraction', 'transform': 'data mapping'
    };
    for (const [key, value] of Object.entries(purposes)) {
      if (line.toLowerCase().includes(key)) return value;
    }
    return 'data processing';
  }

  private inferComplexity(code: string): string {
    if (code.includes('for') && code.match(/for.*for/s)) return 'O(n^2) - nested iteration';
    if (code.includes('while')) return 'O(n) - linear scan with condition';
    if (code.includes('recur')) return 'O(2^n) - recursive branching';
    if (code.includes('sort')) return 'O(n log n) - comparison sort';
    return 'O(n) - single pass';
  }

  private inferSpaceComplexity(code: string): string {
    if (code.includes('new Array') || code.includes('[]')) return 'O(n) - array storage';
    if (code.includes('Map') || code.includes('Set')) return 'O(n) - hash table overhead';
    if (code.includes('recur')) return 'O(log n) - call stack depth';
    return 'O(1) - constant space';
  }

  private inferPattern(code: string): string {
    if (code.includes('class') && code.includes('extends')) return 'Inheritance/Template Method';
    if (code.includes('=>') && code.includes('map')) return 'Functional/Map-Reduce';
    if (code.includes('Promise') || code.includes('async')) return 'Async/Concurrent';
    if (code.includes('factory') || code.includes('create')) return 'Factory/Creational';
    if (code.includes('observer') || code.includes('emit')) return 'Observer/Event-Driven';
    return 'Procedural';
  }

  private suggestOptimizations(code: string): string {
    const suggestions: string[] = [];
    if (code.includes('for') && !code.includes('break')) suggestions.push('early termination');
    if (!code.includes('cache') && code.includes('fetch')) suggestions.push('memoization');
    if (code.includes('+') && code.includes('for')) suggestions.push('StringBuilder for string concatenation');
    if (!code.includes('try')) suggestions.push('add error boundaries');
    return suggestions.length > 0 ? suggestions.join(', ') : 'none apparent';
  }
}

export const paraphraser = new ParaphraserEngine();
