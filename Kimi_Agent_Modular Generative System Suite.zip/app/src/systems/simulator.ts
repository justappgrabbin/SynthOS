// ═══════════════════════════════════════════════════════════════════
//  6. HISTORICAL CHANGE SIMULATOR (Sheldon Klein, 1966)
//  Monte Carlo Simulation of Language Change
//  Modern twist: Evolution simulator for languages, code, patterns
// ═══════════════════════════════════════════════════════════════════

import type { Speaker, GrammarRule, LanguageChangeEvent, SimulationState, SimulatorConfig } from '@/types';

// ── INITIAL RULE SETS ─────────────────────────────────────────────
const INITIAL_RULES: Record<string, string[]> = {
  language: [
    'S -> NP VP', 'NP -> Det N', 'NP -> N', 'VP -> V NP', 'VP -> V',
    'Det -> the', 'Det -> a', 'N -> man', 'N -> woman', 'N -> child',
    'N -> dog', 'N -> cat', 'V -> sees', 'V -> chases', 'V -> loves',
    'V -> eats', 'Adj -> big', 'Adj -> small', 'NP -> Adj N',
    'Adv -> quickly', 'Adv -> slowly', 'VP -> V Adv'
  ],
  'code-evolution': [
    'FUNC -> keyword IDENT PARAMS BLOCK',
    'VAR -> type IDENT = value',
    'IF -> if ( COND ) BLOCK ELSE',
    'LOOP -> for ( INIT ; COND ; STEP ) BLOCK',
    'CLASS -> class IDENT { MEMBERS }',
    'CALL -> IDENT ( ARGS )',
    'IMPORT -> import PATH from STRING',
    'EXPORT -> export DEFAULT IDENT',
    'ASYNC -> async FUNC',
    'DESTRUCTURE -> const { FIELDS } = OBJ'
  ],
  'pattern-drift': [
    'PATTERN -> Observer SUBJECT NOTIFY',
    'PATTERN -> Factory TYPE CREATE',
    'PATTERN -> Singleton INSTANCE ACCESS',
    'PATTERN -> Strategy ALGORITHM SWITCH',
    'PATTERN -> Decorator WRAPPER ENHANCE',
    'PATTERN -> MVC MODEL VIEW CONTROLLER',
    'PATTERN -> REST RESOURCE HTTP_METHOD',
    'PATTERN -> Microservice SERVICE API',
    'PATTERN -> EventSource STREAM EVENTS',
    'PATTERN -> CQRS COMMAND QUERY SPLIT'
  ]
};

// ── ENGINE ────────────────────────────────────────────────────────
export class HistoricalChangeEngine {
  private state: SimulationState;
  private config: SimulatorConfig;
  private rng: () => number;
  private eventLog: LanguageChangeEvent[] = [];
  constructor(config: Partial<SimulatorConfig> = {}) {
    this.config = {
      population: config.population || 20,
      generations: config.generations || 50,
      initialRules: config.initialRules || 10,
      socialGroups: config.socialGroups || 3,
      mutationRate: config.mutationRate || 0.1,
      mode: config.mode || 'language'
    };

    // Seeded RNG for reproducibility
    let seed = 42;
    this.rng = () => {
      seed = (seed * 16807 + 0) % 2147483647;
      return (seed - 1) / 2147483646;
    };

    this.state = this.initializeState();
  }

  private initializeState(): SimulationState {
    const speakers: Speaker[] = [];
    const ruleTemplates = INITIAL_RULES[this.config.mode] || INITIAL_RULES.language;
    
    // Create initial grammar
    const baseGrammar: GrammarRule[] = ruleTemplates.slice(0, this.config.initialRules).map((rule, i) => ({
      id: `rule_${i}`,
      lhs: rule.split(' -> ')[0],
      rhs: rule.split(' -> ')[1]?.split(' ') || [],
      frequency: Math.floor(this.rng() * 50) + 50,
      confirmed: true
    }));

    // Create speakers in social groups
    for (let i = 0; i < this.config.population; i++) {
      const groupId = i % this.config.socialGroups;
      speakers.push({
        id: `speaker_${i}`,
        age: Math.floor(this.rng() * 60) + 20,
        status: Math.floor(this.rng() * 10) + 1,
        grammar: this.cloneGrammar(baseGrammar),
        socialGroup: `group_${groupId}`,
        birthTick: 0
      });
    }

    return {
      tick: 0,
      speakers,
      events: [],
      communityGrammar: baseGrammar,
      stability: 1.0
    };
  }

  private cloneGrammar(grammar: GrammarRule[]): GrammarRule[] {
    return grammar.map(r => ({
      ...r,
      rhs: [...r.rhs],
      frequency: r.frequency + Math.floor(this.rng() * 10) - 5
    }));
  }

  step(): SimulationState {
    this.state.tick++;
    const events: LanguageChangeEvent[] = [];

    // 1. Social interactions
    for (let i = 0; i < this.config.population; i++) {
      const speaker = this.state.speakers[i];
      
      // Find interaction partner (biased toward same social group)
      let partnerIndex: number;
      if (this.rng() < 0.7) {
        // Same group
        const sameGroup = this.state.speakers.filter((s, idx) => 
          idx !== i && s.socialGroup === speaker.socialGroup
        );
        partnerIndex = sameGroup.length > 0 
          ? this.state.speakers.indexOf(sameGroup[Math.floor(this.rng() * sameGroup.length)])
          : (i + 1) % this.config.population;
      } else {
        // Different group
        partnerIndex = Math.floor(this.rng() * this.config.population);
      }

      const partner = this.state.speakers[partnerIndex];

      // Rule adoption
      if (this.rng() < this.config.mutationRate * speaker.status / 10) {
        const foreignRules = partner.grammar.filter(pr => 
          !speaker.grammar.some(sr => sr.lhs === pr.lhs && sr.rhs.join(' ') === pr.rhs.join(' '))
        );

        if (foreignRules.length > 0) {
          const adopted = foreignRules[Math.floor(this.rng() * foreignRules.length)];
          const newRule: GrammarRule = {
            id: `rule_${Date.now()}_${i}`,
            lhs: adopted.lhs,
            rhs: [...adopted.rhs],
            frequency: 10,
            confirmed: false
          };
          speaker.grammar.push(newRule);
          
          events.push({
            tick: this.state.tick,
            speaker: speaker.id,
            type: 'rule-adoption',
            description: `${speaker.id} adopted rule from ${partner.id}`,
            magnitude: 0.5
          });
        }
      }

      // Rule frequency shift (reinforcement)
      const sharedRules = speaker.grammar.filter(sr => 
        partner.grammar.some(pr => pr.lhs === sr.lhs)
      );
      
      sharedRules.forEach(rule => {
        rule.frequency = Math.min(100, rule.frequency + 1);
      });
    }

    // 2. Rule decay and loss
    this.state.speakers.forEach(speaker => {
      speaker.grammar = speaker.grammar.filter(rule => {
        if (rule.frequency < 5 && this.rng() < 0.3) {
          events.push({
            tick: this.state.tick,
            speaker: speaker.id,
            type: 'rule-loss',
            description: `${speaker.id} lost rule ${rule.lhs} -> ${rule.rhs.join(' ')}`,
            magnitude: 0.3
          });
          return false;
        }
        // Slight decay
        if (!rule.confirmed) {
          rule.frequency = Math.max(0, rule.frequency - 0.5);
        }
        return true;
      });
    });

    // 3. Innovation (spontaneous new rules)
    if (this.rng() < this.config.mutationRate * 0.1) {
      const innovator = this.state.speakers[Math.floor(this.rng() * this.config.population)];
      const newRule = this.generateInnovation(innovator);
      innovator.grammar.push(newRule);
      
      events.push({
        tick: this.state.tick,
        speaker: innovator.id,
        type: 'innovation',
        description: `${innovator.id} innovated: ${newRule.lhs} -> ${newRule.rhs.join(' ')}`,
        magnitude: 0.8
      });
    }

    // 4. Birth and death
    if (this.state.tick % 20 === 0) {
      // Aging
      this.state.speakers.forEach(s => {
        s.age++;
        if (s.age > 80 && this.rng() < 0.3) {
          // Death - replace with child
          events.push({
            tick: this.state.tick,
            speaker: s.id,
            type: 'rule-loss',
            description: `${s.id} died, grammar lost`,
            magnitude: 1.0
          });
          
          // Child inherits from random "parent"
          const parent = this.state.speakers[Math.floor(this.rng() * this.config.population)];
          s.age = 0;
          s.birthTick = this.state.tick;
          s.grammar = this.cloneGrammar(parent.grammar.filter(r => r.confirmed || r.frequency > 20));
          s.status = 1;
        }
      });
    }

    // 5. Calculate community grammar and stability
    this.updateCommunityGrammar();
    this.calculateStability();

    this.state.events = events;
    this.eventLog.push(...events);

    return { ...this.state };
  }

  private generateInnovation(speaker: Speaker): GrammarRule {
    const existing = speaker.grammar;
    const lhs = existing[Math.floor(this.rng() * existing.length)]?.lhs || 'S';
    
    // Create a variation
    const rhs = ['X', 'Y', lhs];
    if (this.rng() < 0.5) {
      rhs.push('Z');
    }

    return {
      id: `innovation_${Date.now()}`,
      lhs,
      rhs,
      frequency: 15,
      confirmed: false
    };
  }

  private updateCommunityGrammar() {
    const ruleCounts: Map<string, { rule: GrammarRule; count: number }> = new Map();

    this.state.speakers.forEach(s => {
      s.grammar.forEach(r => {
        const key = `${r.lhs} -> ${r.rhs.join(' ')}`;
        const existing = ruleCounts.get(key);
        if (existing) {
          existing.count++;
          existing.rule.frequency = Math.max(existing.rule.frequency, r.frequency);
        } else {
          ruleCounts.set(key, { rule: r, count: 1 });
        }
      });
    });

    // Rules present in >50% of speakers are community rules
    const threshold = this.config.population * 0.5;
    this.state.communityGrammar = Array.from(ruleCounts.values())
      .filter(({ count }) => count >= threshold)
      .map(({ rule }) => ({ ...rule, confirmed: true }));
  }

  private calculateStability() {
    const totalRules = this.state.speakers.reduce((sum, s) => sum + s.grammar.length, 0);
    const avgRules = totalRules / this.config.population;
    const communitySize = this.state.communityGrammar.length;
    
    // Stability = ratio of shared rules to total diversity
    this.state.stability = communitySize / Math.max(avgRules, 1);
  }

  runFullSimulation(): SimulationState {
    for (let i = 0; i < this.config.generations; i++) {
      this.step();
    }
    return this.state;
  }

  getState(): SimulationState {
    return { ...this.state };
  }

  getEventLog(): LanguageChangeEvent[] {
    return [...this.eventLog];
  }

  getStats() {
    const avgRules = this.state.speakers.reduce((sum, s) => sum + s.grammar.length, 0) / this.config.population;
    const avgAge = this.state.speakers.reduce((sum, s) => sum + s.age, 0) / this.config.population;
    const diversity = this.calculateDiversity();

    return {
      tick: this.state.tick,
      population: this.config.population,
      avgRulesPerSpeaker: avgRules.toFixed(1),
      avgAge: avgAge.toFixed(1),
      communityRules: this.state.communityGrammar.length,
      stability: (this.state.stability * 100).toFixed(1) + '%',
      diversity: diversity.toFixed(3),
      totalEvents: this.eventLog.length
    };
  }

  private calculateDiversity(): number {
    const allRules = new Set<string>();
    this.state.speakers.forEach(s => {
      s.grammar.forEach(r => {
        allRules.add(`${r.lhs} -> ${r.rhs.join(' ')}`);
      });
    });
    return allRules.size / this.config.population;
  }

  // Modern twist: Track code pattern evolution
  getCodeEvolutionTrace(): { generation: number; dominantPatterns: string[]; complexity: number }[] {
    const trace: { generation: number; dominantPatterns: string[]; complexity: number }[] = [];
    
    // Group events by generation window
    const windowSize = Math.max(1, Math.floor(this.config.generations / 10));
    for (let g = 0; g < this.config.generations; g += windowSize) {
      const windowEvents = this.eventLog.filter(e => e.tick >= g && e.tick < g + windowSize);
      const innovations = windowEvents.filter(e => e.type === 'innovation');
      const adoptions = windowEvents.filter(e => e.type === 'rule-adoption');
      
      trace.push({
        generation: g,
        dominantPatterns: [
          `${innovations.length} innovations`,
          `${adoptions.length} adoptions`,
          `stability: ${(this.state.stability * 100).toFixed(0)}%`
        ],
        complexity: innovations.length + adoptions.length
      });
    }

    return trace;
  }
}

export const simulator = new HistoricalChangeEngine();
