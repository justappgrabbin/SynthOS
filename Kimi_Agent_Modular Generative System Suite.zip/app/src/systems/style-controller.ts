// ═══════════════════════════════════════════════════════════════════
//  3. STYLE CONTROLLER ENGINE (Sheldon Klein, 1965)
//  Modern twist: Adaptive style engine for code, text, games
// ═══════════════════════════════════════════════════════════════════

import type { StyleProfile, StyleRule, StyleTransformResult } from '@/types';

// ── STYLE PROFILES ────────────────────────────────────────────────
const STYLE_PROFILES: Record<string, StyleProfile> = {
  formal: {
    name: 'Academic Formal',
    target: 'technical',
    description: 'Precise, objective, impersonal academic prose',
    rules: [
      { id: 'passive', parameter: 'passive_voice_frequency', value: 0.8, description: 'Use passive voice extensively', category: 'syntax' },
      { id: 'nominalization', parameter: 'nominalization_density', value: 0.7, description: 'Convert verbs to noun phrases', category: 'syntax' },
      { id: 'hedging', parameter: 'hedging_devices', value: 0.9, description: 'Add epistemic hedges', category: 'tone' },
      { id: 'citations', parameter: 'citation_density', value: 0.6, description: 'Include frequent references', category: 'structure' },
      { id: 'jargon', parameter: 'technical_vocabulary', value: 0.8, description: 'Use domain-specific terminology', category: 'vocabulary' }
    ]
  },
  casual: {
    name: 'Conversational',
    target: 'casual',
    description: 'Relaxed, personal, accessible prose',
    rules: [
      { id: 'contractions', parameter: 'contraction_frequency', value: 0.9, description: 'Use contractions freely', category: 'syntax' },
      { id: 'personal', parameter: 'first_person_pronouns', value: 0.8, description: 'Include personal perspective', category: 'tone' },
      { id: 'simple', parameter: 'sentence_length', value: 0.3, description: 'Keep sentences short', category: 'syntax' },
      { id: 'colloquial', parameter: 'colloquial_expressions', value: 0.6, description: 'Use everyday language', category: 'vocabulary' },
      { id: 'questions', parameter: 'rhetorical_questions', value: 0.5, description: 'Engage reader with questions', category: 'structure' }
    ]
  },
  poetic: {
    name: 'Poetic/Lyrical',
    target: 'poetic',
    description: 'Evocative, metaphorical, rhythmic prose',
    rules: [
      { id: 'metaphor', parameter: 'metaphorical_density', value: 0.8, description: 'Use figurative language', category: 'vocabulary' },
      { id: 'rhythm', parameter: 'rhythmic_patterns', value: 0.9, description: 'Create prosodic effects', category: 'syntax' },
      { id: 'imagery', parameter: 'sensory_details', value: 0.85, description: 'Add sensory descriptions', category: 'vocabulary' },
      { id: 'repetition', parameter: 'anaphora_epiphora', value: 0.6, description: 'Use repetition for effect', category: 'structure' },
      { id: 'alliteration', parameter: 'sound_devices', value: 0.5, description: 'Include phonetic patterns', category: 'vocabulary' }
    ]
  },
  code: {
    name: 'Clean Code',
    target: 'code',
    description: 'Professional software development style',
    rules: [
      { id: 'naming', parameter: 'descriptive_naming', value: 0.95, description: 'Use descriptive identifiers', category: 'syntax' },
      { id: 'comments', parameter: 'documentation_density', value: 0.7, description: 'Add inline documentation', category: 'structure' },
      { id: 'functions', parameter: 'function_decomposition', value: 0.9, description: 'Keep functions focused', category: 'structure' },
      { id: 'types', parameter: 'type_annotations', value: 0.8, description: 'Use explicit typing', category: 'syntax' },
      { id: 'errors', parameter: 'error_handling', value: 0.85, description: 'Handle edge cases', category: 'structure' }
    ]
  },
  noir: {
    name: 'Film Noir',
    target: 'fiction',
    description: 'Hard-boiled detective fiction style',
    rules: [
      { id: ' terse', parameter: 'sentence_fragmentation', value: 0.7, description: 'Use sentence fragments', category: 'syntax' },
      { id: 'metaphor_dark', parameter: 'dark_metaphors', value: 0.8, description: 'Use shadowy imagery', category: 'vocabulary' },
      { id: 'pacing', parameter: 'staccato_rhythm', value: 0.9, description: 'Short punchy sentences', category: 'syntax' },
      { id: 'attitude', parameter: 'cynical_tone', value: 0.75, description: 'World-weary perspective', category: 'tone' },
      { id: 'atmosphere', parameter: 'atmospheric_details', value: 0.85, description: 'Describe mood and setting', category: 'vocabulary' }
    ]
  },
  'game-design': {
    name: 'Game Design Document',
    target: 'technical',
    description: 'Professional game development documentation',
    rules: [
      { id: 'mechanics', parameter: 'mechanics_clarity', value: 0.95, description: 'Clearly define mechanics', category: 'structure' },
      { id: 'player', parameter: 'player_focus', value: 0.9, description: 'Center player experience', category: 'tone' },
      { id: 'numbers', parameter: 'quantitative_specifications', value: 0.8, description: 'Include specific values', category: 'vocabulary' },
      { id: 'visual', parameter: 'visual_references', value: 0.7, description: 'Describe visual elements', category: 'structure' },
      { id: 'flow', parameter: 'flow_description', value: 0.85, description: 'Explain game flow', category: 'structure' }
    ]
  }
};

// ── TRANSFORMATION RULES ──────────────────────────────────────────
const TRANSFORMATIONS: Record<string, Record<string, (text: string) => string>> = {
  syntax: {
    passive_voice_frequency: (text) => {
      // Convert active to passive
      return text
        .replace(/(\w+)\s+(\w+ed)\s+(\w+)/g, '$3 was $2 by $1')
        .replace(/I\s+(\w+)/g, 'It was $1 by me')
        .replace(/We\s+(\w+)/g, 'It was $1 by us');
    },
    sentence_length: (text) => {
      // Split long sentences
      return text.replace(/([^,]+),\s+([^,]+)/g, '$1. $2');
    },
    contraction_frequency: (text) => {
      return text
        .replace(/do not/gi, "don't").replace(/does not/gi, "doesn't")
        .replace(/did not/gi, "didn't").replace(/will not/gi, "won't")
        .replace(/cannot/gi, "can't").replace(/is not/gi, "isn't")
        .replace(/are not/gi, "aren't").replace(/was not/gi, "wasn't")
        .replace(/were not/gi, "weren't").replace(/have not/gi, "haven't")
        .replace(/has not/gi, "hasn't").replace(/would not/gi, "wouldn't")
        .replace(/could not/gi, "couldn't").replace(/should not/gi, "shouldn't");
    }
  },
  vocabulary: {
    technical_vocabulary: (text) => {
      // Add technical terms
      const enhancements = [
        ' (hereinafter referred to as the subject entity)',
        ', utilizing established methodologies',
        ' within the relevant domain paradigm'
      ];
      const sentences = text.split('. ');
      return sentences.map((s, i) => i % 2 === 0 ? s + (enhancements[i % enhancements.length] || '') : s).join('. ');
    },
    colloquial_expressions: (text) => {
      return text
        .replace(/however/gi, 'but hey')
        .replace(/therefore/gi, 'so basically')
        .replace(/furthermore/gi, 'plus')
        .replace(/nevertheless/gi, 'still though')
        .replace(/consequently/gi, 'which means');
    }
  },
  tone: {
    hedging_devices: (text) => {
      const hedges = ['It appears that', 'One might suggest that', 'It could be argued that', 'Evidence suggests that'];
      const sentences = text.split('. ');
      return sentences.map((s, i) => i % 3 === 0 ? `${hedges[i % hedges.length]} ${s.toLowerCase()}` : s).join('. ');
    },
    first_person_pronouns: (text) => {
      return text
        .replace(/The system/gi, 'I')
        .replace(/The user/gi, 'you')
        .replace(/It is/g, "It's");
    }
  },
  structure: {
    documentation_density: (text) => {
      const lines = text.split('\n');
      return lines.map(line => {
        if (line.trim().startsWith('function') || line.trim().startsWith('class') || line.trim().startsWith('const')) {
          return `/**\n * ${StyleControllerEngine.inferDescription(line)}\n */\n${line}`;
        }
        return line;
      }).join('\n');
    }
  }
};

// ── ENGINE ────────────────────────────────────────────────────────
export class StyleControllerEngine {
  getProfiles(): StyleProfile[] {
    return Object.values(STYLE_PROFILES);
  }

  getProfile(name: string): StyleProfile | undefined {
    return STYLE_PROFILES[name];
  }

  transform(text: string, profileName: string): StyleTransformResult {
    const profile = STYLE_PROFILES[profileName];
    if (!profile) {
      return { original: text, transformed: text, appliedRules: [], styleMetrics: {} };
    }

    let transformed = text;
    const appliedRules: StyleRule[] = [];
    const styleMetrics: Record<string, number> = {};

    profile.rules.forEach(rule => {
      const categoryTransforms = TRANSFORMATIONS[rule.category];
      if (categoryTransforms) {
        const transform = categoryTransforms[rule.parameter];
        if (transform) {
          transformed = transform(transformed);
          appliedRules.push(rule);
          styleMetrics[rule.parameter] = rule.value;
        }
      }
    });

    return {
      original: text,
      transformed,
      appliedRules,
      styleMetrics
    };
  }

  analyzeStyle(text: string): Record<string, number> {
    const metrics: Record<string, number> = {};
    
    // Average sentence length
    const sentences = text.split(/[.!?]+/).filter(s => s.trim());
    const words = text.split(/\s+/).filter(w => w.trim());
    metrics.avgSentenceLength = sentences.length > 0 ? words.length / sentences.length : 0;
    
    // Passive voice ratio
    const passiveMatches = text.match(/\b(is|was|were|be|been|being)\s+\w+ed\b/gi);
    metrics.passiveRatio = passiveMatches ? passiveMatches.length / sentences.length : 0;
    
    // Complex word ratio (3+ syllables)
    const complexWords = words.filter(w => this.countSyllables(w) >= 3);
    metrics.complexWordRatio = words.length > 0 ? complexWords.length / words.length : 0;
    
    // First person ratio
    const firstPerson = text.match(/\b(I|me|my|mine|we|us|our|ours)\b/gi);
    metrics.firstPersonRatio = firstPerson ? firstPerson.length / words.length : 0;
    
    // Lexical diversity (unique words / total words)
    const uniqueWords = new Set(words.map(w => w.toLowerCase()));
    metrics.lexicalDiversity = words.length > 0 ? uniqueWords.size / words.length : 0;

    return metrics;
  }

  private countSyllables(word: string): number {
    const vowels = 'aeiouy';
    let count = 0;
    let prevWasVowel = false;
    for (const char of word.toLowerCase()) {
      const isVowel = vowels.includes(char);
      if (isVowel && !prevWasVowel) count++;
      prevWasVowel = isVowel;
    }
    return Math.max(1, count);
  }

  static inferDescription(line: string): string {
    if (line.includes('function')) {
      const nameMatch = line.match(/function\s+(\w+)/);
      return `Handles ${nameMatch ? nameMatch[1].replace(/([A-Z])/g, ' $1').toLowerCase() : 'operation'}`;
    }
    if (line.includes('class')) {
      const nameMatch = line.match(/class\s+(\w+)/);
      return `Represents ${nameMatch ? nameMatch[1] : 'entity'} object`;
    }
    return 'Performs specified operation';
  }

  // Modern twist: Transform between programming paradigms
  transformCodeStyle(code: string, from: string, to: string): string {
    const transforms: Record<string, Record<string, (c: string) => string>> = {
      imperative: {
        functional: (c) => c
          .replace(/for\s*\([^)]+\)\s*\{/g, '// Use Array methods instead\nconst result = array.map(item => {')
          .replace(/let\s+(\w+)\s*=\s*\[\];/g, 'const $1 = []; // Prefer const')
          .replace(/if\s*\([^)]+\)\s*\{[^}]+\}/g, (m) => `${m.replace(/\{/g, '').replace(/\}/g, '')}`),
        oop: (c) => `class Processor {\n  constructor() {\n    this.data = [];\n  }\n  \n  ${c.split('\n').map(l => '  ' + l).join('\n')}\n}`
      },
      oop: {
        functional: (c) => c
          .replace(/class\s+\w+\s*\{[^}]*\}/gs, (m) => {
            const methods = m.match(/(\w+)\([^)]*\)\s*\{([^}]+)\}/g);
            return methods ? methods.map(m => `const ${m.match(/(\w+)/)?.[0]} = ${m.match(/\(([^)]*)\)/)?.[0]} => ${m.match(/\{([^}]+)\}/)?.[0] || '{}'};`).join('\n') : m;
          }),
        imperative: (c) => c.replace(/class\s+\w+\s*\{/g, '// Converted to imperative\n').replace(/\}/g, '')
      },
      functional: {
        imperative: (c) => c
          .replace(/const\s+(\w+)\s*=\s*\(.*\)\s*=>/g, 'function $1()')
          .replace(/\.map\(/g, '// Imperative loop\nfor (let i = 0; i < arr.length; i++) {\n  arr[i]'),
        oop: (c) => `class FunctionalWrapper {\n  static pipe(...fns) { return x => fns.reduce((v, f) => f(v), x); }\n  \n  ${c.split('\n').map(l => '  ' + l).join('\n')}\n}`
      }
    };

    const transform = transforms[from]?.[to];
    return transform ? transform(code) : `// Convert from ${from} to ${to} manually\n${code}`;
  }
}

export const styleController = new StyleControllerEngine();
