// ═══════════════════════════════════════════════════════════════════
//  8. KLEIN NETWORK - Neural Connector
//  Connects all Sheldon Klein systems into a unified network
// ═══════════════════════════════════════════════════════════════════

import type { KleinNetwork, SystemStatus } from '@/types';
import { novelWriter } from './novel-writer';
import { paraphraser } from './paraphraser';
import { styleController } from './style-controller';
import { diseminer } from './diseminer';
import { autoling } from './autoling';
import { simulator } from './simulator';
import { grammarCoder } from './grammar-coder';

// ── SYSTEM DEFINITIONS ────────────────────────────────────────────
const SYSTEM_DEFINITIONS: SystemStatus[] = [
  { id: 'novel-writer', name: 'Novel Writer (1973)', description: 'Generates stories, code, games, video scripts', year: 1973, status: 'idle' },
  { id: 'paraphraser', name: 'Auto-Paraphraser (1965)', description: 'Rewrites text, explains code, simplifies', year: 1965, status: 'idle' },
  { id: 'style-controller', name: 'Style Controller (1965)', description: 'Transforms content between styles', year: 1965, status: 'idle' },
  { id: 'diseminer', name: 'DISEMINER (1968)', description: 'Semantic inference from distribution', year: 1968, status: 'idle' },
  { id: 'autoling', name: 'AUTOLING (1968)', description: 'Interactive language/code learning', year: 1968, status: 'idle' },
  { id: 'simulator', name: 'Historical Change Simulator (1966)', description: 'Evolution simulation for languages/code', year: 1966, status: 'idle' },
  { id: 'grammar-coder', name: 'Grammar Coder (1963)', description: 'Structure analysis for code/text', year: 1963, status: 'idle' },
  { id: 'chatbot', name: 'Klein Chatbot', description: 'Conversational interface to all systems', year: 2025, status: 'idle' }
];

// ── NETWORK ARCHITECTURE ──────────────────────────────────────────
const DEFAULT_EDGES: Array<{ source: string; target: string; weight: number; type: 'data' | 'control' | 'feedback' }> = [
  { source: 'novel-writer', target: 'style-controller', weight: 0.8, type: 'data' },
  { source: 'novel-writer', target: 'paraphraser', weight: 0.6, type: 'data' },
  { source: 'style-controller', target: 'novel-writer', weight: 0.4, type: 'feedback' },
  { source: 'paraphraser', target: 'diseminer', weight: 0.7, type: 'data' },
  { source: 'paraphraser', target: 'grammar-coder', weight: 0.5, type: 'data' },
  { source: 'diseminer', target: 'paraphraser', weight: 0.3, type: 'feedback' },
  { source: 'style-controller', target: 'grammar-coder', weight: 0.6, type: 'data' },
  { source: 'grammar-coder', target: 'style-controller', weight: 0.4, type: 'feedback' },
  { source: 'diseminer', target: 'autoling', weight: 0.7, type: 'data' },
  { source: 'diseminer', target: 'simulator', weight: 0.5, type: 'data' },
  { source: 'autoling', target: 'diseminer', weight: 0.3, type: 'feedback' },
  { source: 'autoling', target: 'grammar-coder', weight: 0.8, type: 'data' },
  { source: 'autoling', target: 'simulator', weight: 0.4, type: 'control' },
  { source: 'grammar-coder', target: 'autoling', weight: 0.5, type: 'feedback' },
  { source: 'simulator', target: 'diseminer', weight: 0.4, type: 'data' },
  { source: 'simulator', target: 'novel-writer', weight: 0.3, type: 'control' },
  { source: 'grammar-coder', target: 'diseminer', weight: 0.6, type: 'data' },
  { source: 'chatbot', target: 'novel-writer', weight: 0.7, type: 'control' },
  { source: 'chatbot', target: 'paraphraser', weight: 0.7, type: 'control' },
  { source: 'chatbot', target: 'style-controller', weight: 0.6, type: 'control' },
  { source: 'chatbot', target: 'diseminer', weight: 0.8, type: 'control' },
  { source: 'chatbot', target: 'autoling', weight: 0.5, type: 'control' },
  { source: 'chatbot', target: 'simulator', weight: 0.4, type: 'control' },
  { source: 'chatbot', target: 'grammar-coder', weight: 0.6, type: 'control' },
  { source: 'novel-writer', target: 'chatbot', weight: 0.5, type: 'feedback' },
  { source: 'paraphraser', target: 'chatbot', weight: 0.5, type: 'feedback' },
  { source: 'style-controller', target: 'chatbot', weight: 0.4, type: 'feedback' },
  { source: 'diseminer', target: 'chatbot', weight: 0.6, type: 'feedback' },
  { source: 'autoling', target: 'chatbot', weight: 0.4, type: 'feedback' },
  { source: 'simulator', target: 'chatbot', weight: 0.3, type: 'feedback' },
  { source: 'grammar-coder', target: 'chatbot', weight: 0.5, type: 'feedback' }
];

// ── ENGINE ────────────────────────────────────────────────────────
export class KleinNetworkEngine {
  private network: KleinNetwork;

  constructor() {
    this.network = {
      nodes: SYSTEM_DEFINITIONS.map(s => ({
        id: s.id,
        system: s.name,
        state: 'idle' as const,
        input: null,
        output: null,
        connections: DEFAULT_EDGES.filter(e => e.source === s.id).map(e => e.target)
      })),
      edges: DEFAULT_EDGES.map((e) => ({
        source: e.source,
        target: e.target,
        weight: e.weight,
        type: e.type,
        active: false
      })),
      running: false,
      tick: 0
    };
  }

  getNetwork(): KleinNetwork {
    return { ...this.network, nodes: [...this.network.nodes], edges: [...this.network.edges] };
  }

  getSystemStatus(): SystemStatus[] {
    return SYSTEM_DEFINITIONS.map(s => ({
      ...s,
      status: this.network.nodes.find(n => n.id === s.id)?.state || 'idle'
    }));
  }

  async activateSystem(systemId: string, input: unknown): Promise<unknown> {
    const node = this.network.nodes.find(n => n.id === systemId);
    if (!node) throw new Error(`System ${systemId} not found`);

    node.state = 'processing';
    node.input = input;

    this.network.edges.forEach(e => {
      if (e.target === systemId) e.active = true;
    });

    try {
      let result: unknown;
      
      switch (systemId) {
        case 'novel-writer':
          result = this.handleNovelWriter(input);
          break;
        case 'paraphraser':
          result = this.handleParaphraser(input);
          break;
        case 'style-controller':
          result = this.handleStyleController(input);
          break;
        case 'diseminer':
          result = this.handleDiseminer(input);
          break;
        case 'autoling':
          result = this.handleAutoling(input);
          break;
        case 'simulator':
          result = this.handleSimulator(input);
          break;
        case 'grammar-coder':
          result = this.handleGrammarCoder(input);
          break;
        default:
          result = { error: 'Unknown system' };
      }

      node.output = result;
      node.state = 'active';
      
      await this.propagate(systemId, result);
      
      return result;
    } catch (error) {
      node.state = 'error';
      throw error;
    }
  }

  private handleNovelWriter(input: unknown): unknown {
    const config = input as Record<string, unknown>;
    if (config?.mode === 'code') {
      return novelWriter.generateCodeNarrative(String(config.language || 'javascript'), (config.complexity as any) || 'medium');
    }
    if (config?.mode === 'game') {
      return novelWriter.generateGameConcept(String(config.genre || 'rpg'));
    }
    if (config?.mode === 'video-script') {
      return novelWriter.generateVideoScript(String(config.style || 'cinematic'));
    }
    return novelWriter.generate(config as any);
  }

  private handleParaphraser(input: unknown): unknown {
    const { text, config } = input as { text: string; config: any };
    if (config?.mode === 'explain-code') {
      return paraphraser.explainCode(text, (config as any).level || 'beginner');
    }
    return paraphraser.paraphrase(text, config || { mode: 'simplify', readingLevel: 'high-school', format: 'paragraph', preserveTone: true });
  }

  private handleStyleController(input: unknown): unknown {
    const { text, profile, transform } = input as { text: string; profile?: string; transform?: { from: string; to: string } };
    if (transform?.from && transform?.to) {
      return styleController.transformCodeStyle(text, transform.from, transform.to);
    }
    return styleController.transform(text, profile || 'formal');
  }

  private handleDiseminer(input: unknown): unknown {
    const { text, type } = input as { text: string; type?: string };
    if (type === 'code') {
      return diseminer.analyzeCodeSemantics(text);
    }
    if (type === 'complete') {
      return diseminer.suggestCompletion(text, text);
    }
    return diseminer.answerQuestion(text);
  }

  private handleAutoling(input: unknown): unknown {
    const { text, action, examples } = input as { text?: string; action?: string; examples?: string[] };
    if (action === 'start') {
      return autoling.startSession(text || 'auto-detect');
    }
    if (action === 'learn-code') {
      return autoling.learnCodePatterns(examples || []);
    }
    if (action === 'learn') {
      return autoling.learnFromExamples(examples || [text || '']);
    }
    return autoling.processInput(text || '');
  }

  private handleSimulator(input: unknown): unknown {
    const { action } = input as { action?: string };
    if (action === 'step') {
      return simulator.step();
    }
    if (action === 'run') {
      return simulator.runFullSimulation();
    }
    if (action === 'stats') {
      return simulator.getStats();
    }
    return simulator.getState();
  }

  private handleGrammarCoder(input: unknown): unknown {
    const { text, action } = input as { text: string; action?: string };
    if (action === 'complexity') {
      return grammarCoder.calculateComplexity(text);
    }
    return grammarCoder.code(text);
  }

  private async propagate(sourceId: string, output: unknown) {
    const outgoingEdges = this.network.edges.filter(e => e.source === sourceId);
    
    for (const edge of outgoingEdges) {
      edge.active = true;
      
      if (edge.target !== 'chatbot') {
        const targetNode = this.network.nodes.find(n => n.id === edge.target);
        if (targetNode && targetNode.state === 'idle') {
          targetNode.input = { forwarded: true, from: sourceId, data: output };
        }
      }
    }
  }

  async routeQuery(query: string): Promise<{ system: string; result: unknown }[]> {
    const results: { system: string; result: unknown }[] = [];
    const systemsToActivate = this.determineSystems(query);
    
    for (const systemId of systemsToActivate) {
      try {
        const result = await this.activateSystem(systemId, { text: query });
        results.push({ system: systemId, result });
      } catch (e) {
        results.push({ system: systemId, result: { error: String(e) } });
      }
    }

    return results;
  }

  private determineSystems(query: string): string[] {
    const lower = query.toLowerCase();
    const systems: string[] = [];

    if (lower.includes('story') || lower.includes('write') || lower.includes('generate') || lower.includes('narrative') || lower.includes('game') || lower.includes('code')) {
      systems.push('novel-writer');
    }
    if (lower.includes('rewrite') || lower.includes('paraphrase') || lower.includes('simplify') || lower.includes('explain')) {
      systems.push('paraphraser');
    }
    if (lower.includes('style') || lower.includes('tone') || lower.includes('formal') || lower.includes('casual')) {
      systems.push('style-controller');
    }
    if (lower.includes('mean') || lower.includes('semantic') || lower.includes('what is') || lower.includes('define') || lower.includes('similar')) {
      systems.push('diseminer');
    }
    if (lower.includes('learn') || lower.includes('pattern') || lower.includes('grammar') || lower.includes('language')) {
      systems.push('autoling');
    }
    if (lower.includes('evolve') || lower.includes('change') || lower.includes('history') || lower.includes('simulate')) {
      systems.push('simulator');
    }
    if (lower.includes('parse') || lower.includes('analyze') || lower.includes('structure') || lower.includes('syntax')) {
      systems.push('grammar-coder');
    }

    if (systems.length === 0) {
      systems.push('diseminer', 'paraphraser');
    }

    return systems;
  }

  reset() {
    this.network.nodes.forEach(n => {
      n.state = 'idle';
      n.input = null;
      n.output = null;
    });
    this.network.edges.forEach(e => {
      e.active = false;
    });
    this.network.tick = 0;
    this.network.running = false;
  }
}

export const kleinNetwork = new KleinNetworkEngine();
