// ═══════════════════════════════════════════════════════════════════
//  4. DISEMINER ENGINE (Sheldon Klein, 1968)
//  Distributional-Semantics Inference Maker
//  Modern twist: Semantic inference for code and natural language
// ═══════════════════════════════════════════════════════════════════

import type { DistributionClass, SemanticInference, DISEMINERConfig } from '@/types';

// ── LEXICAL DATABASE ──────────────────────────────────────────────
const SEMANTIC_FIELDS: Record<string, string[]> = {
  technology: ['computer', 'algorithm', 'program', 'software', 'hardware', 'network', 'database', 'interface', 'protocol', 'system'],
  motion: ['run', 'walk', 'jump', 'fly', 'swim', 'drive', 'move', 'go', 'travel', 'accelerate'],
  cognition: ['think', 'know', 'believe', 'understand', 'remember', 'learn', 'decide', 'analyze', 'reason', 'perceive'],
  emotion: ['love', 'hate', 'fear', 'joy', 'anger', 'sadness', 'hope', 'desire', 'envy', 'pride'],
  communication: ['speak', 'write', 'read', 'tell', 'say', 'ask', 'answer', 'discuss', 'explain', 'describe'],
  code_concepts: ['function', 'variable', 'class', 'object', 'method', 'property', 'module', 'component', 'service', 'api'],
  data_structures: ['array', 'list', 'map', 'set', 'tree', 'graph', 'queue', 'stack', 'heap', 'hash'],
  code_patterns: ['loop', 'recursion', 'iteration', 'callback', 'promise', 'async', 'stream', 'event', 'observer', 'singleton']
};

const CODE_SEMANTICS: Record<string, { category: string; related: string[]; description: string }> = {
  'function': { category: 'abstraction', related: ['method', 'procedure', 'callback', 'arrow'], description: 'Encapsulates reusable logic' },
  'class': { category: 'abstraction', related: ['object', 'prototype', 'constructor', 'instance'], description: 'Defines object blueprint' },
  'const': { category: 'declaration', related: ['let', 'var', 'immutable', 'readonly'], description: 'Immutable binding declaration' },
  'async': { category: 'concurrency', related: ['await', 'promise', 'then', 'catch'], description: 'Asynchronous operation marker' },
  'import': { category: 'modularity', related: ['export', 'require', 'module', 'namespace'], description: 'Dependency resolution' },
  'return': { category: 'control-flow', related: ['yield', 'break', 'continue', 'throw'], description: 'Value propagation or exit' },
  'if': { category: 'control-flow', related: ['else', 'switch', 'ternary', 'guard'], description: 'Conditional branching' },
  'for': { category: 'iteration', related: ['while', 'map', 'filter', 'reduce'], description: 'Repetition construct' },
  'try': { category: 'error-handling', related: ['catch', 'finally', 'throw', 'error'], description: 'Exception containment' },
  'new': { category: 'instantiation', related: ['constructor', 'create', 'instanceof', 'this'], description: 'Object creation' }
};

// ── ENGINE ────────────────────────────────────────────────────────
export class DISEMINEREngine {
  private corpus: Map<string, DistributionClass> = new Map();
  private config: DISEMINERConfig;

  constructor(config: Partial<DISEMINERConfig> = {}) {
    this.config = {
      analysisDepth: config.analysisDepth || 'full-context',
      corpusSize: config.corpusSize || 1000,
      domain: config.domain || 'general'
    };
    this.seedCorpus();
  }

  private seedCorpus() {
    // Seed with semantic field data
    Object.entries(SEMANTIC_FIELDS).forEach(([field, words]) => {
      words.forEach(word => {
        this.corpus.set(word, {
          stem: word,
          class: field,
          cooccurrences: words.filter(w => w !== word),
          frequency: Math.floor(Math.random() * 100) + 1,
          contexts: [`Used in ${field} context`]
        });
      });
    });

    // Seed code semantics
    Object.entries(CODE_SEMANTICS).forEach(([token, info]) => {
      this.corpus.set(token, {
        stem: token,
        class: info.category,
        cooccurrences: info.related,
        frequency: Math.floor(Math.random() * 200) + 50,
        contexts: [info.description]
      });
    });
  }

  processText(text: string): DistributionClass[] {
    const words = text.toLowerCase().match(/\b[a-z]+\b/g) || [];
    const found: DistributionClass[] = [];

    words.forEach(word => {
      const entry = this.corpus.get(word);
      if (entry) {
        // Update frequency
        entry.frequency++;
        entry.contexts.push(text.substring(0, 50));
        if (entry.contexts.length > 10) entry.contexts.shift();
        found.push(entry);
      } else {
        // Infer class from context
        const inferred = this.inferClass(word, words);
        if (inferred) {
          this.corpus.set(word, inferred);
          found.push(inferred);
        }
      }
    });

    return found;
  }

  private inferClass(word: string, context: string[]): DistributionClass | null {
    // Find co-occurring known words
    const knownNeighbors = context.filter(w => this.corpus.has(w));
    if (knownNeighbors.length === 0) return null;

    // Vote on class
    const classVotes: Record<string, number> = {};
    knownNeighbors.forEach(neighbor => {
      const entry = this.corpus.get(neighbor);
      if (entry) {
        classVotes[entry.class] = (classVotes[entry.class] || 0) + 1;
      }
    });

    const bestClass = Object.entries(classVotes).sort((a, b) => b[1] - a[1])[0];
    if (!bestClass) return null;

    return {
      stem: word,
      class: bestClass[0],
      cooccurrences: knownNeighbors.slice(0, 5),
      frequency: 1,
      contexts: [`Inferred from ${knownNeighbors.slice(0, 3).join(', ')}`]
    };
  }

  answerQuestion(question: string): SemanticInference {
    const words = question.toLowerCase().match(/\b[a-z]+\b/g) || [];
    const relevant = this.processText(question);

    // Build inference chain
    const inferenceChain: string[] = [];
    const evidence: DistributionClass[] = [];

    words.forEach(word => {
      const entry = this.corpus.get(word);
      if (entry) {
        inferenceChain.push(`"${word}" is classified as [${entry.class}]`);
        inferenceChain.push(`  → co-occurs with: ${entry.cooccurrences.slice(0, 3).join(', ')}`);
        evidence.push(entry);
      }
    });

    // Generate answer based on semantic relationships
    const answer = this.generateAnswer(question, relevant);
    const confidence = Math.min(0.95, relevant.length / Math.max(words.length * 0.5, 1));

    return {
      query: question,
      answer,
      confidence,
      evidence,
      inferenceChain
    };
  }

  private generateAnswer(question: string, relevant: DistributionClass[]): string {
    const questionLower = question.toLowerCase();

    // Code-related questions
    if (questionLower.includes('code') || questionLower.includes('programming') || questionLower.includes('function')) {
      const codeTerms = relevant.filter(r => ['code_concepts', 'data_structures', 'code_patterns'].includes(r.class));
      if (codeTerms.length > 0) {
        return `Based on distributional analysis, ${codeTerms[0].stem} is semantically related to ${codeTerms[0].cooccurrences.slice(0, 3).join(', ')}. In ${this.config.domain} contexts, this pattern suggests a ${codeTerms[0].class} operation.`;
      }
    }

    // Relationship questions
    if (questionLower.includes('what is') || questionLower.includes('define')) {
      const term = relevant[0];
      if (term) {
        const codeSem = CODE_SEMANTICS[term.stem];
        if (codeSem) {
          return `${term.stem}: ${codeSem.description}. Related concepts: ${codeSem.related.join(', ')}.`;
        }
        return `${term.stem} belongs to the semantic class of ${term.class}, frequently co-occurring with ${term.cooccurrences.slice(0, 3).join(', ')}.`;
      }
    }

    // General inference
    if (relevant.length > 0) {
      const classes = [...new Set(relevant.map(r => r.class))];
      return `Distributional analysis reveals associations with: ${classes.join(', ')}. The query terms share semantic fields with ${relevant.slice(0, 3).map(r => r.stem).join(', ')}.`;
    }

    return 'Insufficient distributional data to infer meaning. Process more text to build semantic classes.';
  }

  // Modern twist: Analyze code semantics
  analyzeCodeSemantics(code: string): SemanticInference {
    const tokens = code.match(/\b[a-zA-Z_][a-zA-Z0-9_]*\b/g) || [];
    const keywords = tokens.filter(t => CODE_SEMANTICS[t.toLowerCase()]);
    
    const inferenceChain: string[] = [];
    const evidence: DistributionClass[] = [];
    
    keywords.forEach(kw => {
      const lower = kw.toLowerCase();
      const sem = CODE_SEMANTICS[lower];
      if (sem) {
        inferenceChain.push(`${kw} → ${sem.category}: ${sem.description}`);
        evidence.push({
          stem: lower,
          class: sem.category,
          cooccurrences: sem.related,
          frequency: CODE_SEMANTICS[lower] ? 100 : 1,
          contexts: [sem.description]
        });
      }
    });

    // Detect patterns
    const patterns = this.detectPatterns(keywords);
    
    return {
      query: `Analyze: ${code.substring(0, 50)}...`,
      answer: `Code semantic analysis: ${patterns}. Key constructs: ${keywords.slice(0, 5).join(', ')}.`,
      confidence: keywords.length > 0 ? Math.min(0.95, evidence.length / keywords.length) : 0.5,
      evidence,
      inferenceChain
    };
  }

  private detectPatterns(keywords: string[]): string {
    const patterns: string[] = [];
    const kwSet = new Set(keywords.map(k => k.toLowerCase()));
    
    if (kwSet.has('async') && kwSet.has('await')) patterns.push('async/await pattern');
    if (kwSet.has('try') && kwSet.has('catch')) patterns.push('error handling');
    if (kwSet.has('class') && kwSet.has('extends')) patterns.push('inheritance hierarchy');
    if (kwSet.has('import') || kwSet.has('require')) patterns.push('module system');
    if (kwSet.has('for') || kwSet.has('while')) patterns.push('iterative processing');
    if (kwSet.has('if') && kwSet.has('else')) patterns.push('conditional logic');
    if (kwSet.has('new') && kwSet.has('this')) patterns.push('OOP instantiation');
    if (kwSet.has('map') || kwSet.has('filter') || kwSet.has('reduce')) patterns.push('functional transformation');
    
    return patterns.length > 0 ? patterns.join(', ') : 'procedural structure';
  }

  // Modern twist: Semantic similarity for code completion
  suggestCompletion(partial: string, context: string): string[] {
    const contextWords = context.toLowerCase().match(/\b[a-z]+\b/g) || [];
    const contextClasses = new Set<string>();
    
    contextWords.forEach(w => {
      const entry = this.corpus.get(w);
      if (entry) contextClasses.add(entry.class);
    });

    // Find completions in same semantic classes
    const suggestions: string[] = [];
    this.corpus.forEach((entry, stem) => {
      if (stem.startsWith(partial.toLowerCase()) && contextClasses.has(entry.class)) {
        suggestions.push(stem);
      }
    });

    // Also suggest from code semantics
    Object.entries(CODE_SEMANTICS).forEach(([token]) => {
      if (token.startsWith(partial.toLowerCase()) && !suggestions.includes(token)) {
        suggestions.push(token);
      }
    });

    return suggestions.slice(0, 5);
  }
}

export const diseminer = new DISEMINEREngine();
