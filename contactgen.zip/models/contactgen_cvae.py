"""ContactGen: Conditional Sequential CVAE for contact map generation."""
import torch
import torch.nn as nn
import torch.nn.functional as F
import sys
sys.path.append("..")
from pointnet_lib.pointnet2_modules import PointNetSetAbstraction, PointNetFeaturePropagation


class ContactEncoder(nn.Module):
    """Encoder: object points + contact maps -> latent z."""

    def __init__(self, latent_dim=64, n_parts=16, n_directions=8):
        super().__init__()
        self.latent_dim = latent_dim
        self.n_parts = n_parts
        self.n_directions = n_directions

        # Input: object points (3) + contact (1) + part (n_parts) + direction (n_directions)
        in_channel = 3 + 1 + n_parts + n_directions

        # PointNet++ encoder
        self.sa1 = PointNetSetAbstraction(
            npoint=512, radius_list=[0.02, 0.04], nsample_list=[16, 32],
            in_channel=in_channel, mlp_list=[[32, 32, 64], [64, 64, 128]]
        )
        self.sa2 = PointNetSetAbstraction(
            npoint=128, radius_list=[0.04, 0.08], nsample_list=[16, 32],
            in_channel=128+64, mlp_list=[[128, 128, 256], [128, 196, 256]]
        )
        self.sa3 = PointNetSetAbstraction(
            npoint=None, radius_list=None, nsample_list=None,
            in_channel=256+256, mlp_list=[[256, 256, 512], [256, 384, 512]],
            group_all=True
        )

        # Global feature to latent
        self.fc_mu = nn.Linear(512+512, latent_dim)
        self.fc_logvar = nn.Linear(512+512, latent_dim)

    def forward(self, obj_points, contact_map, part_map, direction_map):
        """
        Args:
            obj_points: [B, N, 3]
            contact_map: [B, N]
            part_map: [B, N, n_parts]
            direction_map: [B, N, n_directions]

        Returns:
            mu, logvar: [B, latent_dim]
        """
        # Concatenate features - keep as [B, N, C] for PointNet++
        contact = contact_map.unsqueeze(-1)  # [B, N, 1]
        x = torch.cat([obj_points, contact, part_map, direction_map], dim=-1)  # [B, N, C]

        # PointNet++ encoding - pass points as [B, N, C] (not [B, C, N])
        xyz = obj_points
        l1_xyz, l1_points = self.sa1(xyz, x)
        l2_xyz, l2_points = self.sa2(l1_xyz, l1_points)
        l3_xyz, l3_points = self.sa3(l2_xyz, l2_points)

        # Global feature
        global_feat = l3_points.view(l3_points.shape[0], -1)  # [B, 1024]

        mu = self.fc_mu(global_feat)
        logvar = self.fc_logvar(global_feat)

        return mu, logvar


class ContactDecoder(nn.Module):
    """Decoder: object points + latent z -> contact maps."""

    def __init__(self, latent_dim=64, n_parts=16, n_directions=8):
        super().__init__()
        self.latent_dim = latent_dim
        self.n_parts = n_parts
        self.n_directions = n_directions

        # Input: object points (3) + latent (latent_dim)
        in_channel = 3 + latent_dim

        # PointNet++ decoder with feature propagation
        self.sa1 = PointNetSetAbstraction(
            npoint=512, radius_list=[0.02, 0.04], nsample_list=[16, 32],
            in_channel=in_channel, mlp_list=[[32, 32, 64], [64, 64, 128]]
        )
        self.sa2 = PointNetSetAbstraction(
            npoint=128, radius_list=[0.04, 0.08], nsample_list=[16, 32],
            in_channel=128+64, mlp_list=[[128, 128, 256], [128, 196, 256]]
        )
        self.sa3 = PointNetSetAbstraction(
            npoint=None, radius_list=None, nsample_list=None,
            in_channel=256+256, mlp_list=[[256, 256, 512], [256, 384, 512]],
            group_all=True
        )

        # Feature propagation
        self.fp3 = PointNetFeaturePropagation(in_channel=512+512+256+256, mlp=[256, 256])
        self.fp2 = PointNetFeaturePropagation(in_channel=256+128+64, mlp=[256, 128])
        self.fp1 = PointNetFeaturePropagation(in_channel=128+in_channel, mlp=[128, 128, 128])

        # Output heads
        self.contact_head = nn.Conv1d(128, 1, 1)
        self.part_head = nn.Conv1d(128, n_parts, 1)
        self.direction_head = nn.Conv1d(128, n_directions, 1)

    def forward(self, obj_points, z):
        """
        Args:
            obj_points: [B, N, 3]
            z: [B, latent_dim]

        Returns:
            contact_map: [B, N]
            part_map: [B, N, n_parts]
            direction_map: [B, N, n_directions]
        """
        B, N, _ = obj_points.shape

        # Broadcast latent to each point
        z_expanded = z.unsqueeze(1).expand(-1, N, -1)  # [B, N, latent_dim]
        x = torch.cat([obj_points, z_expanded], dim=-1)  # [B, N, 3+latent_dim]

        # Encoder path (for skip connections)
        l0_xyz = obj_points
        l0_points = x

        l1_xyz, l1_points = self.sa1(l0_xyz, l0_points)
        l2_xyz, l2_points = self.sa2(l1_xyz, l1_points)
        l3_xyz, l3_points = self.sa3(l2_xyz, l2_points)

        # Decoder path with feature propagation
        l2_points = self.fp3(l2_xyz, l3_xyz, l2_points, l3_points)
        l1_points = self.fp2(l1_xyz, l2_xyz, l1_points, l2_points)
        l0_points = self.fp1(l0_xyz, l1_xyz, l0_points, l1_points)

        # Output predictions - l0_points is [B, C, N]
        contact = self.contact_head(l0_points).squeeze(1)  # [B, N]
        contact_map = torch.sigmoid(contact)

        part_logits = self.part_head(l0_points)  # [B, n_parts, N]
        part_map = F.softmax(part_logits.permute(0, 2, 1), dim=-1)  # [B, N, n_parts]

        direction_logits = self.direction_head(l0_points)  # [B, n_directions, N]
        direction_map = F.softmax(direction_logits.permute(0, 2, 1), dim=-1)  # [B, N, n_directions]

        return contact_map, part_map, direction_map


class ContactGenCVAE(nn.Module):
    """Complete ContactGen CVAE model."""

    def __init__(self, latent_dim=64, n_parts=16, n_directions=8):
        super().__init__()
        self.latent_dim = latent_dim
        self.encoder = ContactEncoder(latent_dim, n_parts, n_directions)
        self.decoder = ContactDecoder(latent_dim, n_parts, n_directions)

    def reparameterize(self, mu, logvar):
        """Reparameterization trick."""
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, obj_points, contact_map, part_map, direction_map):
        """
        Training forward pass.

        Args:
            obj_points: [B, N, 3]
            contact_map: [B, N]
            part_map: [B, N, n_parts]
            direction_map: [B, N, n_directions]

        Returns:
            recon_contact, recon_part, recon_direction, mu, logvar
        """
        # Encode
        mu, logvar = self.encoder(obj_points, contact_map, part_map, direction_map)

        # Sample latent
        z = self.reparameterize(mu, logvar)

        # Decode
        recon_contact, recon_part, recon_direction = self.decoder(obj_points, z)

        return recon_contact, recon_part, recon_direction, mu, logvar

    def sample(self, obj_points, n_samples=1):
        """
        Sample contact maps for an object.

        Args:
            obj_points: [B, N, 3]
            n_samples: number of samples

        Returns:
            List of (contact_map, part_map, direction_map) tuples
        """
        B = obj_points.shape[0]
        device = obj_points.device

        results = []
        for _ in range(n_samples):
            z = torch.randn(B, self.latent_dim, device=device)
            contact, part, direction = self.decoder(obj_points, z)
            results.append((contact, part, direction))

        return results

    def compute_loss(self, recon_contact, recon_part, recon_direction,
                     target_contact, target_part, target_direction,
                     mu, logvar, kl_weight=0.1):
        """Compute VAE loss."""
        # Reconstruction losses
        contact_loss = F.binary_cross_entropy(recon_contact, target_contact, reduction="mean")
        part_loss = F.cross_entropy(recon_part.view(-1, recon_part.shape[-1]),
                                     target_part.argmax(dim=-1).view(-1), reduction="mean")
        direction_loss = F.cross_entropy(recon_direction.view(-1, recon_direction.shape[-1]),
                                          target_direction.argmax(dim=-1).view(-1), reduction="mean")

        # KL divergence
        kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp()) / mu.shape[0]

        # Total loss
        total_loss = contact_loss + part_loss + direction_loss + kl_weight * kl_loss

        return {
            "total": total_loss,
            "contact": contact_loss,
            "part": part_loss,
            "direction": direction_loss,
            "kl": kl_loss
        }
