"""PointNet++ Set Abstraction and Feature Propagation modules."""
import torch
import torch.nn as nn
import torch.nn.functional as F
from .pointnet2_utils import sample_and_group, sample_and_group_all, index_points, query_ball_point, farthest_point_sample


class PointNetSetAbstraction(nn.Module):
    """Set Abstraction layer with multi-scale grouping."""
    def __init__(self, npoint, radius_list, nsample_list, in_channel, mlp_list, group_all=False):
        super().__init__()
        self.npoint = npoint
        self.radius_list = radius_list
        self.nsample_list = nsample_list
        self.group_all = group_all
        self.mlp_convs = nn.ModuleList()
        self.mlp_bns = nn.ModuleList()

        for i in range(len(mlp_list)):
            convs = nn.ModuleList()
            bns = nn.ModuleList()
            last_channel = in_channel + 3
            for out_channel in mlp_list[i]:
                convs.append(nn.Conv2d(last_channel, out_channel, 1))
                bns.append(nn.BatchNorm2d(out_channel))
                last_channel = out_channel
            self.mlp_convs.append(convs)
            self.mlp_bns.append(bns)

    def forward(self, xyz, points):
        """
        xyz: [B, N, 3]
        points: [B, N, C] or None
        Returns: new_xyz [B, S, 3], new_points [B, S, C']
        """
        if self.group_all:
            new_xyz, new_points = sample_and_group_all(xyz, points)
            new_points = new_points.permute(0, 3, 2, 1)
            for i, (convs, bns) in enumerate(zip(self.mlp_convs, self.mlp_bns)):
                for conv, bn in zip(convs, bns):
                    new_points = F.relu(bn(conv(new_points)))
            new_points = torch.max(new_points, 2)[0]  # [B, C, 1]
            new_xyz = xyz.mean(dim=1, keepdim=True)  # [B, 1, 3]
            # Transpose to [B, N, C] format
            new_points = new_points.permute(0, 2, 1)  # [B, 1, C]
            return new_xyz, new_points

        B, N, C = xyz.shape
        S = self.npoint
        new_xyz = index_points(xyz, farthest_point_sample(xyz, S))
        new_points_list = []

        for i, radius in enumerate(self.radius_list):
            nsample = self.nsample_list[i]
            group_idx = query_ball_point(radius, nsample, xyz, new_xyz)
            grouped_xyz = index_points(xyz, group_idx)
            grouped_xyz -= new_xyz.view(B, S, 1, C)
            if points is not None:
                grouped_points = index_points(points, group_idx)
                grouped_points = torch.cat([grouped_xyz, grouped_points], dim=-1)
            else:
                grouped_points = grouped_xyz
            grouped_points = grouped_points.permute(0, 3, 2, 1)  # [B, C, nsample, S]

            for conv, bn in zip(self.mlp_convs[i], self.mlp_bns[i]):
                grouped_points = F.relu(bn(conv(grouped_points)))
            new_points_list.append(torch.max(grouped_points, 2)[0])  # [B, C, S]

        new_points = torch.cat(new_points_list, dim=1)  # [B, C, S]
        # Transpose to [B, S, C] format for next layer
        new_points = new_points.permute(0, 2, 1)  # [B, S, C]
        return new_xyz, new_points


class PointNetFeaturePropagation(nn.Module):
    """Feature Propagation layer."""
    def __init__(self, in_channel, mlp):
        super().__init__()
        self.mlp_convs = nn.ModuleList()
        self.mlp_bns = nn.ModuleList()
        last_channel = in_channel
        for out_channel in mlp:
            self.mlp_convs.append(nn.Conv1d(last_channel, out_channel, 1))
            self.mlp_bns.append(nn.BatchNorm1d(out_channel))
            last_channel = out_channel

    def forward(self, xyz1, xyz2, points1, points2):
        """
        xyz1: [B, N, 3] - coarse points (target)
        xyz2: [B, S, 3] - fine points (source)
        points1: [B, N, C1] - coarse features
        points2: [B, S, C2] - fine features
        """
        B, N, C = xyz1.shape
        _, S, _ = xyz2.shape

        if S == 1:
            interpolated_points = points2.repeat(1, N, 1)  # [B, N, C2]
        else:
            # Compute distances and interpolate
            dists = torch.cdist(xyz1, xyz2)  # [B, N, S]
            dists, idx = dists.sort(dim=-1)
            dists, idx = dists[:, :, :3], idx[:, :, :3]  # [B, N, 3]

            dist_recip = 1.0 / (dists + 1e-8)
            norm = torch.sum(dist_recip, dim=2, keepdim=True)  # [B, N, 1]
            weight = dist_recip / norm  # [B, N, 3]

            # Gather points2 using idx
            # points2 is [B, S, C2], idx is [B, N, 3]
            # We need to gather for each of the 3 nearest neighbors
            B_idx = torch.arange(B, device=xyz1.device).view(B, 1, 1).expand(B, N, 3)
            gathered = points2[B_idx, idx, :]  # [B, N, 3, C2]

            interpolated_points = torch.sum(gathered * weight.unsqueeze(-1), dim=2)  # [B, N, C2]

        if points1 is not None:
            new_points = torch.cat([points1, interpolated_points], dim=-1)  # [B, N, C1+C2]
        else:
            new_points = interpolated_points

        # Convert to [B, C, N] for Conv1d
        new_points = new_points.permute(0, 2, 1)  # [B, C, N]

        for conv, bn in zip(self.mlp_convs, self.mlp_bns):
            new_points = F.relu(bn(conv(new_points)))

        # Return in [B, N, C] format
        new_points = new_points.permute(0, 2, 1)  # [B, N, C]

        return new_points
