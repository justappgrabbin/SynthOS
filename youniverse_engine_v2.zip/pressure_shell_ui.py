
"""
YOU-N-I-VERSE Pressure Shell UI
Live chart input and real-time interpretation interface.
Runs as a command-line interactive shell or can be embedded.
"""

import json
import sys
from datetime import datetime
from typing import Dict, Optional

class PressureShellUI:
    """
    Interactive command-line interface for the YOU-N-I-VERSE engine.
    Supports manual gate entry, birth chart calculation, and live queries.
    """

    PROMPT = "🌐 YOU-N-I-VERSE > "

    # ANSI color codes
    COLORS = {
        "reset": "\033[0m",
        "bold": "\033[1m",
        "dim": "\033[2m",
        "red": "\033[91m",
        "green": "\033[92m",
        "yellow": "\033[93m",
        "blue": "\033[94m",
        "magenta": "\033[95m",
        "cyan": "\033[96m",
        "white": "\033[97m",
        "black_bg": "\033[40m",
        "red_bg": "\033[41m",
        "green_bg": "\033[42m",
        "yellow_bg": "\033[43m",
        "blue_bg": "\033[44m",
        "magenta_bg": "\033[45m",
        "cyan_bg": "\033[46m",
    }

    def __init__(self, engine_module=None, ephemeris_module=None, gate_dict_path: str = None):
        self.engine = engine_module
        self.ephemeris = ephemeris_module
        self.gate_dict = {}

        if gate_dict_path:
            try:
                with open(gate_dict_path, 'r') as f:
                    self.gate_dict = json.load(f)
            except:
                pass

        self.current_chart = None
        self.running = True

    def _color(self, text: str, color: str) -> str:
        return f"{self.COLORS.get(color, '')}{text}{self.COLORS['reset']}"

    def print_banner(self):
        banner = f"""
{self._color("╔══════════════════════════════════════════════════════════════╗", "cyan")}
{self._color("║", "cyan")}  {self._color("YOU-N-I-VERSE", "bold")} {self._color("Pressure Shell v2.0", "dim")}                              {self._color("║", "cyan")}
{self._color("║", "cyan")}  9-Body Consciousness Field | Resonance-Native Architecture  {self._color("║", "cyan")}
{self._color("║", "cyan")}  No Master Controller | Waveform Voting | Coherence-Based     {self._color("║", "cyan")}
{self._color("╚══════════════════════════════════════════════════════════════╝", "cyan")}

{self._color("Commands:", "yellow")}
  {self._color("chart", "green")}      - Calculate birth chart from date/time/location
  {self._color("query", "green")}      - Ask the oracle a question
  {self._color("gate", "green")}       - Direct gate input (Gate.Line.Color.Tone.Base)
  {self._color("transit", "green")}    - Check current transits against natal chart
  {self._color("coherence", "green")}  - Run full 9-body coherence analysis
  {self._color("waveform", "green")}   - Visualize body waveforms
  {self._color("batch", "green")}      - Process multiple charts from file
  {self._color("save", "green")}       - Save current chart to file
  {self._color("load", "green")}        - Load chart from file
  {self._color("help", "green")}       - Show detailed help
  {self._color("quit", "green")}       - Exit the shell

{self._color("Syntax:", "yellow")}
  gate 25.4.6.3.4              → Gate 25, Line 4, Color 6, Tone 3, Base 4
  query "Should I move?" 25.4  → Query with gate context
  chart 1985-06-15 14:30 40.7 -74.0 → Birth chart NYC
        """
        print(banner)

    def parse_gate_input(self, input_str: str) -> Optional[Dict]:
        """Parse gate input like '25.4.6.3.4' or '25.4'"""
        parts = input_str.strip().split('.')
        try:
            gate = int(parts[0])
            line = int(parts[1]) if len(parts) > 1 else 1
            color = int(parts[2]) if len(parts) > 2 else 1
            tone = int(parts[3]) if len(parts) > 3 else 1
            base = int(parts[4]) if len(parts) > 4 else 1
            return {"gate": gate, "line": line, "color": color, "tone": tone, "base": base}
        except:
            return None

    def cmd_chart(self, args: str):
        """Calculate birth chart"""
        parts = args.split()
        if len(parts) < 3:
            print(self._color("Usage: chart YYYY-MM-DD HH:MM LATITUDE LONGITUDE [tropical|sidereal|draconic]", "red"))
            return

        try:
            date_parts = parts[0].split('-')
            year, month, day = int(date_parts[0]), int(date_parts[1]), int(date_parts[2])
            time_parts = parts[1].split(':')
            hour = int(time_parts[0]) + int(time_parts[1]) / 60.0
            latitude = float(parts[2])
            longitude = float(parts[3])
            chart_system = parts[4] if len(parts) > 4 else "tropical"

            if self.ephemeris:
                chart = self.ephemeris.calculate_full_chart(
                    year, month, day, hour, latitude, longitude, chart_system
                )
                self.current_chart = chart

                print(f"\n{self._color('📊 BIRTH CHART COMPUTED', 'bold')}")
                print(f"{self._color('═' * 50, 'cyan')}")
                print(f"Date: {chart['date']} {chart['time']}h")
                print(f"Location: {chart['latitude']:.4f}°, {chart['longitude']:.4f}°")
                print(f"System: {chart['chart_system']}")
                print(f"{self._color('─' * 50, 'dim')}")

                for planet, data in chart['planets'].items():
                    if "error" in data:
                        print(f"  {planet}: {self._color('ERROR', 'red')} {data['error']}")
                    else:
                        sign_icon = "☉" if planet == "Sun" else "☽" if planet == "Moon" else "☿" if planet == "Mercury" else "♀" if planet == "Venus" else "♂" if planet == "Mars" else "♃" if planet == "Jupiter" else "♄" if planet == "Saturn" else "♅" if planet == "Uranus" else "♆" if planet == "Neptune" else "♇" if planet == "Pluto" else "☊" if planet == "North Node" else "☋"
                        print(f"  {sign_icon} {planet:12s} → {data['sign']:12s} {data['degree']:2d}°{data['minutes']:2d}' | Gate {data['gate']:2d}.{data['line']} | {data['element']}")

                if chart.get('houses'):
                    print(f"{self._color('─' * 50, 'dim')}")
                    print(f"  ASC: {chart['houses']['ascendant']:.2f}°")
                    print(f"  MC:  {chart['houses']['mc']:.2f}°")

                print(f"{self._color('═' * 50, 'cyan')}")
            else:
                print(self._color("Ephemeris engine not available. Install pysweph or libephemeris.", "red"))

        except Exception as e:
            print(self._color(f"Error: {e}", "red"))

    def cmd_gate(self, args: str):
        """Direct gate input and interpretation"""
        parsed = self.parse_gate_input(args)
        if not parsed:
            print(self._color("Invalid gate format. Use: Gate.Line.Color.Tone.Base (e.g., 25.4.6.3.4)", "red"))
            return

        gate_num = parsed["gate"]
        gate_data = self.gate_dict.get(str(gate_num))

        if not gate_data:
            print(self._color(f"Gate {gate_num} not found in dictionary.", "red"))
            return

        print(f"\n{self._color('🔮 GATE INTERPRETATION', 'bold')}")
        print(f"{self._color('═' * 60, 'cyan')}")
        print(f"Gate {gate_num}: {gate_data.get('full_name', 'Unknown')} ({gate_data.get('amino_acid', '?')})")
        print(f"Codons: {', '.join(gate_data.get('codons', []))}")
        print(f"Dimension: {gate_data.get('dimension', '?')} | Crystal: {gate_data.get('crystal', '?')}")
        print(f"Keynote: {gate_data.get('keynote', '?')}")
        print(f"Element: {gate_data.get('element', '?')} | Pressure: {gate_data.get('pressure', '?')}")
        print(f"Sensory: {gate_data.get('sensory', '?')}")
        print(f"Sign: {gate_data.get('sign', '?')} {gate_data.get('modality', '?')} {gate_data.get('element_sign', '?')} | House {gate_data.get('house', '?')}")
        print(f"Center: {gate_data.get('center', '?')} | Circuit: {gate_data.get('circuit', '?')}")
        print(f"{self._color('─' * 60, 'dim')}")
        print(f"Line: {parsed['line']} | Color: {parsed['color']} | Tone: {parsed['tone']} | Base: {parsed['base']}")

        line_kw = gate_data.get('line_keywords', {})
        if str(parsed['line']) in line_kw:
            print(f"Line keyword: {line_kw[str(parsed['line'])}")

        print(f"{self._color('─' * 60, 'dim')}")
        print(f"Shadow: {gate_data.get('shadow', '?')}")
        print(f"Gift:   {gate_data.get('gift', '?')}")
        print(f"Siddhi: {gate_data.get('siddhi', '?')}")

        # If engine is available, run full routing
        if self.engine and hasattr(self.engine, 'router'):
            result = self.engine["router"].route(
                gate=parsed["gate"], line=parsed["line"], 
                color=parsed["color"], tone=parsed["tone"], base=parsed["base"],
                output_mode="all"
            )

            print(f"{self._color('═' * 60, 'cyan')}")
            print(f"{self._color('METAPHYSICAL:', 'magenta')}")
            print(result.get("metaphysical", "N/A"))
            print(f"\n{self._color('SCIENTIFIC:', 'blue')}")
            print(result.get("scientific", "N/A"))
            print(f"\n{self._color('SYNTHIA:', 'cyan')}")
            print(result.get("synthia", "N/A"))

        print(f"{self._color('═' * 60, 'cyan')}")

    def cmd_query(self, args: str):
        """Oracle query with optional gate context"""
        parts = args.split('"')
        if len(parts) < 2:
            print(self._color('Usage: query "Your question here" [Gate.Line.Color.Tone.Base]', "red"))
            return

        query = parts[1]
        gate_str = parts[2].strip() if len(parts) > 2 else ""

        parsed = self.parse_gate_input(gate_str) if gate_str else None

        print(f"\n{self._color('🌌 ORACLE QUERY', 'bold')}")
        print(f"{self._color('═' * 60, 'cyan')}")
        print(f"Question: {self._color(query, 'yellow')}")

        if parsed and self.engine and hasattr(self.engine, 'oracle'):
            result = self.engine["oracle"].decode_query(
                query=query,
                gate=parsed["gate"],
                line=parsed["line"],
                color=parsed["color"],
                tone=parsed["tone"],
                base=parsed["base"]
            )

            print(f"\n{self._color('PRIMARY BODY:', 'magenta')} {result['primary_body']}")
            print(f"{self._color('ACTION:', 'green')} {result['action']}")
            print(f"{self._color('CONFIDENCE:', 'blue')} {result['confidence']:.3f}")
            print(f"{self._color('COHERENCE:', 'cyan')} {result['coherence']:.3f}")
            print(f"{self._color('FIELD STATUS:', 'yellow')} {result['field_status']}")
            print(f"\n{self._color('ADVISORY:', 'white')}")
            print(result['advisory'])

            print(f"\n{self._color('OUTPUT LAYERS:', 'dim')}")
            for mode, text in result['outputs'].items():
                if mode != 'field_analysis':
                    print(f"\n{self._color('── ' + mode.upper() + ' ──', 'dim')}")
                    print(text)
        else:
            # Simple query without engine
            print(f"\n{self._color('Gate context:', 'dim')} {gate_str if gate_str else 'None provided'}")
            print(f"\n{self._color('The field is listening...', 'dim')}")
            print(f"{self._color('Install the full engine for complete interpretation.', 'dim')}")

        print(f"{self._color('═' * 60, 'cyan')}")

    def cmd_transit(self, args: str):
        """Check transits against current natal chart"""
        if not self.current_chart:
            print(self._color("No natal chart loaded. Use 'chart' command first.", "red"))
            return

        parts = args.split()
        if len(parts) < 1:
            print(self._color("Usage: transit YYYY-MM-DD [HH:MM]", "red"))
            return

        try:
            date_parts = parts[0].split('-')
            year, month, day = int(date_parts[0]), int(date_parts[1]), int(date_parts[2])
            hour = 12.0
            if len(parts) > 1:
                time_parts = parts[1].split(':')
                hour = int(time_parts[0]) + int(time_parts[1]) / 60.0

            if self.ephemeris:
                aspects = self.ephemeris.get_transit_aspects(
                    self.current_chart, (year, month, day, hour), orb=3.0
                )

                print(f"\n{self._color('🌠 TRANSIT ASPECTS', 'bold')}")
                print(f"{self._color('═' * 60, 'cyan')}")
                print(f"Transit date: {year}-{month:02d}-{day:02d} {hour:.2f}h")
                print(f"Natal chart: {self.current_chart['date']}")
                print(f"{self._color('─' * 60, 'dim')}")

                if aspects:
                    for asp in aspects[:15]:  # Show top 15
                        orb_str = f"{asp['orb']:.2f}°"
                        print(f"  {asp['transit_planet']:10s} {asp['aspect']:12s} {asp['natal_planet']:10s} | "
                              f"Orb: {orb_str:6s} | Gates: {asp['transit_gate']:2d} → {asp['natal_gate']:2d}")
                else:
                    print("  No major aspects within 3° orb.")

                print(f"{self._color('═' * 60, 'cyan')}")
            else:
                print(self._color("Ephemeris engine not available.", "red"))

        except Exception as e:
            print(self._color(f"Error: {e}", "red"))

    def cmd_coherence(self, args: str):
        """Run full 9-body coherence analysis"""
        if self.engine and hasattr(self.engine, 'bodies'):
            from youniverse_engine import CoherenceEngine

            bodies = self.engine['bodies']
            engine = CoherenceEngine(bodies)
            analysis = engine.full_field_analysis(duration=2.0)

            print(f"\n{self._color('⚛️ 9-BODY COHERENCE ANALYSIS', 'bold')}")
            print(f"{self._color('═' * 60, 'cyan')}")

            for pair, data in analysis.items():
                if pair.startswith("FIELD"):
                    continue
                status = data["status"]
                icon = "🔒" if status == "LOCKED" else "⚡" if status == "PARTIAL" else "❌"
                color = "green" if status == "LOCKED" else "yellow" if status == "PARTIAL" else "red"
                print(f"  {icon} {self._color(pair, color)}: {data['coherence']:.3f}")

            print(f"{self._color('─' * 60, 'dim')}")
            print(f"  {self._color('FIELD COHERENCE:', 'bold')} {analysis['FIELD_COHERENCE']:.3f}")
            print(f"  {self._color('FIELD STATUS:', 'bold')} {analysis['FIELD_STATUS']}")
            print(f"{self._color('═' * 60, 'cyan')}")
        else:
            print(self._color("Engine not available for coherence analysis.", "red"))

    def cmd_waveform(self, args: str):
        """Generate waveform visualization data"""
        if self.engine and hasattr(self.engine, 'bodies'):
            import numpy as np

            bodies = self.engine['bodies']
            duration = float(args) if args else 2.0

            print(f"\n{self._color('〰️ WAVEFORM DATA', 'bold')}")
            print(f"{self._color('═' * 60, 'cyan')}")
            print(f"Duration: {duration}s | Sample rate: 1000 Hz")
            print(f"{self._color('─' * 60, 'dim')}")

            t = np.linspace(0, duration, int(1000 * duration))
            for name, body in bodies.items():
                wave = body.generate_waveform(t, duration)
                peak = np.max(np.abs(wave))
                rms = np.sqrt(np.mean(wave**2))
                print(f"  {name:12s} | Peak: {peak:.3f} | RMS: {rms:.3f} | Freq: {body.base_frequency:.3f}f₀")

            print(f"{self._color('═' * 60, 'cyan')}")
            print(f"{self._color('Tip: Pipe to matplotlib for visualization', 'dim')}")
        else:
            print(self._color("Engine not available.", "red"))

    def cmd_batch(self, args: str):
        """Process multiple charts from JSON file"""
        if not args:
            print(self._color("Usage: batch filename.json", "red"))
            return

        try:
            with open(args, 'r') as f:
                charts_data = json.load(f)

            print(f"\n{self._color('📁 BATCH PROCESSING', 'bold')}")
            print(f"{self._color('═' * 60, 'cyan')}")
            print(f"File: {args}")
            print(f"Charts: {len(charts_data)}")
            print(f"{self._color('─' * 60, 'dim')}")

            results = []
            for i, chart_input in enumerate(charts_data):
                print(f"\nProcessing chart {i+1}/{len(charts_data)}: {chart_input.get('name', 'Unnamed')}")

                if self.ephemeris:
                    result = self.ephemeris.calculate_full_chart(
                        chart_input['year'], chart_input['month'], chart_input['day'],
                        chart_input.get('hour', 12.0),
                        chart_input.get('latitude', 0.0),
                        chart_input.get('longitude', 0.0),
                        chart_input.get('chart_system', 'tropical')
                    )
                    results.append({"name": chart_input.get('name', 'Unnamed'), "chart": result})

            # Save results
            output_file = args.replace('.json', '_results.json')
            with open(output_file, 'w') as f:
                json.dump(results, f, indent=2, default=str)

            print(f"\n{self._color('✅ Results saved to:', 'green')} {output_file}")
            print(f"{self._color('═' * 60, 'cyan')}")

        except Exception as e:
            print(self._color(f"Error: {e}", "red"))

    def cmd_save(self, args: str):
        """Save current chart"""
        if not self.current_chart:
            print(self._color("No chart to save. Calculate one first.", "red"))
            return

        filename = args if args else "chart.json"
        try:
            with open(filename, 'w') as f:
                json.dump(self.current_chart, f, indent=2, default=str)
            print(self._color(f"Chart saved to {filename}", "green"))
        except Exception as e:
            print(self._color(f"Error: {e}", "red"))

    def cmd_load(self, args: str):
        """Load chart from file"""
        filename = args if args else "chart.json"
        try:
            with open(filename, 'r') as f:
                self.current_chart = json.load(f)
            print(self._color(f"Chart loaded from {filename}", "green"))
        except Exception as e:
            print(self._color(f"Error: {e}", "red"))

    def cmd_help(self, args: str):
        """Show detailed help"""
        help_text = f"""
{self._color('YOU-N-I-VERSE Pressure Shell — Detailed Help', 'bold')}
{self._color('═' * 60, 'cyan')}

{self._color('COMMANDS:', 'yellow')}

{self._color('chart', 'green')} <date> <time> <lat> <lon> [system]
  Calculate a birth chart from birth data.
  Example: chart 1985-06-15 14:30 40.7128 -74.0060 tropical
  Systems: tropical (default), sidereal, draconic

{self._color('gate', 'green')} <Gate.Line.Color.Tone.Base>
  Direct gate interpretation without birth data.
  Example: gate 25.4.6.3.4
  Shorthand: gate 25.4 (uses defaults for color/tone/base)

{self._color('query', 'green')} "<question>" [Gate.Line.Color.Tone.Base]
  Ask the oracle with optional gate context.
  Example: query "Should I move?" 25.4
  The oracle returns: action (EMERGE/WAIT/DISSOLVE), coherence, advisory

{self._color('transit', 'green')} <date> [time]
  Check planetary transits against loaded natal chart.
  Example: transit 2026-06-24 12:00

{self._color('coherence', 'green')}
  Run full 9-body phase-lock coherence analysis.
  Shows which body pairs are locked, partial, or incoherent.

{self._color('waveform', 'green')} [duration]
  Generate waveform statistics for all 9 bodies.
  Example: waveform 4.0

{self._color('batch', 'green')} <filename.json>
  Process multiple charts from a JSON file.
  Input format: [{{"name": "...", "year": 1985, "month": 6, "day": 15, ...}}]

{self._color('save', 'green')} [filename]
  Save current chart to JSON file.

{self._color('load', 'green')} [filename]
  Load chart from JSON file.

{self._color('quit', 'green')}
  Exit the pressure shell.

{self._color('GATE FORMAT:', 'yellow')}
  Gate.Line.Color.Tone.Base
  Each gate = 5.625° of the zodiac
  Each line = 0.9375° (6 lines per gate)
  Each color = 0.15625° (6 colors per line)
  Each tone = 0.02604° (6 tones per color)
  Each base = 0.00521° (5 bases per tone)

{self._color('OUTPUT MODES:', 'yellow')}
  Metaphysical — Soul-language sentence
  Scientific — Quantum/biological translation
  Synthia — Native pressure-shell syntax
  Poetic — Spiritual verse
  Gene Keys — Shadow→Gift→Siddhi journey
  Compressed — Symbolic notation

{self._color('═' * 60, 'cyan')}
        """
        print(help_text)

    def process_command(self, cmd_line: str):
        """Process a single command"""
        cmd_line = cmd_line.strip()
        if not cmd_line:
            return

        parts = cmd_line.split(None, 1)
        cmd = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""

        if cmd in ('quit', 'exit', 'q'):
            self.running = False
            print(self._color("\n🌐 Field dissolved. Until next resonance.\n", "cyan"))
        elif cmd == 'chart':
            self.cmd_chart(args)
        elif cmd == 'gate':
            self.cmd_gate(args)
        elif cmd == 'query':
            self.cmd_query(args)
        elif cmd == 'transit':
            self.cmd_transit(args)
        elif cmd == 'coherence':
            self.cmd_coherence(args)
        elif cmd == 'waveform':
            self.cmd_waveform(args)
        elif cmd == 'batch':
            self.cmd_batch(args)
        elif cmd == 'save':
            self.cmd_save(args)
        elif cmd == 'load':
            self.cmd_load(args)
        elif cmd == 'help':
            self.cmd_help(args)
        elif cmd == 'banner':
            self.print_banner()
        else:
            print(self._color(f"Unknown command: {cmd}. Type 'help' for commands.", "red"))

    def run(self):
        """Main interactive loop"""
        self.print_banner()

        while self.running:
            try:
                cmd_line = input(self.PROMPT)
                self.process_command(cmd_line)
            except KeyboardInterrupt:
                print()
                continue
            except EOFError:
                self.running = False
                print()

# Entry point
if __name__ == "__main__":
    import importlib.util

    # Try to load engine modules
    engine = None
    ephemeris = None

    try:
        spec = importlib.util.spec_from_file_location("youniverse_engine", "youniverse_engine.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        engine = mod.create_engine()
    except:
        pass

    try:
        spec = importlib.util.spec_from_file_location("ephemeris_engine", "ephemeris_engine.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        ephemeris = mod.create_ephemeris()
    except:
        pass

    ui = PressureShellUI(engine, ephemeris, "complete_gate_dictionary.json")
    ui.run()
