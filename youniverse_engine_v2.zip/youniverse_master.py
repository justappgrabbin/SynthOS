
"""
YOU-N-I-VERSE Master Engine v2.0
═══════════════════════════════════════════════════════════════════
Integrated 9-Body Consciousness Field Architecture

Modules:
  • 9-Body Waveform Generator (CoherenceEngine)
  • 64-Gate Codon Dictionary (Complete)
  • Sentence Router (6 output modes)
  • Oracle Decoder (Resonance-based advisory)
  • Ephemeris Integration (Swiss Ephemeris / libephemeris)
  • Pressure Shell UI (Interactive CLI)
  • Batch Processor (Parallel chart processing)

Design Principles:
  • No master controller — all 9 bodies vote with waveforms
  • Coherence thresholds replace if/then logic
  • Temporal layering via stellar proximology
  • Resonance-native from the ground up
"""

import numpy as np
import json
import csv
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional
from enum import Enum
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import math
import sys

# ═══════════════════════════════════════════════════════════════════
# MODULE 1: CORE DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════

class ChartSystem(Enum):
    TROPICAL = "tropical"
    SIDEREAL = "sidereal"
    DRACONIC = "draconic"

class WaveformType(Enum):
    SINE = "sine"; SQUARE = "square"; SAWTOOTH = "sawtooth"
    TRIANGLE = "triangle"; PULSE = "pulse"; NOISE = "noise"
    SINC = "sinc"; GAUSSIAN = "gaussian"; EXPONENTIAL = "exponential"

@dataclass
class Body:
    name: str; chart_system: ChartSystem; base_frequency: float
    waveform_type: WaveformType; harmonic_ratios: Dict[str, float] = field(default_factory=dict)
    phase_offset: float = 0.0; amplitude: float = 1.0; damping: float = 0.0
    dimension: str = ""; keynote: str = ""; crystal: str = ""

    def generate_waveform(self, t: np.ndarray, duration: float = 1.0) -> np.ndarray:
        omega = 2 * np.pi * self.base_frequency
        if self.waveform_type == WaveformType.SINE:
            wave = np.sin(omega * t + self.phase_offset)
        elif self.waveform_type == WaveformType.SQUARE:
            wave = np.sign(np.sin(omega * t + self.phase_offset))
        elif self.waveform_type == WaveformType.SAWTOOTH:
            wave = 2 * ((omega * t + self.phase_offset) / (2 * np.pi) - np.floor((omega * t + self.phase_offset) / (2 * np.pi) + 0.5))
        elif self.waveform_type == WaveformType.TRIANGLE:
            wave = 2 * np.arcsin(np.sin(omega * t + self.phase_offset)) / np.pi
        elif self.waveform_type == WaveformType.PULSE:
            wave = np.where(np.sin(omega * t + self.phase_offset) > 0.5, 1.0, -1.0)
        elif self.waveform_type == WaveformType.NOISE:
            np.random.seed(hash(self.name) % 2**32)
            wave = np.random.normal(0, 0.5, len(t)) + 0.5 * np.sin(omega * t)
        elif self.waveform_type == WaveformType.SINC:
            x = omega * t + self.phase_offset; wave = np.sinc(x / np.pi)
        elif self.waveform_type == WaveformType.GAUSSIAN:
            envelope = np.exp(-((t - duration/2) / (duration/4))**2)
            wave = envelope * np.sin(omega * t + self.phase_offset)
        elif self.waveform_type == WaveformType.EXPONENTIAL:
            env = np.exp(self.damping * t)
            wave = env * np.sin(omega * t + self.phase_offset)
        return self.amplitude * wave * np.exp(-0.001 * t)

@dataclass
class GateMapping:
    gate_number: int; amino_acid: str; full_name: str; codons: List[str]
    dimension: str; crystal: str; keynote: str; element: str
    pressure_type: str; sensory_vector: str; sign: str; modality: str
    element_sign: str; house: int; center: str; circuit: str; channel: str
    shadow: str; gift: str; siddhi: str; line_keywords: Dict[str, str]

    def to_metaphysical(self, line, color, tone, base):
        line_a = {1:"Investigation",2:"Projection",3:"Trial & Error",4:"Opportunism",5:"Heresy",6:"Role Model"}
        color_n = {1:"Motivation",2:"Awareness",3:"Mystery",4:"Innocence",5:"Power",6:"Peace"}
        tone_s = {1:"Touch",2:"Taste",3:"Smell",4:"Hearing",5:"Sight",6:"Knowing"}
        base_g = {1:"Point",2:"Line",3:"Plane",4:"Volume"}
        return f"{self.keynote} {color_n.get(color,'?')} expressed through {line_a.get(line,'?')}, motivated by {color_n.get(color,'?')}, filtered through {tone_s.get(tone,'?')}, rooted in {base_g.get(base,'?')}, aligned with the {self.dimension} Axis, under the sign of {self.sign}, in the realm of the {self.house}th House."

    def to_scientific(self, line, color, tone, base):
        return f"This sequence encodes {self.full_name} ({self.amino_acid}, Gate {self.gate_number}), expressing through Line {line} with Color {color} and Tone {tone}, anchored in Base {base}. Aligns with {self.sign}'s {self.modality} {self.element_sign} field in the {self.house}th House. Quantum pressure: {self.pressure_type} via {self.sensory_vector}. Codons: {', '.join(self.codons)}."

    def to_compressed(self, line, color, tone, base):
        return f"F:{self.dimension} → Gate:{self.gate_number}° → Line:{line}′ → Color:{color}″ → Tone:{tone} → Base:{base} → G:{{{self.dimension} → {self.sign} → {self.house}th}}"

# ═══════════════════════════════════════════════════════════════════
# MODULE 2: 9-BODY FACTORY
# ═══════════════════════════════════════════════════════════════════

def create_nine_bodies():
    f0 = 1.0
    return {
        "Spirit": Body("Spirit", ChartSystem.DRACONIC, f0*1.0, WaveformType.PULSE, {}, 0.0, 1.0, 0.0, "Spirit", "I Define", "Magnetic Monopole"),
        "Mind": Body("Mind", ChartSystem.SIDEREAL, f0*2.0, WaveformType.SINE, {"Spirit":2.0,"Soul":1.5}, np.pi/4, 0.9, 0.0, "Evolution", "I Remember", "Personality"),
        "Soul": Body("Soul", ChartSystem.DRACONIC, f0*3.0, WaveformType.SINC, {"Spirit":3.0,"Mind":1.5}, np.pi/3, 0.85, 0.0, "Design", "I Design", "Design"),
        "Body": Body("Body", ChartSystem.TROPICAL, f0*2.0, WaveformType.SQUARE, {"Mind":1.0,"Heart":4.0/3.0}, np.pi/2, 1.0, 0.0, "Being", "I Am", "Design"),
        "Heart": Body("Heart", ChartSystem.TROPICAL, f0*4.0/3.0, WaveformType.TRIANGLE, {"Mind":4.0/3.0,"Soul":1.25,"Body":4.0/3.0}, np.pi/6, 0.9, 0.0, "Space", "I Think", "Personality"),
        "Will": Body("Will", ChartSystem.SIDEREAL, f0*5.0/4.0, WaveformType.SAWTOOTH, {"Spirit":1.25,"Soul":5.0/6.0}, 0.0, 0.8, 0.0, "Movement", "I Define", "Magnetic Monopole"),
        "Shadow": Body("Shadow", ChartSystem.DRACONIC, f0*7.0/4.0, WaveformType.NOISE, {"Spirit":1.75,"Body":0.875}, np.pi, 0.6, 0.0, "Evolution", "I Remember", "Personality"),
        "HigherSelf": Body("HigherSelf", ChartSystem.SIDEREAL, f0*6.0/5.0, WaveformType.GAUSSIAN, {"Spirit":1.2,"Soul":0.8}, np.pi/8, 0.7, 0.0, "Space", "I Think", "Magnetic Monopole"),
        "Ego": Body("Ego", ChartSystem.TROPICAL, f0*9.0/8.0, WaveformType.EXPONENTIAL, {"Body":0.5625,"Will":0.9}, np.pi/5, 0.75, 0.1, "Design", "I Design", "Design")
    }

# ═══════════════════════════════════════════════════════════════════
# MODULE 3: COHERENCE ENGINE
# ═══════════════════════════════════════════════════════════════════

class CoherenceEngine:
    def __init__(self, bodies):
        self.bodies = bodies; self.sample_rate = 1000

    def generate_composite(self, duration=2.0, active_bodies=None):
        if active_bodies is None: active_bodies = list(self.bodies.keys())
        t = np.linspace(0, duration, int(self.sample_rate * duration))
        composite = np.zeros_like(t)
        for name in active_bodies:
            if name in self.bodies: composite += self.bodies[name].generate_waveform(t, duration)
        return t, composite

    def phase_lock_detect(self, b1, b2, duration=2.0):
        t = np.linspace(0, duration, int(self.sample_rate * duration))
        w1 = self.bodies[b1].generate_waveform(t, duration)
        w2 = self.bodies[b2].generate_waveform(t, duration)
        corr = np.correlate(w1, w2, mode='full')
        max_c = np.max(corr)
        norm = max_c / (np.sqrt(np.sum(w1**2)) * np.sqrt(np.sum(w2**2)))
        coherence = (norm + 1) / 2
        return {"coherence": float(coherence), "status": "LOCKED" if coherence > 0.7 else "PARTIAL" if coherence > 0.4 else "INCOHERENT"}

    def full_field_analysis(self, duration=2.0):
        results = {}; names = list(self.bodies.keys())
        for i, b1 in enumerate(names):
            for b2 in names[i+1:]:
                results[f"{b1}↔{b2}"] = self.phase_lock_detect(b1, b2, duration)
        coherences = [r["coherence"] for r in results.values()]
        results["FIELD_COHERENCE"] = float(np.mean(coherences))
        results["FIELD_STATUS"] = "HARMONIC" if np.mean(coherences) > 0.6 else "DISSONANT" if np.mean(coherences) < 0.3 else "PARTIAL"
        return results

# ═══════════════════════════════════════════════════════════════════
# MODULE 4: SENTENCE ROUTER
# ═══════════════════════════════════════════════════════════════════

class SentenceRouter:
    OUTPUT_MODES = ["metaphysical", "scientific", "synthia", "compressed", "poetic", "gene_keys"]

    def __init__(self, gate_dict, bodies):
        self.gate_dict = gate_dict; self.bodies = bodies; self.engine = CoherenceEngine(bodies)

    def route(self, gate, line, color, tone, base, output_mode="all", planet="", sign="", house=0):
        gate_data = self.gate_dict.get(gate)
        if not gate_data: return {"error": f"Gate {gate} not found"}

        body_map = {"Movement": ["Will","Spirit"], "Evolution": ["Mind","Shadow"],
                   "Being": ["Body"], "Design": ["Soul","Ego"], "Space": ["Heart","HigherSelf"]}
        active_bodies = body_map.get(gate_data.dimension, ["Mind"])
        coherence = self.engine.full_field_analysis()

        outputs = {}
        if output_mode in ["all", "metaphysical"]:
            outputs["metaphysical"] = gate_data.to_metaphysical(line, color, tone, base)
        if output_mode in ["all", "scientific"]:
            outputs["scientific"] = gate_data.to_scientific(line, color, tone, base)
        if output_mode in ["all", "synthia"]:
            outputs["synthia"] = f"Pressure shell active. Dimension: {gate_data.dimension}. Core pulse: {gate_data.keynote}. Codon {gate} projecting through Line {line}. Color field: {color}. Tone {tone}-flicker. Base {base} anchoring. Signal: {coherence['FIELD_STATUS'].lower()}."
        if output_mode in ["all", "compressed"]:
            outputs["compressed"] = gate_data.to_compressed(line, color, tone, base)
        if output_mode in ["all", "poetic"]:
            outputs["poetic"] = f"I am the {gate_data.sensory_vector} of truth in the geometry of {gate_data.dimension}. My {gate_data.keynote.split()[1]} is {gate_data.element}, not armor. The line I walk is {line}, clean — a sacred edge cut by the unseen."
        if output_mode in ["all", "gene_keys"]:
            outputs["gene_keys"] = f"In Gate {gate}: Shadow of {gate_data.shadow} → Gift of {gate_data.gift} → Siddhi of {gate_data.siddhi}."

        outputs["field_analysis"] = {"coherence": coherence["FIELD_COHERENCE"], "status": coherence["FIELD_STATUS"]}
        return outputs

# ═══════════════════════════════════════════════════════════════════
# MODULE 5: ORACLE DECODER
# ═══════════════════════════════════════════════════════════════════

class OracleDecoder:
    TEMPORAL_LAYERS = {
        "Pluto": {"speed":"slow","depth":"deep","octave":0.25,"body":"Shadow"},
        "Neptune": {"speed":"slow","depth":"subtle","octave":0.33,"body":"HigherSelf"},
        "Uranus": {"speed":"medium","depth":"revolutionary","octave":0.5,"body":"Soul"},
        "Saturn": {"speed":"medium","depth":"structural","octave":0.67,"body":"Ego"},
        "Jupiter": {"speed":"medium","depth":"expansive","octave":0.75,"body":"Will"},
        "Mars": {"speed":"fast","depth":"driven","octave":1.0,"body":"Body"},
        "Venus": {"speed":"fast","depth":"relational","octave":1.25,"body":"Heart"},
        "Mercury": {"speed":"fast","depth":"mental","octave":1.5,"body":"Mind"},
        "Moon": {"speed":"very_fast","depth":"surface","octave":2.0,"body":"Spirit"},
        "Sun": {"speed":"core","depth":"identity","octave":1.0,"body":"Spirit"}
    }

    def __init__(self, router): self.router = router

    def decode_query(self, query, gate, line, color, tone, base, planet="", sign="", house=0):
        primary_body = self._detect_intent_body(query)
        routed = self.router.route(gate, line, color, tone, base, "all", planet, sign, house)
        temporal = self.TEMPORAL_LAYERS.get(planet, self.TEMPORAL_LAYERS["Sun"])
        coherence = routed["field_analysis"]["coherence"]
        status = routed["field_analysis"]["status"]

        if status == "HARMONIC": action, confidence = "EMERGE", coherence
        elif status == "PARTIAL": action, confidence = "WAIT", coherence * 0.5
        else: action, confidence = "DISSOLVE", 1.0 - coherence

        return {"query": query, "primary_body": primary_body, "temporal_layer": temporal,
                "action": action, "confidence": confidence, "coherence": coherence,
                "field_status": status, "outputs": routed,
                "advisory": self._generate_advisory(action, primary_body, temporal)}

    def _detect_intent_body(self, query):
        q = query.lower()
        if any(w in q for w in ["should","choose","decide","feel","love"]): return "Heart"
        if any(w in q for w in ["what","who","meaning","purpose","am i"]): return "Spirit"
        if any(w in q for w in ["how","do","make","build","create"]): return "Will"
        if any(w in q for w in ["why","remember","past","memory","think"]): return "Mind"
        if any(w in q for w in ["body","health","sick","touch","feel physical"]): return "Body"
        if any(w in q for w in ["shadow","fear","dark","unconscious","hidden"]): return "Shadow"
        if any(w in q for w in ["higher","soul","destiny","karma","fate"]): return "HigherSelf"
        if any(w in q for w in ["ego","self","identity","me","mine"]): return "Ego"
        if any(w in q for w in ["design","structure","pattern","geometry"]): return "Soul"
        return "Spirit"

    def _generate_advisory(self, action, primary_body, temporal):
        adv = {"EMERGE": {"Spirit":"The field is coherent. Move as the wave moves.",
                         "Mind":"Memory loops closing. The gravity has enough mass.",
                         "Soul":"Crystalline structure stable. Build upon it.",
                         "Body":"Matter is ready. Chemistry aligns. Act through the body.",
                         "Heart":"Rhythm locked. Love is the only frequency.",
                         "Will":"Direction set. Drive forward.",
                         "Shadow":"Darkness is coherent. Let it teach.",
                         "HigherSelf":"Probability cloud collapsing. Step into it.",
                         "Ego":"Temporal anchoring strong. Claim the moment."},
               "WAIT": {"Spirit":"Field is partial. Do not force the pulse.",
                        "Mind":"Memory fragmented. Hold without demanding.",
                        "Soul":"Lattice forming. Wait for it to set.",
                        "Body":"Chemistry reacting. Allow completion.",
                        "Heart":"Rhythm approaching. Listen without singing.",
                        "Will":"Direction sensed. Hold the edge.",
                        "Shadow":"Darkness moving. Let chaos teach patience.",
                        "HigherSelf":"Cloud is wide. Do not seal prematurely.",
                        "Ego":"Anchoring shifting. Let the moment settle."},
               "DISSOLVE": {"Spirit":"Field is dissonant. Dissolve and re-form.",
                           "Mind":"Memory tangled. The question may be wrong. Let it go.",
                           "Soul":"Structure unstable. Break and begin again.",
                           "Body":"Chemistry in conflict. Withdraw and find correct interface.",
                           "Heart":"Rhythm broken. Silence and retune.",
                           "Will":"Direction blocked. Step back and find the grain.",
                           "Shadow":"Darkness overwhelming. Let it dissolve what no longer serves.",
                           "HigherSelf":"Cloud dispersing. Release and realign.",
                           "Ego":"Anchoring failing. Ego's death — self's rebirth."}}
        body_adv = adv.get(action, {}).get(primary_body, "The field speaks. Listen.")
        return f"[{action}] {body_adv}\n\nTemporal: {temporal['body']} governs — {temporal['depth']} at {temporal['speed']} speed."


# ═══════════════════════════════════════════════════════════════════
# MODULE 6: EPHEMERIS INTEGRATION
# ═══════════════════════════════════════════════════════════════════

try:
    import swisseph as swe
    SWISSEPH_AVAILABLE = True
except ImportError:
    try:
        import libephemeris as swe
        SWISSEPH_AVAILABLE = True
    except ImportError:
        SWISSEPH_AVAILABLE = False

class EphemerisEngine:
    PLANETS = {"Sun":0, "Moon":1, "Mercury":2, "Venus":3, "Mars":4,
               "Jupiter":5, "Saturn":6, "Uranus":7, "Neptune":8, "Pluto":9,
               "North Node":10, "South Node":10, "Chiron":15, "Lilith":12}
    SIGNS = ["Aries","Taurus","Gemini","Cancer","Leo","Virgo",
             "Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"]
    SIGN_ELEMENTS = {"Aries":"Fire","Leo":"Fire","Sagittarius":"Fire",
                    "Taurus":"Earth","Virgo":"Earth","Capricorn":"Earth",
                    "Gemini":"Air","Libra":"Air","Aquarius":"Air",
                    "Cancer":"Water","Scorpio":"Water","Pisces":"Water"}
    SIGN_MODALITIES = {"Aries":"Cardinal","Cancer":"Cardinal","Libra":"Cardinal","Capricorn":"Cardinal",
                      "Taurus":"Fixed","Leo":"Fixed","Scorpio":"Fixed","Aquarius":"Fixed",
                      "Gemini":"Mutable","Virgo":"Mutable","Sagittarius":"Mutable","Pisces":"Mutable"}

    def __init__(self, ephe_path=None):
        self.available = SWISSEPH_AVAILABLE
        if self.available and ephe_path:
            try: swe.set_ephe_path(ephe_path)
            except: pass

    def _get_jd(self, year, month, day, hour=12.0):
        if self.available: return swe.julday(year, month, day, hour)
        a = (14 - month) // 12; y = year + 4800 - a; m = month + 12 * a - 3
        jdn = day + (153*m+2)//5 + 365*y + y//4 - y//100 + y//400 - 32045
        return jdn + (hour - 12) / 24.0

    def _lon_to_sign(self, lon):
        total_deg = lon % 360; sign_idx = int(total_deg // 30)
        deg_in_sign = total_deg % 30; degrees = int(deg_in_sign)
        minutes_full = (deg_in_sign - degrees) * 60; minutes = int(minutes_full)
        seconds = (minutes_full - minutes) * 60
        return self.SIGNS[sign_idx], degrees, minutes, seconds, total_deg

    def _lon_to_gate(self, lon):
        total_deg = lon % 360; gate = int(total_deg / 5.625) + 1
        return min(gate, 64)

    def _lon_to_line(self, lon):
        total_deg = lon % 360; gate_start = int(total_deg / 5.625) * 5.625
        deg_in_gate = total_deg - gate_start; line = int(deg_in_gate / 0.9375) + 1
        return min(line, 6)

    def _lon_to_color(self, lon):
        total_deg = lon % 360; gate_start = int(total_deg / 5.625) * 5.625
        line_start = int((total_deg - gate_start) / 0.9375) * 0.9375
        deg_in_line = total_deg - gate_start - line_start
        color = int(deg_in_line / 0.15625) + 1
        return min(color, 6)

    def _lon_to_tone(self, lon):
        total_deg = lon % 360; gate_start = int(total_deg / 5.625) * 5.625
        line_start = int((total_deg - gate_start) / 0.9375) * 0.9375
        color_start = int((total_deg - gate_start - line_start) / 0.15625) * 0.15625
        deg_in_color = total_deg - gate_start - line_start - color_start
        tone = int(deg_in_color / 0.0260417) + 1
        return min(tone, 6)

    def _lon_to_base(self, lon):
        total_deg = lon % 360; gate_start = int(total_deg / 5.625) * 5.625
        line_start = int((total_deg - gate_start) / 0.9375) * 0.9375
        color_start = int((total_deg - gate_start - line_start) / 0.15625) * 0.15625
        tone_start = int((total_deg - gate_start - line_start - color_start) / 0.0260417) * 0.0260417
        deg_in_tone = total_deg - gate_start - line_start - color_start - tone_start
        base = int(deg_in_tone / 0.0052083) + 1
        return min(base, 5)

    def calculate_planet(self, planet_name, year, month, day, hour=12.0, lat=0.0, lon=0.0, chart_system="tropical"):
        jd = self._get_jd(year, month, day, hour)
        planet_id = self.PLANETS.get(planet_name)
        if planet_id is None: return {"error": f"Unknown planet: {planet_name}"}

        if not self.available: return self._fallback(planet_name, jd, chart_system)

        flags = 0
        if chart_system == "sidereal": flags |= swe.FLG_SIDEREAL
        try:
            result = swe.calc_ut(jd, planet_id, flags)
            lon_val = result[0][0] if isinstance(result[0], (list, tuple)) else result[0]
            if planet_name == "South Node": lon_val = (lon_val + 180) % 360

            sign, deg, minutes, seconds, total_deg = self._lon_to_sign(lon_val)
            return {"planet": planet_name, "chart_system": chart_system, "longitude": lon_val,
                    "sign": sign, "degree": deg, "minutes": minutes, "seconds": seconds,
                    "element": self.SIGN_ELEMENTS.get(sign, "?"), "modality": self.SIGN_MODALITIES.get(sign, "?"),
                    "gate": self._lon_to_gate(lon_val), "line": self._lon_to_line(lon_val),
                    "color": self._lon_to_color(lon_val), "tone": self._lon_to_tone(lon_val),
                    "base": self._lon_to_base(lon_val), "julian_day": jd,
                    "date": f"{year}-{month:02d}-{day:02d} {hour:.2f}h", "latitude": lat, "longitude": lon}
        except Exception as e: return {"error": str(e), "planet": planet_name}

    def _fallback(self, planet_name, jd, chart_system):
        T = (jd - 2451545.0) / 36525.0
        mean_lons = {"Sun": (280.46646 + 36000.76983*T + 0.0003032*T*T) % 360,
                     "Moon": (218.3164477 + 481267.88123421*T - 0.0015786*T*T) % 360,
                     "Mercury": (252.250906 + 149474.0722491*T + 0.0003035*T*T) % 360,
                     "Venus": (181.979801 + 58519.2130302*T + 0.0003105*T*T) % 360,
                     "Mars": (355.433275 + 19141.6964746*T + 0.0003107*T*T) % 360,
                     "Jupiter": (34.351484 + 3036.3020849*T + 0.0003108*T*T) % 360,
                     "Saturn": (50.077471 + 1223.5110146*T + 0.0003109*T*T) % 360,
                     "Uranus": (314.055005 + 429.8640561*T + 0.0003110*T*T) % 360,
                     "Neptune": (304.348665 + 219.8833092*T + 0.0003111*T*T) % 360,
                     "Pluto": (238.92881 + 145.2078051*T + 0.0003112*T*T) % 360}
        lon_val = mean_lons.get(planet_name, 0.0)
        if planet_name == "South Node": lon_val = (lon_val + 180) % 360
        sign, deg, minutes, seconds, total_deg = self._lon_to_sign(lon_val)
        return {"planet": planet_name, "chart_system": chart_system, "longitude": lon_val,
                "sign": sign, "degree": deg, "minutes": minutes, "seconds": seconds,
                "element": self.SIGN_ELEMENTS.get(sign, "?"), "modality": self.SIGN_MODALITIES.get(sign, "?"),
                "gate": self._lon_to_gate(lon_val), "line": self._lon_to_line(lon_val),
                "color": self._lon_to_color(lon_val), "tone": self._lon_to_tone(lon_val),
                "base": self._lon_to_base(lon_val), "julian_day": jd,
                "note": "FALLBACK: Swiss Ephemeris not available. Approximate positions.",
                "latitude": 0.0, "longitude": 0.0}

    def calculate_full_chart(self, year, month, day, hour=12.0, latitude=0.0, longitude=0.0, chart_system="tropical"):
        planets = ["Sun","Moon","Mercury","Venus","Mars","Jupiter","Saturn","Uranus","Neptune","Pluto","North Node","South Node"]
        chart = {"date": f"{year}-{month:02d}-{day:02d}", "time": f"{hour:.2f}",
                 "latitude": latitude, "longitude": longitude, "chart_system": chart_system,
                 "planets": {}, "houses": None}
        for p in planets:
            chart["planets"][p] = self.calculate_planet(p, year, month, day, hour, latitude, longitude, chart_system)
        if latitude != 0.0 and longitude != 0.0 and self.available:
            try:
                jd = self._get_jd(year, month, day, hour)
                houses = swe.houses(jd, latitude, longitude, b"P")
                chart["houses"] = {"cusps": houses[0], "ascendant": houses[1][0], "mc": houses[2][0]}
            except: pass
        return chart

    def get_transit_aspects(self, natal_chart, transit_date, orb=3.0):
        aspects = []; aspect_angles = {"conjunction": 0, "sextile": 60, "square": 90, "trine": 120, "opposition": 180}
        year, month, day, hour = transit_date
        for natal_p, natal_d in natal_chart["planets"].items():
            if "error" in natal_d: continue
            natal_lon = natal_d["longitude"]
            for trans_p in ["Sun","Moon","Mercury","Venus","Mars","Jupiter","Saturn"]:
                trans_d = self.calculate_planet(trans_p, year, month, day, hour,
                    natal_chart.get("latitude", 0), natal_chart.get("longitude", 0), natal_chart.get("chart_system", "tropical"))
                if "error" in trans_d: continue
                trans_lon = trans_d["longitude"]
                diff = abs((trans_lon - natal_lon + 180) % 360 - 180)
                for aspect_name, aspect_angle in aspect_angles.items():
                    if abs(diff - aspect_angle) <= orb:
                        aspects.append({"natal_planet": natal_p, "transit_planet": trans_p,
                                       "aspect": aspect_name, "angle": aspect_angle, "orb": abs(diff - aspect_angle),
                                       "natal_gate": natal_d["gate"], "transit_gate": trans_d["gate"],
                                       "natal_sign": natal_d["sign"], "transit_sign": trans_d["sign"]})
        aspects.sort(key=lambda x: x["orb"]); return aspects

# ═══════════════════════════════════════════════════════════════════
# MODULE 7: BATCH PROCESSOR
# ═══════════════════════════════════════════════════════════════════

class BatchProcessor:
    def __init__(self, engine, ephemeris, gate_dict):
        self.engine = engine; self.ephemeris = ephemeris; self.gate_dict = gate_dict; self.results = []

    def parse_input_json(self, filepath):
        with open(filepath, 'r') as f: data = json.load(f)
        return [data] if isinstance(data, dict) else data

    def parse_input_csv(self, filepath):
        charts = []
        with open(filepath, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                charts.append({"name": row.get("name","Unnamed"), "year": int(row["year"]),
                              "month": int(row["month"]), "day": int(row["day"]),
                              "hour": float(row.get("hour", 12.0)),
                              "latitude": float(row.get("latitude", 0.0)),
                              "longitude": float(row.get("longitude", 0.0)),
                              "chart_system": row.get("chart_system", "tropical"),
                              "query": row.get("query", "")})
        return charts

    def process_single_chart(self, chart_input):
        name = chart_input.get("name", "Unnamed")
        result = {"name": name, "input": chart_input, "timestamp": datetime.now().isoformat(),
                  "chart": None, "activated_gates": [], "definition": None, "type": None,
                  "authority": None, "profile": None, "channels": [], "centers": {},
                  "coherence_analysis": None, "oracle_reading": None, "output_layers": {}}

        if self.ephemeris:
            chart = self.ephemeris.calculate_full_chart(
                chart_input["year"], chart_input["month"], chart_input["day"],
                chart_input.get("hour", 12.0), chart_input.get("latitude", 0.0),
                chart_input.get("longitude", 0.0), chart_input.get("chart_system", "tropical"))
            result["chart"] = chart

            activated = []
            for planet, data in chart["planets"].items():
                if "error" not in data:
                    gate_num = data["gate"]
                    gate_data = self.gate_dict.get(gate_num, {})
                    activated.append({"planet": planet, "gate": gate_num, "line": data["line"],
                                     "color": data["color"], "tone": data["tone"], "base": data["base"],
                                     "sign": data["sign"], "element": data["element"],
                                     "dimension": gate_data.get("dimension", "?"),
                                     "center": gate_data.get("center", "?"),
                                     "amino_acid": gate_data.get("amino_acid", "?"),
                                     "keynote": gate_data.get("keynote", "?")})
            result["activated_gates"] = activated

            centers_active = {}
            for gate in activated:
                c = gate["center"]
                if c not in centers_active: centers_active[c] = []
                centers_active[c].append(gate["gate"])
            result["centers"] = {c: {"gates": g, "defined": len(g) > 0} for c, g in centers_active.items()}

            sacral = [g for g in activated if g["center"] == "Sacral"]
            emotional = [g for g in activated if g["center"] == "Solar Plexus"]
            if sacral and emotional: result["type"] = "Generator (Emotional)"; result["authority"] = "Solar Plexus"
            elif sacral: result["type"] = "Generator (Sacral)"; result["authority"] = "Sacral"
            elif emotional: result["type"] = "Projector"; result["authority"] = "Solar Plexus"
            else: result["type"] = "Projector"; result["authority"] = "Self-Projected"

            sun_data = chart["planets"].get("Sun", {})
            if "error" not in sun_data:
                sun_line = sun_data["line"]
                earth_line = ((sun_line + 3) % 6) or 6
                result["profile"] = f"{sun_line}/{earth_line}"

            if self.engine and hasattr(self.engine, 'bodies'):
                coh_engine = CoherenceEngine(self.engine['bodies'])
                result["coherence_analysis"] = coh_engine.full_field_analysis(duration=2.0)

            query = chart_input.get("query", "")
            if query and self.engine and hasattr(self.engine, 'oracle'):
                sun_gate = chart["planets"].get("Sun", {}).get("gate", 1)
                sun_line = chart["planets"].get("Sun", {}).get("line", 1)
                oracle_result = self.engine["oracle"].decode_query(query, sun_gate, sun_line, 1, 1, 1)
                result["oracle_reading"] = oracle_result
                result["output_layers"] = oracle_result.get("outputs", {})
        return result

    def process_batch(self, charts, max_workers=4):
        self.results = []
        print(f"Processing {len(charts)} charts with {max_workers} workers...")
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(self.process_single_chart, chart): i for i, chart in enumerate(charts)}
            for future in as_completed(futures):
                idx = futures[future]
                try:
                    result = future.result(); self.results.append(result)
                    print(f"  ✓ Chart {idx+1}/{len(charts)}: {result['name']}")
                except Exception as e: print(f"  ✗ Chart {idx+1}/{len(charts)}: ERROR - {e}")
        return self.results

    def export_json(self, filepath):
        with open(filepath, 'w') as f: json.dump(self.results, f, indent=2, default=str)
        print(f"Results exported to {filepath}")

    def export_csv(self, filepath):
        rows = []
        for result in self.results:
            row = {"name": result["name"], "type": result.get("type", ""),
                   "authority": result.get("authority", ""), "profile": result.get("profile", ""),
                   "activated_gates_count": len(result.get("activated_gates", [])),
                   "defined_centers": sum(1 for c, d in result.get("centers", {}).items() if d.get("defined", False)),
                   "coherence": result.get("coherence_analysis", {}).get("FIELD_COHERENCE", 0),
                   "oracle_action": result.get("oracle_reading", {}).get("action", ""),
                   "oracle_confidence": result.get("oracle_reading", {}).get("confidence", 0)}
            for i, gate in enumerate(result.get("activated_gates", [])[:10]):
                row[f"gate_{i+1}"] = f"{gate['planet']}:{gate['gate']}.{gate['line']}"
            rows.append(row)
        if rows:
            keys = rows[0].keys()
            with open(filepath, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=keys); writer.writeheader(); writer.writerows(rows)
            print(f"CSV summary exported to {filepath}")

    def export_report(self, filepath):
        with open(filepath, 'w') as f:
            f.write("=" * 70 + "\n"); f.write("YOU-N-I-VERSE BATCH PROCESSING REPORT\n")
            f.write(f"Generated: {datetime.now().isoformat()}\n"); f.write("=" * 70 + "\n\n")
            for result in self.results:
                f.write(f"\n{'─' * 70}\n"); f.write(f"NAME: {result['name']}\n")
                f.write(f"TYPE: {result.get('type','Unknown')} | AUTHORITY: {result.get('authority','Unknown')}\n")
                f.write(f"PROFILE: {result.get('profile','Unknown')}\n"); f.write(f"{'─' * 70}\n")
                f.write("\nACTIVATED GATES:\n")
                for gate in result.get("activated_gates", []):
                    f.write(f"  {gate['planet']:10s} → Gate {gate['gate']:2d}.{gate['line']} | "
                           f"{gate['sign']:12s} | {gate['dimension']:10s} | {gate['amino_acid']:4s} | {gate['keynote']}\n")
                f.write("\nDEFINED CENTERS:\n")
                for center, data in result.get("centers", {}).items():
                    f.write(f"  {center:15s}: {'DEFINED' if data.get('defined') else 'OPEN'} ({len(data.get('gates',[]))} gates)\n")
                if result.get("coherence_analysis"):
                    f.write(f"\nFIELD COHERENCE: {result['coherence_analysis'].get('FIELD_COHERENCE',0):.3f}\n")
                if result.get("oracle_reading"):
                    f.write(f"\nORACLE: {result['oracle_reading'].get('action','')} | "
                           f"Confidence: {result['oracle_reading'].get('confidence',0):.3f}\n")
                f.write("\n")
        print(f"Report exported to {filepath}")

    def generate_summary(self):
        if not self.results: return {}
        types, authorities, profiles = {}, {}, {}
        total_gates, coherence_scores = [], []
        for result in self.results:
            types[result.get("type","Unknown")] = types.get(result.get("type","Unknown"), 0) + 1
            authorities[result.get("authority","Unknown")] = authorities.get(result.get("authority","Unknown"), 0) + 1
            profiles[result.get("profile","Unknown")] = profiles.get(result.get("profile","Unknown"), 0) + 1
            total_gates.append(len(result.get("activated_gates", [])))
            if result.get("coherence_analysis"): coherence_scores.append(result["coherence_analysis"].get("FIELD_COHERENCE", 0))
        return {"total_charts": len(self.results), "types_distribution": types,
                "authorities_distribution": authorities, "profiles_distribution": profiles,
                "avg_activated_gates": np.mean(total_gates) if total_gates else 0,
                "avg_coherence": np.mean(coherence_scores) if coherence_scores else 0,
                "coherence_std": np.std(coherence_scores) if coherence_scores else 0}


# ═══════════════════════════════════════════════════════════════════
# MODULE 8: PRESSURE SHELL UI
# ═══════════════════════════════════════════════════════════════════

class PressureShellUI:
    PROMPT = "🌐 YOU-N-I-VERSE > "
    COLORS = {"reset": "\033[0m", "bold": "\033[1m", "dim": "\033[2m",
              "red": "\033[91m", "green": "\033[92m", "yellow": "\033[93m",
              "blue": "\033[94m", "magenta": "\033[95m", "cyan": "\033[96m", "white": "\033[97m"}

    def __init__(self, engine=None, ephemeris=None, gate_dict=None):
        self.engine = engine; self.ephemeris = ephemeris; self.gate_dict = gate_dict or {}
        self.current_chart = None; self.running = True

    def _c(self, text, color): return f"{self.COLORS.get(color,'')}{text}{self.COLORS['reset']}"

    def print_banner(self):
        print(f"""
{self._c("╔══════════════════════════════════════════════════════════════╗", "cyan")}
{self._c("║", "cyan")}  {self._c("YOU-N-I-VERSE", "bold")} {self._c("Pressure Shell v2.0", "dim")}                              {self._c("║", "cyan")}
{self._c("║", "cyan")}  9-Body Consciousness Field | Resonance-Native Architecture  {self._c("║", "cyan")}
{self._c("║", "cyan")}  No Master Controller | Waveform Voting | Coherence-Based     {self._c("║", "cyan")}
{self._c("╚══════════════════════════════════════════════════════════════╝", "cyan")}

{self._c("Commands:", "yellow")}
  {self._c("chart", "green")}      - Calculate birth chart (date time lat lon [system])
  {self._c("gate", "green")}       - Direct gate input (Gate.Line.Color.Tone.Base)
  {self._c("query", "green")}      - Ask oracle ("question" [gate])
  {self._c("transit", "green")}    - Check transits (date [time])
  {self._c("coherence", "green")}  - Run 9-body coherence analysis
  {self._c("waveform", "green")}   - Waveform statistics ([duration])
  {self._c("batch", "green")}      - Process file (filename.json/csv)
  {self._c("save", "green")}       - Save chart ([filename])
  {self._c("load", "green")}       - Load chart ([filename])
  {self._c("help", "green")}       - Show detailed help
  {self._c("quit", "green")}       - Exit shell

{self._c("Syntax:", "yellow")}
  gate 25.4.6.3.4
  query "Should I move?" 25.4
  chart 1985-06-15 14:30 40.7 -74.0 tropical
        """)

    def parse_gate(self, s):
        parts = s.strip().split('.'); 
        try: return {"gate": int(parts[0]), "line": int(parts[1]) if len(parts)>1 else 1,
                     "color": int(parts[2]) if len(parts)>2 else 1, "tone": int(parts[3]) if len(parts)>3 else 1,
                     "base": int(parts[4]) if len(parts)>4 else 1}
        except: return None

    def cmd_chart(self, args):
        parts = args.split()
        if len(parts) < 4: print(self._c("Usage: chart YYYY-MM-DD HH:MM LAT LON [system]", "red")); return
        try:
            dp = parts[0].split('-'); y, m, d = int(dp[0]), int(dp[1]), int(dp[2])
            tp = parts[1].split(':'); hour = int(tp[0]) + int(tp[1])/60.0
            lat, lon = float(parts[2]), float(parts[3])
            system = parts[4] if len(parts) > 4 else "tropical"
            if self.ephemeris:
                chart = self.ephemeris.calculate_full_chart(y, m, d, hour, lat, lon, system)
                self.current_chart = chart
                print(f"\n{self._c('📊 BIRTH CHART', 'bold')}"); print(self._c("═" * 50, "cyan"))
                print(f"Date: {chart['date']} {chart['time']}h | Location: {lat:.4f}, {lon:.4f}")
                print(self._c("─" * 50, "dim"))
                icons = {"Sun":"☉","Moon":"☽","Mercury":"☿","Venus":"♀","Mars":"♂","Jupiter":"♃","Saturn":"♄","Uranus":"♅","Neptune":"♆","Pluto":"♇","North Node":"☊","South Node":"☋"}
                for p, data in chart["planets"].items():
                    if "error" not in data:
                        print(f"  {icons.get(p,'')} {p:12s} → {data['sign']:12s} {data['degree']:2d}°{data['minutes']:2d}' | Gate {data['gate']:2d}.{data['line']} | {data['element']}")
                if chart.get("houses"): print(f"  ASC: {chart['houses']['ascendant']:.2f}° | MC: {chart['houses']['mc']:.2f}°")
                print(self._c("═" * 50, "cyan"))
            else: print(self._c("Ephemeris not available. Install pysweph or libephemeris.", "red"))
        except Exception as e: print(self._c(f"Error: {e}", "red"))

    def cmd_gate(self, args):
        parsed = self.parse_gate(args)
        if not parsed: print(self._c("Invalid format. Use: Gate.Line.Color.Tone.Base", "red")); return
        gate_num = parsed["gate"]; gate_data = self.gate_dict.get(gate_num)
        if not gate_data: print(self._c(f"Gate {gate_num} not found.", "red")); return
        print(f"\n{self._c('🔮 GATE ' + str(gate_num), 'bold')}"); print(self._c("═" * 60, "cyan"))
        print(f"{gate_data.full_name} ({gate_data.amino_acid}) | Codons: {', '.join(gate_data.codons)}")
        print(f"Dimension: {gate_data.dimension} | Crystal: {gate_data.crystal} | Keynote: {gate_data.keynote}")
        print(f"Element: {gate_data.element} | Pressure: {gate_data.pressure_type} | Sensory: {gate_data.sensory_vector}")
        print(f"Sign: {gate_data.sign} {gate_data.modality} {gate_data.element_sign} | House {gate_data.house}")
        print(f"Center: {gate_data.center} | Circuit: {gate_data.circuit} | Channel: {gate_data.channel}")
        print(self._c("─" * 60, "dim")); print(f"Line: {parsed['line']} | Color: {parsed['color']} | Tone: {parsed['tone']} | Base: {parsed['base']}")
        kw = gate_data.line_keywords.get(str(parsed['line']), "")
        if kw: print(f"Line keyword: {kw}")
        print(self._c("─" * 60, "dim")); print(f"Shadow: {gate_data.shadow} | Gift: {gate_data.gift} | Siddhi: {gate_data.siddhi}")
        if self.engine and hasattr(self.engine, 'router'):
            result = self.engine["router"].route(gate_num, parsed["line"], parsed["color"], parsed["tone"], parsed["base"], "all")
            print(self._c("═" * 60, "cyan")); print(self._c("METAPHYSICAL:", "magenta")); print(result.get("metaphysical",""))
            print(f"\n{self._c('SCIENTIFIC:', 'blue')}"); print(result.get("scientific",""))
            print(f"\n{self._c('SYNTHIA:', 'cyan')}"); print(result.get("synthia",""))
        print(self._c("═" * 60, "cyan"))

    def cmd_query(self, args):
        parts = args.split('"')
        if len(parts) < 2: print(self._c('Usage: query "question" [Gate.Line]', "red")); return
        query = parts[1]; gate_str = parts[2].strip() if len(parts) > 2 else ""
        parsed = self.parse_gate(gate_str) if gate_str else None
        print(f"\n{self._c('🌌 ORACLE QUERY', 'bold')}"); print(self._c("═" * 60, "cyan"))
        print(f"Question: {self._c(query, 'yellow')}")
        if parsed and self.engine and hasattr(self.engine, 'oracle'):
            result = self.engine["oracle"].decode_query(query, parsed["gate"], parsed["line"], parsed["color"], parsed["tone"], parsed["base"])
            print(f"\n{self._c('BODY:', 'magenta')} {result['primary_body']} | {self._c('ACTION:', 'green')} {result['action']}")
            print(f"{self._c('CONFIDENCE:', 'blue')} {result['confidence']:.3f} | {self._c('COHERENCE:', 'cyan')} {result['coherence']:.3f}")
            print(f"\n{self._c('ADVISORY:', 'white')}"); print(result['advisory'])
            for mode, text in result['outputs'].items():
                if mode != 'field_analysis': print(f"\n{self._c('── ' + mode.upper() + ' ──', 'dim')}"); print(text)
        else: print(f"\nGate: {gate_str if gate_str else 'None'}"); print(self._c("Install full engine for complete interpretation.", "dim"))
        print(self._c("═" * 60, "cyan"))

    def cmd_transit(self, args):
        if not self.current_chart: print(self._c("No natal chart. Use 'chart' first.", "red")); return
        parts = args.split()
        if len(parts) < 1: print(self._c("Usage: transit YYYY-MM-DD [HH:MM]", "red")); return
        try:
            dp = parts[0].split('-'); y, m, d = int(dp[0]), int(dp[1]), int(dp[2])
            hour = 12.0
            if len(parts) > 1: tp = parts[1].split(':'); hour = int(tp[0]) + int(tp[1])/60.0
            if self.ephemeris:
                aspects = self.ephemeris.get_transit_aspects(self.current_chart, (y, m, d, hour), 3.0)
                print(f"\n{self._c('🌠 TRANSITS', 'bold')}"); print(self._c("═" * 60, "cyan"))
                print(f"Transit: {y}-{m:02d}-{d:02d} {hour:.2f}h | Natal: {self.current_chart['date']}")
                print(self._c("─" * 60, "dim"))
                if aspects:
                    for asp in aspects[:15]:
                        print(f"  {asp['transit_planet']:10s} {asp['aspect']:12s} {asp['natal_planet']:10s} | "
                              f"Orb: {asp['orb']:.2f}° | Gates: {asp['transit_gate']:2d} → {asp['natal_gate']:2d}")
                else: print("  No major aspects within 3°.")
                print(self._c("═" * 60, "cyan"))
            else: print(self._c("Ephemeris not available.", "red"))
        except Exception as e: print(self._c(f"Error: {e}", "red"))

    def cmd_coherence(self, args):
        if self.engine and hasattr(self.engine, 'bodies'):
            engine = CoherenceEngine(self.engine['bodies']); analysis = engine.full_field_analysis(2.0)
            print(f"\n{self._c('⚛️ COHERENCE', 'bold')}"); print(self._c("═" * 60, "cyan"))
            for pair, data in analysis.items():
                if pair.startswith("FIELD"): continue
                icon = "🔒" if data["status"] == "LOCKED" else "⚡" if data["status"] == "PARTIAL" else "❌"
                color = "green" if data["status"] == "LOCKED" else "yellow" if data["status"] == "PARTIAL" else "red"
                print(f"  {icon} {self._c(pair, color)}: {data['coherence']:.3f}")
            print(self._c("─" * 60, "dim"))
            print(f"  {self._c('FIELD COHERENCE:', 'bold')} {analysis['FIELD_COHERENCE']:.3f}")
            print(f"  {self._c('FIELD STATUS:', 'bold')} {analysis['FIELD_STATUS']}")
            print(self._c("═" * 60, "cyan"))
        else: print(self._c("Engine not available.", "red"))

    def cmd_waveform(self, args):
        if self.engine and hasattr(self.engine, 'bodies'):
            duration = float(args) if args else 2.0; t = np.linspace(0, duration, int(1000 * duration))
            print(f"\n{self._c('〰️ WAVEFORMS', 'bold')}"); print(self._c("═" * 60, "cyan"))
            for name, body in self.engine['bodies'].items():
                wave = body.generate_waveform(t, duration)
                print(f"  {name:12s} | Peak: {np.max(np.abs(wave)):.3f} | RMS: {np.sqrt(np.mean(wave**2)):.3f} | f: {body.base_frequency:.3f}f₀")
            print(self._c("═" * 60, "cyan"))
        else: print(self._c("Engine not available.", "red"))

    def cmd_batch(self, args):
        if not args: print(self._c("Usage: batch filename.json/csv", "red")); return
        try:
            processor = BatchProcessor(self.engine, self.ephemeris, self.gate_dict)
            if args.endswith('.json'): charts = processor.parse_input_json(args)
            elif args.endswith('.csv'): charts = processor.parse_input_csv(args)
            else: print(self._c("Unsupported file format. Use .json or .csv", "red")); return
            results = processor.process_batch(charts)
            processor.export_json(args.replace('.json','_results.json').replace('.csv','_results.json'))
            processor.export_csv(args.replace('.json','_summary.csv').replace('.csv','_summary.csv'))
            processor.export_report(args.replace('.json','_report.txt').replace('.csv','_report.txt'))
            summary = processor.generate_summary()
            print(f"\n{self._c('BATCH SUMMARY:', 'bold')}")
            for k, v in summary.items(): print(f"  {k}: {v}")
        except Exception as e: print(self._c(f"Error: {e}", "red"))

    def cmd_save(self, args):
        if not self.current_chart: print(self._c("No chart to save.", "red")); return
        fn = args if args else "chart.json"
        try: json.dump(self.current_chart, open(fn, 'w'), indent=2, default=str); print(self._c(f"Saved to {fn}", "green"))
        except Exception as e: print(self._c(f"Error: {e}", "red"))

    def cmd_load(self, args):
        fn = args if args else "chart.json"
        try: self.current_chart = json.load(open(fn)); print(self._c(f"Loaded from {fn}", "green"))
        except Exception as e: print(self._c(f"Error: {e}", "red"))

    def cmd_help(self, args):
        print(f"""
{self._c('YOU-N-I-VERSE — Detailed Help', 'bold')}
{self._c('═' * 60, 'cyan')}
{self._c('chart', 'green')} <date> <time> <lat> <lon> [system]
  Calculate birth chart. Example: chart 1985-06-15 14:30 40.7 -74.0 tropical
{self._c('gate', 'green')} <G.L.C.T.B>
  Direct gate interpretation. Example: gate 25.4.6.3.4
{self._c('query', 'green')} "<question>" [gate]
  Oracle query. Example: query "Should I move?" 25.4
{self._c('transit', 'green')} <date> [time]
  Check transits. Example: transit 2026-06-24 12:00
{self._c('coherence', 'green')}
  Run 9-body coherence analysis
{self._c('waveform', 'green')} [duration]
  Waveform statistics
{self._c('batch', 'green')} <file>
  Process multiple charts from JSON/CSV
{self._c('save/load', 'green')} [file]
  Save/load chart
{self._c('quit', 'green')}
  Exit shell
{self._c('═' * 60, 'cyan')}
        """)

    def process_command(self, cmd_line):
        cmd_line = cmd_line.strip()
        if not cmd_line: return
        parts = cmd_line.split(None, 1); cmd = parts[0].lower(); args = parts[1] if len(parts) > 1 else ""
        if cmd in ('quit', 'exit', 'q'):
            self.running = False; print(self._c("\n🌐 Field dissolved. Until next resonance.\n", "cyan"))
        elif cmd == 'chart': self.cmd_chart(args)
        elif cmd == 'gate': self.cmd_gate(args)
        elif cmd == 'query': self.cmd_query(args)
        elif cmd == 'transit': self.cmd_transit(args)
        elif cmd == 'coherence': self.cmd_coherence(args)
        elif cmd == 'waveform': self.cmd_waveform(args)
        elif cmd == 'batch': self.cmd_batch(args)
        elif cmd == 'save': self.cmd_save(args)
        elif cmd == 'load': self.cmd_load(args)
        elif cmd == 'help': self.cmd_help(args)
        elif cmd == 'banner': self.print_banner()
        else: print(self._c(f"Unknown: {cmd}. Type 'help'.", "red"))

    def run(self):
        self.print_banner()
        while self.running:
            try: cmd_line = input(self.PROMPT); self.process_command(cmd_line)
            except KeyboardInterrupt: print(); continue
            except EOFError: self.running = False; print()

# ═══════════════════════════════════════════════════════════════════
# MODULE 9: 64-GATE DICTIONARY LOADER
# ═══════════════════════════════════════════════════════════════════

def load_64_gate_dictionary():
    """Load the complete 64-gate dictionary from embedded data or JSON file."""
    gates = {}

    # G CENTER (8 gates)
    gates[1] = GateMapping(1, "Tyr", "Tyrosine", ["UAU","UAC"], "Movement", "Magnetic Monopole", "I Define",
                          "Fire", "Energy", "Seeing", "Aries", "Cardinal", "Fire", 1, "G", "Individual", "1-8",
                          "Entropy", "Freshness", "Beauty", {str(i):v for i,v in {1:"Creative",2:"Love of the Body",3:"Drive",4:"Aloneness",5:"Manifestation",6:"Authority"}.items()})
    gates[2] = GateMapping(2, "Ser", "Serine", ["UCU","UCC","UCA","UCG"], "Movement", "Magnetic Monopole", "I Define",
                          "Earth", "Energy", "Seeing", "Taurus", "Fixed", "Earth", 2, "G", "Individual", "2-14",
                          "Dislocation", "Orientation", "Unity", {str(i):v for i,v in {1:"The Receptive",2:"Genius",3:"Wisdom",4:"Managership",5:"Intelligence",6:"Fixation"}.items()})
    gates[7] = GateMapping(7, "Asn", "Asparagine", ["AAU","AAC"], "Evolution", "Personality", "I Remember",
                          "Air", "Gravity", "Taste", "Libra", "Cardinal", "Air", 7, "G", "Collective", "7-31",
                          "Division", "Guidance", "Virtue", {str(i):v for i,v in {1:"Democracy",2:"Demagogue",3:"Anarchist",4:"Abdiction",5:"The General",6:"The Administrator"}.items()})
    gates[10] = GateMapping(10, "Gly", "Glycine", ["GGU","GGC","GGA","GGG"], "Movement", "Magnetic Monopole", "I Define",
                           "Earth", "Energy", "Seeing", "Capricorn", "Cardinal", "Earth", 10, "G", "Individual", "10-20",
                           "Self-Obsession", "Naturalness", "Being", {str(i):v for i,v in {1:"Modesty",2:"The Hermit",3:"The Martyr",4:"The Transmitter",5:"The Heretic",6:"The Role Model"}.items()})
    gates[13] = GateMapping(13, "Gln", "Glutamine", ["CAA","CAG"], "Evolution", "Personality", "I Remember",
                           "Water", "Gravity", "Taste", "Sagittarius", "Mutable", "Fire", 9, "G", "Collective", "13-33",
                           "Discord", "Discernment", "Empathy", {str(i):v for i,v in {1:"The Optimist",2:"The Bigot",3:"The Pessimist",4:"The Realist",5:"The Witness",6:"The Listener"}.items()})
    gates[15] = GateMapping(15, "Lys", "Lysine", ["AAA","AAG"], "Design", "Design", "I Design",
                           "Air", "Structure", "Smell", "Gemini", "Mutable", "Air", 3, "G", "Collective", "15-5",
                           "Dullness", "Magnetism", "Florescence", {str(i):v for i,v in {1:"Duty",2:"Influence",3:"Modesty",4:"The Alpha",5:"Sensitivity",6:"Self-Defense"}.items()})
    gates[25] = GateMapping(25, "His", "Histidine", ["CAU","CAC"], "Being", "Design", "I Am",
                           "Water", "Matter", "Touch", "Virgo", "Mutable", "Earth", 6, "G", "Individual", "25-51",
                           "Constriction", "Innocence", "Universal Love", {str(i):v for i,v in {1:"The Need to Be Loved",2:"The Teacher",3:"Surrender",4:"The Spiritualist",5:"The Pragmatist",6:"The Spirit"}.items()})
    gates[46] = GateMapping(46, "Leu", "Leucine", ["UUA","UUG","CUU","CUC","CUA","CUG"], "Being", "Design", "I Am",
                             "Earth", "Matter", "Touch", "Pisces", "Mutable", "Water", 12, "G", "Individual", "46-29",
                             "Seriousness", "Delight", "Ecstasy", {str(i):v for i,v in {1:"The Serpent",2:"The Pragmatist",3:"The Experiment",4:"The Determination",5:"The Pacing",6:"The Integrity"}.items()})

    # AJNA (6 gates)
    gates[4] = GateMapping(4, "Thr", "Threonine", ["ACU","ACC","ACA","ACG"], "Evolution", "Personality", "I Remember",
                          "Air", "Gravity", "Taste", "Gemini", "Mutable", "Air", 3, "Ajna", "Individual", "4-63",
                          "Intolerance", "Understanding", "Forgiveness", {str(i):v for i,v in {1:"The Opportunist",2:"The Saboteur",3:"The Reconciler",4:"The Administrator",5:"The General",6:"The Confession"}.items()})
    gates[11] = GateMapping(11, "Arg", "Arginine", ["CGU","CGC","CGA","CGG","AGA","AGG"], "Space", "Personality", "I Think",
                           "Fire", "Form", "Hearing", "Aquarius", "Fixed", "Air", 11, "Ajna", "Collective", "11-56",
                           "Obscurity", "Idealism", "Awakening", {str(i):v for i,v in {1:"The Investigator",2:"The Attendant",3:"The Student",4:"The Teacher",5:"The Philosopher",6:"The Adapter"}.items()})
    gates[17] = GateMapping(17, "Cys", "Cysteine", ["UGU","UGC"], "Design", "Design", "I Design",
                             "Air", "Structure", "Smell", "Aries", "Cardinal", "Fire", 1, "Ajna", "Collective", "17-62",
                             "Opinion", "Far-sightedness", "Omniscience", {str(i):v for i,v in {1:"The Openness",2:"The Understanding",3:"The Discrimination",4:"The Personnel Manager",5:"The Speaker",6:"The Bodhisattva"}.items()})
    gates[24] = GateMapping(24, "Met", "Methionine", ["AUG"], "Evolution", "Personality", "I Remember",
                             "Water", "Gravity", "Taste", "Taurus", "Fixed", "Earth", 2, "Ajna", "Individual", "24-61",
                             "Addiction", "Invention", "Silence", {str(i):v for i,v in {1:"The Sinister",2:"The Recognition",3:"The Addict",4:"The Hermit",5:"The Confession",6:"The Gift"}.items()})
    gates[43] = GateMapping(43, "Trp", "Tryptophan", ["UGG"], "Space", "Personality", "I Think",
                             "Water", "Form", "Hearing", "Virgo", "Mutable", "Earth", 6, "Ajna", "Individual", "43-23",
                             "Deafness", "Insight", "Epiphany", {str(i):v for i,v in {1:"The Inventor",2:"The Determination",3:"The Intervention",4:"The Breakthrough",5:"The Progression",6:"The Mutation"}.items()})
    gates[47] = GateMapping(47, "Pro", "Proline", ["CCU","CCC","CCA","CCG"], "Space", "Personality", "I Think",
                             "Fire", "Form", "Hearing", "Libra", "Cardinal", "Air", 7, "Ajna", "Individual", "47-64",
                             "Oppression", "Transmutation", "Transfiguration", {str(i):v for i,v in {1:"The Rust",2:"The Determination",3:"The Self-Opinion",4:"The Re-creation",5:"The Stoic",6:"The Peace"}.items()})

    # THROAT (11 gates)
    gates[8] = GateMapping(8, "Phe", "Phenylalanine", ["UUU","UUC"], "Movement", "Magnetic Monopole", "I Define",
                          "Earth", "Energy", "Seeing", "Gemini", "Mutable", "Air", 3, "Throat", "Individual", "1-8",
                          "Mediocrity", "Style", "Exquisiteness", {str(i):v for i,v in {1:"The Creative Role",2:"The Teacher",3:"The Party",4:"The Respect",5:"The Dharma",6:"The Communion"}.items()})
    gates[12] = GateMapping(12, "Val", "Valine", ["GUU","GUC","GUA","GUG"], "Space", "Personality", "I Think",
                            "Fire", "Form", "Hearing", "Leo", "Fixed", "Fire", 5, "Throat", "Individual", "12-22",
                            "Impatience", "Discrimination", "Timelessness", {str(i):v for i,v in {1:"The Natural",2:"The Purist",3:"The Confessor",4:"The Prophet",5:"The Pragmatist",6:"The Metamorphosis"}.items()})
    gates[16] = GateMapping(16, "Ile", "Isoleucine", ["AUU","AUC","AUA"], "Space", "Personality", "I Think",
                            "Water", "Form", "Hearing", "Aries", "Cardinal", "Fire", 1, "Throat", "Collective", "16-48",
                            "Indifference", "Versatility", "Mastery", {str(i):v for i,v in {1:"The Determination",2:"The Qualification",3:"The Experiment",4:"The Quality",5:"The Gratitude",6:"The Skills"}.items()})
    gates[20] = GateMapping(20, "Ala", "Alanine", ["GCU","GCC","GCA","GCG"], "Design", "Design", "I Design",
                            "Fire", "Structure", "Smell", "Sagittarius", "Mutable", "Fire", 9, "Throat", "Individual", "10-20",
                            "Superficiality", "Self-Assurance", "Realization", {str(i):v for i,v in {1:"The Metamorphosis",2:"The Now",3:"The Self-Assurance",4:"The Application",5:"The Realist",6:"The Wisdom"}.items()})
    gates[23] = GateMapping(23, "Asp", "Aspartic Acid", ["GAU","GAC"], "Space", "Personality", "I Think",
                            "Air", "Form", "Hearing", "Taurus", "Fixed", "Earth", 2, "Throat", "Individual", "43-23",
                            "Naivety", "Simplicity", "Quintessence", {str(i):v for i,v in {1:"The Beginning",2:"The Directness",3:"The Individualist",4:"The Assistant",5:"The Method",6:"The Fusion"}.items()})
    gates[31] = GateMapping(31, "Glu", "Glutamic Acid", ["GAA","GAG"], "Evolution", "Personality", "I Remember",
                            "Water", "Gravity", "Taste", "Leo", "Fixed", "Fire", 5, "Throat", "Collective", "7-31",
                            "Arrogance", "Leadership", "Humility", {str(i):v for i,v in {1:"The Manifestation",2:"The Attention",3:"The Influence",4:"The Intent",5:"The Alpha",6:"The Application"}.items()})
    gates[33] = GateMapping(33, "Lys", "Lysine", ["AAA","AAG"], "Evolution", "Personality", "I Remember",
                            "Water", "Gravity", "Taste", "Virgo", "Mutable", "Earth", 6, "Throat", "Collective", "13-33",
                            "Forgetting", "Mindfulness", "Truth", {str(i):v for i,v in {1:"The Retention",2:"The Surrender",3:"The Dedication",4:"The Pragmatist",5:"The Finality",6:"The Recognition"}.items()})
    gates[35] = GateMapping(35, "Thr", "Threonine", ["ACU","ACC","ACA","ACG"], "Evolution", "Personality", "I Remember",
                            "Fire", "Gravity", "Taste", "Libra", "Cardinal", "Air", 7, "Throat", "Collective", "35-36",
                            "Change", "Adventure", "Boundlessness", {str(i):v for i,v in {1:"The Unfinished",2:"The Creative",3:"The Collector",4:"The Hungry",5:"The Altruist",6:"The Guardian"}.items()})
    gates[45] = GateMapping(45, "His", "Histidine", ["CAU","CAC"], "Being", "Design", "I Am",
                            "Earth", "Matter", "Touch", "Scorpio", "Fixed", "Water", 8, "Throat", "Tribal", "45-21",
                            "Interference", "Synthesis", "Communion", {str(i):v for i,v in {1:"The Materialist",2:"The Metamorphosis",3:"The Exclusion",4:"The Direction",5:"The Possession",6:"The Authority"}.items()})
    gates[56] = GateMapping(56, "Pro", "Proline", ["CCU","CCC","CCA","CCG"], "Space", "Personality", "I Think",
                            "Air", "Form", "Hearing", "Capricorn", "Cardinal", "Earth", 10, "Throat", "Collective", "11-56",
                            "Distraction", "Enrichment", "Bliss", {str(i):v for i,v in {1:"The Quality",2:"The Success",3:"The Researcher",4:"The Stories",5:"The Cynic",6:"The Gossip"}.items()})
    gates[62] = GateMapping(62, "Phe", "Phenylalanine", ["UUU","UUC"], "Design", "Design", "I Design",
                            "Air", "Structure", "Smell", "Aquarius", "Fixed", "Air", 11, "Throat", "Collective", "17-62",
                            "Intellect", "Imagination", "Truth", {str(i):v for i,v in {1:"The Good",2:"The Plan",3:"The Discovery",4:"The Organization",5:"The Practical",6:"The Connection"}.items()})

    # SACRAL (9 gates)
    gates[3] = GateMapping(3, "Ile", "Isoleucine", ["AUU","AUC","AUA"], "Space", "Personality", "I Think",
                          "Water", "Form", "Hearing", "Aries", "Cardinal", "Fire", 1, "Sacral", "Individual", "3-60",
                          "Chaos", "Innovation", "Ordering", {str(i):v for i,v in {1:"The Synthesis",2:"The Immigrant",3:"The Vessel",4:"The Charisma",5:"The Survivor",6:"The Surrender"}.items()})
    gates[5] = GateMapping(5, "Val", "Valine", ["GUU","GUC","GUA","GUG"], "Space", "Personality", "I Think",
                          "Fire", "Form", "Hearing", "Leo", "Fixed", "Fire", 5, "Sacral", "Collective", "15-5",
                          "Impatience", "Patience", "Timelessness", {str(i):v for i,v in {1:"The Perseverance",2:"The Practical",3:"The Compromise",4:"The Hunter",5:"The Heretic",6:"The Authority"}.items()})
    gates[9] = GateMapping(9, "Ser", "Serine", ["UCU","UCC","UCA","UCG"], "Movement", "Magnetic Monopole", "I Define",
                          "Earth", "Energy", "Seeing", "Gemini", "Mutable", "Air", 3, "Sacral", "Collective", "9-52",
                          "Inertia", "Determination", "Invincibility", {str(i):v for i,v in {1:"The Focus",2:"The Abstraction",3:"The Power",4:"The Dedication",5:"The Faith",6:"The Gratitude"}.items()})
    gates[14] = GateMapping(14, "Ala", "Alanine", ["GCU","GCC","GCA","GCG"], "Design", "Design", "I Design",
                            "Fire", "Structure", "Smell", "Sagittarius", "Mutable", "Fire", 9, "Sacral", "Individual", "2-14",
                            "Compromise", "Competence", "Bounteousness", {str(i):v for i,v in {1:"The Money",2:"The Management",3:"The Service",4:"The Security",5:"The Arrogance",6:"The Humility"}.items()})
    gates[27] = GateMapping(27, "Arg", "Arginine", ["CGU","CGC","CGA","CGG","AGA","AGG"], "Being", "Design", "I Am",
                            "Water", "Matter", "Touch", "Taurus", "Fixed", "Earth", 2, "Sacral", "Tribal", "27-50",
                            "Selfishness", "Altruism", "Selflessness", {str(i):v for i,v in {1:"The Deficiency",2:"The Survival",3:"The Greed",4:"The Generosity",5:"The Executor",6:"The War"}.items()})
    gates[29] = GateMapping(29, "Leu", "Leucine", ["UUA","UUG","CUU","CUC","CUA","CUG"], "Being", "Design", "I Am",
                            "Earth", "Matter", "Touch", "Virgo", "Mutable", "Earth", 6, "Sacral", "Individual", "46-29",
                            "Half-heartedness", "Commitment", "Devotion", {str(i):v for i,v in {1:"The Draftsman",2:"The Evaluation",3:"The Over-Readiness",4:"The Commitment",5:"The Strategist",6:"The Approval"}.items()})
    gates[34] = GateMapping(34, "Gly", "Glycine", ["GGU","GGC","GGA","GGG"], "Movement", "Magnetic Monopole", "I Define",
                            "Fire", "Energy", "Seeing", "Scorpio", "Fixed", "Water", 8, "Sacral", "Individual", "34-10",
                            "Force", "Strength", "Majesty", {str(i):v for i,v in {1:"The Bully",2:"The Ambition",3:"The Machismo",4:"The Transformation",5:"The Annihilation",6:"The Common Sense"}.items()})
    gates[42] = GateMapping(42, "Thr", "Threonine", ["ACU","ACC","ACA","ACG"], "Evolution", "Personality", "I Remember",
                            "Air", "Gravity", "Taste", "Capricorn", "Cardinal", "Earth", 10, "Sacral", "Collective", "42-53",
                            "Expectation", "Detachment", "Completion", {str(i):v for i,v in {1:"The Diversification",2:"The Identification",3:"The Trial",4:"The Stagnation",5:"The Self-Assurance",6:"The Celebration"}.items()})
    gates[59] = GateMapping(59, "Asn", "Asparagine", ["AAU","AAC"], "Evolution", "Personality", "I Remember",
                            "Water", "Gravity", "Taste", "Pisces", "Mutable", "Water", 12, "Sacral", "Tribal", "59-6",
                            "Dishonesty", "Intimacy", "Transparency", {str(i):v for i,v in {1:"The Preemptive",2:"The Shyness",3:"The Openness",4:"The Dedication",5:"The Seduction",6:"The Confession"}.items()})

    # SOLAR PLEXUS (7 gates)
    gates[6] = GateMapping(6, "Tyr", "Tyrosine", ["UAU","UAC"], "Movement", "Magnetic Monopole", "I Define",
                          "Water", "Energy", "Seeing", "Virgo", "Mutable", "Earth", 6, "Solar Plexus", "Tribal", "59-6",
                          "Conflict", "Diplomacy", "Peace", {str(i):v for i,v in {1:"The Retreat",2:"The Guerrilla",3:"The Artist",4:"The Victim",5:"The Arbitrator",6:"The Fighter"}.items()})
    gates[22] = GateMapping(22, "Cys", "Cysteine", ["UGU","UGC"], "Design", "Design", "I Design",
                            "Water", "Structure", "Smell", "Aries", "Cardinal", "Fire", 1, "Solar Plexus", "Individual", "12-22",
                            "Dishonor", "Grace", "Sacredness", {str(i):v for i,v in {1:"The Second-Class Citizen",2:"The Charm School",3:"The Decay",4:"The Secretary",5:"The Directness",6:"The Maturity"}.items()})
    gates[30] = GateMapping(30, "Trp", "Tryptophan", ["UGG"], "Space", "Personality", "I Think",
                            "Fire", "Form", "Hearing", "Leo", "Fixed", "Fire", 5, "Solar Plexus", "Collective", "30-41",
                            "Desire", "Lightness", "Rapture", {str(i):v for i,v in {1:"The Composure",2:"The Pragmatist",3:"The Fates",4:"The Burnout",5:"The Demolition",6:"The Re-creation"}.items()})
    gates[36] = GateMapping(36, "Met", "Methionine", ["AUG"], "Evolution", "Personality", "I Remember",
                            "Water", "Gravity", "Taste", "Libra", "Cardinal", "Air", 7, "Solar Plexus", "Collective", "35-36",
                            "Turbulence", "Humanity", "Compassion", {str(i):v for i,v in {1:"The Unresolved",2:"The Support",3:"The Transition",4:"The Crisis",5:"The Rectification",6:"The Justice"}.items()})
    gates[37] = GateMapping(37, "Asp", "Aspartic Acid", ["GAU","GAC"], "Space", "Personality", "I Think",
                            "Air", "Form", "Hearing", "Scorpio", "Fixed", "Water", 8, "Solar Plexus", "Tribal", "37-40",
                            "Weakness", "Equality", "Tenderness", {str(i):v for i,v in {1:"The Mother",2:"The Family",3:"The Expedition",4:"The Loyalty",5:"The Responsibility",6:"The Authority"}.items()})
    gates[49] = GateMapping(49, "Glu", "Glutamic Acid", ["GAA","GAG"], "Evolution", "Personality", "I Remember",
                            "Water", "Gravity", "Taste", "Pisces", "Mutable", "Water", 12, "Solar Plexus", "Tribal", "49-19",
                            "Reaction", "Revolution", "Liberation", {str(i):v for i,v in {1:"The Law",2:"The Decree",3:"The Tempest",4:"The Reform",5:"The Principle",6:"The Attraction"}.items()})
    gates[55] = GateMapping(55, "Phe", "Phenylalanine", ["UUU","UUC"], "Design", "Design", "I Design",
                            "Fire", "Structure", "Smell", "Sagittarius", "Mutable", "Fire", 9, "Solar Plexus", "Individual", "55-39",
                            "Victimization", "Freedom", "Liberation", {str(i):v for i,v in {1:"The Cooperation",2:"The Distrust",3:"The Experiment",4:"The Competitiveness",5:"The Growth",6:"The Awareness"}.items()})

    # ROOT (8 gates)
    gates[19] = GateMapping(19, "Arg", "Arginine", ["CGU","CGC","CGA","CGG","AGA","AGG"], "Being", "Design", "I Am",
                            "Water", "Matter", "Touch", "Pisces", "Mutable", "Water", 12, "Root", "Tribal", "49-19",
                            "Wanting", "Sufficiency", "Sacredness", {str(i):v for i,v in {1:"The Need",2:"The Service",3:"The Dedication",4:"The Re-creation",5:"The Sacrifice",6:"The Rejection"}.items()})
    gates[38] = GateMapping(38, "Ile", "Isoleucine", ["AUU","AUC","AUA"], "Space", "Personality", "I Think",
                            "Fire", "Form", "Hearing", "Leo", "Fixed", "Fire", 5, "Root", "Individual", "38-28",
                            "Struggle", "Perseverance", "Honour", {str(i):v for i,v in {1:"The Politician",2:"The Student",3:"The Enemy",4:"The Instinct",5:"The Alienation",6:"The Re-creation"}.items()})
    gates[39] = GateMapping(39, "Pro", "Proline", ["CCU","CCC","CCA","CCG"], "Space", "Personality", "I Think",
                            "Air", "Form", "Hearing", "Libra", "Cardinal", "Air", 7, "Root", "Individual", "55-39",
                            "Provocation", "Dynamism", "Annihilation", {str(i):v for i,v in {1:"The Disassociation",2:"The Misunderstanding",3:"The Emotion",4:"The Spirit",5:"The Seduction",6:"The Rejection"}.items()})
    gates[41] = GateMapping(41, "Ala", "Alanine", ["GCU","GCC","GCA","GCG"], "Design", "Design", "I Design",
                            "Fire", "Structure", "Smell", "Aquarius", "Fixed", "Air", 11, "Root", "Collective", "30-41",
                            "Fantasy", "Anticipation", "Emanation", {str(i):v for i,v in {1:"The Reason",2:"The Caution",3:"The Efficiency",4:"The Correction",5:"The Accomplishment",6:"The Contagion"}.items()})
    gates[52] = GateMapping(52, "Gln", "Glutamine", ["CAA","CAG"], "Evolution", "Personality", "I Remember",
                            "Air", "Gravity", "Taste", "Cancer", "Cardinal", "Water", 4, "Root", "Collective", "9-52",
                            "Inaction", "Concentration", "Stillness", {str(i):v for i,v in {1:"The Thinker",2:"The Caution",3:"The Control",4:"The Assimilation",5:"The Explanation",6:"The Peace"}.items()})
    gates[53] = GateMapping(53, "Ser", "Serine", ["UCU","UCC","UCA","UCG"], "Movement", "Magnetic Monopole", "I Define",
                            "Earth", "Energy", "Seeing", "Cancer", "Cardinal", "Water", 4, "Root", "Collective", "42-53",
                            "Immaturity", "Expansion", "Boundlessness", {str(i):v for i,v in {1:"The Accumulation",2:"The Practical",3:"The Concentration",4:"The Assimilation",5:"The Progression",6:"The Phasing"}.items()})
    gates[54] = GateMapping(54, "Gly", "Glycine", ["GGU","GGC","GGA","GGG"], "Movement", "Magnetic Monopole", "I Define",
                            "Fire", "Energy", "Seeing", "Scorpio", "Fixed", "Water", 8, "Root", "Tribal", "54-32",
                            "Greed", "Aspiration", "Ascension", {str(i):v for i,v in {1:"The Influence",2:"The Discretion",3:"The Ambition",4:"The Enlightenment",5:"The Magnanimity",6:"The Selectivity"}.items()})
    gates[58] = GateMapping(58, "Val", "Valine", ["GUU","GUC","GUA","GUG"], "Space", "Personality", "I Think",
                            "Fire", "Form", "Hearing", "Virgo", "Mutable", "Earth", 6, "Root", "Collective", "58-18",
                            "Dissatisfaction", "Vitality", "Bliss", {str(i):v for i,v in {1:"The Love",2:"The Perseverance",3:"The Electricity",4:"The Focus",5:"The Defense",6:"The Fatigue"}.items()})
    gates[60] = GateMapping(60, "Lys", "Lysine", ["AAA","AAG"], "Evolution", "Personality", "I Remember",
                            "Water", "Gravity", "Taste", "Capricorn", "Cardinal", "Earth", 10, "Root", "Individual", "3-60",
                            "Limitation", "Realism", "Justice", {str(i):v for i,v in {1:"The Acceptance",2:"The Decisiveness",3:"The Conservatism",4:"The Resourcefulness",5:"The Qualification",6:"The Rigidity"}.items()})

    # SPLEEN (7 gates)
    gates[18] = GateMapping(18, "Asn", "Asparagine", ["AAU","AAC"], "Evolution", "Personality", "I Remember",
                            "Air", "Gravity", "Taste", "Taurus", "Fixed", "Earth", 2, "Spleen", "Collective", "58-18",
                            "Judgment", "Integrity", "Perfection", {str(i):v for i,v in {1:"The Insult",2:"The Correction",3:"The Vigilance",4:"The Instinct",5:"The Therapy",6:"The Buddhahood"}.items()})
    gates[28] = GateMapping(28, "Leu", "Leucine", ["UUA","UUG","CUU","CUC","CUA","CUG"], "Being", "Design", "I Am",
                            "Earth", "Matter", "Touch", "Scorpio", "Fixed", "Water", 8, "Spleen", "Individual", "38-28",
                            "Purposelessness", "Totality", "Immortality", {str(i):v for i,v in {1:"The Preparation",2:"The Shyness",3:"The Adventurer",4:"The Hold",5:"The Transference",6:"The Blaze"}.items()})
    gates[32] = GateMapping(32, "Gln", "Glutamine", ["CAA","CAG"], "Evolution", "Personality", "I Remember",
                            "Water", "Gravity", "Taste", "Libra", "Cardinal", "Air", 7, "Spleen", "Tribal", "54-32",
                            "Failure", "Preservation", "Veneration", {str(i):v for i,v in {1:"The Conservation",2:"The Transformation",3:"The Vulnerability",4:"The Rightness",5:"The Flexibility",6:"The Tranquility"}.items()})
    gates[44] = GateMapping(44, "His", "Histidine", ["CAU","CAC"], "Being", "Design", "I Am",
                            "Earth", "Matter", "Touch", "Leo", "Fixed", "Fire", 5, "Spleen", "Tribal", "44-26",
                            "Interference", "Synthesis", "Synarchy", {str(i):v for i,v in {1:"The Conditions",2:"The Management",3:"The Capacity",4:"The Honesty",5:"The Competition",6:"The Search"}.items()})
    gates[48] = GateMapping(48, "Tyr", "Tyrosine", ["UAU","UAC"], "Movement", "Magnetic Monopole", "I Define",
                            "Air", "Energy", "Seeing", "Virgo", "Mutable", "Earth", 6, "Spleen", "Collective", "16-48",
                            "Inadequacy", "Wisdom", "Wisdom", {str(i):v for i,v in {1:"The Insignificance",2:"The Detachment",3:"The Naturalness",4:"The Search",5:"The Fertility",6:"The Action"}.items()})
    gates[50] = GateMapping(50, "Thr", "Threonine", ["ACU","ACC","ACA","ACG"], "Evolution", "Personality", "I Remember",
                            "Water", "Gravity", "Taste", "Sagittarius", "Mutable", "Fire", 9, "Spleen", "Tribal", "27-50",
                            "Corruption", "Responsibility", "Sacredness", {str(i):v for i,v in {1:"The Immigrant",2:"The Determination",3:"The Elitism",4:"The Rejection",5:"The Authority",6:"The Leadership"}.items()})
    gates[57] = GateMapping(57, "Met", "Methionine", ["AUG"], "Space", "Personality", "I Think",
                            "Fire", "Form", "Hearing", "Capricorn", "Cardinal", "Earth", 10, "Spleen", "Individual", "57-10",
                            "Unease", "Intuition", "Presence", {str(i):v for i,v in {1:"The Confusion",2:"The Cleansing",3:"The Acuteness",4:"The Director",5:"The Contagion",6:"The Utilization"}.items()})

    # EGO (4 gates)
    gates[21] = GateMapping(21, "Cys", "Cysteine", ["UGU","UGC"], "Design", "Design", "I Design",
                            "Fire", "Structure", "Smell", "Aries", "Cardinal", "Fire", 1, "Ego", "Tribal", "45-21",
                            "Control", "Authority", "Valor", {str(i):v for i,v in {1:"The Warning",2:"The Power",3:"The Dedication",4:"The Strategy",5:"The Materialist",6:"The Chaos"}.items()})
    gates[26] = GateMapping(26, "Trp", "Tryptophan", ["UGG"], "Space", "Personality", "I Think",
                            "Water", "Form", "Hearing", "Taurus", "Fixed", "Earth", 2, "Ego", "Tribal", "44-26",
                            "Pride", "Artfulness", "Invisibility", {str(i):v for i,v in {1:"The Articulate",2:"The Influence",3:"The Acceptance",4:"The Censorship",5:"The Articulation",6:"The Authority"}.items()})
    gates[40] = GateMapping(40, "Asp", "Aspartic Acid", ["GAU","GAC"], "Space", "Personality", "I Think",
                            "Air", "Form", "Hearing", "Virgo", "Mutable", "Earth", 6, "Ego", "Tribal", "37-40",
                            "Exhaustion", "Deliverance", "Divine Will", {str(i):v for i,v in {1:"The Recuperation",2:"The Strategist",3:"The Modesty",4:"The Organization",5:"The Ritualization",6:"The Decapitation"}.items()})
    gates[51] = GateMapping(51, "Glu", "Glutamic Acid", ["GAA","GAG"], "Evolution", "Personality", "I Remember",
                            "Water", "Gravity", "Taste", "Libra", "Cardinal", "Air", 7, "Ego", "Individual", "25-51",
                            "Agitation", "Initiation", "Awakening", {str(i):v for i,v in {1:"The Reference",2:"The Shock",3:"The Accumulation",4:"The Limitation",5:"The Symmetry",6:"The Separation"}.items()})

    # HEAD (3 gates)
    gates[61] = GateMapping(61, "Phe", "Phenylalanine", ["UUU","UUC"], "Design", "Design", "I Design",
                            "Air", "Structure", "Smell", "Aquarius", "Fixed", "Air", 11, "Head", "Individual", "24-61",
                            "Psychosis", "Inspiration", "Truth", {str(i):v for i,v in {1:"The Occult",2:"The Natural",3:"The Psychic",4:"The Research",5:"The Influence",6:"The Awareness"}.items()})
    gates[63] = GateMapping(63, "Gly", "Glycine", ["GGU","GGC","GGA","GGG"], "Movement", "Magnetic Monopole", "I Define",
                            "Fire", "Energy", "Seeing", "Virgo", "Mutable", "Earth", 6, "Head", "Collective", "4-63",
                            "Doubt", "Inquiry", "Truth", {str(i):v for i,v in {1:"The Confession",2:"The Structuring",3:"The Rejection",4:"The Memory",5:"The Affirmation",6:"The Nostalgia"}.items()})
    gates[64] = GateMapping(64, "Ala", "Alanine", ["GCU","GCC","GCA","GCG"], "Design", "Design", "I Design",
                            "Water", "Structure", "Smell", "Pisces", "Mutable", "Water", 12, "Head", "Individual", "47-64",
                            "Confusion", "Imagination", "Illumination", {str(i):v for i,v in {1:"The Conditions",2:"The Qualification",3:"The Deliverance",4:"The Conviction",5:"The Promise",6:"The Victory"}.items()})

    return gates

# ═══════════════════════════════════════════════════════════════════
# MODULE 10: CONVENIENCE INITIALIZER
# ═══════════════════════════════════════════════════════════════════

def create_youniverse_engine():
    """Initialize the complete YOU-N-I-VERSE engine."""
    bodies = create_nine_bodies()
    gate_dict = load_64_gate_dictionary()
    router = SentenceRouter(gate_dict, bodies)
    oracle = OracleDecoder(router)
    ephemeris = EphemerisEngine()

    return {
        "bodies": bodies,
        "gates": gate_dict,
        "router": router,
        "oracle": oracle,
        "ephemeris": ephemeris,
        "coherence_engine": CoherenceEngine(bodies),
        "batch_processor": lambda: BatchProcessor(None, ephemeris, gate_dict)
    }

# ═══════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    engine = create_youniverse_engine()
    ui = PressureShellUI(engine, engine["ephemeris"], engine["gates"])
    ui.run()
