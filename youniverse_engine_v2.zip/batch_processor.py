
"""
YOU-N-I-VERSE Batch Processing Engine
Process multiple Human Design charts simultaneously with full
9-body coherence analysis and multi-layer output generation.
"""

import json
import csv
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed
import numpy as np

class BatchProcessor:
    """
    Batch processor for Human Design chart interpretation.
    Supports JSON and CSV input, generates multi-layer output files.
    """

    def __init__(self, engine, ephemeris, gate_dict: Dict):
        self.engine = engine
        self.ephemeris = ephemeris
        self.gate_dict = gate_dict
        self.results = []

    def parse_input_json(self, filepath: str) -> List[Dict]:
        """Parse batch input from JSON file"""
        with open(filepath, 'r') as f:
            data = json.load(f)

        # Handle both single object and array
        if isinstance(data, dict):
            return [data]
        return data

    def parse_input_csv(self, filepath: str) -> List[Dict]:
        """Parse batch input from CSV file"""
        charts = []
        with open(filepath, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                charts.append({
                    "name": row.get("name", "Unnamed"),
                    "year": int(row["year"]),
                    "month": int(row["month"]),
                    "day": int(row["day"]),
                    "hour": float(row.get("hour", 12.0)),
                    "latitude": float(row.get("latitude", 0.0)),
                    "longitude": float(row.get("longitude", 0.0)),
                    "chart_system": row.get("chart_system", "tropical"),
                    "query": row.get("query", "")
                })
        return charts

    def process_single_chart(self, chart_input: Dict) -> Dict:
        """Process a single chart with full analysis"""
        name = chart_input.get("name", "Unnamed")

        result = {
            "name": name,
            "input": chart_input,
            "timestamp": datetime.now().isoformat(),
            "chart": None,
            "activated_gates": [],
            "definition": None,
            "type": None,
            "authority": None,
            "profile": None,
            "channels": [],
            "centers": {},
            "coherence_analysis": None,
            "oracle_reading": None,
            "output_layers": {}
        }

        # Calculate chart
        if self.ephemeris:
            chart = self.ephemeris.calculate_full_chart(
                chart_input["year"], chart_input["month"], chart_input["day"],
                chart_input.get("hour", 12.0),
                chart_input.get("latitude", 0.0),
                chart_input.get("longitude", 0.0),
                chart_input.get("chart_system", "tropical")
            )
            result["chart"] = chart

            # Extract activated gates (simplified — all planets)
            activated = []
            for planet, data in chart["planets"].items():
                if "error" not in data:
                    gate_num = data["gate"]
                    gate_data = self.gate_dict.get(str(gate_num), {})
                    activated.append({
                        "planet": planet,
                        "gate": gate_num,
                        "line": data["line"],
                        "color": data["color"],
                        "tone": data["tone"],
                        "base": data["base"],
                        "sign": data["sign"],
                        "element": data["element"],
                        "dimension": gate_data.get("dimension", "Unknown"),
                        "center": gate_data.get("center", "Unknown"),
                        "amino_acid": gate_data.get("amino_acid", "?"),
                        "keynote": gate_data.get("keynote", "?")
                    })

            result["activated_gates"] = activated

            # Determine definition type (simplified)
            centers_active = {}
            for gate in activated:
                center = gate["center"]
                if center not in centers_active:
                    centers_active[center] = []
                centers_active[center].append(gate["gate"])

            result["centers"] = {c: {"gates": g, "defined": len(g) > 0} 
                                for c, g in centers_active.items()}

            # Determine type (simplified heuristic)
            sacral_gates = [g for g in activated if g["center"] == "Sacral"]
            emotional_gates = [g for g in activated if g["center"] == "Solar Plexus"]

            if sacral_gates and emotional_gates:
                result["type"] = "Generator (Emotional)"
                result["authority"] = "Solar Plexus"
            elif sacral_gates:
                result["type"] = "Generator (Sacral)"
                result["authority"] = "Sacral"
            elif emotional_gates:
                result["type"] = "Projector"
                result["authority"] = "Solar Plexus"
            else:
                result["type"] = "Projector"
                result["authority"] = "Self-Projected"

            # Profile (simplified — Sun/Earth lines)
            sun_data = chart["planets"].get("Sun", {})
            if "error" not in sun_data:
                sun_line = sun_data["line"]
                earth_line = ((sun_line + 3) % 6) or 6  # Earth is opposite
                result["profile"] = f"{sun_line}/{earth_line}"

            # Run coherence analysis if engine available
            if self.engine and hasattr(self.engine, 'bodies'):
                from youniverse_engine import CoherenceEngine
                coh_engine = CoherenceEngine(self.engine['bodies'])
                result["coherence_analysis"] = coh_engine.full_field_analysis(duration=2.0)

            # Oracle reading if query provided
            query = chart_input.get("query", "")
            if query and self.engine and hasattr(self.engine, 'oracle'):
                # Use Sun gate as primary context
                sun_gate = chart["planets"].get("Sun", {}).get("gate", 1)
                sun_line = chart["planets"].get("Sun", {}).get("line", 1)

                oracle_result = self.engine["oracle"].decode_query(
                    query=query,
                    gate=sun_gate,
                    line=sun_line,
                    color=1,
                    tone=1,
                    base=1
                )
                result["oracle_reading"] = oracle_result
                result["output_layers"] = oracle_result.get("outputs", {})

        return result

    def process_batch(self, charts: List[Dict], max_workers: int = 4) -> List[Dict]:
        """Process multiple charts in parallel"""
        self.results = []

        print(f"Processing {len(charts)} charts with {max_workers} workers...")

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(self.process_single_chart, chart): i 
                      for i, chart in enumerate(charts)}

            for future in as_completed(futures):
                idx = futures[future]
                try:
                    result = future.result()
                    self.results.append(result)
                    print(f"  ✓ Chart {idx+1}/{len(charts)}: {result['name']}")
                except Exception as e:
                    print(f"  ✗ Chart {idx+1}/{len(charts)}: ERROR - {e}")

        return self.results

    def export_json(self, filepath: str):
        """Export results to JSON"""
        with open(filepath, 'w') as f:
            json.dump(self.results, f, indent=2, default=str)
        print(f"Results exported to {filepath}")

    def export_csv(self, filepath: str):
        """Export results to CSV summary"""
        rows = []
        for result in self.results:
            row = {
                "name": result["name"],
                "type": result.get("type", ""),
                "authority": result.get("authority", ""),
                "profile": result.get("profile", ""),
                "activated_gates_count": len(result.get("activated_gates", [])),
                "defined_centers": sum(1 for c, d in result.get("centers", {}).items() if d.get("defined", False)),
                "coherence": result.get("coherence_analysis", {}).get("FIELD_COHERENCE", 0),
                "oracle_action": result.get("oracle_reading", {}).get("action", ""),
                "oracle_confidence": result.get("oracle_reading", {}).get("confidence", 0)
            }

            # Add activated gates as columns
            for i, gate in enumerate(result.get("activated_gates", [])[:10]):
                row[f"gate_{i+1}"] = f"{gate['planet']}:{gate['gate']}.{gate['line']}"

            rows.append(row)

        if rows:
            keys = rows[0].keys()
            with open(filepath, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=keys)
                writer.writeheader()
                writer.writerows(rows)
            print(f"CSV summary exported to {filepath}")

    def export_report(self, filepath: str):
        """Export human-readable report"""
        with open(filepath, 'w') as f:
            f.write("=" * 70 + "\n")
            f.write("YOU-N-I-VERSE BATCH PROCESSING REPORT\n")
            f.write(f"Generated: {datetime.now().isoformat()}\n")
            f.write("=" * 70 + "\n\n")

            for result in self.results:
                f.write(f"\n{'─' * 70}\n")
                f.write(f"NAME: {result['name']}\n")
                f.write(f"TYPE: {result.get('type', 'Unknown')} | AUTHORITY: {result.get('authority', 'Unknown')}\n")
                f.write(f"PROFILE: {result.get('profile', 'Unknown')}\n")
                f.write(f"{'─' * 70}\n")

                f.write("\nACTIVATED GATES:\n")
                for gate in result.get("activated_gates", []):
                    f.write(f"  {gate['planet']:10s} → Gate {gate['gate']:2d}.{gate['line']} | "
                           f"{gate['sign']:12s} | {gate['dimension']:10s} | "
                           f"{gate['amino_acid']:4s} | {gate['keynote']}\n")

                f.write("\nDEFINED CENTERS:\n")
                for center, data in result.get("centers", {}).items():
                    status = "DEFINED" if data.get("defined") else "OPEN"
                    f.write(f"  {center:15s}: {status} ({len(data.get('gates', []))} gates)\n")

                if result.get("coherence_analysis"):
                    f.write("\nFIELD COHERENCE:\n")
                    f.write(f"  Overall: {result['coherence_analysis'].get('FIELD_COHERENCE', 0):.3f}\n")
                    f.write(f"  Status: {result['coherence_analysis'].get('FIELD_STATUS', 'Unknown')}\n")

                if result.get("oracle_reading"):
                    f.write("\nORACLE READING:\n")
                    f.write(f"  Query: {result['oracle_reading'].get('query', '')}\n")
                    f.write(f"  Action: {result['oracle_reading'].get('action', '')}\n")
                    f.write(f"  Confidence: {result['oracle_reading'].get('confidence', 0):.3f}\n")
                    f.write(f"  Primary Body: {result['oracle_reading'].get('primary_body', '')}\n")

                f.write("\n")

        print(f"Report exported to {filepath}")

    def generate_summary(self) -> Dict:
        """Generate aggregate statistics"""
        if not self.results:
            return {}

        types = {}
        authorities = {}
        profiles = {}
        total_gates = []
        coherence_scores = []

        for result in self.results:
            t = result.get("type", "Unknown")
            types[t] = types.get(t, 0) + 1

            a = result.get("authority", "Unknown")
            authorities[a] = authorities.get(a, 0) + 1

            p = result.get("profile", "Unknown")
            profiles[p] = profiles.get(p, 0) + 1

            total_gates.append(len(result.get("activated_gates", [])))

            if result.get("coherence_analysis"):
                coherence_scores.append(result["coherence_analysis"].get("FIELD_COHERENCE", 0))

        return {
            "total_charts": len(self.results),
            "types_distribution": types,
            "authorities_distribution": authorities,
            "profiles_distribution": profiles,
            "avg_activated_gates": np.mean(total_gates) if total_gates else 0,
            "avg_coherence": np.mean(coherence_scores) if coherence_scores else 0,
            "coherence_std": np.std(coherence_scores) if coherence_scores else 0
        }


# Example batch input format (JSON)
EXAMPLE_BATCH_INPUT = [
    {
        "name": "Cynthia Alpha",
        "year": 1985, "month": 6, "day": 15,
        "hour": 14.5, "latitude": 40.7128, "longitude": -74.0060,
        "chart_system": "tropical",
        "query": "Should I pursue the new direction?"
    },
    {
        "name": "Adaya Beta",
        "year": 1992, "month": 3, "day": 22,
        "hour": 8.0, "latitude": 51.5074, "longitude": -0.1278,
        "chart_system": "sidereal",
        "query": "What is the nature of my current transformation?"
    },
    {
        "name": "Joe Gamma",
        "year": 1978, "month": 11, "day": 3,
        "hour": 23.75, "latitude": 35.6762, "longitude": 139.6503,
        "chart_system": "draconic",
        "query": "How do I align with the collective field?"
    }
]

# Example CSV format
EXAMPLE_CSV_HEADER = "name,year,month,day,hour,latitude,longitude,chart_system,query"
EXAMPLE_CSV_ROW = 'Cynthia Alpha,1985,6,15,14.5,40.7128,-74.0060,tropical,"Should I pursue the new direction?"'


if __name__ == "__main__":
    import importlib.util

    # Load modules
    engine = None
    ephemeris = None
    gate_dict = {}

    try:
        with open("complete_gate_dictionary.json", 'r') as f:
            gate_dict = json.load(f)
    except:
        pass

    try:
        spec = importlib.util.spec_from_file_location("youniverse_engine", "youniverse_engine.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        engine = mod.create_engine()
    except:
        pass

    try:
        spec = importlib.util.spec_from_file_location("ephemeris_engine", "ephemeris_engine.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        ephemeris = mod.create_ephemeris()
    except:
        pass

    # Create example input file
    with open("example_batch.json", 'w') as f:
        json.dump(EXAMPLE_BATCH_INPUT, f, indent=2)

    with open("example_batch.csv", 'w') as f:
        f.write(EXAMPLE_CSV_HEADER + "\n")
        f.write(EXAMPLE_CSV_ROW + "\n")

    # Process
    processor = BatchProcessor(engine, ephemeris, gate_dict)

    print("YOU-N-I-VERSE Batch Processor")
    print("=" * 50)
    print("Example files created: example_batch.json, example_batch.csv")
    print("\nTo process:")
    print("  processor = BatchProcessor(engine, ephemeris, gate_dict)")
    print("  results = processor.process_batch(processor.parse_input_json('example_batch.json'))")
    print("  processor.export_json('results.json')")
    print("  processor.export_csv('results.csv')")
    print("  processor.export_report('report.txt')")
