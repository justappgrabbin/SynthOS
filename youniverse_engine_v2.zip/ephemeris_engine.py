
"""
YOU-N-I-VERSE Ephemeris Integration Module
Real-time planetary position calculation using Swiss Ephemeris API.
Falls back to libephemeris if pysweph/pyswisseph unavailable.
"""

import math
from datetime import datetime
from typing import Dict, Tuple, Optional, List

try:
    import swisseph as swe
    SWISSEPH_AVAILABLE = True
except ImportError:
    try:
        import libephemeris as swe
        SWISSEPH_AVAILABLE = True
    except ImportError:
        SWISSEPH_AVAILABLE = False

class EphemerisEngine:
    """
    Planetary position calculator for YOU-N-I-VERSE framework.
    Computes tropical, sidereal, and draconic positions.
    """

    # Planet IDs for Swiss Ephemeris
    PLANETS = {
        "Sun": swe.SUN,
        "Moon": swe.MOON,
        "Mercury": swe.MERCURY,
        "Venus": swe.VENUS,
        "Mars": swe.MARS,
        "Jupiter": swe.JUPITER,
        "Saturn": swe.SATURN,
        "Uranus": swe.URANUS,
        "Neptune": swe.NEPTUNE,
        "Pluto": swe.PLUTO,
        "North Node": swe.MEAN_NODE,  # or TRUE_NODE
        "South Node": swe.MEAN_NODE,  # calculated as opposite
        "Chiron": swe.CHIRON,
        "Lilith": swe.MEAN_APOG,  # Black Moon Lilith
    }

    # Signs
    SIGNS = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
             "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"]

    # Elements by sign
    SIGN_ELEMENTS = {
        "Aries": "Fire", "Leo": "Fire", "Sagittarius": "Fire",
        "Taurus": "Earth", "Virgo": "Earth", "Capricorn": "Earth",
        "Gemini": "Air", "Libra": "Air", "Aquarius": "Air",
        "Cancer": "Water", "Scorpio": "Water", "Pisces": "Water"
    }

    # Modalities
    SIGN_MODALITIES = {
        "Aries": "Cardinal", "Cancer": "Cardinal", "Libra": "Cardinal", "Capricorn": "Cardinal",
        "Taurus": "Fixed", "Leo": "Fixed", "Scorpio": "Fixed", "Aquarius": "Fixed",
        "Gemini": "Mutable", "Virgo": "Mutable", "Sagittarius": "Mutable", "Pisces": "Mutable"
    }

    # Human Design gate degree ranges (each gate = 5.625° of the 360° wheel)
    # Gate 1 starts at 0° (Aries 0°), Gate 2 at 5.625°, etc.
    # This is the Rave I'Ching wheel mapping
    GATE_RANGES = {}
    for i in range(1, 65):
        start_deg = (i - 1) * 5.625
        end_deg = i * 5.625
        GATE_RANGES[i] = (start_deg, end_deg)

    def __init__(self, ephe_path: str = None):
        self.available = SWISSEPH_AVAILABLE
        if self.available and ephe_path:
            try:
                swe.set_ephe_path(ephe_path)
            except:
                pass

    def _get_julian_day(self, year: int, month: int, day: int, hour: float = 12.0) -> float:
        """Convert calendar date to Julian Day"""
        if self.available:
            return swe.julday(year, month, day, hour)
        else:
            # Fallback: simple Julian Day calculation (less precise)
            a = (14 - month) // 12
            y = year + 4800 - a
            m = month + 12 * a - 3
            jdn = day + (153 * m + 2) // 5 + 365 * y + y // 4 - y // 100 + y // 400 - 32045
            return jdn + (hour - 12) / 24.0

    def _longitude_to_sign(self, longitude: float) -> Tuple[str, float, int, float, float]:
        """
        Convert longitude to sign, degree, minute, second.
        Returns: (sign_name, degree_in_sign, minutes, seconds, total_degree)
        """
        total_deg = longitude % 360
        sign_idx = int(total_deg // 30)
        deg_in_sign = total_deg % 30
        degrees = int(deg_in_sign)
        minutes_full = (deg_in_sign - degrees) * 60
        minutes = int(minutes_full)
        seconds = (minutes_full - minutes) * 60
        return self.SIGNS[sign_idx], degrees, minutes, seconds, total_deg

    def _longitude_to_gate(self, longitude: float) -> int:
        """Convert longitude to Human Design gate number"""
        total_deg = longitude % 360
        gate = int(total_deg / 5.625) + 1
        if gate > 64:
            gate = 64
        return gate

    def _longitude_to_line(self, longitude: float) -> int:
        """Convert longitude within gate to line (1-6)"""
        total_deg = longitude % 360
        gate_start = int(total_deg / 5.625) * 5.625
        deg_in_gate = total_deg - gate_start
        line = int(deg_in_gate / 0.9375) + 1  # Each line = 0.9375°
        if line > 6:
            line = 6
        return line

    def _longitude_to_color(self, longitude: float) -> int:
        """Convert to color (1-6)"""
        total_deg = longitude % 360
        gate_start = int(total_deg / 5.625) * 5.625
        line_start = int((total_deg - gate_start) / 0.9375) * 0.9375
        deg_in_line = total_deg - gate_start - line_start
        color = int(deg_in_line / 0.15625) + 1  # Each color = 0.15625°
        if color > 6:
            color = 6
        return color

    def _longitude_to_tone(self, longitude: float) -> int:
        """Convert to tone (1-6)"""
        total_deg = longitude % 360
        gate_start = int(total_deg / 5.625) * 5.625
        line_start = int((total_deg - gate_start) / 0.9375) * 0.9375
        color_start = int((total_deg - gate_start - line_start) / 0.15625) * 0.15625
        deg_in_color = total_deg - gate_start - line_start - color_start
        tone = int(deg_in_color / 0.0260417) + 1  # Each tone ≈ 0.0260417°
        if tone > 6:
            tone = 6
        return tone

    def _longitude_to_base(self, longitude: float) -> int:
        """Convert to base (1-5)"""
        total_deg = longitude % 360
        gate_start = int(total_deg / 5.625) * 5.625
        line_start = int((total_deg - gate_start) / 0.9375) * 0.9375
        color_start = int((total_deg - gate_start - line_start) / 0.15625) * 0.15625
        tone_start = int((total_deg - gate_start - line_start - color_start) / 0.0260417) * 0.0260417
        deg_in_tone = total_deg - gate_start - line_start - color_start - tone_start
        base = int(deg_in_tone / 0.0052083) + 1  # Each base ≈ 0.0052083°
        if base > 5:
            base = 5
        return base

    def calculate_planet(self, planet_name: str, year: int, month: int, day: int, 
                        hour: float = 12.0, latitude: float = 0.0, longitude: float = 0.0,
                        chart_system: str = "tropical") -> Dict:
        """
        Calculate planetary position for a given date/time.

        Args:
            planet_name: Name of planet
            year, month, day: Date
            hour: Hour in 24h format (e.g., 14.5 = 2:30 PM)
            latitude, longitude: Geographic coordinates
            chart_system: "tropical", "sidereal", or "draconic"

        Returns:
            Dictionary with position data
        """
        jd = self._get_julian_day(year, month, day, hour)

        if not self.available:
            return self._fallback_calculation(planet_name, jd, chart_system)

        planet_id = self.PLANETS.get(planet_name)
        if planet_id is None:
            return {"error": f"Unknown planet: {planet_name}"}

        # Calculate flags
        flags = swe.FLG_EQUATORIAL if chart_system == "sidereal" else 0
        if chart_system == "sidereal":
            flags |= swe.FLG_SIDEREAL

        try:
            result = swe.calc_ut(jd, planet_id, flags)
            lon = result[0][0] if isinstance(result[0], (list, tuple)) else result[0]

            # For South Node, add 180°
            if planet_name == "South Node":
                lon = (lon + 180) % 360

            sign, deg, minutes, seconds, total_deg = self._longitude_to_sign(lon)
            gate = self._longitude_to_gate(lon)
            line = self._longitude_to_line(lon)
            color = self._longitude_to_color(lon)
            tone = self._longitude_to_tone(lon)
            base = self._longitude_to_base(lon)

            return {
                "planet": planet_name,
                "chart_system": chart_system,
                "longitude": lon,
                "sign": sign,
                "degree": deg,
                "minutes": minutes,
                "seconds": seconds,
                "element": self.SIGN_ELEMENTS.get(sign, "Unknown"),
                "modality": self.SIGN_MODALITIES.get(sign, "Unknown"),
                "gate": gate,
                "line": line,
                "color": color,
                "tone": tone,
                "base": base,
                "julian_day": jd,
                "date": f"{year}-{month:02d}-{day:02d} {hour:.2f}h",
                "latitude": latitude,
                "longitude": longitude
            }
        except Exception as e:
            return {"error": str(e), "planet": planet_name}

    def _fallback_calculation(self, planet_name: str, jd: float, chart_system: str) -> Dict:
        """Fallback when Swiss Ephemeris is not available"""
        # Use simplified mean orbital elements (very approximate)
        # This is NOT accurate — it's a placeholder
        T = (jd - 2451545.0) / 36525.0  # Julian centuries from J2000

        # Simplified mean longitudes (degrees)
        mean_longitudes = {
            "Sun": (280.46646 + 36000.76983 * T + 0.0003032 * T * T) % 360,
            "Moon": (218.3164477 + 481267.88123421 * T - 0.0015786 * T * T) % 360,
            "Mercury": (252.250906 + 149474.0722491 * T + 0.0003035 * T * T) % 360,
            "Venus": (181.979801 + 58519.2130302 * T + 0.0003105 * T * T) % 360,
            "Mars": (355.433275 + 19141.6964746 * T + 0.0003107 * T * T) % 360,
            "Jupiter": (34.351484 + 3036.3020849 * T + 0.0003108 * T * T) % 360,
            "Saturn": (50.077471 + 1223.5110146 * T + 0.0003109 * T * T) % 360,
            "Uranus": (314.055005 + 429.8640561 * T + 0.0003110 * T * T) % 360,
            "Neptune": (304.348665 + 219.8833092 * T + 0.0003111 * T * T) % 360,
            "Pluto": (238.92881 + 145.2078051 * T + 0.0003112 * T * T) % 360,
        }

        lon = mean_longitudes.get(planet_name, 0.0)
        if planet_name == "South Node":
            lon = (lon + 180) % 360

        sign, deg, minutes, seconds, total_deg = self._longitude_to_sign(lon)
        gate = self._longitude_to_gate(lon)
        line = self._longitude_to_line(lon)
        color = self._longitude_to_color(lon)
        tone = self._longitude_to_tone(lon)
        base = self._longitude_to_base(lon)

        return {
            "planet": planet_name,
            "chart_system": chart_system,
            "longitude": lon,
            "sign": sign,
            "degree": deg,
            "minutes": minutes,
            "seconds": seconds,
            "element": self.SIGN_ELEMENTS.get(sign, "Unknown"),
            "modality": self.SIGN_MODALITIES.get(sign, "Unknown"),
            "gate": gate,
            "line": line,
            "color": color,
            "tone": tone,
            "base": base,
            "julian_day": jd,
            "note": "FALLBACK: Swiss Ephemeris not available. Positions are approximate.",
            "latitude": 0.0,
            "longitude": 0.0
        }

    def calculate_full_chart(self, year: int, month: int, day: int, hour: float = 12.0,
                            latitude: float = 0.0, longitude: float = 0.0,
                            chart_system: str = "tropical") -> Dict:
        """
        Calculate full chart for all planets.
        """
        planets = ["Sun", "Moon", "Mercury", "Venus", "Mars", "Jupiter", 
                  "Saturn", "Uranus", "Neptune", "Pluto", "North Node", "South Node"]

        chart = {
            "date": f"{year}-{month:02d}-{day:02d}",
            "time": f"{hour:.2f}",
            "latitude": latitude,
            "longitude": longitude,
            "chart_system": chart_system,
            "planets": {},
            "houses": None
        }

        for planet in planets:
            chart["planets"][planet] = self.calculate_planet(
                planet, year, month, day, hour, latitude, longitude, chart_system
            )

        # Calculate houses if coordinates provided
        if latitude != 0.0 and longitude != 0.0 and self.available:
            try:
                jd = self._get_julian_day(year, month, day, hour)
                houses = swe.houses(jd, latitude, longitude, b"P")  # Placidus
                chart["houses"] = {
                    "cusps": houses[0],
                    "ascendant": houses[1][0] if isinstance(houses[1], (list, tuple)) else houses[1],
                    "mc": houses[2][0] if len(houses) > 2 and isinstance(houses[2], (list, tuple)) else houses[2]
                }
            except:
                pass

        return chart

    def get_transit_aspects(self, natal_chart: Dict, transit_date: Tuple[int, int, int, float],
                         orb: float = 3.0) -> List[Dict]:
        """
        Calculate transit aspects to natal chart.

        Args:
            natal_chart: Result from calculate_full_chart
            transit_date: (year, month, day, hour)
            orb: Aspect orb in degrees

        Returns:
            List of active aspects
        """
        aspects = []
        aspect_angles = {
            "conjunction": 0,
            "sextile": 60,
            "square": 90,
            "trine": 120,
            "opposition": 180
        }

        year, month, day, hour = transit_date

        for natal_planet, natal_data in natal_chart["planets"].items():
            if "error" in natal_data:
                continue
            natal_lon = natal_data["longitude"]

            for trans_planet in ["Sun", "Moon", "Mercury", "Venus", "Mars", "Jupiter", "Saturn"]:
                trans_data = self.calculate_planet(
                    trans_planet, year, month, day, hour,
                    natal_chart.get("latitude", 0),
                    natal_chart.get("longitude", 0),
                    natal_chart.get("chart_system", "tropical")
                )
                if "error" in trans_data:
                    continue

                trans_lon = trans_data["longitude"]
                diff = abs((trans_lon - natal_lon + 180) % 360 - 180)

                for aspect_name, aspect_angle in aspect_angles.items():
                    if abs(diff - aspect_angle) <= orb:
                        aspects.append({
                            "natal_planet": natal_planet,
                            "transit_planet": trans_planet,
                            "aspect": aspect_name,
                            "angle": aspect_angle,
                            "orb": abs(diff - aspect_angle),
                            "natal_gate": natal_data["gate"],
                            "transit_gate": trans_data["gate"],
                            "natal_sign": natal_data["sign"],
                            "transit_sign": trans_data["sign"]
                        })

        # Sort by orb (tightest first)
        aspects.sort(key=lambda x: x["orb"])
        return aspects

# Convenience function
def create_ephemeris(ephe_path: str = None):
    return EphemerisEngine(ephe_path)
