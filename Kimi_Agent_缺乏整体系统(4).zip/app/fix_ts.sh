#!/bin/bash
# Fix all TypeScript errors at once

# App.tsx - remove unused imports and fix type
sed -i 's/import type { PipelineFlow, PipelineNode, ChatMsg, Token, DepLink, SGNode, SGEdge, Rule } from/@types';\nimport type { PipelineFlow, PipelineNode, ChatMsg, SGNode, SGEdge, Rule } from/' src/App.tsx 2>/dev/null
# Actually, just edit directly
