// ═══════════════════════════════════════════════════════════════
//  KLEIN OS TYPES
//  Real engines. Real state. Real learning.
// ═══════════════════════════════════════════════════════════════

// ── SEMANTIC GRAPH ────────────────────────────────────────────
export type NodeType = 'concept' | 'object' | 'action' | 'rule' | 'event' | 'style' | 'file' | 'entity' | 'relation' | 'pattern';

export interface SGNode {
  id: string;
  type: NodeType;
  label: string;
  features: Record<string, string | number | boolean>;
  createdAt: number;
  accessCount: number;
}

export interface SGEdge {
  id: string;
  from: string;
  to: string;
  relation: string;
  weight: number;
  confidence: number;
  createdAt: number;
}

export interface SemanticGraph {
  nodes: Map<string, SGNode>;
  edges: SGEdge[];
}

// ── RULES ─────────────────────────────────────────────────────
export type RuleType = 'transformation' | 'grammar' | 'style' | 'inference';

export interface Rule {
  id: string;
  type: RuleType;
  name: string;
  lhs: string;           // pattern to match
  rhs: string;           // replacement/generation
  variables: string[];   // extracted variables
  weight: number;        // 0-1, learned
  confidence: number;    // 0-1, based on success
  examples: Array<{ input: string; output: string }>;
  createdAt: number;
  lastUsed: number;
  useCount: number;
}

// ── PARSING ───────────────────────────────────────────────────
export interface Token {
  text: string;
  pos: string;
  start: number;
  end: number;
  lemma?: string;
  features: Record<string, string>;
}

export interface DepLink {
  governor: number;   // token index
  dependent: number;  // token index
  relation: string;
}

export interface ParseTree {
  tokens: Token[];
  dependencies: DepLink[];
  root: number;
  entities: Array<{ text: string; type: string; start: number; end: number }>;
}

// ── SIMULATION ────────────────────────────────────────────────
export interface WorldState {
  tick: number;
  agents: Agent[];
  events: SimEvent[];
  facts: Fact[];
  timeline: TimelineEntry[];
}

export interface Agent {
  id: string;
  name: string;
  traits: Record<string, number>;
  goals: string[];
  beliefs: Fact[];
  location: string;
}

export interface SimEvent {
  id: string;
  type: string;
  agents: string[];
  objects: string[];
  preconditions: string[];
  consequences: string[];
  probability: number;
  tick: number;
}

export interface Fact {
  id: string;
  subject: string;
  predicate: string;
  object: string;
  confidence: number;
  source: 'user' | 'inferred' | 'simulated';
}

export interface TimelineEntry {
  tick: number;
  event: string;
  agents: string[];
  description: string;
}

// ── GENERATION ────────────────────────────────────────────────
export interface DiscoursePlan {
  intent: string;
  topic: string;
  steps: PlanStep[];
}

export interface PlanStep {
  type: 'state' | 'event' | 'quote' | 'action' | 'reveal';
  content: string;
  agents: string[];
  mood: string;
}

// ── PIPELINE ──────────────────────────────────────────────────
export type PipelineStage = 'ingest' | 'parse' | 'graph' | 'infer' | 'route' | 'morph' | 'simulate' | 'generate' | 'learn' | 'output';

export type SystemId =
  | 'parser'
  | 'diseminer'
  | 'autoling'
  | 'paraphraser'
  | 'style-controller'
  | 'simulator'
  | 'generator';

export interface PipelineNode {
  id: string;
  stage: PipelineStage;
  systemId?: SystemId;
  label: string;
  description: string;
  status: 'idle' | 'active' | 'complete' | 'error';
  input: unknown;
  output: unknown;
}

export interface ArtifactOutput {
  type: 'game' | 'app' | 'video' | 'text';
  spec: unknown;
  rendered: string | Record<string, string> | null;
  previewHTML: string | null;
}

export interface PipelineFlow {
  id: string;
  input: string;
  intent: string;
  nodes: PipelineNode[];
  parseTree?: ParseTree;
  graph?: { nodes: SGNode[]; edges: SGEdge[] };
  rules?: Rule[];
  finalOutput: string;
  startedAt: number;
  artifact: ArtifactOutput;
}

export interface ChatMsg {
  id: string;
  role: 'user' | 'system';
  content: string;
  flowId?: string;
  timestamp: number;
}
