// ═══════════════════════════════════════════════════════════════
//  VIDEO GENERATOR
//  Produces VideoSpec from semantic graph → animated HTML preview.
//  Not AI video. Programmatic composition + timeline + preview.
// ═══════════════════════════════════════════════════════════════

import type { SGNode } from '@/types';

export interface VideoSpec {
  title: string;
  scenes: Array<{
    id: string;
    type: 'wide' | 'medium' | 'closeup' | 'montage';
    setting: string;
    characters: string[];
    action: string;
    mood: string;
    duration: number;
    visualElements: Array<{ type: string; label: string; x: number; y: number; color: string }>;
  }>;
  narration: string[];
  captions: string[];
  cameraMoves: Array<{ type: string; target: string; duration: number }>;
  timing: Array<{ start: number; end: number; label: string }>;
}

function capitalize(s: string): string { return s.charAt(0).toUpperCase() + s.slice(1); }

// Extract video concept from semantic graph
function extractVideoConcept(nodes: SGNode[]): { characters: string[]; settings: string[]; actions: string[]; mood: string } {
  const entityNodes = nodes.filter(n => n.type === 'entity');
  const actionNodes = nodes.filter(n => n.type === 'action');

  const characters = entityNodes.slice(0, 4).map(n => n.label);
  const actions = actionNodes.slice(0, 6).map(n => n.label);

  // Detect mood
  let mood = 'neutral';
  if (actions.some(a => /kill|murder|die|blood/.test(a))) mood = 'noir';
  else if (actions.some(a => /chase|run|escape/.test(a))) mood = 'tense';
  else if (actions.some(a => /discover|reveal|truth/.test(a))) mood = 'dramatic';
  else if (actions.some(a => /love|kiss|embrace/.test(a))) mood = 'romantic';

  // Detect settings
  const settings: string[] = [];
  for (const node of nodes) {
    if (/lab|house|street|city|forest|castle|room|office/.test(node.label.toLowerCase())) {
      settings.push(node.label);
    }
  }
  if (settings.length === 0) {
    settings.push(mood === 'noir' ? 'dark alley' : mood === 'dramatic' ? 'grand hall' : 'open field');
  }

  return { characters, settings, actions, mood };
}

// Build VideoSpec
export function planVideo(nodes: SGNode[], _intent: string): VideoSpec {
  const concept = extractVideoConcept(nodes);
  const { characters, settings, actions, mood } = concept;

  const mainChar = characters[0] || 'Protagonist';
  const secondChar = characters[1] || 'Supporting';
  const mainSetting = settings[0] || 'unknown location';

  // Color palette per mood
  const palettes: Record<string, string[]> = {
    noir: ['#0a0a0f', '#1a1a2e', '#2d2d44', '#8b0000', '#4a4a6a'],
    tense: ['#1a0f0a', '#2e1a0f', '#ff4400', '#ff8800', '#332211'],
    dramatic: ['#0a0f1a', '#1a1a3e', '#5b4b8a', '#8b6cf5', '#c4b5fd'],
    romantic: ['#1a0a1a', '#2e1a2e', '#ff6b9d', '#ff8ec7', '#ffd6e5'],
    neutral: ['#0a0a0f', '#1a1a2e', '#334155', '#64748b', '#94a3b8'],
  };
  const colors = palettes[mood] || palettes.neutral;

  const scenes: VideoSpec['scenes'] = [
    {
      id: 's1',
      type: 'wide',
      setting: mainSetting,
      characters: [mainChar],
      action: 'establishing',
      mood,
      duration: 3000,
      visualElements: [
        { type: 'character', label: mainChar, x: 50, y: 60, color: colors[3] },
        { type: 'environment', label: mainSetting, x: 50, y: 30, color: colors[1] },
        { type: 'atmosphere', label: mood, x: 80, y: 20, color: colors[2] },
      ],
    },
    {
      id: 's2',
      type: 'medium',
      setting: mainSetting,
      characters: [mainChar, secondChar],
      action: actions[0] || 'interacts',
      mood,
      duration: 4000,
      visualElements: [
        { type: 'character', label: mainChar, x: 30, y: 55, color: colors[3] },
        { type: 'character', label: secondChar, x: 70, y: 55, color: colors[4] },
        { type: 'action', label: actions[0] || 'interaction', x: 50, y: 40, color: colors[2] },
      ],
    },
    {
      id: 's3',
      type: 'closeup',
      setting: mainSetting,
      characters: [mainChar],
      action: actions[1] || 'reacts',
      mood,
      duration: 2500,
      visualElements: [
        { type: 'character', label: mainChar, x: 50, y: 50, color: colors[3] },
        { type: 'expression', label: 'intense', x: 50, y: 35, color: colors[0] },
      ],
    },
    {
      id: 's4',
      type: 'montage',
      setting: mainSetting,
      characters: characters,
      action: 'climax',
      mood,
      duration: 5000,
      visualElements: [
        { type: 'character', label: mainChar, x: 25, y: 50, color: colors[3] },
        { type: 'character', label: secondChar, x: 75, y: 50, color: colors[4] },
        { type: 'action', label: actions[2] || 'climax', x: 50, y: 30, color: '#ef4444' },
        { type: 'atmosphere', label: 'tension', x: 50, y: 70, color: colors[2] },
      ],
    },
    {
      id: 's5',
      type: 'wide',
      setting: mainSetting,
      characters: [mainChar],
      action: 'resolution',
      mood,
      duration: 3500,
      visualElements: [
        { type: 'character', label: mainChar, x: 50, y: 65, color: colors[3] },
        { type: 'environment', label: mainSetting, x: 50, y: 30, color: colors[1] },
        { type: 'atmosphere', label: 'resolution', x: 20, y: 80, color: colors[4] },
      ],
    },
  ];

  const narration = [
    `Scene 1. We open on ${mainSetting}. ${mainChar} stands alone.`,
    `Scene 2. ${secondChar} enters. ${capitalize(actions[0] || 'something happens')}.`,
    `Scene 3. Close on ${mainChar}. The weight of the moment.`,
    `Scene 4. The climax. ${characters.join(' and ')} collide.`,
    `Scene 5. The aftermath. ${mainSetting} returns to stillness.`,
  ];

  const captions = scenes.map((s, i) => `SCENE ${i + 1}: ${s.type.toUpperCase()} - ${s.action}`);

  const cameraMoves = [
    { type: 'dolly_in', target: mainChar, duration: 3000 },
    { type: 'pan', target: secondChar, duration: 4000 },
    { type: 'static', target: mainChar, duration: 2500 },
    { type: 'zoom_out', target: 'all', duration: 5000 },
    { type: 'fade', target: mainSetting, duration: 3500 },
  ];

  const timing: Array<{ start: number; end: number; label: string }> = [];
  scenes.forEach((s, i) => {
    const prevEnd = i === 0 ? 0 : timing[i - 1].end;
    timing.push({ start: prevEnd, end: prevEnd + s.duration, label: `Scene ${i + 1}: ${s.action}` });
  });

  return {
    title: `${capitalize(mainChar)} - ${capitalize(mood)}`,
    scenes,
    narration,
    captions,
    cameraMoves,
    timing,
  };
}

// Render VideoSpec to animated HTML preview
export function renderVideo(spec: VideoSpec): string {
  const totalDuration = spec.timing[spec.timing.length - 1]?.end || 20000;

  return `<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${spec.title}</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#050508;color:#e2e8f0;font-family:ui-monospace,'Cascadia Code',monospace;font-size:13px;overflow-x:hidden}
.timeline{position:fixed;top:0;left:0;right:0;height:48px;background:#0a0a1a;border-bottom:1px solid #1a1a2e;display:flex;align-items:center;padding:0 16px;z-index:100}
.timeline-track{flex:1;height:8px;background:#1a1a2e;border-radius:4px;position:relative;margin:0 12px}
.timeline-progress{height:100%;background:linear-gradient(90deg,#8b5cf6,#ec4899);border-radius:4px;width:0%;transition:width 0.1s linear}
.timeline-markers{display:flex;position:absolute;top:-16px;left:0;right:0;justify-content:space-between;font-size:9px;color:#64748b}
.scene-viewer{position:fixed;top:48px;left:0;right:0;bottom:200px;background:#0a0a0f;display:flex;align-items:center;justify-content:center}
.scene-canvas{width:800px;height:450px;background:#0a0a1a;border:1px solid #1a1a2e;border-radius:8px;position:relative;overflow:hidden}
.scene-element{position:absolute;border-radius:50%;transition:all 0.5s ease;display:flex;align-items:center;justify-content:center;font-size:10px;color:#fff;text-shadow:0 1px 2px rgba(0,0,0,0.8);white-space:nowrap}
.scene-label{position:absolute;bottom:12px;left:12px;font-size:11px;color:#94a3b8}
.scene-type{position:absolute;top:12px;right:12px;font-size:10px;text-transform:uppercase;letter-spacing:2px;color:#8b5cf6;background:rgba(139,92,246,0.1);padding:4px 8px;border-radius:4px}
.controls{position:fixed;bottom:0;left:0;right:0;height:200px;background:#0a0a1a;border-top:1px solid #1a1a2e;display:flex}
.narration{flex:1;padding:16px;overflow-y:auto;border-right:1px solid #1a1a2e}
.narration h3{font-size:11px;text-transform:uppercase;letter-spacing:2px;color:#64748b;margin-bottom:8px}
.narration p{font-size:12px;line-height:1.6;color:#94a3b8;margin-bottom:8px;padding-left:12px;border-left:2px solid transparent}
.narration p.active{color:#e2e8f0;border-left-color:#8b5cf6}
.storyboard{width:300px;padding:16px;overflow-y:auto}
.storyboard h3{font-size:11px;text-transform:uppercase;letter-spacing:2px;color:#64748b;margin-bottom:8px}
.story-thumb{display:flex;gap:8px;margin-bottom:8px;padding:8px;border-radius:6px;cursor:pointer;border:1px solid transparent}
.story-thumb:hover,.story-thumb.active{border-color:#8b5cf6;background:rgba(139,92,246,0.05)}
.story-thumb .num{width:24px;height:24px;background:#1a1a2e;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:10px;color:#64748b}
.story-thumb.active .num{background:#8b5cf6;color:#fff}
.story-thumb .info{flex:1}
.story-thumb .type{font-size:10px;color:#94a3b8}
.story-thumb .dur{font-size:9px;color:#64748b}
</style></head>
<body>
<div class="timeline">
  <span id="time">00:00</span>
  <div class="timeline-track"><div class="timeline-progress" id="prog"></div><div class="timeline-markers">${spec.timing.map(t => `<span>${formatTime(t.start)}</span>`).join('')}</div></div>
  <span id="total">${formatTime(totalDuration)}</span>
</div>
<div class="scene-viewer"><div class="scene-canvas" id="canvas"></div></div>
<div class="controls">
  <div class="narration"><h3>Narration</h3><div id="narr">${spec.narration.map((n, i) => `<p id="nar${i}">${n}</p>`).join('')}</div></div>
  <div class="storyboard"><h3>Storyboard</h3><div id="thumbs">${spec.scenes.map((s, i) => `<div class="story-thumb" id="thumb${i}" onclick="jumpTo(${spec.timing[i].start})"><div class="num">${i+1}</div><div class="info"><div class="type">${s.type.toUpperCase()} - ${s.action}</div><div class="dur">${s.duration}ms</div></div></div>`).join('')}</div></div>
</div>
<script>
const spec=${JSON.stringify(spec)};
const total=${totalDuration};
let currentTime=0,playing=true,currentScene=-1;
const canvas=document.getElementById('canvas');
const progEl=document.getElementById('prog');
const timeEl=document.getElementById('time');

function formatTime(ms){const s=Math.floor(ms/1000),m=Math.floor(s/60);return String(m).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}

function renderScene(si){
  if(si===currentScene)return;currentScene=si;
  const s=spec.scenes[si];if(!s)return;
  canvas.innerHTML='<div class="scene-type">'+s.type+'</div><div class="scene-label">'+s.setting+' | '+s.action+'</div>';
  // Background gradient based on mood
  const moodColors={noir:'linear-gradient(135deg,#0a0a0f,#1a0a0f)',tense:'linear-gradient(135deg,#1a0f0a,#2e1a0f)',dramatic:'linear-gradient(135deg,#0a0a1a,#1a1a3e)',romantic:'linear-gradient(135deg,#1a0a1a,#2e1a2e)',neutral:'linear-gradient(135deg,#0a0a0f,#0f0f1a)'};
  canvas.style.background=moodColors[s.mood]||moodColors.neutral;
  // Render elements
  s.visualElements.forEach((el,ei)=>{
    const div=document.createElement('div');
    div.className='scene-element';
    div.style.left=el.x+'%';div.style.top=el.y+'%';
    div.style.background=el.color+'40';div.style.border='2px solid '+el.color;
    div.style.width=(el.type==='environment'?120:el.type==='atmosphere'?80:48)+'px';
    div.style.height=(el.type==='environment'?80:el.type==='atmosphere'?40:48)+'px';
    div.style.transform='scale(0)';
    div.textContent=el.label.substring(0,10);
    canvas.appendChild(div);
    setTimeout(()=>{div.style.transform='scale(1)'},ei*200);
  });
  // Update narration highlight
  spec.narration.forEach((_,i)=>{document.getElementById('nar'+i).classList.toggle('active',i===si);});
  spec.scenes.forEach((_,i)=>{document.getElementById('thumb'+i).classList.toggle('active',i===si);});
}

function jumpTo(ms){currentTime=ms;}

function tick(){
  if(playing)currentTime+=50;
  if(currentTime>total)currentTime=0;
  const pct=(currentTime/total)*100;
  progEl.style.width=pct+'%';
  timeEl.textContent=formatTime(currentTime);
  // Find current scene
  for(let i=spec.timing.length-1;i>=0;i--){
    if(currentTime>=spec.timing[i].start){renderScene(i);break;}
  }
  requestAnimationFrame(tick);
}
tick();
</script></body></html>`;
}

function formatTime(ms: number): string {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  return String(m).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
}
