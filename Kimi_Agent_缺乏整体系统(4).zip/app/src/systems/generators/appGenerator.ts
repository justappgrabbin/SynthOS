// ═══════════════════════════════════════════════════════════════
//  APP GENERATOR
//  Produces AppSpec from semantic graph → real React components.
//  Not a spec sheet. Renderable code.
// ═══════════════════════════════════════════════════════════════

import type { SGNode, SGEdge } from '@/types';

export interface AppSpec {
  name: string;
  purpose: string;
  screens: Array<{ name: string; route: string; components: string[] }>;
  components: Array<{ name: string; type: string; props: string[]; state: string[]; actions: string[] }>;
  state: Array<{ name: string; type: string; defaultValue: string }>;
  dataModel: Array<{ name: string; fields: string[] }>;
  routes: string[];
}

function toPascal(s: string): string {
  return s.replace(/(?:^|[-_\s])(\w)/g, (_, c) => c.toUpperCase()).replace(/[-_\s]/g, '');
}

function toCamel(s: string): string {
  const pascal = toPascal(s);
  return pascal.charAt(0).toLowerCase() + pascal.slice(1);
}

// Extract app concept from semantic graph
function extractAppConcept(nodes: SGNode[], _edges: SGEdge[]): { purpose: string; entities: string[]; actions: string[] } {
  const entityNodes = nodes.filter(n => n.type === 'entity' || n.type === 'object');
  const actionNodes = nodes.filter(n => n.type === 'action');

  const entities = entityNodes.slice(0, 6).map(n => n.label);
  const actions = actionNodes.slice(0, 6).map(n => n.label);

  // Detect purpose from relations
  let purpose = 'management';
  if (actions.some(a => /track|monitor|log/.test(a))) purpose = 'tracking';
  if (actions.some(a => /create|build|make/.test(a))) purpose = 'creation';
  if (actions.some(a => /analyze|report|view/.test(a))) purpose = 'analytics';
  if (actions.some(a => /search|find|query/.test(a))) purpose = 'search';

  return { purpose, entities, actions };
}

// Build AppSpec
export function planApp(nodes: SGNode[], edges: SGEdge[], intent: string): AppSpec {
  const concept = extractAppConcept(nodes, edges);
  const { entities } = concept;

  // Derive app name from entities + intent
  const mainEntity = entities[0] || 'Item';
  const appName = toPascal(mainEntity) + (intent.includes('tracker') ? 'Tracker' : intent.includes('dashboard') ? 'Dashboard' : intent.includes('manager') ? 'Manager' : 'App');

  // Derive screens from CRUD on main entity
  const screens = [
    { name: `${appName}Home`, route: '/', components: [`${mainEntity}Summary`, 'Navigation', 'StatsPanel'] },
    { name: `${appName}List`, route: '/list', components: [`${mainEntity}List`, `${mainEntity}Filter`, 'Pagination'] },
    { name: `${appName}Detail`, route: '/detail/:id', components: [`${mainEntity}Detail`, `${mainEntity}EditForm`, 'ActionButtons'] },
    { name: `${appName}Create`, route: '/new', components: [`${mainEntity}CreateForm`, 'ValidationPanel'] },
    { name: `${appName}Settings`, route: '/settings', components: ['SettingsForm', 'ThemeToggle'] },
  ];

  // Derive components from entities + actions
  const components = [
    {
      name: `${mainEntity}List`,
      type: 'list',
      props: ['items', 'onSelect', 'onDelete'],
      state: ['selectedIds', 'sortField', 'sortDir'],
      actions: ['handleSelect', 'handleSort', 'handleDelete'],
    },
    {
      name: `${mainEntity}Detail`,
      type: 'detail',
      props: ['item', 'onEdit', 'onBack'],
      state: ['isEditing', 'formData'],
      actions: ['handleEdit', 'handleSave', 'handleCancel'],
    },
    {
      name: `${mainEntity}CreateForm`,
      type: 'form',
      props: ['onSubmit', 'onCancel'],
      state: ['formData', 'errors', 'isSubmitting'],
      actions: ['handleChange', 'handleSubmit', 'validate'],
    },
    {
      name: `${mainEntity}EditForm`,
      type: 'form',
      props: ['item', 'onSave', 'onCancel'],
      state: ['formData', 'errors', 'dirty'],
      actions: ['handleChange', 'handleSave', 'handleReset'],
    },
    {
      name: `${mainEntity}Filter`,
      type: 'filter',
      props: ['filters', 'onChange'],
      state: ['localFilters'],
      actions: ['handleChange', 'handleClear'],
    },
    {
      name: `${mainEntity}Summary`,
      type: 'summary',
      props: ['stats'],
      state: [],
      actions: [],
    },
    {
      name: 'Navigation',
      type: 'navigation',
      props: ['activeRoute'],
      state: ['isOpen'],
      actions: ['toggle'],
    },
    {
      name: 'StatsPanel',
      type: 'stats',
      props: ['data'],
      state: [],
      actions: ['refresh'],
    },
  ];

  // State from entities
  const state = [
    { name: toCamel(mainEntity) + 's', type: mainEntity + '[]', defaultValue: '[]' },
    { name: 'selected' + mainEntity, type: mainEntity + ' | null', defaultValue: 'null' },
    { name: 'isLoading', type: 'boolean', defaultValue: 'false' },
    { name: 'error', type: 'string | null', defaultValue: 'null' },
    { name: 'filters', type: 'Record<string, string>', defaultValue: '{}' },
    { name: 'theme', type: "'light' | 'dark'", defaultValue: "'dark'" },
  ];

  // Data model
  const dataModel = [
    {
      name: mainEntity,
      fields: ['id: string', 'name: string', 'createdAt: Date', 'updatedAt: Date', ...entities.slice(1, 4).map(e => `${toCamel(e)}: string`)],
    },
    ...entities.slice(1, 3).map(e => ({
      name: e,
      fields: ['id: string', 'name: string', `${toCamel(mainEntity)}Id: string`],
    })),
  ];

  return { name: appName, purpose: concept.purpose, screens, components, state, dataModel, routes: screens.map(s => s.route) };
}

// Render AppSpec to React component code
export function renderApp(spec: AppSpec): Record<string, string> {
  const files: Record<string, string> = {};
  const mainEntity = spec.dataModel[0].name;
  const camelEntity = toCamel(mainEntity);

  // 1. Types
  files['types.ts'] = `export interface ${mainEntity} {
  id: string;
  name: string;
  createdAt: Date;
  updatedAt: Date;
  ${spec.dataModel[0].fields.filter(f => !['id', 'name', 'createdAt', 'updatedAt'].includes(f.split(':')[0])).join('\n  ')}
}

export interface AppState {
  ${spec.state.map(s => `${s.name}: ${s.type};`).join('\n  ')}
}
`;

  // 2. Store (context-based state)
  files['store.ts'] = `import { createContext, useContext, useReducer } from 'react';
import type { ${mainEntity}, AppState } from './types';

type Action =
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null }
  | { type: 'SET_${mainEntity.toUpperCase()}S'; payload: ${mainEntity}[] }
  | { type: 'SELECT_${mainEntity.toUpperCase()}'; payload: ${mainEntity} | null }
  | { type: 'ADD_${mainEntity.toUpperCase()}'; payload: ${mainEntity} }
  | { type: 'UPDATE_${mainEntity.toUpperCase()}'; payload: ${mainEntity} }
  | { type: 'DELETE_${mainEntity.toUpperCase()}'; payload: string }
  | { type: 'SET_FILTERS'; payload: Record<string, string> }
  | { type: 'SET_THEME'; payload: 'light' | 'dark' };

const initialState: AppState = {
  ${spec.state.map(s => `${s.name}: ${s.defaultValue},`).join('\n  ')}
};

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'SET_LOADING': return { ...state, isLoading: action.payload };
    case 'SET_ERROR': return { ...state, error: action.payload };
    case 'SET_${mainEntity.toUpperCase()}S': return { ...state, ${camelEntity}s: action.payload };
    case 'SELECT_${mainEntity.toUpperCase()}': return { ...state, selected${mainEntity}: action.payload };
    case 'ADD_${mainEntity.toUpperCase()}': return { ...state, ${camelEntity}s: [...state.${camelEntity}s, action.payload] };
    case 'UPDATE_${mainEntity.toUpperCase()}': return { ...state, ${camelEntity}s: state.${camelEntity}s.map(i => i.id === action.payload.id ? action.payload : i) };
    case 'DELETE_${mainEntity.toUpperCase()}': return { ...state, ${camelEntity}s: state.${camelEntity}s.filter(i => i.id !== action.payload) };
    case 'SET_FILTERS': return { ...state, filters: action.payload };
    case 'SET_THEME': return { ...state, theme: action.payload };
    default: return state;
  }
}

const StoreContext = createContext<{ state: AppState; dispatch: React.Dispatch<Action> } | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  return <StoreContext.Provider value={{ state, dispatch }}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be inside StoreProvider');
  return ctx;
}
`;

  // 3. List component
  files[`${mainEntity}List.tsx`] = `import { useStore } from './store';
import type { ${mainEntity} } from './types';

export function ${mainEntity}List() {
  const { state, dispatch } = useStore();
  const items = state.${camelEntity}s;
  const [selectedIds, setSelectedIds] = React.useState<string[]>([]);

  const handleSelect = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const handleDelete = (id: string) => {
    dispatch({ type: 'DELETE_${mainEntity.toUpperCase()}', payload: id });
  };

  if (state.isLoading) return <div className="loading">Loading...</div>;
  if (state.error) return <div className="error">{state.error}</div>;

  return (
    <div className="list-container">
      <h2>${mainEntity}s ({items.length})</h2>
      <div className="list">
        {items.map(item => (
          <div key={item.id} className={\`list-item \${selectedIds.includes(item.id) ? 'selected' : ''}\`} onClick={() => handleSelect(item.id)}>
            <span className="name">{item.name}</span>
            <button onClick={e => { e.stopPropagation(); handleDelete(item.id); }}>Delete</button>
          </div>
        ))}
      </div>
    </div>
  );
}
`;

  // 4. Create Form
  files[`${mainEntity}CreateForm.tsx`] = `import { useState } from 'react';
import { useStore } from './store';

export function ${mainEntity}CreateForm() {
  const { dispatch } = useStore();
  const [formData, setFormData] = useState({ name: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.name.trim()) errs.name = 'Name is required';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    dispatch({
      type: 'ADD_${mainEntity.toUpperCase()}',
      payload: { id: crypto.randomUUID(), name: formData.name, createdAt: new Date(), updatedAt: new Date() }
    });
    setFormData({ name: '' });
  };

  return (
    <form onSubmit={handleSubmit} className="create-form">
      <h2>Create ${mainEntity}</h2>
      <div className="field">
        <label>Name</label>
        <input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} />
        {errors.name && <span className="error">{errors.name}</span>}
      </div>
      <button type="submit">Create</button>
    </form>
  );
}
`;

  // 5. Navigation
  files['Navigation.tsx'] = `import { useState } from 'react';

const routes = [
  ${spec.screens.map(s => `{ label: '${s.name}', path: '${s.route}' }`).join(',\n  ')}
];

export function Navigation({ activeRoute = '/' }: { activeRoute?: string }) {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <nav className="navigation">
      <button onClick={() => setIsOpen(!isOpen)}>{isOpen ? '<<' : '>>'}</button>
      {isOpen && routes.map(r => (
        <div key={r.path} className={\`nav-item \${r.path === activeRoute ? 'active' : ''}\`}>
          {r.label}
        </div>
      ))}
    </nav>
  );
}
`;

  // 6. Stats Panel
  files['StatsPanel.tsx'] = `import { useStore } from './store';

export function StatsPanel() {
  const { state } = useStore();
  const total = state.${camelEntity}s.length;

  return (
    <div className="stats-panel">
      <div className="stat"><span className="value">{total}</span><span className="label">Total ${mainEntity}s</span></div>
      <div className="stat"><span className="value">{state.theme}</span><span className="label">Theme</span></div>
    </div>
  );
}
`;

  // 7. App shell
  files['App.tsx'] = `import { StoreProvider } from './store';
import { Navigation } from './Navigation';
import { ${mainEntity}List } from './${mainEntity}List';
import { ${mainEntity}CreateForm } from './${mainEntity}CreateForm';
import { StatsPanel } from './StatsPanel';
import './App.css';

export default function App() {
  return (
    <StoreProvider>
      <div className="app" data-theme="dark">
        <Navigation />
        <main className="main">
          <header className="header"><h1>${spec.name}</h1><p>${spec.purpose}</p></header>
          <div className="content">
            <div className="panel"><StatsPanel /></div>
            <div className="panel"><${mainEntity}CreateForm /></div>
            <div className="panel wide"><${mainEntity}List /></div>
          </div>
        </main>
      </div>
    </StoreProvider>
  );
}
`;

  // 8. CSS
  files['App.css'] = `:root { --bg: #0a0a0f; --surface: #14141f; --border: #2a2a3a; --text: #e2e8f0; --accent: #8b5cf6; --success: #22c55e; --error: #ef4444; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body { background: var(--bg); color: var(--text); font-family: ui-monospace, 'Cascadia Code', monospace; font-size: 14px; }
.app { display: flex; min-height: 100vh; }
.navigation { width: 200px; background: var(--surface); border-right: 1px solid var(--border); padding: 16px; }
.nav-item { padding: 8px 12px; margin: 4px 0; border-radius: 6px; cursor: pointer; color: #94a3b8; }
.nav-item:hover, .nav-item.active { background: rgba(139,92,246,0.15); color: #c4b5fd; }
.main { flex: 1; padding: 24px; }
.header { margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid var(--border); }
.header h1 { font-size: 24px; color: #c4b5fd; }
.content { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.panel { background: var(--surface); border: 1px solid var(--border); border-radius: 8px; padding: 16px; }
.panel.wide { grid-column: 1 / -1; }
.create-form h2 { margin-bottom: 12px; color: #c4b5fd; font-size: 16px; }
.field { margin-bottom: 12px; }
.field label { display: block; margin-bottom: 4px; color: #94a3b8; font-size: 12px; }
.field input { width: 100%; padding: 8px 12px; background: var(--bg); border: 1px solid var(--border); border-radius: 6px; color: var(--text); font-family: inherit; }
.field .error { color: var(--error); font-size: 11px; margin-top: 4px; display: block; }
button { padding: 8px 16px; background: var(--accent); color: #fff; border: none; border-radius: 6px; cursor: pointer; font-family: inherit; font-size: 12px; }
button:hover { opacity: 0.9; }
.list-container h2 { margin-bottom: 12px; color: #c4b5fd; font-size: 16px; }
.list-item { display: flex; justify-content: space-between; align-items: center; padding: 10px 12px; margin: 4px 0; background: rgba(255,255,255,0.03); border-radius: 6px; cursor: pointer; border: 1px solid transparent; }
.list-item:hover { border-color: var(--border); }
.list-item.selected { border-color: var(--accent); background: rgba(139,92,246,0.08); }
.list-item .name { color: var(--text); }
.stats-panel { display: flex; gap: 24px; }
.stat { text-align: center; }
.stat .value { display: block; font-size: 32px; font-weight: bold; color: var(--accent); }
.stat .label { font-size: 11px; color: #64748b; text-transform: uppercase; }
.loading, .error { padding: 24px; text-align: center; color: #64748b; }
`;

  return files;
}
