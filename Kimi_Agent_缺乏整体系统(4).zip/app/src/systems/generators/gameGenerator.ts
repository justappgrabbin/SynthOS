// ═══════════════════════════════════════════════════════════════
//  GAME GENERATOR
//  Produces GameSpec from semantic graph → playable HTML Canvas game.
//  Not a spec sheet. A running game.
// ═══════════════════════════════════════════════════════════════

import type { SGNode } from '@/types';

export interface GameSpec {
  title: string;
  genre: string;
  width: number;
  height: number;
  player: { x: number; y: number; size: number; color: string; speed: number };
  objectives: string[];
  mechanics: string[];
  entities: Array<{ type: string; x: number; y: number; size: number; color: string; behavior: string }>;
  winCondition: string;
  controls: string[];
}

// Extract game concept from semantic graph nodes
function extractGameConcept(nodes: SGNode[]): { theme: string; genre: string; entities: string[] } {
  const labels = nodes.map(n => n.label.toLowerCase());

  // Detect genre from semantic cues
  let genre = 'adventure';
  if (labels.some(l => /chase|hunt|pursue|detective/.test(l))) genre = 'detective';
  else if (labels.some(l => /mystery|clue|secret|hidden/.test(l))) genre = 'mystery';
  else if (labels.some(l => /fight|battle|war|combat/.test(l))) genre = 'action';
  else if (labels.some(l => /explore|discover|world|journey/.test(l))) genre = 'exploration';
  else if (labels.some(l => /murder|kill|dead|crime/.test(l))) genre = 'crime';

  // Extract entity names from the graph
  const entityNodes = nodes.filter(n => n.type === 'entity' || n.type === 'object');
  const entities = entityNodes.length > 0
    ? entityNodes.slice(0, 5).map(n => n.label)
    : ['player', 'target', 'obstacle', 'item', 'enemy'];

  // Theme from first entity
  const theme = entities[0] || 'adventure';

  return { theme, genre, entities };
}

// Build the GameSpec
export function planGame(nodes: SGNode[], _intent: string): GameSpec {
  const concept = extractGameConcept(nodes);
  const { genre, entities } = concept;

  // Genre-specific configurations
  const configs: Record<string, Partial<GameSpec>> = {
    detective: {
      title: 'The Case of the ' + capitalize(entities[1] || 'Missing Evidence'),
      player: { x: 50, y: 250, size: 16, color: '#3b82f6', speed: 3 },
      objectives: ['Find all clues', 'Avoid suspects', 'Reach the truth'],
      mechanics: ['move', 'collect', 'avoid'],
      entities: [
        { type: 'clue', x: 200, y: 100, size: 12, color: '#f59e0b', behavior: 'static' },
        { type: 'clue', x: 400, y: 300, size: 12, color: '#f59e0b', behavior: 'static' },
        { type: 'clue', x: 600, y: 150, size: 12, color: '#f59e0b', behavior: 'static' },
        { type: 'suspect', x: 300, y: 200, size: 18, color: '#ef4444', behavior: 'patrol_horizontal' },
        { type: 'suspect', x: 500, y: 350, size: 18, color: '#ef4444', behavior: 'patrol_vertical' },
        { type: 'item', x: 700, y: 250, size: 10, color: '#22c55e', behavior: 'static' },
      ],
      winCondition: 'collect_all_clues',
    },
    mystery: {
      title: capitalize(entities[0] || 'The') + ' Mystery',
      player: { x: 30, y: 200, size: 16, color: '#8b5cf6', speed: 3 },
      objectives: ['Discover the secret', 'Solve the puzzle', 'Find the exit'],
      mechanics: ['move', 'discover', 'solve'],
      entities: [
        { type: 'secret', x: 350, y: 80, size: 14, color: '#f59e0b', behavior: 'reveal_on_proximity' },
        { type: 'puzzle', x: 200, y: 200, size: 20, color: '#ec4899', behavior: 'static' },
        { type: 'puzzle', x: 500, y: 100, size: 20, color: '#ec4899', behavior: 'static' },
        { type: 'guardian', x: 400, y: 300, size: 18, color: '#64748b', behavior: 'orbit' },
        { type: 'exit', x: 750, y: 350, size: 24, color: '#22c55e', behavior: 'static' },
      ],
      winCondition: 'reach_exit_with_secrets',
    },
    action: {
      title: capitalize(entities[0] || 'Battle') + ' Arena',
      player: { x: 400, y: 250, size: 18, color: '#3b82f6', speed: 4 },
      objectives: ['Defeat all enemies', 'Survive', 'Score 1000 points'],
      mechanics: ['move', 'attack', 'dodge'],
      entities: [
        { type: 'enemy', x: 100, y: 100, size: 16, color: '#ef4444', behavior: 'chase' },
        { type: 'enemy', x: 700, y: 100, size: 16, color: '#ef4444', behavior: 'chase' },
        { type: 'enemy', x: 100, y: 400, size: 16, color: '#ef4444', behavior: 'patrol_horizontal' },
        { type: 'powerup', x: 400, y: 50, size: 12, color: '#22c55e', behavior: 'static' },
        { type: 'powerup', x: 400, y: 450, size: 12, color: '#22c55e', behavior: 'static' },
      ],
      winCondition: 'defeat_all_enemies',
    },
    exploration: {
      title: 'Journey to ' + capitalize(entities[1] || 'the Unknown'),
      player: { x: 30, y: 250, size: 14, color: '#06b6d4', speed: 3 },
      objectives: ['Explore the world', 'Collect artifacts', 'Reach the destination'],
      mechanics: ['move', 'explore', 'collect'],
      entities: [
        { type: 'artifact', x: 150, y: 100, size: 12, color: '#f59e0b', behavior: 'static' },
        { type: 'artifact', x: 400, y: 350, size: 12, color: '#f59e0b', behavior: 'static' },
        { type: 'artifact', x: 650, y: 80, size: 12, color: '#f59e0b', behavior: 'static' },
        { type: 'obstacle', x: 250, y: 200, size: 40, color: '#78716c', behavior: 'static' },
        { type: 'obstacle', x: 500, y: 280, size: 40, color: '#78716c', behavior: 'static' },
        { type: 'destination', x: 750, y: 250, size: 24, color: '#22c55e', behavior: 'static' },
      ],
      winCondition: 'reach_destination',
    },
    crime: {
      title: 'Crime Scene: ' + capitalize(entities[0] || 'Investigation'),
      player: { x: 50, y: 300, size: 16, color: '#0ea5e9', speed: 3 },
      objectives: ['Find evidence', 'Photograph clues', 'Identify suspect'],
      mechanics: ['move', 'investigate', 'collect'],
      entities: [
        { type: 'evidence', x: 200, y: 150, size: 12, color: '#f59e0b', behavior: 'static' },
        { type: 'evidence', x: 450, y: 350, size: 12, color: '#f59e0b', behavior: 'static' },
        { type: 'evidence', x: 650, y: 100, size: 12, color: '#f59e0b', behavior: 'static' },
        { type: 'suspect', x: 350, y: 250, size: 20, color: '#ef4444', behavior: 'flee' },
        { type: 'barrier', x: 150, y: 350, size: 30, color: '#57534e', behavior: 'static' },
      ],
      winCondition: 'collect_all_evidence',
    },
  };

  const config = configs[genre] || configs.exploration;

  return {
    width: 800,
    height: 480,
    controls: ['Arrow keys / WASD to move', 'Space to interact', 'R to restart'],
    ...config,
    title: config.title || 'Game',
    genre,
  } as GameSpec;
}

// Render GameSpec to playable HTML Canvas game
export function renderGame(spec: GameSpec): string {
  const entitiesJSON = JSON.stringify(spec.entities);

  return `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>${spec.title}</title>
<style>body{margin:0;background:#0a0a0f;display:flex;justify-content:center;align-items:center;height:100vh;font-family:monospace;color:#fff}canvas{border:1px solid #333}#ui{position:absolute;top:10px;left:10px;font-size:12px}#win{position:absolute;center;center;font-size:24px;display:none}</style></head>
<body><div id="ui">${spec.title} | Clues: <span id="score">0</span>/${spec.entities.filter(e=>e.type==='clue'||e.type==='evidence'||e.type==='artifact'||e.type==='secret').length}</div>
<canvas id="g" width="${spec.width}" height="${spec.height}"></canvas><div id="win">COMPLETE</div>
<script>
const canvas=document.getElementById('g'),ctx=canvas.getContext('2d');
const spec={player:${JSON.stringify(spec.player)},entities:${entitiesJSON},winCondition:'${spec.winCondition}'};
let player={...spec.player,keys:{}};
let entities=spec.entities.map(e=>({...e,vx:0,vy:0,collected:false,active:true}));
let score=0,gameOver=false,won=false,tick=0;
const cluesNeeded=entities.filter(e=>e.type==='clue'||e.type==='evidence'||e.type==='artifact'||e.type==='secret').length;

document.addEventListener('keydown',e=>{player.keys[e.key]=true;if(e.key==='r'||e.key==='R')reset();});
document.addEventListener('keyup',e=>player.keys[e.key]=false);

function reset(){
  player={...spec.player,keys:{}};
  entities=spec.entities.map(e=>({...e,vx:0,vy:0,collected:false,active:true}));
  score=0;gameOver=false;won=false;tick=0;
  document.getElementById('win').style.display='none';
  document.getElementById('score').textContent='0';
}

function update(){
  if(gameOver)return;
  tick++;
  // Player movement
  if(player.keys['ArrowLeft']||player.keys['a'])player.x-=player.speed;
  if(player.keys['ArrowRight']||player.keys['d'])player.x+=player.speed;
  if(player.keys['ArrowUp']||player.keys['w'])player.y-=player.speed;
  if(player.keys['ArrowDown']||player.keys['s'])player.y+=player.speed;
  player.x=Math.max(player.size,Math.min(${spec.width}-player.size,player.x));
  player.y=Math.max(player.size,Math.min(${spec.height}-player.size,player.y));

  // Entity behaviors
  entities.forEach(e=>{
    if(!e.active)return;
    if(e.behavior==='patrol_horizontal'){e.x+=Math.sin(tick*0.02)*2;e.x=Math.max(e.size,Math.min(${spec.width}-e.size,e.x));}
    if(e.behavior==='patrol_vertical'){e.y+=Math.sin(tick*0.025)*2;e.y=Math.max(e.size,Math.min(${spec.height}-e.size,e.y));}
    if(e.behavior==='orbit'){e.x=${spec.width}/2+Math.cos(tick*0.03)*150;e.y=${spec.height}/2+Math.sin(tick*0.03)*100;}
    if(e.behavior==='chase'){const dx=player.x-e.x,dy=player.y-e.y,d=Math.sqrt(dx*dx+dy*dy);if(d>1){e.x+=dx/d*1.2;e.y+=dy/d*1.2;}}
    if(e.behavior==='flee'){const dx=player.x-e.x,dy=player.y-e.y,d=Math.sqrt(dx*dx+dy*dy);if(d<150&&d>1){e.x-=dx/d*1.5;e.y-=dy/d*1.5;}}

    // Collision with player
    const dx=player.x-e.x,dy=player.y-e.y,dist=Math.sqrt(dx*dx+dy*dy);
    if(dist<player.size+e.size){
      if(e.type==='clue'||e.type==='evidence'||e.type==='artifact'||e.type==='secret'){e.collected=true;e.active=false;score++;document.getElementById('score').textContent=score;}
      if(e.type==='powerup'){e.active=false;player.speed+=1;}
      if(e.type==='suspect'||e.type==='guardian'||e.type==='enemy'){if(!e.hit){e.hit=true;player.x-=dx/dist*30;player.y-=dy/dist*30;}}
      if(e.type==='exit'&&score>=cluesNeeded){won=true;gameOver=true;document.getElementById('win').style.display='block';}
    }
  });

  // Win conditions
  if(spec.winCondition==='collect_all_clues'&&score>=cluesNeeded){won=true;gameOver=true;}
  if(spec.winCondition==='defeat_all_enemies'&&entities.filter(e=>e.type==='enemy'&&e.active).length===0){won=true;gameOver=true;}
  if(spec.winCondition==='reach_destination'){const dest=entities.find(e=>e.type==='destination');if(dest){const dx=player.x-dest.x,dy=player.y-dest.y;if(Math.sqrt(dx*dx+dy*dy)<dest.size+player.size&&score>=cluesNeeded){won=true;gameOver=true;}}}
}

function draw(){
  ctx.fillStyle='#0a0a0f';ctx.fillRect(0,0,${spec.width},${spec.height});
  // Grid
  ctx.strokeStyle='#1a1a2e';ctx.lineWidth=0.5;
  for(let x=0;x<${spec.width};x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,${spec.height});ctx.stroke();}
  for(let y=0;y<${spec.height};y+=40){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(${spec.width},y);ctx.stroke();}
  // Entities
  entities.forEach(e=>{
    if(!e.active)return;
    ctx.fillStyle=e.color;ctx.beginPath();
    if(e.type==='clue'||e.type==='evidence'||e.type==='artifact'){
      ctx.arc(e.x,e.y,e.size,0,Math.PI*2);ctx.fill();
      ctx.fillStyle='#fff';ctx.font='10px monospace';ctx.textAlign='center';ctx.fillText('?',e.x,e.y+3);
    }else if(e.type==='obstacle'||e.type==='barrier'){
      ctx.fillRect(e.x-e.size/2,e.y-e.size/2,e.size,e.size);
    }else{
      ctx.arc(e.x,e.y,e.size,0,Math.PI*2);ctx.fill();
    }
  });
  // Player
  ctx.fillStyle=player.color;ctx.beginPath();ctx.arc(player.x,player.y,player.size,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.stroke();
  // Win overlay
  if(won){ctx.fillStyle='rgba(0,255,0,0.2)';ctx.fillRect(0,0,${spec.width},${spec.height});ctx.fillStyle='#22c55e';ctx.font='bold 32px monospace';ctx.textAlign='center';ctx.fillText('COMPLETE',${spec.width}/2,${spec.height}/2);}
  if(gameOver&&!won){ctx.fillStyle='rgba(255,0,0,0.2)';ctx.fillRect(0,0,${spec.width},${spec.height});}
}

function loop(){update();draw();requestAnimationFrame(loop);}
loop();
</script></body></html>`;
}

function capitalize(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
