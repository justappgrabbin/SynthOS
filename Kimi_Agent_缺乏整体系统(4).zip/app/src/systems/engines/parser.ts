// ═══════════════════════════════════════════════════════════════
//  PARSER ENGINE (Klein & Simmons, 1963)
//  Real tokenization + phrase structure + dependency parsing.
//  Not token soup. Structured meaning extraction.
// ═══════════════════════════════════════════════════════════════

import type { Token, DepLink, ParseTree } from '@/types';

// ── LEXICON ─────────────────────────────────────────────────
const LEXICON: Record<string, { pos: string; features: Record<string, string> }> = {
  the: { pos: 'DET', features: { definiteness: 'def' } },
  a: { pos: 'DET', features: { definiteness: 'indef' } },
  an: { pos: 'DET', features: { definiteness: 'indef' } },
  this: { pos: 'DET', features: { definiteness: 'dem', proximity: 'near' } },
  that: { pos: 'DET', features: { definiteness: 'dem', proximity: 'far' } },
  i: { pos: 'PRP', features: { person: '1', number: 'sg', case: 'nom' } },
  me: { pos: 'PRP', features: { person: '1', number: 'sg', case: 'acc' } },
  you: { pos: 'PRP', features: { person: '2', number: 'both' } } ,
  he: { pos: 'PRP', features: { person: '3', number: 'sg', gender: 'masc' } },
  she: { pos: 'PRP', features: { person: '3', number: 'sg', gender: 'fem' } },
  it: { pos: 'PRP', features: { person: '3', number: 'sg', gender: 'neut' } },
  we: { pos: 'PRP', features: { person: '1', number: 'pl', case: 'nom' } },
  they: { pos: 'PRP', features: { person: '3', number: 'pl' } },
  is: { pos: 'VBZ', features: { lemma: 'be', tense: 'pres', aspect: 'simp' } },
  was: { pos: 'VBD', features: { lemma: 'be', tense: 'past', aspect: 'simp' } },
  are: { pos: 'VBP', features: { lemma: 'be', tense: 'pres', aspect: 'simp' } },
  were: { pos: 'VBD', features: { lemma: 'be', tense: 'past', aspect: 'simp' } },
  be: { pos: 'VB', features: { lemma: 'be' } },
  been: { pos: 'VBN', features: { lemma: 'be', tense: 'past', aspect: 'perf' } },
  being: { pos: 'VBG', features: { lemma: 'be', aspect: 'prog' } },
  have: { pos: 'VBP', features: { lemma: 'have' } },
  has: { pos: 'VBZ', features: { lemma: 'have', tense: 'pres' } },
  had: { pos: 'VBD', features: { lemma: 'have', tense: 'past' } },
  do: { pos: 'VBP', features: { lemma: 'do' } },
  does: { pos: 'VBZ', features: { lemma: 'do', tense: 'pres' } },
  did: { pos: 'VBD', features: { lemma: 'do', tense: 'past' } },
  will: { pos: 'MD', features: { tense: 'fut' } },
  would: { pos: 'MD', features: { tense: 'cond' } },
  can: { pos: 'MD', features: { ability: 'yes' } },
  could: { pos: 'MD', features: { ability: 'yes', tense: 'past' } },
  should: { pos: 'MD', features: { obligation: 'yes' } },
  may: { pos: 'MD', features: { possibility: 'yes' } },
  might: { pos: 'MD', features: { possibility: 'yes', confidence: 'low' } },
  and: { pos: 'CC', features: { type: 'coord' } },
  but: { pos: 'CC', features: { type: 'coord', contrast: 'yes' } },
  or: { pos: 'CC', features: { type: 'coord', disjunct: 'yes' } },
  not: { pos: 'RB', features: { polarity: 'neg' } },
  no: { pos: 'DT', features: { polarity: 'neg' } },
  in: { pos: 'IN', features: { type: 'prep', spatial: 'yes' } },
  on: { pos: 'IN', features: { type: 'prep', spatial: 'yes', contact: 'yes' } },
  at: { pos: 'IN', features: { type: 'prep', locative: 'yes' } },
  to: { pos: 'IN', features: { type: 'prep', directional: 'yes' } },
  from: { pos: 'IN', features: { type: 'prep', source: 'yes' } },
  with: { pos: 'IN', features: { type: 'prep', comitative: 'yes' } },
  by: { pos: 'IN', features: { type: 'prep', agentive: 'yes' } },
  for: { pos: 'IN', features: { type: 'prep', benefactive: 'yes' } },
  of: { pos: 'IN', features: { type: 'prep', genitive: 'yes' } },
  about: { pos: 'IN', features: { type: 'prep', topic: 'yes' } },
  through: { pos: 'IN', features: { type: 'prep', path: 'yes' } },
  over: { pos: 'IN', features: { type: 'prep', spatial: 'yes', above: 'yes' } },
  under: { pos: 'IN', features: { type: 'prep', spatial: 'yes', below: 'yes' } },
  between: { pos: 'IN', features: { type: 'prep', spatial: 'yes', intermediary: 'yes' } },
  who: { pos: 'WP', features: { wh: 'yes', entity: 'person' } },
  what: { pos: 'WP', features: { wh: 'yes', entity: 'thing' } },
  where: { pos: 'WRB', features: { wh: 'yes', entity: 'place' } },
  when: { pos: 'WRB', features: { wh: 'yes', entity: 'time' } },
  why: { pos: 'WRB', features: { wh: 'yes', entity: 'reason' } },
  how: { pos: 'WRB', features: { wh: 'yes', entity: 'manner' } },
  because: { pos: 'IN', features: { type: 'subord', causal: 'yes' } },
  although: { pos: 'IN', features: { type: 'subord', concessive: 'yes' } },
  while: { pos: 'IN', features: { type: 'subord', temporal: 'yes' } },
  if: { pos: 'IN', features: { type: 'subord', conditional: 'yes' } },
  unless: { pos: 'IN', features: { type: 'subord', conditional: 'yes', neg: 'yes' } },
  since: { pos: 'IN', features: { type: 'subord', temporal: 'yes', causal: 'yes' } },
  very: { pos: 'RB', features: { degree: 'intensifier' } },
  quite: { pos: 'RB', features: { degree: 'moderate' } },
  too: { pos: 'RB', features: { degree: 'excessive' } },
  so: { pos: 'RB', features: { degree: 'result' } },
  more: { pos: 'RBR', features: { degree: 'comparative' } },
  most: { pos: 'RBS', features: { degree: 'superlative' } },
  less: { pos: 'RBR', features: { degree: 'comparative', neg: 'yes' } },
  least: { pos: 'RBS', features: { degree: 'superlative', neg: 'yes' } },
};

// Morphological patterns
const MORPH_PATTERNS = [
  { pattern: /ing$/, pos: 'VBG', features: { aspect: 'prog' } as Record<string, string> },
  { pattern: /ed$/, pos: 'VBD', features: { tense: 'past' } as Record<string, string> },
  { pattern: /(s|es|ies)$/, pos: 'VBZ', features: { tense: 'pres', number: '3sg' } as Record<string, string> },
  { pattern: /ly$/, pos: 'RB', features: { type: 'manner' } as Record<string, string> },
  { pattern: /(ful|ous|ive|able|ible|al|ic|ish|less)$/, pos: 'JJ', features: { type: 'descriptive' } as Record<string, string> },
  { pattern: /(tion|ment|ness|ity|er|or|ism|hood|ship)$/, pos: 'NN', features: { derived: 'yes' } as Record<string, string> },
];

// Common verbs
const VERBS = new Set([
  'run', 'walk', 'go', 'come', 'see', 'take', 'make', 'get', 'know', 'think',
  'say', 'tell', 'give', 'find', 'feel', 'become', 'leave', 'put', 'mean',
  'keep', 'let', 'begin', 'seem', 'help', 'turn', 'start', 'hear', 'play',
  'move', 'live', 'believe', 'bring', 'happen', 'write', 'stand', 'lose',
  'pay', 'meet', 'include', 'continue', 'set', 'learn', 'change', 'lead',
  'understand', 'watch', 'follow', 'stop', 'create', 'speak', 'read', 'spend',
  'grow', 'open', 'offer', 'remember', 'love', 'consider', 'appear', 'buy',
  'wait', 'serve', 'die', 'send', 'expect', 'build', 'stay', 'fall', 'cut',
  'reach', 'kill', 'remain', 'want', 'like', 'need', 'use', 'work', 'try',
  'call', 'ask', 'show', 'look', 'hit', 'chase', 'jump', 'fly', 'swim',
  'drive', 'eat', 'drink', 'sleep', 'run', 'sing', 'dance', 'fight',
  'build', 'destroy', 'discover', 'explain', 'analyze', 'process', 'transform',
  'generate', 'create', 'design', 'develop', 'implement', 'parse', 'infer',
  'simulate', 'learn', 'recognize', 'classify', 'optimize', 'execute',
]);

const NOUNS = new Set([
  'dog', 'cat', 'man', 'woman', 'child', 'person', 'people', 'world', 'time',
  'year', 'way', 'day', 'thing', 'man', 'government', 'company', 'hand', 'part',
  'place', 'case', 'week', 'system', 'program', 'question', 'work', 'number',
  'group', 'problem', 'fact', 'right', 'story', 'idea', 'water', 'room', 'mother',
  'area', 'money', 'story', 'month', 'lot', 'book', 'eye', 'job', 'word',
  'business', 'issue', 'side', 'kind', 'head', 'house', 'service', 'friend',
  'father', 'power', 'hour', 'game', 'line', 'end', 'member', 'law', 'car',
  'city', 'community', 'name', 'president', 'team', 'minute', 'information',
  'body', 'back', 'parent', 'face', 'others', 'level', 'office', 'door',
  'health', 'person', 'art', 'war', 'history', 'party', 'result', 'change',
  'morning', 'reason', 'research', 'girl', 'guy', 'moment', 'air', 'teacher',
  'force', 'education', 'ball', 'tree', 'computer', 'code', 'function',
  'class', 'object', 'method', 'variable', 'program', 'system', 'data',
  'algorithm', 'pattern', 'network', 'graph', 'rule', 'event', 'state',
  'agent', 'action', 'node', 'edge', 'query', 'result', 'process',
]);

// ── TOKENIZER ───────────────────────────────────────────────
export function tokenize(text: string): Token[] {
  const tokens: Token[] = [];
  const regex = /\b[\w']+\b|[.,!?;:"()\[\]{}]|[+\-*/=<>!&|]+|\S/g;
  let match: RegExpExecArray | null;

  while ((match = regex.exec(text)) !== null) {
    const word = match[0];
    const start = match.index;
    const end = start + word.length;

    // Skip pure whitespace
    if (/^\s+$/.test(word)) continue;

    // Punctuation
    if (/^[.,!?;:"()\[\]{}]$/.test(word)) {
      tokens.push({ text: word, pos: word === '.' || word === '!' || word === '?' ? 'PUNC_SENT' : 'PUNC', start, end, features: {} });
      continue;
    }

    const lower = word.toLowerCase();

    // Lexicon lookup
    if (LEXICON[lower]) {
      const entry = LEXICON[lower];
      tokens.push({ text: word, pos: entry.pos, start, end, features: { ...entry.features } });
      continue;
    }

    // Morphological patterns
    let found = false;
    for (const mp of MORPH_PATTERNS) {
      if (mp.pattern.test(lower)) {
        tokens.push({ text: word, pos: mp.pos, start, end, features: { ...mp.features } });
        found = true;
        break;
      }
    }
    if (found) continue;

    // Known verbs
    if (VERBS.has(lower)) {
      tokens.push({ text: word, pos: 'VB', start, end, features: { lemma: lower } });
      continue;
    }

    // Known nouns
    if (NOUNS.has(lower)) {
      tokens.push({ text: word, pos: 'NN', start, end, features: {} });
      continue;
    }

    // Numbers
    if (/^\d+(\.\d+)?$/.test(word)) {
      tokens.push({ text: word, pos: 'CD', start, end, features: { type: 'number' } });
      continue;
    }

    // Capitalized = proper noun
    if (/^[A-Z][a-z]+$/.test(word)) {
      tokens.push({ text: word, pos: 'NNP', start, end, features: { proper: 'yes' } });
      continue;
    }

    // Default: guess noun
    tokens.push({ text: word, pos: 'NN', start, end, features: { inferred: 'yes' } });
  }

  return tokens;
}

// ── PHRASE STRUCTURE ────────────────────────────────────────
export function parsePhrases(tokens: Token[]): Array<{ type: string; start: number; end: number; tokens: Token[] }> {
  const phrases: Array<{ type: string; start: number; end: number; tokens: Token[] }> = [];
  let i = 0;

  while (i < tokens.length) {
    // NP: DET (ADJ)* N
    if (/^(DET|PRP\$|CD)$/.test(tokens[i].pos)) {
      const start = i;
      i++;
      while (i < tokens.length && tokens[i].pos === 'JJ') i++;
      if (i < tokens.length && /^N/.test(tokens[i].pos)) {
        i++;
        phrases.push({ type: 'NP', start, end: i, tokens: tokens.slice(start, i) });
        continue;
      }
      i = start + 1;
      continue;
    }

    // NP: N+ (compound)
    if (/^N/.test(tokens[i].pos)) {
      const start = i;
      i++;
      while (i < tokens.length && /^N/.test(tokens[i].pos)) i++;
      phrases.push({ type: 'NP', start, end: i, tokens: tokens.slice(start, i) });
      continue;
    }

    // VP: V+ (ADV)*
    if (/^V/.test(tokens[i].pos) || tokens[i].pos === 'MD') {
      const start = i;
      i++;
      while (i < tokens.length && (/^V/.test(tokens[i].pos) || tokens[i].pos === 'RB' || tokens[i].pos === 'RP')) i++;
      phrases.push({ type: 'VP', start, end: i, tokens: tokens.slice(start, i) });
      continue;
    }

    // PP: PREP NP
    if (tokens[i].pos === 'IN') {
      const start = i;
      i++;
      if (i < tokens.length && (/^N/.test(tokens[i].pos) || /^(DET|PRP|CD)$/.test(tokens[i].pos))) {
        while (i < tokens.length && !/^V/.test(tokens[i].pos) && tokens[i].pos !== 'PUNC_SENT' && tokens[i].pos !== 'CC') i++;
        phrases.push({ type: 'PP', start, end: i, tokens: tokens.slice(start, i) });
        continue;
      }
      phrases.push({ type: 'PP', start, end: start + 1, tokens: [tokens[start]] });
      continue;
    }

    i++;
  }

  return phrases;
}

// ── DEPENDENCY PARSER ──────────────────────────────────────
export function parseDependencies(tokens: Token[]): DepLink[] {
  const deps: DepLink[] = [];
  const n = tokens.length;
  if (n === 0) return deps;

  // Find root (first finite verb, or copula, or main verb)
  let root = -1;
  for (let i = 0; i < n; i++) {
    if (/^(VB|VBD|VBP|VBZ)$/.test(tokens[i].pos) && !/^(be|have|do)$/.test(tokens[i].features.lemma || '')) {
      root = i;
      break;
    }
  }
  if (root === -1) {
    for (let i = 0; i < n; i++) {
      if (/^V/.test(tokens[i].pos)) { root = i; break; }
    }
  }
  if (root === -1) root = 0;

  // Find subject (nominal before root)
  let subject = -1;
  for (let i = 0; i < root; i++) {
    if (/^(NN|NNS|NNP|NNPS|PRP)$/.test(tokens[i].pos)) {
      subject = i;
    }
  }
  if (subject >= 0) {
    deps.push({ governor: root, dependent: subject, relation: 'nsubj' });
  }

  // Find object (nominal after root)
  let object = -1;
  for (let i = root + 1; i < n; i++) {
    if (/^(NN|NNS|NNP|NNPS|PRP)$/.test(tokens[i].pos)) {
      object = i;
      break;
    }
  }
  if (object >= 0) {
    deps.push({ governor: root, dependent: object, relation: 'dobj' });
  }

  // Find prepositional modifiers
  for (let i = 0; i < n; i++) {
    if (tokens[i].pos === 'IN') {
      // Attach to nearest noun or verb
      let gov = root;
      for (let j = i - 1; j >= 0; j--) {
        if (/^(NN|NNS|NNP|VB|VBD)$/.test(tokens[j].pos)) { gov = j; break; }
      }
      deps.push({ governor: gov, dependent: i, relation: 'nmod' });

      // Attach prepositional object
      if (i + 1 < n && /^(NN|NNS|NNP|PRP)$/.test(tokens[i + 1].pos)) {
        deps.push({ governor: i, dependent: i + 1, relation: 'pobj' });
      }
    }
  }

  // Adjectives modify nearest noun
  for (let i = 0; i < n; i++) {
    if (tokens[i].pos === 'JJ' && i + 1 < n && /^N/.test(tokens[i + 1].pos)) {
      deps.push({ governor: i + 1, dependent: i, relation: 'amod' });
    }
  }

  // Determiners modify nouns
  for (let i = 0; i < n; i++) {
    if (/^DT/.test(tokens[i].pos) && i + 1 < n && /^N/.test(tokens[i + 1].pos)) {
      deps.push({ governor: i + 1, dependent: i, relation: 'det' });
    }
  }

  // Auxiliaries
  for (let i = 0; i < n; i++) {
    if (/^(MD|VBZ|VBP|VBD)$/.test(tokens[i].pos) && /^(be|have|do)$/.test(tokens[i].features.lemma || '')) {
      deps.push({ governor: root, dependent: i, relation: 'aux' });
    }
  }

  return deps;
}

// ── ENTITY EXTRACTION ──────────────────────────────────────
export function extractEntities(tokens: Token[]): Array<{ text: string; type: string; start: number; end: number }> {
  const entities: Array<{ text: string; type: string; start: number; end: number }> = [];
  let i = 0;

  while (i < tokens.length) {
    // Proper noun sequences
    if (tokens[i].pos === 'NNP') {
      const start = i;
      let text = tokens[i].text;
      i++;
      while (i < tokens.length && tokens[i].pos === 'NNP') {
        text += ' ' + tokens[i].text;
        i++;
      }
      entities.push({ text, type: 'PERSON_ORG', start, end: i });
      continue;
    }

    // Pronouns as entity references
    if (tokens[i].pos === 'PRP') {
      entities.push({ text: tokens[i].text, type: 'PRONOUN', start: i, end: i + 1 });
    }

    i++;
  }

  return entities;
}

// ── FULL PARSE ──────────────────────────────────────────────
export function parse(text: string): ParseTree {
  const tokens = tokenize(text);
  const dependencies = parseDependencies(tokens);
  const entities = extractEntities(tokens);

  // Find root
  let root = 0;
  const rootDep = dependencies.find(d => d.relation === 'root');
  if (rootDep) root = rootDep.governor;

  return { tokens, dependencies, root, entities };
}

// ── CODE PARSING ────────────────────────────────────────────
export function parseCode(code: string): ParseTree {
  const tokens: Token[] = [];
  const codeTokens = code.match(/\b\w+\b|[{}();,=+\-*/<>!&|:]+|"[^"]*"|'[^']*'|`[^`]*`|\S/g) || [];

  const CODE_KEYWORDS: Record<string, string> = {
    function: 'KEYWORD', const: 'KEYWORD', let: 'KEYWORD', var: 'KEYWORD',
    class: 'KEYWORD', if: 'KEYWORD', else: 'KEYWORD', for: 'KEYWORD',
    while: 'KEYWORD', return: 'KEYWORD', import: 'KEYWORD', export: 'KEYWORD',
    from: 'KEYWORD', async: 'KEYWORD', await: 'KEYWORD', try: 'KEYWORD',
    catch: 'KEYWORD', finally: 'KEYWORD', throw: 'KEYWORD', new: 'KEYWORD',
    this: 'KEYWORD', static: 'KEYWORD', extends: 'KEYWORD', super: 'KEYWORD',
    true: 'LITERAL', false: 'LITERAL', null: 'LITERAL', undefined: 'KEYWORD',
    string: 'TYPE', number: 'TYPE', boolean: 'TYPE', void: 'TYPE', any: 'TYPE',
  };

  codeTokens.forEach((tok, i) => {
    const lower = tok.toLowerCase();
    if (CODE_KEYWORDS[lower]) {
      tokens.push({ text: tok, pos: CODE_KEYWORDS[lower], start: i, end: i + 1, features: {} });
    } else if (/^"|'|`/.test(tok)) {
      tokens.push({ text: tok, pos: 'LITERAL', start: i, end: i + 1, features: { type: 'string' } });
    } else if (/^\d/.test(tok)) {
      tokens.push({ text: tok, pos: 'LITERAL', start: i, end: i + 1, features: { type: 'number' } });
    } else if (/^[{}();,=+\-*/<>!&|:]+$/.test(tok)) {
      tokens.push({ text: tok, pos: 'OPERATOR', start: i, end: i + 1, features: {} });
    } else {
      tokens.push({ text: tok, pos: 'IDENT', start: i, end: i + 1, features: {} });
    }
  });

  // Simple dependency: keywords govern nearby identifiers
  const deps: DepLink[] = [];
  for (let i = 0; i < tokens.length; i++) {
    if (tokens[i].pos === 'KEYWORD' && tokens[i].text === 'function' && i + 1 < tokens.length) {
      deps.push({ governor: i, dependent: i + 1, relation: 'defines' });
    }
    if (tokens[i].pos === 'KEYWORD' && /^(const|let|var)$/.test(tokens[i].text) && i + 1 < tokens.length) {
      deps.push({ governor: i, dependent: i + 1, relation: 'declares' });
    }
  }

  return { tokens, dependencies: deps, root: 0, entities: [] };
}
