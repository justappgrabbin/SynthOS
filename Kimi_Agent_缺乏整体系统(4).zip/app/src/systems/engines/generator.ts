// ═══════════════════════════════════════════════════════════════
//  GENERATOR ENGINE
//  Discourse planner → grammar templates → surface text.
//  Not random text. Structured generation from semantic plans.
// ═══════════════════════════════════════════════════════════════

import type { DiscoursePlan, PlanStep, ParseTree } from '@/types';

export class GeneratorEngine {
  // Generate from a discourse plan
  generate(plan: DiscoursePlan): string {
    const segments: string[] = [];

    for (const step of plan.steps) {
      const text = this.realizeStep(step);
      segments.push(text);
    }

    return segments.join('\n\n');
  }

  private realizeStep(step: PlanStep): string {
    const templates: Record<string, string[]> = {
      state: [
        '{content}',
        'The {content} stretched before them.',
        'It was a time when {content}.',
      ],
      event: [
        '{content}',
        'Then, {content}.',
        'Suddenly, {content}.',
        'Without warning, {content}.',
      ],
      quote: [
        '"{content}," said {agent}.',
        '{agent} spoke: "{content}."',
        '"{content}," {agent} replied.',
      ],
      action: [
        '{agent} {content}.',
        '{agent} began to {content}.',
        'With determination, {agent} {content}.',
      ],
      reveal: [
        'The truth was revealed: {content}.',
        'It became clear that {content}.',
        'At last, {content}.',
      ],
    };

    const stepTemplates = templates[step.type] || templates.state;
    const template = stepTemplates[Math.floor(Math.random() * stepTemplates.length)];

    return template
      .replace('{content}', step.content)
      .replace('{agent}', step.agents[0] || 'someone')
      .replace('{mood}', step.mood);
  }

  // Build a discourse plan from parsed input
  planFromParse(parseTree: ParseTree, intent: string): DiscoursePlan {
    const steps: PlanStep[] = [];
    const tokens = parseTree.tokens;
    const entities = parseTree.entities;

    // Extract key content words
    const nouns = tokens.filter(t => /^NN/.test(t.pos)).map(t => t.text);
    const verbs = tokens.filter(t => /^V/.test(t.pos)).map(t => t.text);

    const mainAgent = entities[0]?.text || nouns[0] || 'the protagonist';

    // Build plan based on intent
    switch (intent) {
      case 'generate-story':
      case 'generate-game':
        steps.push({ type: 'state', content: `world of ${nouns.slice(0, 3).join(' and ')}`, agents: [mainAgent], mood: 'ominous' });
        steps.push({ type: 'event', content: `${verbs[0] || 'something happened'}`, agents: [mainAgent], mood: 'tense' });
        if (verbs.length > 1) {
          steps.push({ type: 'action', content: `${verbs[1]} forward`, agents: [mainAgent], mood: 'determined' });
        }
        steps.push({ type: 'reveal', content: `nothing would ever be the same`, agents: [mainAgent], mood: 'dramatic' });
        break;

      case 'generate-code':
        steps.push({ type: 'state', content: `function accepting ${nouns.slice(0, 2).join(', ')}`, agents: ['developer'], mood: 'technical' });
        steps.push({ type: 'action', content: `process the input through transformation pipeline`, agents: ['system'], mood: 'precise' });
        steps.push({ type: 'reveal', content: `the output emerges, validated and structured`, agents: ['system'], mood: 'satisfying' });
        break;

      case 'generate-script':
        steps.push({ type: 'state', content: `dimly lit scene`, agents: [mainAgent], mood: 'noir' });
        steps.push({ type: 'quote', content: `We need to talk about ${nouns[0] || 'this'}`, agents: [mainAgent], mood: 'tense' });
        steps.push({ type: 'event', content: `${verbs[0] || 'tension escalates'}`, agents: [mainAgent], mood: 'dramatic' });
        break;

      default:
        steps.push({ type: 'state', content: tokens.map(t => t.text).slice(0, 8).join(' '), agents: [mainAgent], mood: 'neutral' });
        if (verbs.length > 0) {
          steps.push({ type: 'action', content: verbs.join(', '), agents: [mainAgent], mood: 'active' });
        }
    }

    return { intent, topic: nouns[0] || 'general', steps };
  }

  // Generate code from semantic specification
  generateCode(spec: { type: string; inputs: string[]; operations: string[]; outputs: string[] }): string {
    const lines: string[] = [];

    // Function signature
    const funcName = spec.type.replace(/\s+/g, '_');
    const params = spec.inputs.map((inp, i) => `${inp.toLowerCase().replace(/\s+/g, '')}_${i}`).join(', ');
    lines.push(`function ${funcName}(${params}) {`);

    // Processing steps
    for (const op of spec.operations) {
      const opName = op.toLowerCase().replace(/\s+/g, '_');
      lines.push(`  const ${opName}_result = ${opName}(input);`);
    }

    // Return
    if (spec.outputs.length > 0) {
      lines.push(`  return { ${spec.outputs.map(o => o.toLowerCase().replace(/\s+/g, '_')).join(', ')} };`);
    }

    lines.push('}');
    return lines.join('\n');
  }

  // Surface realizer: convert structured content to natural text
  realize(text: string, style: 'narrative' | 'technical' | 'dialogue' = 'narrative'): string {
    switch (style) {
      case 'technical':
        return text
          .replace(/\bThe\b/g, 'the')
          .replace(/\bsuddenly\b/gi, 'subsequently')
          .replace(/\bthen\b/gi, 'thereafter')
          + '.';
      case 'dialogue':
        return `"${text.charAt(0).toUpperCase() + text.slice(1)}."`;
      default:
        return text.charAt(0).toUpperCase() + text.slice(1) + '.';
    }
  }
}

export const generator = new GeneratorEngine();
