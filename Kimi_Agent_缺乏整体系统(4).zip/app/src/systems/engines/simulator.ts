// ═══════════════════════════════════════════════════════════════
//  SIMULATOR ENGINE (Klein, 1966)
//  Monte Carlo simulation of world states, agents, events.
//  Generates narratives through simulation, not random text.
// ═══════════════════════════════════════════════════════════════

import type { WorldState, Agent, Fact } from '@/types';

export class SimulatorEngine {
  private state: WorldState;
  private rng: () => number;

  constructor(seed = 42) {
    let s = seed;
    this.rng = () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; };
    this.state = this.createInitialState();
  }

  private createInitialState(): WorldState {
    return {
      tick: 0,
      agents: [],
      events: [],
      facts: [],
      timeline: [],
    };
  }

  // Create a world from user input
  setupWorld(description: string): string {
    // Parse description for entities and relationships
    const entities = this.extractEntities(description);

    // Create agents
    for (const entity of entities.filter(e => e.type === 'person')) {
      const agent: Agent = {
        id: `agent_${this.state.agents.length}`,
        name: entity.name,
        traits: {
          courage: this.rng(),
          intelligence: this.rng(),
          aggression: this.rng(),
          curiosity: this.rng(),
          loyalty: this.rng(),
        },
        goals: this.generateGoals(entity.name),
        beliefs: [],
        location: 'unknown',
      };
      this.state.agents.push(agent);
    }

    // Create initial facts
    for (const entity of entities) {
      if (entity.relations.length > 0) {
        for (const rel of entity.relations) {
          const fact: Fact = {
            id: `fact_${this.state.facts.length}`,
            subject: entity.name,
            predicate: rel.type,
            object: rel.target,
            confidence: 0.8,
            source: 'user',
          };
          this.state.facts.push(fact);
        }
      }
    }

    // Set locations from description
    const locationWords = description.match(/\b(in|at|on)\s+(\w+)/gi) || [];
    for (const loc of locationWords) {
      const place = loc.replace(/^\w+\s+/, '');
      for (const agent of this.state.agents) {
        if (description.includes(agent.name) && description.includes(place)) {
          agent.location = place;
        }
      }
    }

    return `World created: ${this.state.agents.length} agents, ${this.state.facts.length} facts.`;
  }

  private extractEntities(text: string): Array<{ name: string; type: string; relations: Array<{ type: string; target: string }> }> {
    const entities: Array<{ name: string; type: string; relations: Array<{ type: string; target: string }> }> = [];
    const capitalized = text.match(/\b[A-Z][a-z]+\b/g) || [];
    const unique = [...new Set(capitalized)];

    for (const name of unique) {
      const type = /(man|woman|person|detective|inspector|doctor|professor|lady|lord|captain)/i.test(text.slice(text.indexOf(name) - 20, text.indexOf(name) + 30)) ? 'person' : 'place';
      const relations: Array<{ type: string; target: string }> = [];

      // Find relations: "X killed Y", "X found Y"
      const context = text.slice(Math.max(0, text.indexOf(name) - 50), text.indexOf(name) + 50);
      const actionMatch = context.match(/\b(killed|found|saw|chased|loved|hated|stole|discovered|met)\s+([A-Z][a-z]+)/i);
      if (actionMatch) {
        relations.push({ type: actionMatch[1].toLowerCase(), target: actionMatch[2] });
      }

      entities.push({ name, type, relations });
    }

    return entities;
  }

  private generateGoals(_name: string): string[] {
    const goals = [
      ['find the truth', 'solve the mystery', 'protect someone', 'seek revenge'],
      ['discover a secret', 'escape danger', 'gain power', 'find love'],
      ['survive', 'uncover conspiracy', 'redeem past', 'build something'],
    ];
    return goals[Math.floor(this.rng() * goals.length)];
  }

  // Run simulation steps
  simulate(ticks = 5): string {
    const outputs: string[] = [];

    for (let t = 0; t < ticks; t++) {
      this.state.tick++;
      const tickEvents: string[] = [];

      // Each agent takes action based on traits + goals
      for (const agent of this.state.agents) {
        // Determine possible actions
        const actions = this.determineActions(agent);
        if (actions.length === 0) continue;

        // Select action based on trait probabilities (Monte Carlo)
        const action = this.selectAction(agent, actions);

        // Execute action
        const result = this.executeAction(agent, action);
        tickEvents.push(result);

        // Update beliefs
        const fact: Fact = {
          id: `fact_${this.state.facts.length}`,
          subject: agent.name,
          predicate: action.type,
          object: action.target || '',
          confidence: 0.7 + this.rng() * 0.3,
          source: 'simulated',
        };
        this.state.facts.push(fact);
        agent.beliefs.push(fact);

        // Add to timeline
        this.state.timeline.push({
          tick: this.state.tick,
          event: action.type,
          agents: [agent.name],
          description: result,
        });
      }

      // Inter-agent interactions
      if (this.state.agents.length >= 2) {
        for (let i = 0; i < this.state.agents.length; i++) {
          for (let j = i + 1; j < this.state.agents.length; j++) {
            if (this.rng() < 0.3) {
              const interaction = this.simulateInteraction(this.state.agents[i], this.state.agents[j]);
              tickEvents.push(interaction);
            }
          }
        }
      }

      outputs.push(`Tick ${this.state.tick}:\n${tickEvents.map(e => '  ' + e).join('\n')}`);
    }

    return outputs.join('\n\n');
  }

  private determineActions(agent: Agent): Array<{ type: string; target?: string; probability: number }> {
    const actions: Array<{ type: string; target?: string; probability: number }> = [];

    // Move
    actions.push({ type: 'moves', probability: 0.2 });

    // Investigate (high curiosity)
    if (agent.traits.curiosity > 0.5) {
      actions.push({ type: 'investigates', probability: agent.traits.curiosity });
    }

    // Confront (high aggression)
    if (agent.traits.aggression > 0.5) {
      const target = this.state.agents.find(a => a.id !== agent.id);
      if (target) actions.push({ type: 'confronts', target: target.name, probability: agent.traits.aggression * 0.5 });
    }

    // Discover (high intelligence)
    if (agent.traits.intelligence > 0.6) {
      actions.push({ type: 'discovers a clue', probability: agent.traits.intelligence * 0.4 });
    }

    // Help (high loyalty)
    if (agent.traits.loyalty > 0.6) {
      actions.push({ type: 'helps an ally', probability: agent.traits.loyalty * 0.3 });
    }

    // Secret action (random)
    if (this.rng() < 0.2) {
      actions.push({ type: 'acts secretly', probability: 0.3 });
    }

    return actions;
  }

  private selectAction(_agent: Agent, actions: Array<{ type: string; target?: string; probability: number }>): { type: string; target?: string } {
    const totalProb = actions.reduce((s, a) => s + a.probability, 0);
    let roll = this.rng() * totalProb;

    for (const action of actions) {
      roll -= action.probability;
      if (roll <= 0) return { type: action.type, target: action.target };
    }

    return { type: actions[0]?.type || 'waits' };
  }

  private executeAction(agent: Agent, action: { type: string; target?: string }): string {
    const locations = ['the study', 'the garden', 'the hallway', 'the library', 'the cellar', 'the tower'];

    switch (action.type) {
      case 'moves':
        agent.location = locations[Math.floor(this.rng() * locations.length)];
        return `${agent.name} moves to ${agent.location}.`;
      case 'investigates':
        return `${agent.name} investigates, searching for clues.`;
      case 'confronts':
        return `${agent.name} confronts ${action.target || 'someone'} aggressively.`;
      case 'discovers a clue':
        const clues = ['a hidden letter', 'a bloodstain', 'a torn photograph', 'a strange noise', 'a missing key'];
        return `${agent.name} discovers ${clues[Math.floor(this.rng() * clues.length)]}.`;
      case 'helps an ally':
        return `${agent.name} helps an ally, strengthening their position.`;
      case 'acts secretly':
        return `${agent.name} acts in secret, their true motives unclear.`;
      default:
        return `${agent.name} ${action.type}${action.target ? ' ' + action.target : ''}.`;
    }
  }

  private simulateInteraction(a: Agent, b: Agent): string {
    const trust = (a.traits.loyalty + b.traits.loyalty) / 2;
    const tension = (a.traits.aggression + b.traits.aggression) / 2;

    if (tension > 0.7 && this.rng() < tension) {
      return `${a.name} and ${b.name} clash! Tension escalates.`;
    }
    if (trust > 0.6 && this.rng() < trust) {
      return `${a.name} and ${b.name} form an alliance.`;
    }
    if (a.traits.curiosity > 0.5 && b.traits.intelligence > 0.5) {
      return `${a.name} questions ${b.name}, seeking information.`;
    }
    return `${a.name} and ${b.name} exchange cautious glances.`;
  }

  // Generate narrative from simulation
  generateNarrative(): string {
    const entries = this.state.timeline;
    if (entries.length === 0) return 'No events to narrate.';

    const lines: string[] = [];
    let currentTick = -1;

    for (const entry of entries) {
      if (entry.tick !== currentTick) {
        currentTick = entry.tick;
        lines.push(`\n--- Tick ${currentTick} ---`);
      }
      lines.push(entry.description);
    }

    // Add dramatic summary
    lines.push(`\n=== SUMMARY ===`);
    lines.push(`Agents: ${this.state.agents.map(a => a.name).join(', ')}`);
    lines.push(`Total events: ${entries.length}`);
    lines.push(`Key facts learned: ${this.state.facts.filter(f => f.source === 'simulated').length}`);

    const keyEvent = entries.find(e => e.event === 'discovers a clue');
    if (keyEvent) {
      lines.push(`\nThe turning point: ${keyEvent.description}`);
    }

    return lines.join('\n');
  }

  getState(): WorldState {
    return this.state;
  }

  reset() {
    this.state = this.createInitialState();
  }
}

export const simulator = new SimulatorEngine();
