// ═══════════════════════════════════════════════════════════════
//  DISEMINER ENGINE (Klein, 1968)
//  Graph-based semantic inference + distributional similarity + analogy.
//  Queries the semantic graph. Infers missing edges. Finds analogies.
// ═══════════════════════════════════════════════════════════════

import { graphStore } from '@/systems/memory/graphStore';
import type { SGNode } from '@/types';

interface InferenceResult {
  query: string;
  answer: string;
  confidence: number;
  evidence: Array<{ type: string; detail: string; confidence: number }>;
  inferenceChain: string[];
}

export class DiseminerEngine {
  // Main entry: answer a question using the semantic graph
  answer(question: string): InferenceResult {
    const evidence: Array<{ type: string; detail: string; confidence: number }> = [];
    const chain: string[] = [];

    // Parse the question
    const words = question.toLowerCase().match(/\b[a-z]+\b/g) || [];

    // Extract potential subject-predicate
    const subject = words.find(w => graphStore.findNode(w)) || words[0];
    const predicate = words.find(w => ['is', 'are', 'was', 'were', 'means', 'does', 'has', 'causes'].includes(w));
    const object = words[words.length - 1];

    chain.push(`Parse: subject="${subject}", predicate="${predicate || '?'}", object="${object}"`);

    // Strategy 1: Direct lookup in graph
    const subjectNode = graphStore.findNode(subject || '');
    if (subjectNode) {
      evidence.push({ type: 'entity_found', detail: `Found "${subject}" in graph (${subjectNode.type})`, confidence: 0.9 });
      chain.push(`Entity "${subject}" exists in graph`);

      const directEdges = graphStore.getEdgesFrom(subjectNode.id);
      if (directEdges.length > 0) {
        const topEdges = directEdges.sort((a, b) => b.weight - a.weight).slice(0, 3);
        for (const e of topEdges) {
          const target = graphStore.getNode(e.to);
          if (target) {
            evidence.push({ type: 'direct_relation', detail: `${subject} --${e.relation}→ ${target.label}`, confidence: e.confidence });
            chain.push(`Direct: ${subject} ${e.relation} ${target.label}`);
          }
        }
      }

      // Strategy 2: Path-based inference
      const neighbors = graphStore.neighbors(subjectNode.id, 2);
      if (neighbors.length > 0) {
        chain.push(`Found ${neighbors.length} neighbors at depth 2`);
        for (const n of neighbors.slice(0, 3)) {
          evidence.push({
            type: 'path_inference',
            detail: `${subject} → ... → ${n.node.label} via ${n.path.map(p => p.relation).join(' → ')}`,
            confidence: n.path.reduce((c, e) => c * e.confidence, 1.0) * 0.7,
          });
        }
      }

      // Strategy 3: Analogy
      const analogies = this.findAnalogies(subjectNode);
      for (const a of analogies.slice(0, 2)) {
        evidence.push({ type: 'analogy', detail: a.description, confidence: a.confidence });
        chain.push(`Analogy: ${a.description}`);
      }
    } else {
      // Unknown entity - try to classify from context
      evidence.push({ type: 'unknown_entity', detail: `"${subject}" not in graph. Classifying from context.`, confidence: 0.3 });
      chain.push(`Entity "${subject}" unknown. Context classification.`);

      // Infer type from surrounding words
      const typeGuess = this.inferTypeFromContext(words);
      if (typeGuess) {
        evidence.push({ type: 'type_inference', detail: `Inferred type: ${typeGuess.type}`, confidence: typeGuess.confidence });
        chain.push(`Inferred "${subject}" is a ${typeGuess.type}`);
      }
    }

    // Build answer from best evidence
    const bestEvidence = evidence.sort((a, b) => b.confidence - a.confidence);
    const answer = this.synthesizeAnswer(subject || '', predicate || 'is', object || '', bestEvidence, chain);

    const overallConfidence = evidence.length > 0
      ? evidence.reduce((s, e) => s + e.confidence, 0) / evidence.length
      : 0.3;

    return { query: question, answer, confidence: overallConfidence, evidence: bestEvidence, inferenceChain: chain };
  }

  private findAnalogies(node: SGNode): Array<{ description: string; confidence: number }> {
    const results: Array<{ description: string; confidence: number }> = [];

    // Find nodes that share neighbors
    const myEdges = graphStore.getEdgesFrom(node.id);
    const myTargets = new Set(myEdges.map(e => e.to));

    for (const [otherId, otherNode] of graphStore['nodes'] as Map<string, SGNode>) {
      if (otherId === node.id) continue;

      const otherEdges = graphStore.getEdgesFrom(otherId);
      const sharedTargets = otherEdges.filter(e => myTargets.has(e.to));

      if (sharedTargets.length >= 2) {
        const sharedLabels = sharedTargets.map(e => {
          const t = graphStore.getNode(e.to);
          return t?.label || '?';
        });
        const conf = sharedTargets.reduce((s, e) => s + e.confidence, 0) / sharedTargets.length;
        results.push({
          description: `${node.label} ~ ${otherNode.label} (both relate to: ${sharedLabels.join(', ')})`,
          confidence: conf * 0.8,
        });
      }
    }

    return results.sort((a, b) => b.confidence - a.confidence);
  }

  private inferTypeFromContext(words: string[]): { type: string; confidence: number } | null {
    const typeIndicators: Record<string, string[]> = {
      person: ['who', 'he', 'she', 'man', 'woman', 'person', 'named'],
      place: ['where', 'city', 'town', 'country', 'location', 'in', 'at'],
      action: ['what', 'did', 'does', 'doing', 'verb', 'action'],
      object: ['what', 'thing', 'object', 'item', 'device'],
    };

    for (const [type, indicators] of Object.entries(typeIndicators)) {
      if (indicators.some(ind => words.includes(ind))) {
        return { type, confidence: 0.5 };
      }
    }
    return null;
  }

  private synthesizeAnswer(subject: string, _predicate: string, _object: string, evidence: Array<{ type: string; detail: string; confidence: number }>, _chain: string[]): string {
    if (evidence.length === 0) return `No semantic data for "${subject}". The graph needs more examples.`;

    const direct = evidence.filter(e => e.type === 'direct_relation');
    if (direct.length > 0) {
      const top = direct[0];
      return `${subject}: ${top.detail} (confidence: ${(top.confidence * 100).toFixed(0)}%)`;
    }

    const inferred = evidence.filter(e => e.type === 'path_inference');
    if (inferred.length > 0) {
      return `Inferred: ${inferred[0].detail}`;
    }

    const analogies = evidence.filter(e => e.type === 'analogy');
    if (analogies.length > 0) {
      return `By analogy: ${analogies[0].detail}`;
    }

    return `Known: ${evidence[0].detail}`;
  }

  // Distributional similarity: two words are similar if they share contexts
  distributionalSimilarity(a: string, b: string): number {
    return graphStore.similarity(a, b);
  }

  // Analogy solver: a is to b as c is to ?
  solveAnalogy(a: string, b: string, c: string): string | null {
    const nodeA = graphStore.findNode(a || '');
    const nodeB = graphStore.findNode(b || '');
    const nodeC = graphStore.findNode(c || '');
    if (!nodeA || !nodeB || !nodeC) return null;

    // Find the relation from A to B
    const aToB = graphStore.getEdgesFrom(nodeA.id);
    const relations = aToB.filter(e => e.to === nodeB.id).map(e => e.relation);

    // Apply same relations from C
    for (const rel of relations) {
      const cEdges = graphStore.getEdgesFrom(nodeC.id).filter(e => e.relation === rel);
      for (const edge of cEdges) {
        const target = graphStore.getNode(edge.to);
        if (target) return target.label;
      }
    }

    // Try: find what B has in common with A, find what C shares
    const bCommon = graphStore.getEdgesFrom(nodeB.id).map(e => e.relation);
    const cEdges = graphStore.getEdgesFrom(nodeC.id);
    for (const ce of cEdges) {
      if (bCommon.includes(ce.relation)) {
        const target = graphStore.getNode(ce.to);
        if (target) return target.label;
      }
    }

    return null;
  }
}

export const diseminer = new DiseminerEngine();
