// ═══════════════════════════════════════════════════════════════
//  AUTOLING ENGINE (Klein, 1968)
//  Interactive grammar fieldworker. Learns from examples,
//  tests hypotheses, asks questions, derives rules.
// ═══════════════════════════════════════════════════════════════

import { tokenize, parseDependencies } from './parser';
import { ruleStore } from '@/systems/memory/ruleStore';
import { graphStore } from '@/systems/memory/graphStore';
import type { Token, Rule } from '@/types';

interface LearnedPattern {
  pattern: string;
  category: 'morphology' | 'phrase-structure' | 'transformation';
  confidence: number;
  examples: string[];
  rule?: Rule;
}

interface Hypothesis {
  id: string;
  statement: string;
  evidence: number;
  status: 'open' | 'confirmed' | 'rejected';
}

export class AutolingEngine {
  private patterns: LearnedPattern[] = [];
  private hypotheses: Hypothesis[] = [];
  private sessionCount = 0;
  private totalInputs = 0;

  constructor() {
    this.seedPatterns();
  }

  private seedPatterns() {
    // Pre-loaded morphological knowledge
    this.patterns.push(
      { pattern: '-s plural marker', category: 'morphology', confidence: 0.95, examples: ['dogs', 'cats', 'houses'] },
      { pattern: '-ed past tense', category: 'morphology', confidence: 0.95, examples: ['walked', 'played', 'started'] },
      { pattern: '-ing progressive', category: 'morphology', confidence: 0.95, examples: ['running', 'walking', 'playing'] },
      { pattern: 'DET + N → NP', category: 'phrase-structure', confidence: 0.9, examples: ['the dog', 'a cat', 'an apple'] },
      { pattern: 'DET + ADJ + N → NP', category: 'phrase-structure', confidence: 0.85, examples: ['the big dog', 'a quick fox'] },
      { pattern: 'NP + VP → S', category: 'phrase-structure', confidence: 0.9, examples: ['The dog runs', 'A cat sleeps'] },
    );
  }

  // Process input: analyze, learn, ask questions
  process(input: string): {
    response: string;
    patterns: LearnedPattern[];
    newHypotheses: Hypothesis[];
    confidence: number;
  } {
    this.totalInputs++;
    const tokens = tokenize(input);
    const deps = parseDependencies(tokens);
    const newPatterns: LearnedPattern[] = [];
    const newHypotheses: Hypothesis[] = [];

    // 1. Learn morphology from unknown words
    const unknownWords = tokens.filter(t => t.features.inferred === 'yes');
    for (const word of unknownWords) {
      const morphPattern = this.inferMorphology(word);
      if (morphPattern) {
        const existing = this.patterns.find(p => p.pattern === morphPattern.pattern);
        if (existing) {
          existing.confidence = Math.min(1, existing.confidence + 0.05);
          if (!existing.examples.includes(word.text)) existing.examples.push(word.text);
        } else {
          this.patterns.push(morphPattern);
          newPatterns.push(morphPattern);
        }
      }
    }

    // 2. Learn phrase structure from parse
    const phrasePatterns = this.inferPhraseStructure(tokens);
    for (const pp of phrasePatterns) {
      const existing = this.patterns.find(p => p.pattern === pp.pattern);
      if (!existing) {
        this.patterns.push(pp);
        newPatterns.push(pp);
      } else {
        existing.confidence = Math.min(1, existing.confidence + 0.1);
      }
    }

    // 3. Learn transformation from rule store feedback
    const transformation = this.detectTransformation(tokens, deps);
    if (transformation) {
      const existing = this.patterns.find(p => p.pattern === transformation.pattern);
      if (!existing) {
        this.patterns.push(transformation);
        newPatterns.push(transformation);
      }
    }

    // 4. Generate hypotheses
    const hyps = this.generateHypotheses(tokens, deps);
    for (const h of hyps) {
      const existing = this.hypotheses.find(eh => eh.statement === h.statement);
      if (!existing) {
        this.hypotheses.push(h);
        newHypotheses.push(h);
      }
    }

    // 5. Build response
    const response = this.buildResponse(input, tokens, newPatterns, newHypotheses);
    const confidence = this.patterns.length > 0
      ? this.patterns.reduce((s, p) => s + p.confidence, 0) / this.patterns.length
      : 0;

    // Update graph store with learned concepts
    for (const tok of tokens) {
      if (/^N/.test(tok.pos)) {
        graphStore.findOrCreate(tok.text, 'concept', { pos: tok.pos });
      }
    }

    return { response, patterns: newPatterns, newHypotheses, confidence };
  }

  private inferMorphology(word: Token): LearnedPattern | null {
    const lower = word.text.toLowerCase();
    if (lower.endsWith('s') && lower.length > 3) {
      const stem = lower.slice(0, -1);
      return { pattern: `-${lower.slice(-1)} marker on ${stem}`, category: 'morphology', confidence: 0.5, examples: [word.text] };
    }
    if (lower.endsWith('ed') && lower.length > 4) {
      return { pattern: '-ed tense marker', category: 'morphology', confidence: 0.5, examples: [word.text] };
    }
    if (lower.endsWith('ing') && lower.length > 5) {
      return { pattern: '-ing aspect marker', category: 'morphology', confidence: 0.5, examples: [word.text] };
    }
    if (lower.endsWith('ly') && lower.length > 4) {
      return { pattern: '-ly adverbial marker', category: 'morphology', confidence: 0.5, examples: [word.text] };
    }
    return null;
  }

  private inferPhraseStructure(tokens: Token[]): LearnedPattern[] {
    const patterns: LearnedPattern[] = [];

    // Look for DET + ADJ* + N sequences
    for (let i = 0; i < tokens.length - 1; i++) {
      if (/^DT/.test(tokens[i].pos)) {
        let j = i + 1;
        while (j < tokens.length && tokens[j].pos === 'JJ') j++;
        if (j < tokens.length && /^NN/.test(tokens[j].pos)) {
          const phrase = tokens.slice(i, j + 1).map(t => t.text).join(' ');
          const hasAdj = j > i + 1;
          patterns.push({
            pattern: hasAdj ? 'DET + ADJ + N → NP' : 'DET + N → NP',
            category: 'phrase-structure',
            confidence: 0.6,
            examples: [phrase],
          });
        }
      }
    }

    // Look for NP + VP patterns (subject + verb)
    const verbIdx = tokens.findIndex(t => /^V/.test(t.pos));
    if (verbIdx > 0) {
      const before = tokens.slice(0, verbIdx).filter(t => /^NN/.test(t.pos) || t.pos === 'PRP');
      if (before.length > 0) {
        patterns.push({
          pattern: 'NP + VP → S',
          category: 'phrase-structure',
          confidence: 0.7,
          examples: [tokens.slice(0, verbIdx + 1).map(t => t.text).join(' ')],
        });
      }
    }

    return patterns;
  }

  private detectTransformation(tokens: Token[], _deps: ReturnType<typeof parseDependencies>): LearnedPattern | null {
    // Check for passive voice structure: be + VBN
    const beIdx = tokens.findIndex(t => /^(VBZ|VBD|VBP)$/.test(t.pos) && /^(be|is|was|are|were)$/.test(t.features.lemma || ''));
    const vbnIdx = tokens.findIndex(t => t.pos === 'VBN');
    if (beIdx >= 0 && vbnIdx > beIdx) {
      return {
        pattern: 'passive voice: BE + VBN',
        category: 'transformation',
        confidence: 0.7,
        examples: [tokens.map(t => t.text).join(' ')],
      };
    }
    return null;
  }

  private generateHypotheses(tokens: Token[], deps: ReturnType<typeof parseDependencies>): Hypothesis[] {
    const hyps: Hypothesis[] = [];

    // If we see a new word pattern, hypothesize about it
    const nouns = tokens.filter(t => /^NN/.test(t.pos));
    const verbs = tokens.filter(t => /^V/.test(t.pos));

    if (nouns.length >= 2 && verbs.length >= 1) {
      hyps.push({
        id: `h_${Date.now()}_1`,
        statement: `"${nouns[0].text}" can act as agent for "${verbs[0].text}"`,
        evidence: 1,
        status: 'open',
      });
    }

    if (deps.length >= 2) {
      hyps.push({
        id: `h_${Date.now()}_2`,
        statement: `Dependency structure: ${deps.map(d => d.relation).join(', ')}`,
        evidence: deps.length,
        status: 'open',
      });
    }

    return hyps;
  }

  private buildResponse(_input: string, tokens: Token[], newPatterns: LearnedPattern[], newHypotheses: Hypothesis[]): string {
    const lines: string[] = [];

    // Analysis summary
    lines.push(`ANALYSIS: ${tokens.length} tokens, ${newPatterns.length} new patterns`);

    // Report new patterns
    if (newPatterns.length > 0) {
      lines.push(`\nLEARNED:`);
      for (const p of newPatterns) {
        lines.push(`  [${p.category}] ${p.pattern} (conf: ${(p.confidence * 100).toFixed(0)}%)`);
      }
    }

    // Report hypotheses
    if (newHypotheses.length > 0) {
      lines.push(`\nHYPOTHESES:`);
      for (const h of newHypotheses) {
        lines.push(`  ? ${h.statement} (evidence: ${h.evidence})`);
      }
    }

    // Ask a question about unknowns
    const unknowns = tokens.filter(t => t.features.inferred === 'yes');
    if (unknowns.length > 0) {
      const word = unknowns[0];
      lines.push(`\nQUERY: What is "${word.text}"? (noun/verb/adjective?)`);
    }

    lines.push(`\nTotal patterns: ${this.patterns.length}, Hypotheses: ${this.hypotheses.length}`);

    return lines.join('\n');
  }

  // User answers a question - confirm or reject hypothesis
  feedback(hypothesisId: string, confirmed: boolean): string {
    const h = this.hypotheses.find(hy => hy.id === hypothesisId);
    if (!h) return 'Hypothesis not found.';

    h.status = confirmed ? 'confirmed' : 'rejected';

    if (confirmed) {
      // Convert to a rule
      ruleStore.addRule('grammar', `learned_${h.id}`, h.statement, 'confirmed', [], []);
      return `Confirmed: "${h.statement}" → converted to rule.`;
    }

    return `Rejected: "${h.statement}"`;
  }

  // Get current knowledge state
  getKnowledge(): { patterns: LearnedPattern[]; hypotheses: Hypothesis[]; stats: { sessions: number; inputs: number; patterns: number } } {
    return {
      patterns: this.patterns,
      hypotheses: this.hypotheses,
      stats: { sessions: this.sessionCount, inputs: this.totalInputs, patterns: this.patterns.length },
    };
  }
}

export const autoling = new AutolingEngine();
