// ═══════════════════════════════════════════════════════════════
//  STYLE CONTROLLER ENGINE (Klein, 1965)
//  Controls measurable style by manipulating grammar-rule weights.
//  Passive voice, nominalization, hedging, sentence length, etc.
// ═══════════════════════════════════════════════════════════════

import { tokenize } from './parser';
// Token type used implicitly through tokenize return

export interface StyleMetrics {
  avgSentenceLength: number;
  passiveVoiceRatio: number;
  nominalizationDensity: number;
  hedgingFrequency: number;
  lexicalDiversity: number;
  firstPersonRatio: number;
  contractionRatio: number;
  complexWordRatio: number;
}

export interface StyleProfile {
  name: string;
  target: StyleMetrics;
  description: string;
}

const PROFILES: Record<string, StyleProfile> = {
  formal: {
    name: 'Academic Formal',
    description: 'High passive, high nominalization, high hedging',
    target: { avgSentenceLength: 25, passiveVoiceRatio: 0.4, nominalizationDensity: 0.3, hedgingFrequency: 0.4, lexicalDiversity: 0.9, firstPersonRatio: 0.0, contractionRatio: 0.0, complexWordRatio: 0.3 },
  },
  casual: {
    name: 'Conversational',
    description: 'Short sentences, contractions, first person',
    target: { avgSentenceLength: 10, passiveVoiceRatio: 0.1, nominalizationDensity: 0.05, hedgingFrequency: 0.1, lexicalDiversity: 0.6, firstPersonRatio: 0.3, contractionRatio: 0.4, complexWordRatio: 0.1 },
  },
  technical: {
    name: 'Technical',
    description: 'Precise, dense, no hedging, high diversity',
    target: { avgSentenceLength: 18, passiveVoiceRatio: 0.25, nominalizationDensity: 0.25, hedgingFrequency: 0.05, lexicalDiversity: 0.85, firstPersonRatio: 0.0, contractionRatio: 0.0, complexWordRatio: 0.35 },
  },
  poetic: {
    name: 'Poetic/Lyrical',
    description: 'Varied rhythm, imagery, repetition',
    target: { avgSentenceLength: 12, passiveVoiceRatio: 0.15, nominalizationDensity: 0.1, hedgingFrequency: 0.2, lexicalDiversity: 0.95, firstPersonRatio: 0.2, contractionRatio: 0.1, complexWordRatio: 0.25 },
  },
};

export class StyleEngine {
  analyze(text: string): StyleMetrics {
    const sentences = text.split(/[.!?]+/).filter(s => s.trim());
    const tokens = tokenize(text);
    const words = tokens.filter(t => /^[a-zA-Z]+$/.test(t.text));

    const totalWords = words.length;
    const totalSentences = Math.max(sentences.length, 1);

    // Passive voice: "was/were + past participle" or "is/are + past participle + by"
    const passiveMatches = text.match(/\b(is|was|were|are|been)\s+\w+(ed|en)\b/gi) || [];
    const byAgentMatches = text.match(/\b\w+ed\s+by\s+\w+/gi) || [];

    // Nominalizations: -tion, -ment, -ness, -ity, -ence, -ance
    const nominalizations = words.filter(w => /(tion|ment|ness|ity|ence|ance|hood|ship)$/.test(w.text.toLowerCase()));

    // Hedging words
    const hedges = ['may', 'might', 'could', 'would', 'perhaps', 'possibly', 'arguably', 'suggests', 'appears', 'seems', 'likely', 'probably'];
    const hedgeCount = words.filter(w => hedges.includes(w.text.toLowerCase())).length;

    // First person
    const firstPerson = words.filter(w => /^(i|me|my|mine|we|us|our|ours)$/.test(w.text.toLowerCase()));

    // Contractions
    const contractions = (text.match(/\w+'\w+/g) || []).length;

    // Complex words (3+ syllables approximated by length)
    const complexWords = words.filter(w => this.countSyllables(w.text) >= 3);

    // Lexical diversity
    const uniqueWords = new Set(words.map(w => w.text.toLowerCase()));

    return {
      avgSentenceLength: totalWords / totalSentences,
      passiveVoiceRatio: (passiveMatches.length + byAgentMatches.length) / totalSentences,
      nominalizationDensity: nominalizations.length / Math.max(totalWords, 1),
      hedgingFrequency: hedgeCount / Math.max(totalWords, 1),
      lexicalDiversity: uniqueWords.size / Math.max(totalWords, 1),
      firstPersonRatio: firstPerson.length / Math.max(totalWords, 1),
      contractionRatio: contractions / Math.max(totalWords, 1),
      complexWordRatio: complexWords.length / Math.max(totalWords, 1),
    };
  }

  transform(text: string, profileName: string): { text: string; metrics: StyleMetrics; profile: StyleProfile; adjustments: string[] } {
    const profile = PROFILES[profileName] || PROFILES.formal;
    const current = this.analyze(text);
    const adjustments: string[] = [];
    let result = text;

    // Passive voice adjustment
    if (current.passiveVoiceRatio < profile.target.passiveVoiceRatio) {
      // Add passive constructions
      result = this.addPassive(result);
      adjustments.push(`Added passive voice (+${((profile.target.passiveVoiceRatio - current.passiveVoiceRatio) * 100).toFixed(0)}%)`);
    } else if (current.passiveVoiceRatio > profile.target.passiveVoiceRatio + 0.1) {
      // Remove passive (convert to active)
      result = this.removePassive(result);
      adjustments.push(`Reduced passive voice`);
    }

    // Hedging adjustment
    if (current.hedgingFrequency < profile.target.hedgingFrequency) {
      result = this.addHedging(result);
      adjustments.push(`Added hedging devices`);
    } else if (current.hedgingFrequency > profile.target.hedgingFrequency + 0.05) {
      result = this.removeHedging(result);
      adjustments.push(`Removed hedging`);
    }

    // Sentence length adjustment
    if (current.avgSentenceLength < profile.target.avgSentenceLength - 3) {
      result = this.expandSentences(result);
      adjustments.push(`Expanded sentence length (${current.avgSentenceLength.toFixed(0)} → ${profile.target.avgSentenceLength.toFixed(0)})`);
    } else if (current.avgSentenceLength > profile.target.avgSentenceLength + 3) {
      result = this.shortenSentences(result);
      adjustments.push(`Shortened sentences (${current.avgSentenceLength.toFixed(0)} → ${profile.target.avgSentenceLength.toFixed(0)})`);
    }

    // Nominalization adjustment
    if (current.nominalizationDensity < profile.target.nominalizationDensity) {
      result = this.addNominalizations(result);
      adjustments.push(`Added nominalizations`);
    }

    // Contraction adjustment (casual)
    if (profile.target.contractionRatio > 0.2 && current.contractionRatio < 0.2) {
      result = this.addContractions(result);
      adjustments.push(`Added contractions`);
    } else if (profile.target.contractionRatio === 0 && current.contractionRatio > 0) {
      result = this.removeContractions(result);
      adjustments.push(`Removed contractions`);
    }

    const newMetrics = this.analyze(result);
    return { text: result, metrics: newMetrics, profile, adjustments };
  }

  private addPassive(text: string): string {
    return text.replace(/\b(\w+)\s+(\w+)s?\s+(\w+)\b/g, (match, subj, verb, obj) => {
      if (subj.length < 2 || obj.length < 2) return match;
      const pp = verb + (verb.endsWith('e') ? 'd' : 'ed');
      return `${obj.charAt(0).toUpperCase() + obj.slice(1)} was ${pp} by ${subj.toLowerCase()}`;
    });
  }

  private removePassive(text: string): string {
    return text.replace(/(\w+)\s+was\s+(\w+)ed\s+by\s+(\w+)/gi, (_match, obj, verb, subj) => {
      return `${subj} ${verb}s ${obj.toLowerCase()}`;
    });
  }

  private addHedging(text: string): string {
    const hedges = ['It may be that', 'Evidence suggests that', 'One might argue that', 'It appears that'];
    const sentences = text.split(/([.!?]+\s*)/);
    for (let i = 0; i < sentences.length; i += 2) {
      if (sentences[i].trim() && Math.random() < 0.3) {
        const hedge = hedges[Math.floor(Math.random() * hedges.length)];
        sentences[i] = `${hedge} ${sentences[i].charAt(0).toLowerCase() + sentences[i].slice(1)}`;
      }
    }
    return sentences.join('');
  }

  private removeHedging(text: string): string {
    return text
      .replace(/\b(It may be that|Evidence suggests that|One might argue that|It appears that)\s+/gi, '')
      .replace(/\b(perhaps|possibly|arguably|likely|probably)\s+/gi, '');
  }

  private expandSentences(text: string): string {
    const elaborations = [
      ', which has significant implications for the broader context',
      ', a finding that warrants further investigation',
      ', representing a notable development in this domain',
    ];
    return text.replace(/([^.!?]+[.!?])/g, (sent) => {
      if (Math.random() < 0.4 && sent.length > 20) {
        const elab = elaborations[Math.floor(Math.random() * elaborations.length)];
        return sent.slice(0, -1) + elab + sent.slice(-1);
      }
      return sent;
    });
  }

  private shortenSentences(text: string): string {
    return text.replace(/,\s+\w+[^,]{20,}[.!?]/g, (m) => m.split(',')[0] + '.');
  }

  private addNominalizations(text: string): string {
    const verbToNoun: Record<string, string> = {
      decide: 'decision', implement: 'implementation', analyze: 'analysis',
      create: 'creation', develop: 'development', transform: 'transformation',
      generate: 'generation', observe: 'observation', conclude: 'conclusion',
    };
    return text.replace(/\b(\w+)s?\b/g, (word) => {
      const lower = word.toLowerCase();
      return verbToNoun[lower] ? verbToNoun[lower] : word;
    });
  }

  private addContractions(text: string): string {
    return text
      .replace(/\bdoes not\b/gi, "doesn't").replace(/\bdid not\b/gi, "didn't")
      .replace(/\bwill not\b/gi, "won't").replace(/\bcannot\b/gi, "can't")
      .replace(/\bis not\b/gi, "isn't").replace(/\bare not\b/gi, "aren't")
      .replace(/\bwas not\b/gi, "wasn't").replace(/\bwere not\b/gi, "weren't")
      .replace(/\bhave not\b/gi, "haven't").replace(/\bhas not\b/gi, "hasn't")
      .replace(/\bdo not\b/gi, "don't").replace(/\bI am\b/gi, "I'm")
      .replace(/\bYou are\b/gi, "You're").replace(/\bIt is\b/gi, "It's")
      .replace(/\bThey are\b/gi, "They're").replace(/\bWe are\b/gi, "We're");
  }

  private removeContractions(text: string): string {
    return text
      .replace(/\bdoesn't\b/gi, 'does not').replace(/\bdidn't\b/gi, 'did not')
      .replace(/\bwon't\b/gi, 'will not').replace(/\bcan't\b/gi, 'cannot')
      .replace(/\bisn't\b/gi, 'is not').replace(/\baren't\b/gi, 'are not')
      .replace(/\bwasn't\b/gi, 'was not').replace(/\bweren't\b/gi, 'were not')
      .replace(/\bhaven't\b/gi, 'have not').replace(/\bhasn't\b/gi, 'has not')
      .replace(/\bdon't\b/gi, 'do not').replace(/\bI'm\b/gi, 'I am')
      .replace(/\bYou're\b/gi, 'You are').replace(/\bIt's\b/gi, 'It is')
      .replace(/\bThey're\b/gi, 'They are').replace(/\bWe're\b/gi, 'We are');
  }

  private countSyllables(word: string): number {
    const vowels = 'aeiouy';
    let count = 0;
    let prevWasVowel = false;
    for (const char of word.toLowerCase()) {
      const isVowel = vowels.includes(char);
      if (isVowel && !prevWasVowel) count++;
      prevWasVowel = isVowel;
    }
    return Math.max(1, count);
  }

  getProfiles(): typeof PROFILES {
    return PROFILES;
  }
}

export const styleEngine = new StyleEngine();
