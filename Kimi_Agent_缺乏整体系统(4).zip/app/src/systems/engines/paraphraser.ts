// ═══════════════════════════════════════════════════════════════
//  PARAPHRASER ENGINE (Klein, 1965)
//  Dependency parse → transformation → regenerate.
//  Not synonym swaps. Real structural rewriting.
// ═══════════════════════════════════════════════════════════════

import { parse } from './parser';
import { ruleStore } from '@/systems/memory/ruleStore';
import type { ParseTree, Rule } from '@/types';

interface ParaphraseResult {
  original: string;
  paraphrase: string;
  transformations: string[];
  rules: Rule[];
  parseTree: ParseTree;
}

export class ParaphraserEngine {
  // Main: paraphrase text by parsing, transforming, regenerating
  paraphrase(text: string, mode: 'simplify' | 'formal' | 'passive' | 'active' | 'expand' = 'simplify'): ParaphraseResult {
    const parseTree = parse(text);
    const transformations: string[] = [];
    const appliedRules: Rule[] = [];

    let result = text;

    // Try transformation rules from the rule store
    const rules = ruleStore.getRules('transformation');
    for (const rule of rules) {
      const applied = ruleStore.applyRule(result, rule);
      if (applied && applied !== result) {
        result = applied;
        transformations.push(`${rule.name}: ${rule.lhs} → ${rule.rhs}`);
        appliedRules.push(rule);
      }
    }

    // Mode-specific transformations
    switch (mode) {
      case 'passive':
        result = this.toPassive(parseTree, result);
        if (result !== text) transformations.push('active_to_passive');
        break;
      case 'active':
        result = this.toActive(parseTree, result);
        if (result !== text) transformations.push('passive_to_active');
        break;
      case 'simplify':
        result = this.simplify(result);
        transformations.push('simplify_vocabulary');
        break;
      case 'formal':
        result = this.toFormal(parseTree, result);
        transformations.push('formalize');
        break;
      case 'expand':
        result = this.expand(parseTree, result);
        transformations.push('expand');
        break;
    }

    return { original: text, paraphrase: result, transformations, rules: appliedRules, parseTree };
  }

  // Active → Passive: "The dog chased the cat" → "The cat was chased by the dog"
  private toPassive(tree: ParseTree, text: string): string {
    const tokens = tree.tokens;
    const deps = tree.dependencies;

    // Find subject (nsubj) and object (dobj)
    const subjDep = deps.find(d => d.relation === 'nsubj');
    const objDep = deps.find(d => d.relation === 'dobj');
    const rootVerb = tokens[tree.root];

    if (!subjDep || !objDep || !rootVerb) return text;

    const subject = tokens[subjDep.dependent];
    const object = tokens[objDep.dependent];

    if (!subject || !object) return text;

    const verb = rootVerb.text;
    const pastParticiple = this.toPastParticiple(verb);

    return `${this.capitalize(object.text)} was ${pastParticiple} by ${subject.text}.`;
  }

  // Passive → Active: "The cat was chased by the dog" → "The dog chased the cat"
  private toActive(_tree: ParseTree, text: string): string {
    const passiveMatch = text.match(/(\w+)\s+was\s+(\w+)\s+by\s+(\w+)/i);
    if (!passiveMatch) return text;

    const [, obj, verb, subj] = passiveMatch;
    const baseVerb = this.toBaseVerb(verb);

    return `${this.capitalize(subj)} ${baseVerb} ${obj.toLowerCase()}.`;
  }

  private simplify(text: string): string {
    return text
      .replace(/\butilize\b/gi, 'use')
      .replace(/\butilizing\b/gi, 'using')
      .replace(/\bdemonstrate\b/gi, 'show')
      .replace(/\bdemonstrating\b/gi, 'showing')
      .replace(/\bimplementation\b/gi, 'doing')
      .replace(/\bimplementing\b/gi, 'doing')
      .replace(/\bapproximately\b/gi, 'about')
      .replace(/\bnevertheless\b/gi, 'but')
      .replace(/\bfurthermore\b/gi, 'also')
      .replace(/\bconsequently\b/gi, 'so')
      .replace(/\bregarding\b/gi, 'about')
      .replace(/\bpertaining to\b/gi, 'about')
      .replace(/\bin the event that\b/gi, 'if')
      .replace(/\bat this point in time\b/gi, 'now')
      .replace(/\bdue to the fact that\b/gi, 'because')
      .replace(/\bin order to\b/gi, 'to')
      .replace(/\bhas the ability to\b/gi, 'can')
      .replace(/\bis able to\b/gi, 'can');
  }

  private toFormal(tree: ParseTree, text: string): string {
    // Add hedging
    const tokens = tree.tokens;
    if (tokens.length > 5) {
      return `It may be argued that ${text.charAt(0).toLowerCase() + text.slice(1)} Furthermore, the evidence suggests this proposition warrants continued investigation.`;
    }
    return text;
  }

  private expand(tree: ParseTree, text: string): string {
    const tokens = tree.tokens;
    const rootVerb = tokens[tree.root];

    if (!rootVerb) return `${text} This is an important consideration that deserves further exploration and detailed analysis.`;

    return `${text} ${this.capitalize(rootVerb.text)}ing this thoroughly reveals deeper patterns and interconnected relationships that merit further detailed investigation and careful consideration.`;
  }

  private toPastParticiple(verb: string): string {
    const irregulars: Record<string, string> = {
      hit: 'hit', chase: 'chased', run: 'run', go: 'gone', come: 'come',
      see: 'seen', take: 'taken', make: 'made', get: 'gotten', know: 'known',
      think: 'thought', say: 'said', tell: 'told', give: 'given', find: 'found',
      feel: 'felt', become: 'become', leave: 'left', put: 'put', mean: 'meant',
      keep: 'kept', let: 'let', begin: 'begun', seem: 'seemed', help: 'helped',
      turn: 'turned', start: 'started', hear: 'heard', play: 'played',
      move: 'moved', live: 'lived', believe: 'believed', bring: 'brought',
      write: 'written', stand: 'stood', lose: 'lost', pay: 'paid', meet: 'met',
      set: 'set', learn: 'learned', change: 'changed', lead: 'led',
      understand: 'understood', watch: 'watched', follow: 'followed',
      stop: 'stopped', create: 'created', speak: 'spoken', read: 'read',
      spend: 'spent', grow: 'grown', open: 'opened', offer: 'offered',
      remember: 'remembered', love: 'loved', consider: 'considered',
      appear: 'appeared', buy: 'bought', wait: 'waited', serve: 'served',
      die: 'died', send: 'sent', expect: 'expected', build: 'built',
      stay: 'stayed', fall: 'fallen', cut: 'cut', reach: 'reached',
      kill: 'killed', remain: 'remained', want: 'wanted', like: 'liked',
      need: 'needed', use: 'used', work: 'worked', try: 'tried',
      call: 'called', ask: 'asked', show: 'shown', look: 'looked',
    };

    const lower = verb.toLowerCase();
    if (irregulars[lower]) return irregulars[lower];
    if (verb.endsWith('e')) return verb + 'd';
    if (verb.endsWith('y') && !/[aeiou]y$/.test(verb)) return verb.slice(0, -1) + 'ied';
    if (/[^aeiou][aeiou][^aeiouwxy]$/.test(verb)) return verb + verb.slice(-1) + 'ed';
    return verb + 'ed';
  }

  private toBaseVerb(pastParticiple: string): string {
    if (pastParticiple.endsWith('ied')) return pastParticiple.slice(0, -3) + 'y';
    if (pastParticiple.endsWith('ed')) return pastParticiple.slice(0, -2);
    if (pastParticiple.endsWith('en')) return pastParticiple.slice(0, -2);
    return pastParticiple;
  }

  private capitalize(s: string): string {
    return s.charAt(0).toUpperCase() + s.slice(1);
  }

  // Learn from a paraphrase pair
  learnFromExample(original: string, paraphrase: string): void {
    const diff = this.detectStructuralDiff(original, paraphrase);
    if (diff) {
      ruleStore.learnFromExample('transformation', original, paraphrase);
    }
  }

  private detectStructuralDiff(a: string, b: string): boolean {
    const wordsA = a.split(/\s+/).filter(w => /\w/.test(w));
    const wordsB = b.split(/\s+/).filter(w => /\w/.test(w));
    const common = new Set(wordsA.filter(w => wordsB.includes(w)));
    return common.size > 0 && a.length !== b.length;
  }
}

export const paraphraser = new ParaphraserEngine();
