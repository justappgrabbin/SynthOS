// ═══════════════════════════════════════════════════════════════
//  KLEIN PIPELINE
//  Pure orchestrator. No processing. Routes data through engines.
//  INGEST → PARSE → GRAPH → INFER → MORPH → SIMULATE → GENERATE → LEARN → OUTPUT
//  + ARTIFACT ROUTE: graph → game/app/video generators
// ═══════════════════════════════════════════════════════════════

import type { PipelineFlow, PipelineNode, PipelineStage, SystemId } from '@/types';
import { parse, parseCode } from './engines/parser';
import { graphStore } from './memory/graphStore';
import { ruleStore } from './memory/ruleStore';
import { diseminer } from './engines/diseminer';
import { paraphraser } from './engines/paraphraser';
import { styleEngine } from './engines/style';
import { autoling } from './engines/autoling';
import { simulator } from './engines/simulator';
import { generator } from './engines/generator';
import { planGame, renderGame } from './generators/gameGenerator';
import { planApp, renderApp } from './generators/appGenerator';
import { planVideo, renderVideo } from './generators/videoGenerator';
import type { GameSpec } from './generators/gameGenerator';
import type { AppSpec } from './generators/appGenerator';
import type { VideoSpec } from './generators/videoGenerator';

export const SYSTEMS: Array<{ id: SystemId; name: string; year: number; color: string }> = [
  { id: 'parser', name: 'Grammar Coder', year: 1963, color: '#8b5cf6' },
  { id: 'diseminer', name: 'DISEMINER', year: 1968, color: '#06b6d4' },
  { id: 'autoling', name: 'AUTOLING', year: 1968, color: '#22c55e' },
  { id: 'paraphraser', name: 'Paraphraser', year: 1965, color: '#3b82f6' },
  { id: 'style-controller', name: 'Style Controller', year: 1965, color: '#ec4899' },
  { id: 'simulator', name: 'Simulator', year: 1966, color: '#ef4444' },
  { id: 'generator', name: 'Generator', year: 1973, color: '#a855f7' },
];

function detectIntent(input: string): { intent: string; route: string[]; artifactType?: 'game' | 'app' | 'video' | 'text' } {
  const lower = input.toLowerCase();

  // Artifact detection FIRST - highest priority
  if (/\bgame\b/.test(lower) || /\bmini.game\b/.test(lower)) return { intent: 'generate-game', route: ['parse', 'graph', 'infer', 'simulate', 'generate'], artifactType: 'game' };
  if (/\bapp\b/.test(lower) || /\bdashboard\b/.test(lower) || /\btracker\b/.test(lower) || /\bmanagement\b/.test(lower)) return { intent: 'generate-app', route: ['parse', 'graph', 'infer', 'generate'], artifactType: 'app' };
  if (/\bvideo\b/.test(lower) || /\bfilm\b/.test(lower) || /\bscript\b/.test(lower) || /\bstoryboard\b/.test(lower) || /\bcinematic\b/.test(lower)) return { intent: 'generate-video', route: ['parse', 'graph', 'simulate', 'generate'], artifactType: 'video' };

  // Text generation
  if (/write|generate.*story|tell.*story|novel|narrative/.test(lower)) return { intent: 'generate-story', route: ['parse', 'graph', 'infer', 'simulate', 'generate'] };
  if (/write.*code|generate.*code|function|class.*\{/.test(lower)) return { intent: 'generate-code', route: ['parse', 'graph', 'infer', 'generate'] };

  // Other text operations
  if (/paraphrase|rewrite|rephrase|simplify/.test(lower)) return { intent: 'paraphrase', route: ['parse', 'graph', 'paraphrase'] };
  if (/explain.*code|what.*does.*code/.test(lower)) return { intent: 'explain-code', route: ['parse', 'graph', 'infer', 'paraphrase'] };
  if (/change.*style|make.*formal|make.*casual/.test(lower)) return { intent: 'style-transform', route: ['parse', 'graph', 'style'] };
  if (/what.*mean|define|semantic|analyze.*meaning/.test(lower)) return { intent: 'semantic-analysis', route: ['parse', 'graph', 'infer'] };
  if (/analyze.*code|complexity|parse.*code/.test(lower)) return { intent: 'code-analysis', route: ['parse', 'graph', 'infer'] };
  if (/simulate|evolution|monte.*carlo|world/.test(lower)) return { intent: 'simulate', route: ['parse', 'graph', 'simulate', 'generate'] };
  if (/learn|pattern|teach|grammar/.test(lower)) return { intent: 'learn', route: ['parse', 'graph', 'autoling'] };
  return { intent: 'general', route: ['parse', 'graph', 'infer', 'paraphrase'] };
}

const wait = (ms: number) => new Promise<void>(r => setTimeout(r, ms));

export interface ArtifactOutput {
  type: 'game' | 'app' | 'video' | 'text';
  spec: GameSpec | AppSpec | VideoSpec | null;
  rendered: string | Record<string, string> | null;
  previewHTML: string | null;
}

export async function runPipeline(input: string): Promise<PipelineFlow & { artifact: ArtifactOutput }> {
  const { intent, route, artifactType } = detectIntent(input);
  const flowId = `flow_${Date.now()}`;
  const nodes: PipelineNode[] = [];

  const add = (id: string, stage: PipelineStage, sysId: SystemId | undefined, label: string, desc: string) => {
    const n: PipelineNode = { id, stage, systemId: sysId, label, description: desc, status: 'idle', input: '', output: '' };
    nodes.push(n);
    return n;
  };

  // INGEST
  const n1 = add('ingest', 'ingest', undefined, 'INGEST', `${input.length} chars`);
  n1.status = 'active'; n1.input = input; n1.output = 'captured';
  await wait(200); n1.status = 'complete';

  // PARSE
  const n2 = add('parse', 'parse', 'parser', 'PARSE', 'Tokenizing + tagging');
  n2.status = 'active'; n2.input = input;
  const isCode = /[{};]|function|class|const|=>/.test(input);
  const parseTree = isCode ? parseCode(input) : parse(input);
  n2.output = `${parseTree.tokens.length} tokens, ${parseTree.dependencies.length} deps`;
  await wait(400); n2.status = 'complete';

  // GRAPH
  const n3 = add('graph', 'graph', undefined, 'GRAPH', 'Building semantic graph');
  n3.status = 'active'; n3.input = parseTree;
  graphStore.extractFromParse(
    parseTree.tokens.map(t => ({ text: t.text, pos: t.pos })),
    parseTree.dependencies.map(d => ({ gov: d.governor, dep: d.dependent, rel: d.relation }))
  );
  const stats = graphStore.stats();
  n3.output = `${stats.nodes} nodes, ${stats.edges} edges`;
  await wait(300); n3.status = 'complete';

  // INFER
  const n4 = add('infer', 'infer', 'diseminer', 'INFER', 'Semantic inference');
  n4.status = 'active'; n4.input = input;
  const inference = diseminer.answer(input);
  n4.output = `${inference.evidence.length} evidence items, conf=${(inference.confidence * 100).toFixed(0)}%`;
  await wait(400); n4.status = 'complete';

  // Route through standard engines
  let currentText = input;
  for (const step of route) {
    switch (step) {
      case 'paraphrase': {
        const n = add('paraphrase', 'morph', 'paraphraser', 'PARAPHRASE', 'Dependency transform');
        n.status = 'active'; n.input = currentText;
        const result = paraphraser.paraphrase(currentText, 'simplify');
        currentText = result.paraphrase;
        n.output = `${result.transformations.join(', ')} (${result.rules.length} rules)`;
        await wait(500); n.status = 'complete';
        break;
      }
      case 'style': {
        const n = add('style', 'morph', 'style-controller', 'STYLE', 'Grammar weight control');
        n.status = 'active'; n.input = currentText;
        const profile = input.includes('formal') ? 'formal' : input.includes('casual') ? 'casual' : 'formal';
        const result = styleEngine.transform(currentText, profile);
        currentText = result.text;
        n.output = `${result.adjustments.join(', ')}`;
        await wait(500); n.status = 'complete';
        break;
      }
      case 'autoling': {
        const n = add('autoling', 'morph', 'autoling', 'AUTOLING', 'Pattern learning');
        n.status = 'active'; n.input = currentText;
        const result = autoling.process(currentText);
        currentText = result.response;
        n.output = `${result.patterns.length} patterns, ${result.newHypotheses.length} hypotheses`;
        await wait(500); n.status = 'complete';
        break;
      }
      case 'simulate': {
        const n = add('simulate', 'simulate', 'simulator', 'SIMULATE', 'World + agents + events');
        n.status = 'active'; n.input = currentText;
        simulator.setupWorld(currentText);
        const simResult = simulator.simulate(5);
        const narrative = simulator.generateNarrative();
        currentText = narrative;
        n.output = `${simResult.split('\n').length} events simulated`;
        await wait(600); n.status = 'complete';
        break;
      }
      case 'generate': {
        const n = add('generate', 'generate', 'generator', 'GENERATE', 'Discourse + surface');
        n.status = 'active'; n.input = currentText;
        const plan = generator.planFromParse(parseTree, intent);
        const generated = generator.generate(plan);
        currentText = generated;
        n.output = `${plan.steps.length} discourse steps`;
        await wait(500); n.status = 'complete';
        break;
      }
    }
  }

  // ARTIFACT GENERATION (if detected)
  const artifact: ArtifactOutput = { type: artifactType || 'text', spec: null, rendered: null, previewHTML: null };

  if (artifactType === 'game') {
    const n = add('artifact', 'generate', undefined, 'GAME GEN', 'Canvas game spec + render');
    n.status = 'active';
    const graphNodes = graphStore.getGraphSnapshot().nodes;
    const gameSpec = planGame(graphNodes, intent);
    const gameHTML = renderGame(gameSpec);
    artifact.spec = gameSpec;
    artifact.rendered = gameHTML;
    artifact.previewHTML = gameHTML;
    n.output = `${gameSpec.title} | ${gameSpec.genre} | ${gameSpec.entities.length} entities`;
    await wait(600); n.status = 'complete';
    currentText = `Game generated: ${gameSpec.title}\nGenre: ${gameSpec.genre}\nControls: ${gameSpec.controls.join(', ')}\nWin: ${gameSpec.winCondition}`;
  }

  if (artifactType === 'app') {
    const n = add('artifact', 'generate', undefined, 'APP GEN', 'React component files');
    n.status = 'active';
    const { nodes: graphNodes, edges: graphEdges } = graphStore.getGraphSnapshot();
    const appSpec = planApp(graphNodes, graphEdges, intent);
    const appFiles = renderApp(appSpec);
    artifact.spec = appSpec;
    artifact.rendered = appFiles;
    // Preview is the CSS + key components rendered as HTML
    artifact.previewHTML = renderAppPreview(appSpec, appFiles);
    n.output = `${appSpec.name} | ${appFiles['types.ts'] ? 'TypeScript' : 'JS'} | ${Object.keys(appFiles).length} files`;
    await wait(600); n.status = 'complete';
    currentText = `App generated: ${appSpec.name}\nPurpose: ${appSpec.purpose}\nScreens: ${appSpec.screens.map(s => s.name).join(', ')}\nFiles: ${Object.keys(appFiles).join(', ')}`;
  }

  if (artifactType === 'video') {
    const n = add('artifact', 'generate', undefined, 'VIDEO GEN', 'Storyboard + HTML preview');
    n.status = 'active';
    const graphNodes = graphStore.getGraphSnapshot().nodes;
    const videoSpec = planVideo(graphNodes, intent);
    const videoHTML = renderVideo(videoSpec);
    artifact.spec = videoSpec;
    artifact.rendered = videoHTML;
    artifact.previewHTML = videoHTML;
    n.output = `${videoSpec.title} | ${videoSpec.scenes.length} scenes | ${videoSpec.scenes.reduce((s, sc) => s + sc.duration, 0)}ms`;
    await wait(600); n.status = 'complete';
    currentText = `Video storyboard: ${videoSpec.title}\nScenes: ${videoSpec.scenes.map((s, i) => `${i + 1}. ${s.type} - ${s.action}`).join('\n')}\n\n${videoSpec.narration.join('\n')}`;
  }

  // LEARN
  const n5 = add('learn', 'learn', 'autoling', 'LEARN', 'Extract patterns');
  n5.status = 'active'; n5.input = input;
  const learnResult = autoling.process(input);
  n5.output = `${learnResult.patterns.length} patterns stored`;
  await wait(300); n5.status = 'complete';

  // OUTPUT
  const n6 = add('output', 'output', undefined, 'OUTPUT', 'Deliver');
  n6.status = 'active'; n6.input = currentText; n6.output = currentText;
  await wait(200); n6.status = 'complete';

  return {
    id: flowId,
    input,
    intent,
    nodes,
    parseTree,
    graph: graphStore.getGraphSnapshot(),
    rules: ruleStore.getRules(),
    finalOutput: currentText,
    startedAt: Date.now(),
    artifact,
  };
}

// Render a simplified app preview as HTML
function renderAppPreview(spec: import('./generators/appGenerator').AppSpec, files: Record<string, string>): string {
  // Extract CSS and build a preview
  const css = files['App.css'] || '';
  return `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>${spec.name} Preview</title>
<style>${css.replace(/:root/g, ':root').replace(/var\(/g, 'var(')}</style>
</head>
<body>
<div class="app">
  <nav class="navigation">
    <div style="font-size:11px;color:#64748b;margin-bottom:12px">${spec.name}</div>
    ${spec.screens.map(s => `<div class="nav-item">${s.name}</div>`).join('')}
  </nav>
  <main class="main">
    <header class="header"><h1>${spec.name}</h1><p>${spec.purpose}</p></header>
    <div class="content">
      <div class="panel">
        <div class="stats-panel">
          <div class="stat"><span class="value">0</span><span class="label">Total ${spec.dataModel[0]?.name}s</span></div>
          <div class="stat"><span class="value">dark</span><span class="label">Theme</span></div>
        </div>
      </div>
      <div class="panel">
        <h2 style="color:#c4b5fd;font-size:16px;margin-bottom:12px">Create ${spec.dataModel[0]?.name}</h2>
        <div class="field"><label>Name</label><input placeholder="Enter name..." /></div>
        <button>Create</button>
      </div>
      <div class="panel wide">
        <h2 style="color:#c4b5fd;font-size:16px;margin-bottom:12px">${spec.dataModel[0]?.name} List</h2>
        <div class="list-item"><span class="name">Example item 1</span><button>Delete</button></div>
        <div class="list-item"><span class="name">Example item 2</span><button>Delete</button></div>
        <div class="list-item"><span class="name">Example item 3</span><button>Delete</button></div>
      </div>
    </div>
  </main>
</div>
</body></html>`;
}
