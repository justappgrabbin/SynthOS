// ═══════════════════════════════════════════════════════════════
//  RULE STORE
//  Learned transformation, grammar, style, and inference rules.
//  Every rule has weight, confidence, examples, and learns from feedback.
// ═══════════════════════════════════════════════════════════════

import type { Rule, RuleType } from '@/types';

const STORAGE_KEY = 'klein_rules_v1';

export class RuleStore {
  private rules: Rule[] = [];

  constructor() {
    this.load();
  }

  private load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) this.rules = JSON.parse(raw);
    } catch { /* empty */ }
  }

  private save() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(this.rules)); } catch { /* full */ }
  }

  // ── RULE CREATION ─────────────────────────────────────────
  addRule(type: RuleType, name: string, lhs: string, rhs: string, variables: string[] = [], examples: Array<{ input: string; output: string }> = []): Rule {
    const rule: Rule = {
      id: `r_${type}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      type, name, lhs, rhs, variables,
      weight: 0.5,
      confidence: examples.length > 0 ? 0.6 : 0.3,
      examples,
      createdAt: Date.now(),
      lastUsed: Date.now(),
      useCount: 0,
    };
    this.rules.push(rule);
    this.save();
    return rule;
  }

  // Learn a rule from an input/output pair
  learnFromExample(type: RuleType, input: string, output: string): Rule | null {
    // Try to find the structural difference
    const diff = this.findStructuralDiff(input, output);
    if (!diff) return null;

    // Check if a similar rule already exists
    const existing = this.rules.find(r =>
      r.type === type &&
      this.patternSimilarity(r.lhs, diff.lhs) > 0.7 &&
      this.patternSimilarity(r.rhs, diff.rhs) > 0.7
    );

    if (existing) {
      // Strengthen existing rule
      existing.examples.push({ input, output });
      existing.confidence = Math.min(1, existing.confidence + 0.1);
      existing.weight = Math.min(1, existing.weight + 0.05);
      existing.lastUsed = Date.now();
      this.save();
      return existing;
    }

    // Create new rule
    return this.addRule(type, diff.name, diff.lhs, diff.rhs, diff.vars, [{ input, output }]);
  }

  private findStructuralDiff(a: string, b: string): { name: string; lhs: string; rhs: string; vars: string[] } | null {
    // Active/passive detection
    const activeMatch = a.match(/^(\w+)\s+(\w+)\s+(the\s+\w+)/i);
    const passiveMatch = b.match(/^(the\s+\w+)\s+was\s+(\w+)\s+by\s+(\w+)/i);
    if (activeMatch && passiveMatch) {
      return {
        name: 'active_to_passive',
        lhs: '<NP1> <V> <NP2>',
        rhs: '<NP2> was <V-en> by <NP1>',
        vars: ['NP1', 'V', 'NP2'],
      };
    }

    // Word order swap
    const wordsA = a.split(/\s+/);
    const wordsB = b.split(/\s+/);
    if (wordsA.length === wordsB.length && wordsA.length > 3) {
      const common = new Set(wordsA.filter(w => wordsB.includes(w)));
      if (common.size / wordsA.length > 0.5) {
        return {
          name: 'reorder',
          lhs: wordsA.map((w, i) => common.has(w) ? `<W${i}>` : w).join(' '),
          rhs: wordsB.map((w, i) => common.has(w) ? `<W${i}>` : w).join(' '),
          vars: Array.from({ length: wordsA.length }, (_, i) => `W${i}`).filter((_, i) => common.has(wordsA[i])),
        };
      }
    }

    // Simplification: long word → short word
    const longWords = a.split(/\s+/).filter(w => w.length > 6);
    void b.split(/\s+/).filter(w => w.length <= 6); // short words detected
    if (longWords.length > 0 && a.length > b.length) {
      return {
        name: 'simplify_vocabulary',
        lhs: a,
        rhs: b,
        vars: longWords,
      };
    }

    return null;
  }

  private patternSimilarity(a: string, b: string): number {
    const tokensA = a.split(/\s+/);
    const tokensB = b.split(/\s+/);
    const common = tokensA.filter(t => tokensB.includes(t));
    return common.length / Math.max(tokensA.length, tokensB.length);
  }

  // ── RULE RETRIEVAL ──────────────────────────────────────
  getRules(type?: RuleType): Rule[] {
    const filtered = type ? this.rules.filter(r => r.type === type) : [...this.rules];
    return filtered.sort((a, b) => b.weight * b.confidence - a.weight * a.confidence);
  }

  findApplicable(input: string, type?: RuleType): Rule[] {
    const candidates = this.getRules(type);
    return candidates.filter(r => this.matchPattern(input, r.lhs));
  }

  private matchPattern(input: string, pattern: string): boolean {
    // Variable patterns like <NP1> <V> <NP2>
    if (pattern.includes('<')) {
      const regex = pattern.replace(/<\w+>/g, '(.+)');
      try { return new RegExp(regex, 'i').test(input); } catch { return false; }
    }
    // Literal contains
    return input.toLowerCase().includes(pattern.toLowerCase());
  }

  // ── RULE APPLICATION ──────────────────────────────────────
  applyRule(input: string, rule: Rule): string | null {
    let result = input;

    if (rule.lhs.includes('<')) {
      // Variable substitution
      const vars = this.extractVariables(input, rule.lhs);
      if (!vars) return null;
      result = rule.rhs;
      for (const [key, val] of Object.entries(vars)) {
        result = result.replace(new RegExp(`<${key}>`, 'g'), val);
      }
    } else if (input.toLowerCase().includes(rule.lhs.toLowerCase())) {
      result = input.replace(new RegExp(rule.lhs, 'gi'), rule.rhs);
    } else {
      return null;
    }

    rule.useCount++;
    rule.lastUsed = Date.now();
    this.save();
    return result;
  }

  private extractVariables(input: string, pattern: string): Record<string, string> | null {
    const varNames: string[] = [];
    const regexPattern = pattern.replace(/<(\w+)>/g, (_, name) => {
      varNames.push(name);
      return '(.+?)';
    });
    try {
      const match = input.match(new RegExp(`^${regexPattern}$`, 'i'));
      if (!match) return null;
      const vars: Record<string, string> = {};
      varNames.forEach((name, i) => { vars[name] = match[i + 1].trim(); });
      return vars;
    } catch { return null; }
  }

  // ── FEEDBACK LEARNING ───────────────────────────────────
  feedback(ruleId: string, correct: boolean) {
    const rule = this.rules.find(r => r.id === ruleId);
    if (!rule) return;

    if (correct) {
      rule.confidence = Math.min(1, rule.confidence + 0.15);
      rule.weight = Math.min(1, rule.weight + 0.1);
    } else {
      rule.confidence = Math.max(0.1, rule.confidence - 0.2);
      rule.weight = Math.max(0.1, rule.weight - 0.15);
    }
    this.save();
  }

  // ── SEED RULES ──────────────────────────────────────────
  seed() {
    if (this.rules.length > 0) return;

    // Transformation rules
    this.addRule('transformation', 'active_to_passive', '<NP1> <V> <NP2>', '<NP2> was <V-en> by <NP1>', ['NP1', 'V', 'NP2'], [
      { input: 'John hit the ball', output: 'The ball was hit by John' },
      { input: 'The dog chased the cat', output: 'The cat was chased by the dog' },
    ]);

    this.addRule('transformation', 'passive_to_active', '<NP2> was <V-en> by <NP1>', '<NP1> <V> <NP2>', ['NP1', 'V', 'NP2'], [
      { input: 'The ball was hit by John', output: 'John hit the ball' },
    ]);

    this.addRule('transformation', 'nominalize', '<NP1> <V> <NP2>', 'The <V-nom> of <NP2> by <NP1>', ['NP1', 'V', 'NP2'], [
      { input: 'The committee decided the policy', output: 'The decision of the policy by the committee' },
    ]);

    this.addRule('transformation', 'simplify', 'utilize', 'use', [], []);
    this.addRule('transformation', 'simplify', 'demonstrate', 'show', [], []);
    this.addRule('transformation', 'simplify', 'implementation', 'doing', [], []);
    this.addRule('transformation', 'simplify', 'approximately', 'about', [], []);
    this.addRule('transformation', 'simplify', 'nevertheless', 'but', [], []);

    // Style rules
    this.addRule('style', 'hedge_weak', '<claim>', 'It may be that <claim>', ['claim'], []);
    this.addRule('style', 'hedge_strong', '<claim>', 'Evidence suggests that <claim>', ['claim'], []);
    this.addRule('style', 'nominalize_verb', '<V>', 'the <V-nom> of', ['V'], []);

    // Grammar rules
    this.addRule('grammar', 'sentence', 'NP VP', 'S', [], []);
    this.addRule('grammar', 'noun_phrase', 'DET N', 'NP', [], []);
    this.addRule('grammar', 'noun_phrase_adj', 'DET ADJ N', 'NP', [], []);
    this.addRule('grammar', 'verb_phrase', 'V NP', 'VP', [], []);
    this.addRule('grammar', 'verb_phrase_adv', 'V ADV', 'VP', [], []);

    // Inference rules
    this.addRule('inference', 'cause_effect', '<A> causes <B>', 'If <A> then <B>', ['A', 'B'], []);
    this.addRule('inference', 'is_a', '<X> is a <Y>', '<X> has properties of <Y>', ['X', 'Y'], []);

    this.save();
  }

  stats(): { total: number; byType: Record<string, number>; avgConfidence: number } {
    const byType: Record<string, number> = {};
    let totalConf = 0;
    for (const r of this.rules) {
      byType[r.type] = (byType[r.type] || 0) + 1;
      totalConf += r.confidence;
    }
    return {
      total: this.rules.length,
      byType,
      avgConfidence: this.rules.length > 0 ? totalConf / this.rules.length : 0,
    };
  }
}

export const ruleStore = new RuleStore();
ruleStore.seed();
