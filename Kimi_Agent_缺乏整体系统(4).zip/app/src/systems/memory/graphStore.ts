// ═══════════════════════════════════════════════════════════════
//  GRAPH STORE
//  Persistent semantic graph. The machine's long-term memory.
//  Nodes: concepts, objects, actions, rules, events, entities
//  Edges: relations with weights and confidence
// ═══════════════════════════════════════════════════════════════

import type { SGNode, SGEdge, NodeType } from '@/types';

const STORAGE_KEY = 'klein_graph_v1';

export class GraphStore {
  private nodes: Map<string, SGNode> = new Map();
  private edges: SGEdge[] = [];
  private dirty = false;

  constructor() {
    this.load();
  }

  // ── PERSISTENCE ───────────────────────────────────────────
  private load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const data = JSON.parse(raw);
        this.nodes = new Map(data.nodes);
        this.edges = data.edges;
      }
    } catch { /* empty graph is fine */ }
  }

  private save() {
    if (!this.dirty) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({
        nodes: Array.from(this.nodes.entries()),
        edges: this.edges,
      }));
      this.dirty = false;
    } catch { /* storage full */ }
  }

  // ── NODE OPERATIONS ──────────────────────────────────────
  addNode(label: string, type: NodeType, features: Record<string, unknown> = {}): SGNode {
    const id = `n_${type}_${label.toLowerCase().replace(/\s+/g, '_')}_${Date.now()}`;
    const node: SGNode = {
      id,
      type,
      label,
      features: features as Record<string, string | number | boolean>,
      createdAt: Date.now(),
      accessCount: 0,
    };
    this.nodes.set(id, node);
    this.dirty = true;
    this.save();
    return node;
  }

  getNode(id: string): SGNode | undefined {
    const n = this.nodes.get(id);
    if (n) { n.accessCount++; }
    return n;
  }

  findNode(label: string, type?: NodeType): SGNode | undefined {
    for (const n of this.nodes.values()) {
      if (n.label.toLowerCase() === label.toLowerCase() && (!type || n.type === type)) {
        n.accessCount++;
        return n;
      }
    }
    return undefined;
  }

  findOrCreate(label: string, type: NodeType, features?: Record<string, unknown>): SGNode {
    return this.findNode(label, type) || this.addNode(label, type, features);
  }

  // ── EDGE OPERATIONS ──────────────────────────────────────
  addEdge(from: string, to: string, relation: string, weight = 1.0, confidence = 0.5): SGEdge {
    // Update existing edge if found
    const existing = this.edges.find(e => e.from === from && e.to === to && e.relation === relation);
    if (existing) {
      existing.weight = Math.min(1, existing.weight + 0.1);
      existing.confidence = Math.min(1, existing.confidence + 0.05);
      this.dirty = true;
      this.save();
      return existing;
    }
    const edge: SGEdge = {
      id: `e_${from}_${relation}_${to}`,
      from, to, relation, weight, confidence,
      createdAt: Date.now(),
    };
    this.edges.push(edge);
    this.dirty = true;
    this.save();
    return edge;
  }

  getEdgesFrom(nodeId: string, relation?: string): SGEdge[] {
    return this.edges.filter(e => e.from === nodeId && (!relation || e.relation === relation));
  }

  getEdgesTo(nodeId: string, relation?: string): SGEdge[] {
    return this.edges.filter(e => e.to === nodeId && (!relation || e.relation === relation));
  }

  // ── GRAPH TRAVERSAL ─────────────────────────────────────
  neighbors(nodeId: string, depth = 1): Array<{ node: SGNode; path: SGEdge[] }> {
    const visited = new Set<string>();
    const results: Array<{ node: SGNode; path: SGEdge[] }> = [];
    const queue: Array<{ id: string; path: SGEdge[] }> = [{ id: nodeId, path: [] }];

    while (queue.length > 0) {
      const current = queue.shift()!;
      if (current.path.length >= depth) continue;

      const outgoing = this.edges.filter(e => e.from === current.id);
      for (const edge of outgoing) {
        const node = this.nodes.get(edge.to);
        if (!node || visited.has(edge.to)) continue;
        visited.add(edge.to);
        const newPath = [...current.path, edge];
        results.push({ node, path: newPath });
        queue.push({ id: edge.to, path: newPath });
      }
    }
    return results;
  }

  // ── SEMANTIC INFERENCE ──────────────────────────────────
  infer(subject: string, predicate: string): Array<{ object: string; confidence: number; path: string[] }> {
    const startNode = this.findNode(subject);
    if (!startNode) return [];

    const results: Array<{ object: string; confidence: number; path: string[] }> = [];

    // Direct edge check
    const direct = this.getEdgesFrom(startNode.id).filter(e => e.relation === predicate);
    for (const e of direct) {
      const target = this.nodes.get(e.to);
      if (target) results.push({ object: target.label, confidence: e.confidence, path: [predicate] });
    }

    // Path-based inference (A→B→C means A~~→C)
    const neighbors1 = this.getEdgesFrom(startNode.id);
    for (const e1 of neighbors1) {
      const mid = this.nodes.get(e1.to);
      if (!mid) continue;
      const e2s = this.getEdgesFrom(e1.to).filter(e => e.relation === predicate);
      for (const e2 of e2s) {
        const target = this.nodes.get(e2.to);
        if (target) {
          const conf = e1.confidence * e2.confidence * 0.7;
          results.push({ object: target.label, confidence: conf, path: [e1.relation, predicate] });
        }
      }
    }

    // Analogy: if A→X and B→X, then A~B
    const myEdges = this.getEdgesFrom(startNode.id);
    for (const myEdge of myEdges) {
      const sharedTargets = this.edges.filter(e => e.to === myEdge.to && e.from !== startNode.id);
      for (const other of sharedTargets) {
        const otherNode = this.nodes.get(other.from);
        if (!otherNode) continue;
        const theirPredEdges = this.getEdgesFrom(other.from).filter(e => e.relation === predicate);
        for (const tp of theirPredEdges) {
          const target = this.nodes.get(tp.to);
          if (target) {
            results.push({
              object: target.label,
              confidence: myEdge.confidence * other.confidence * tp.confidence * 0.5,
              path: [`analogy via ${otherNode.label}`, predicate],
            });
          }
        }
      }
    }

    return results.sort((a, b) => b.confidence - a.confidence);
  }

  // ── SIMILARITY ───────────────────────────────────────────
  similarity(a: string, b: string): number {
    const nodeA = this.findNode(a);
    const nodeB = this.findNode(b);
    if (!nodeA || !nodeB) return 0;

    // Shared neighbors
    const neighborsA = new Set(this.getEdgesFrom(nodeA.id).map(e => e.to));
    const neighborsB = new Set(this.getEdgesFrom(nodeB.id).map(e => e.to));
    const intersection = new Set([...neighborsA].filter(x => neighborsB.has(x)));
    const union = new Set([...neighborsA, ...neighborsB]);
    return union.size > 0 ? intersection.size / union.size : 0;
  }

  // ── BULK OPERATIONS ─────────────────────────────────────
  extractFromParse(tokens: Array<{ text: string; pos: string }>, deps: Array<{ gov: number; dep: number; rel: string }>): void {
    // Create entity nodes for nouns/proper nouns
    const entities: Array<{ node: SGNode; tokenIdx: number }> = [];
    tokens.forEach((tok, i) => {
      if (/^(NN|NNS|NNP|NNPS|PRP)$/.test(tok.pos)) {
        const node = this.findOrCreate(tok.text, 'entity', { pos: tok.pos });
        entities.push({ node, tokenIdx: i });
      }
      if (/^(VB|VBD|VBG|VBN|VBP|VBZ)$/.test(tok.pos)) {
        this.findOrCreate(tok.text, 'action', { pos: tok.pos });
      }
    });

    // Create edges from dependencies
    for (const d of deps) {
      const gov = tokens[d.gov];
      const dep = tokens[d.dep];
      if (!gov || !dep) continue;

      const govNode = this.findNode(gov.text);
      const depNode = this.findNode(dep.text);
      if (!govNode || !depNode) continue;

      const relation = d.rel.replace(/^(nsubj|nsubj:pass)$/, 'agentOf')
        .replace(/^(dobj|obj)$/, 'patientOf')
        .replace(/^(iobj)$/, 'recipientOf')
        .replace(/^(nmod|obl)$/, 'modifierOf')
        .replace(/^(amod)$/, 'propertyOf')
        .replace(/^(compound)$/, 'partOf')
        || d.rel;

      this.addEdge(govNode.id, depNode.id, relation, 0.8, 0.7);
    }
  }

  getGraphSnapshot(): { nodes: SGNode[]; edges: SGEdge[] } {
    return {
      nodes: Array.from(this.nodes.values()),
      edges: [...this.edges],
    };
  }

  stats(): { nodes: number; edges: number; nodeTypes: Record<string, number> } {
    const types: Record<string, number> = {};
    for (const n of this.nodes.values()) {
      types[n.type] = (types[n.type] || 0) + 1;
    }
    return { nodes: this.nodes.size, edges: this.edges.length, nodeTypes: types };
  }

  clear() {
    this.nodes.clear();
    this.edges = [];
    this.dirty = true;
    this.save();
  }
}

export const graphStore = new GraphStore();
