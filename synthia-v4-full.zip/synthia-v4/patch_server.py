"""
patch_server.py
Runs once at Docker build time.
Adds 3 things to server.py:
  1. Serves static/index.html (SYNTHIA OS) at /
  2. Mounts engine_router at /engine/*
  3. Starts signal_server as background thread
"""
import shutil
from pathlib import Path

SERVER = Path("server.py")
if not SERVER.exists():
    print("server.py not found — skipping patch")
    exit(0)

src = SERVER.read_text()

if "engine_router" in src:
    print("Already patched — skipping")
    exit(0)

shutil.copy(SERVER, "server.py.bak")

IMPORTS = "\nfrom fastapi.staticfiles import StaticFiles\nfrom fastapi.responses import FileResponse\nimport threading\n"

MOUNT_BLOCK = '''
# ── SYNTHIA OS UI ─────────────────────────────────────────────
import os as _os
_static = _os.path.join(_os.path.dirname(__file__), "static")
if _os.path.isdir(_static):
    app.mount("/static", StaticFiles(directory=_static), name="static")

@app.get("/ui", response_class=FileResponse)
@app.get("/os", response_class=FileResponse)
async def serve_os():
    idx = _os.path.join(_static, "index.html")
    if _os.path.exists(idx):
        return FileResponse(idx, media_type="text/html")
    return HTMLResponse("<h1>SYNTHIA OS not found</h1>")

# Serve OS at root if no other handler
@app.get("/", response_class=FileResponse, include_in_schema=False)
async def serve_root():
    idx = _os.path.join(_static, "index.html")
    if _os.path.exists(idx):
        return FileResponse(idx, media_type="text/html")
    return HTMLResponse("<h1>SYNTHIA</h1>")

# ── ENGINE ROUTER ─────────────────────────────────────────────
try:
    from engines.engine_router import engine_router
    app.include_router(engine_router)
    print("[server] Engine router mounted at /engine/*")
except Exception as _er:
    try:
        from engine_router import engine_router
        app.include_router(engine_router)
        print("[server] Engine router mounted at /engine/*")
    except Exception as _er2:
        print(f"[server] Engine router not loaded: {_er2}")

# ── SIGNAL SERVER THREAD ──────────────────────────────────────
def _run_signal():
    try:
        import asyncio as _aio
        import signal_server as _ss
        _aio.run(_ss.main())
    except Exception as _e:
        print(f"[signal] {_e}")
threading.Thread(target=_run_signal, daemon=True).start()
'''

# 1. Add imports
if "from fastapi.staticfiles import StaticFiles" not in src:
    src = src.replace(
        "from fastapi.responses import JSONResponse, HTMLResponse",
        "from fastapi.responses import JSONResponse, HTMLResponse, FileResponse" + IMPORTS,
        1
    )

# 2. Add mount block after middleware
mw = 'app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])'
if mw in src:
    src = src.replace(mw, mw + MOUNT_BLOCK, 1)
else:
    # Fallback: append before if __name__
    src = src.replace(
        'if __name__ == "__main__":',
        MOUNT_BLOCK + '\nif __name__ == "__main__":',
        1
    )

SERVER.write_text(src)
print("server.py patched successfully")
print("  + Serves SYNTHIA OS at /")
print("  + Engine router at /engine/*")
print("  + Signal server thread on :8765")
