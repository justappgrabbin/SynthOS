# SYNTHIA OS — Docker Setup

One container. Self-hosted. Show Joe this.

## What's running

```
Container port 8000
├── GET /          → SYNTHIA OS (the full OS interface)
├── GET /health    → health check  
├── POST /engine/* → all Python engines
├── POST /trident/ → Trident inference
├── POST /oracle/  → Cynthia oracle
├── POST /consciousness/ → HD chart + GNN
└── WS  :8765      → WebRTC signaling (background thread)
```

## Run it (from the repo root)

```bash
# 1. Clone your repo
git clone https://github.com/justappgrabbin/Synthia-server.git
cd Synthia-server

# 2. Copy this whole synthia-v4 folder into the repo
# (drag the contents in or copy via terminal)

# 3. Set up env
cp .env.example .env
# Edit .env — add your Supabase key and Anthropic key

# 4. Build and start
docker compose up --build

# That's it. Open http://localhost:8000 in your browser.
```

## On Android (same WiFi as your laptop/server)

```bash
# Find your machine's IP
ip addr | grep "inet " | grep -v 127   # Linux
ipconfig | grep "IPv4"                  # Windows

# Open in Chrome on Android:
http://192.168.x.x:8000
```

## What Joe will see

- Full OS interface — home screen with widgets, dimensional field bars
- Drop any file into App Center → real local analysis (5W, address, CHNOPS)
- Organ generated instantly, no cloud needed
- Settings → Server → paste http://localhost:8000 to connect engines
- Terminal → type `engine` to see all systems status

## What the engines do locally (no stubs)

| Engine | What |
|--------|------|
| AddressEngine | Derives B.T.C.G.L address from file content via real hash |
| CHNOPS | 64-gate biochemical vectors + cosine resonance scoring |
| MorphPatch v28 | Behavior graph compiler → generates executable HTML organ |
| FiveW | WHO/WHAT/WHERE/WHEN/WHY local pattern analysis |
| MorphBus | Message passing between all components |
| GlobalIndex | Artifact registry, need broadcasting |

## Troubleshooting

**Port already in use:**
```bash
docker compose down
docker compose up --build
```

**Can't connect from phone:**
- Make sure phone and laptop are on same WiFi
- Disable firewall temporarily or allow port 8000

**Engines offline:**
- Check Settings → Server → enter `http://localhost:8000` → Test
- Or just use the OS standalone — all local engines run in the browser
