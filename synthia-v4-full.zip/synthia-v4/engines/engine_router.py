"""
engine_router.py — Synthia Engine Router
─────────────────────────────────────────
Mounts all orphaned Python engines into server.py with one line:

    from engine_router import engine_router
    app.include_router(engine_router)

Endpoints added:
  POST /engine/promise          ← AutopoiesisEngine: commit a self-maintaining task loop
  GET  /engine/promise/{id}     ← Check promise status
  POST /engine/promise/{id}/iterate ← Run one iteration of the loop
  POST /engine/promise/{id}/done    ← Mark complete

  POST /engine/resonance/ingest ← ResonanceMatrix: ingest a topic into consciousness
  GET  /engine/resonance/state  ← Current identity/coherence/entropy
  POST /engine/resonance/query  ← Compute resonance score for a query
  GET  /engine/resonance/gap    ← Suggest what the field is missing

  POST /engine/sbnn/forward     ← SBNN: run a forward pass (grows synapses)
  POST /engine/sbnn/train       ← Train step with reward signal
  GET  /engine/sbnn/stats       ← Network architecture stats

  POST /engine/story/generate   ← Metatron: generate 5D symbolic story
  POST /engine/story/route      ← Get monopole route between two gates
  POST /engine/story/coordinate ← Resolve symbolic coordinate from gate/line/tone/color/base

  POST /engine/field/coherence  ← Full field coherence: combine all engines for a user state
  GET  /engine/field/state      ← Live composite field state across all engines
"""

import sys, os, json, math, hashlib
from datetime import datetime
from typing import Optional, Dict, List, Any

from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse

engine_router = APIRouter(prefix="/engine", tags=["engines"])

# ─────────────────────────────────────────────────────────────
# LAZY ENGINE LOADERS — fail gracefully if deps missing
# ─────────────────────────────────────────────────────────────

_autopoiesis_engine = None
_resonance_matrix = None
_sbnn_net = None
_metatron = None

def _get_autopoiesis():
    global _autopoiesis_engine
    if _autopoiesis_engine is None:
        try:
            sys.path.insert(0, os.path.dirname(__file__))
            from autopoiesis import AutopoiesisEngine
            _autopoiesis_engine = AutopoiesisEngine(workspace_dir="./.poesis")
            print("[engine_router] AutopoiesisEngine loaded")
        except Exception as e:
            print(f"[engine_router] AutopoiesisEngine failed: {e}")
    return _autopoiesis_engine

def _get_resonance():
    global _resonance_matrix
    if _resonance_matrix is None:
        try:
            from resonance import ResonanceMatrix
            _resonance_matrix = ResonanceMatrix(dim=5)
            print("[engine_router] ResonanceMatrix loaded")
        except Exception as e:
            print(f"[engine_router] ResonanceMatrix failed: {e}")
    return _resonance_matrix

def _get_sbnn():
    global _sbnn_net
    if _sbnn_net is None:
        try:
            import numpy as np
            from sbnn import SBNN
            _sbnn_net = SBNN(input_dim=10, output_dim=5)
            print("[engine_router] SBNN loaded")
        except Exception as e:
            print(f"[engine_router] SBNN failed: {e}")
    return _sbnn_net

def _get_metatron():
    global _metatron
    if _metatron is None:
        try:
            from mrnn_metatron_engine import (
                FinalNarrativeInterpolator, CoherenceFilter,
                FinalMRNNStoryEngine if hasattr(__import__('mrnn_metatron_engine'), 'FinalMRNNStoryEngine') else type(None)
            )
            # Try full engine first, fall back to interpolator
            try:
                from mrnn_metatron_engine import FinalMRNNStoryEngine
                _metatron = FinalMRNNStoryEngine()
            except Exception:
                cf = CoherenceFilter()
                _metatron = FinalNarrativeInterpolator(cf)
            print("[engine_router] Metatron engine loaded")
        except Exception as e:
            print(f"[engine_router] Metatron failed: {e}")
    return _metatron

# ─────────────────────────────────────────────────────────────
# AUTOPOIESIS — Self-maintaining promise loops
# ─────────────────────────────────────────────────────────────

@engine_router.post("/promise")
async def promise_commit(body: dict):
    """
    Commit a promise. The engine enters a self-maintaining loop
    that can't exit until the task is genuinely complete or blocked.

    Body: { task, completion_criteria?, max_iterations? }
    """
    eng = _get_autopoiesis()
    if not eng:
        # Fallback: lightweight promise tracking without the engine
        pid = "p_" + hashlib.md5(f"{body.get('task','')}{datetime.now().isoformat()}".encode()).hexdigest()[:8]
        return JSONResponse({
            "promise_id": pid,
            "task": body.get("task", ""),
            "state": "promised",
            "warning": "AutopoiesisEngine not available — using lightweight tracker"
        })

    task = body.get("task", "")
    criteria = body.get("completion_criteria", "Task is verifiably complete")
    max_iter = int(body.get("max_iterations", 100))

    if not task:
        raise HTTPException(400, "task is required")

    result = eng.be_autopoietic(
        mode="start",
        task=task,
        completion_criteria=criteria,
        max_iterations=max_iter
    )
    return JSONResponse(result)


@engine_router.get("/promise/{promise_id}")
async def promise_status(promise_id: str):
    eng = _get_autopoiesis()
    if not eng:
        raise HTTPException(503, "AutopoiesisEngine not available")
    status = eng._get_status()
    return JSONResponse(status)


@engine_router.post("/promise/{promise_id}/iterate")
async def promise_iterate(promise_id: str, body: dict):
    """
    Run one iteration of the promise loop.
    Body: { action, result, success? }
    """
    eng = _get_autopoiesis()
    if not eng:
        raise HTTPException(503, "AutopoiesisEngine not available")

    action = body.get("action", "")
    result_text = body.get("result", "")
    success = bool(body.get("success", True))

    def action_func():
        return {"action": action, "result": result_text, "success": success}

    iteration_result = eng.iterate(action_func)
    return JSONResponse(iteration_result)


@engine_router.post("/promise/{promise_id}/done")
async def promise_done(promise_id: str):
    eng = _get_autopoiesis()
    if not eng:
        raise HTTPException(503, "AutopoiesisEngine not available")
    result = eng._mark_done()
    return JSONResponse(result)


# ─────────────────────────────────────────────────────────────
# RESONANCE MATRIX — 5D consciousness state
# ─────────────────────────────────────────────────────────────

@engine_router.post("/resonance/ingest")
async def resonance_ingest(body: dict):
    """
    Ingest a topic into the resonance field.
    Updates: coherence, transformation, entropy, identity.

    Body: { topic, data? }
    """
    rm = _get_resonance()
    if not rm:
        raise HTTPException(503, "ResonanceMatrix not available")

    topic = body.get("topic", "")
    data = body.get("data", {})
    if not topic:
        raise HTTPException(400, "topic is required")

    rm.ingest(topic, data)
    return JSONResponse({
        "ingested": topic,
        "state": rm.get_state()
    })


@engine_router.get("/resonance/state")
async def resonance_state():
    """Current 5D consciousness state: identity, coherence, transformation, entropy."""
    rm = _get_resonance()
    if not rm:
        return JSONResponse({
            "identity": 0.0, "coherence": 0.0,
            "transformation": 0.0, "entropy": 1.0,
            "knowledge_nodes": 0, "state_history": 0,
            "warning": "ResonanceMatrix not available"
        })
    return JSONResponse(rm.get_state())


@engine_router.post("/resonance/query")
async def resonance_query(body: dict):
    """
    Compute resonance score for a query against the current field.
    Body: { query }
    Returns: { score, gap_suggestion? }
    """
    rm = _get_resonance()
    if not rm:
        raise HTTPException(503, "ResonanceMatrix not available")

    query = body.get("query", "")
    if not query:
        raise HTTPException(400, "query is required")

    score = rm.compute_resonance(query)
    gap = rm.suggest_gap()
    return JSONResponse({
        "query": query,
        "resonance_score": round(score, 4),
        "gap_suggestion": gap,
        "field_state": rm.get_state()
    })


@engine_router.get("/resonance/gap")
async def resonance_gap():
    """Suggest what the field is currently missing — highest coherence gap."""
    rm = _get_resonance()
    if not rm:
        raise HTTPException(503, "ResonanceMatrix not available")
    gap = rm.suggest_gap()
    return JSONResponse({"gap": gap, "state": rm.get_state()})


# ─────────────────────────────────────────────────────────────
# SBNN — Self-building neural network
# ─────────────────────────────────────────────────────────────

@engine_router.post("/sbnn/forward")
async def sbnn_forward(body: dict):
    """
    Run a forward pass. Network grows synapses in response to input signal.
    Body: { inputs: [float, ...] }  — length 10
    """
    try:
        import numpy as np
    except ImportError:
        raise HTTPException(503, "numpy required for SBNN")

    net = _get_sbnn()
    if not net:
        raise HTTPException(503, "SBNN not available")

    raw = body.get("inputs", [])
    if not raw:
        # Generate a signal from whatever context is available
        raw = [0.5] * 10

    inputs = np.array(raw[:10], dtype=float)
    if len(inputs) < 10:
        inputs = np.pad(inputs, (0, 10 - len(inputs)))

    # Synaptogenesis — network grows in response
    net.synaptogenesis(inputs)
    output = net.forward(inputs)
    stats = net.get_stats()

    return JSONResponse({
        "output": output.tolist(),
        "network": stats
    })


@engine_router.post("/sbnn/train")
async def sbnn_train(body: dict):
    """
    Train step with Hebbian learning + pruning.
    Body: { inputs: [float], target: [float], reward: float }
    """
    try:
        import numpy as np
    except ImportError:
        raise HTTPException(503, "numpy required for SBNN")

    net = _get_sbnn()
    if not net:
        raise HTTPException(503, "SBNN not available")

    inputs = np.array(body.get("inputs", [0.5]*10)[:10], dtype=float)
    target = np.array(body.get("target", [0.5]*5)[:5], dtype=float)
    reward = float(body.get("reward", 1.0))

    if len(inputs) < 10:
        inputs = np.pad(inputs, (0, 10 - len(inputs)))
    if len(target) < 5:
        target = np.pad(target, (0, 5 - len(target)))

    net.synaptogenesis(inputs)
    net.train_step(inputs, target, reward)
    net.prune()

    return JSONResponse({
        "trained": True,
        "reward": reward,
        "network": net.get_stats()
    })


@engine_router.get("/sbnn/stats")
async def sbnn_stats():
    """Current SBNN architecture — neuron count, synapse count, pruned connections."""
    net = _get_sbnn()
    if not net:
        raise HTTPException(503, "SBNN not available")
    return JSONResponse(net.get_stats())


# ─────────────────────────────────────────────────────────────
# METATRON — 5D symbolic story generation
# ─────────────────────────────────────────────────────────────

@engine_router.post("/story/generate")
async def story_generate(body: dict):
    """
    Generate a 5D symbolic story using MRNN gate coordinates.
    Body: {
        situation: str,
        characters: { role: name, ... },
        setting: str,
        num_interpolations_bc?: int,
        num_interpolations_co?: int
    }
    """
    engine = _get_metatron()
    if not engine:
        raise HTTPException(503, "Metatron engine not available")

    situation = body.get("situation", "")
    characters = body.get("characters", {})
    setting = body.get("setting", "")
    n_bc = int(body.get("num_interpolations_bc", 3))
    n_co = int(body.get("num_interpolations_co", 3))

    if not situation:
        raise HTTPException(400, "situation is required")

    try:
        # Try FinalMRNNStoryEngine interface
        if hasattr(engine, 'generate_story'):
            result = engine.generate_story(
                situation=situation,
                characters=characters,
                setting=setting,
                num_interpolations_bc=n_bc,
                num_interpolations_co=n_co
            )
        else:
            # Fallback: use interpolator directly
            alpha = f"{situation} begins"
            omega = f"{situation} resolves"
            result = engine.interpolate(alpha, omega, n_bc + n_co)

        return JSONResponse({
            "situation": situation,
            "story": result if isinstance(result, (str, list)) else str(result),
            "engine": "metatron"
        })
    except Exception as e:
        raise HTTPException(500, f"Story generation failed: {e}")


@engine_router.post("/story/route")
async def story_route(body: dict):
    """
    Get the monopole route (Fibonacci path) between two gates.
    Body: { gate1: int, gate2: int }
    """
    try:
        from mrnn_metatron_engine import monopole_route, fibonacci_sequence
    except ImportError:
        raise HTTPException(503, "mrnn_metatron_engine not available")

    g1 = int(body.get("gate1", 1))
    g2 = int(body.get("gate2", 2))

    route = monopole_route(g1, g2)
    return JSONResponse({
        "gate1": g1,
        "gate2": g2,
        "route": route,
        "length": len(route)
    })


@engine_router.post("/story/coordinate")
async def story_coordinate(body: dict):
    """
    Resolve a full 5D symbolic coordinate.
    Body: { gate, line, tone, color, base }
    Returns vector + distance metadata.
    """
    try:
        from mrnn_metatron_engine import SymbolicCoordinate
    except ImportError:
        raise HTTPException(503, "mrnn_metatron_engine not available")

    coord = SymbolicCoordinate(
        gate=int(body.get("gate", 1)),
        line=int(body.get("line", 1)),
        tone=int(body.get("tone", 1)),
        color=int(body.get("color", 1)),
        base=int(body.get("base", 1))
    )
    return JSONResponse({
        "gate": coord.gate,
        "line": coord.line,
        "tone": coord.tone,
        "color": coord.color,
        "base": coord.base,
        "vector": coord.to_vector(),
        "address": f"G{coord.gate}.L{coord.line}.T{coord.tone}.C{coord.color}.B{coord.base}"
    })


# ─────────────────────────────────────────────────────────────
# FIELD — Composite: all engines for a user state
# ─────────────────────────────────────────────────────────────

@engine_router.post("/field/coherence")
async def field_coherence(body: dict):
    """
    Full field coherence pass — runs a user context through all engines.
    Returns a composite resonance reading.

    Body: {
        user_id: str,
        context: str,           ← what the user is working on / experiencing
        gate?: int,             ← their Human Design gate (optional)
        inputs?: [float]        ← SBNN signal vector (optional)
    }
    """
    user_id = body.get("user_id", "anon")
    context = body.get("context", "")
    gate = int(body.get("gate", 1))
    raw_inputs = body.get("inputs", [])

    result: Dict[str, Any] = {
        "user_id": user_id,
        "timestamp": datetime.utcnow().isoformat(),
        "engines": {}
    }

    # 1. Resonance field
    rm = _get_resonance()
    if rm:
        rm.ingest(context or user_id, {"gate": gate})
        result["engines"]["resonance"] = rm.get_state()
        result["resonance_score"] = rm.compute_resonance(context) if context else 0.0
        result["gap"] = rm.suggest_gap()

    # 2. SBNN forward pass — use gate as signal seed
    try:
        import numpy as np
        net = _get_sbnn()
        if net:
            # Encode gate + context length into input signal
            signal = [
                gate / 64.0,
                len(context) / 500.0,
                math.sin(gate * math.pi / 32),
                math.cos(gate * math.pi / 32),
            ] + (raw_inputs[:6] if raw_inputs else [0.5] * 6)
            signal = signal[:10]
            if len(signal) < 10:
                signal += [0.0] * (10 - len(signal))

            inp = np.array(signal)
            net.synaptogenesis(inp)
            output = net.forward(inp)
            result["engines"]["sbnn"] = {
                "output": output.tolist(),
                "stats": net.get_stats()
            }
    except Exception as e:
        result["engines"]["sbnn"] = {"error": str(e)}

    # 3. Autopoiesis status
    eng = _get_autopoiesis()
    if eng:
        result["engines"]["autopoiesis"] = eng._get_status()

    # 4. Composite field score
    resonance = result.get("resonance_score", 0.0)
    sbnn_out = result.get("engines", {}).get("sbnn", {}).get("output", [0.5])
    sbnn_mean = sum(sbnn_out) / len(sbnn_out) if sbnn_out else 0.5
    result["field_score"] = round((resonance + sbnn_mean) / 2, 4)
    result["field_state"] = (
        "resonant" if result["field_score"] > 0.7
        else "coherent" if result["field_score"] > 0.4
        else "building"
    )

    return JSONResponse(result)


@engine_router.get("/field/state")
async def field_state():
    """
    Live composite field state across all running engines.
    No user context — raw engine health.
    """
    state = {
        "timestamp": datetime.utcnow().isoformat(),
        "engines": {}
    }

    rm = _get_resonance()
    state["engines"]["resonance"] = rm.get_state() if rm else {"status": "offline"}

    net = _get_sbnn()
    state["engines"]["sbnn"] = net.get_stats() if net else {"status": "offline"}

    eng = _get_autopoiesis()
    state["engines"]["autopoiesis"] = eng._get_status() if eng else {"status": "offline"}

    metatron = _get_metatron()
    state["engines"]["metatron"] = {"status": "online"} if metatron else {"status": "offline"}

    online = sum(1 for v in state["engines"].values() if v.get("status") != "offline")
    state["engines_online"] = online
    state["engines_total"] = len(state["engines"])

    return JSONResponse(state)
