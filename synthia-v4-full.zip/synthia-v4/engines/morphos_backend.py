#!/usr/bin/env python3
"""
MORPHOS BACKEND — JSPyBridge Server
=====================================

Integrates:
- address_space_engine (deterministic coordinate resolution)
- dms360_engine (pure integer DMS arithmetic)
- isomorphic_framework (universal topology engine)
- mesh_os_kernel (microkernel OS mesh)
- autoling_runtime (semantic embeddings, actors, ontology)
- linguistic_mesh_router (5 Ws pipeline)

Serves:
- WebSocket mesh communication
- HTTP API for file analysis/regeneration
- Pyodide-compatible endpoints
- Auto-writer pipeline

Usage:
    python morphos_backend.py
"""

import asyncio
import websockets
import json
import hashlib
import base64
import io
import zipfile
import tarfile
import os
import sys
import time
import uuid
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple, Set
from dataclasses import dataclass, asdict
from datetime import datetime
from enum import Enum, auto

# Import uploaded modules (they'll be in the same directory)
# These are the user's uploaded files integrated into the backend
from address_space_engine import AddressSpaceEngine, Address, StateSpace, Planet, Dimension, Gate, Line, Color, Tone, Base, Zodiac, House
from dms360_engine import DMSEngine, DMS360, DMS60
from isomorphic_framework import UniversalKernel, AstrologicalInterpretation, OSMeshInterpretation, TopologyEngine
from mesh_os_kernel import MeshKernel, MeshAddress, MeshPacket, Endpoint, Capability, NodeType, Subsystem
from autoling_runtime_v2 import AutoLingRuntime, IChingAddress, SemanticEmbedder, Message, Actor, OntologyRegistry
from linguistic_mesh_router import LinguisticMeshRouter

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

CONFIG = {
    "WS_PORT": 8765,
    "HTTP_PORT": 8080,
    "HOST": "0.0.0.0",
    "MESH_NODES": 64,
    "MAX_FILE_SIZE": 50 * 1024 * 1024,  # 50MB
    "SUPPORTED_EXTENSIONS": {
        "js", "ts", "jsx", "tsx", "py", "zip", "tar", "gz", "jpg", "jpeg",
        "png", "gif", "svg", "mp3", "mp4", "mpeg", "html", "xml", "json",
        "css", "kt", "java", "go", "rs", "cpp", "c", "rb", "php", "swift",
        "dart", "md", "txt", "pdf", "wasm", "sql", "yaml", "toml"
    }
}

# ═══════════════════════════════════════════════════════════════════════════════
# FILE ANALYSIS ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

class FileAnalyzer:
    """Analyzes any file type and extracts structure, relationships, purpose."""

    TYPE_MAP = {
        "js": {"lang": "javascript", "category": "script"},
        "ts": {"lang": "typescript", "category": "script"},
        "jsx": {"lang": "jsx", "category": "component"},
        "tsx": {"lang": "tsx", "category": "component"},
        "py": {"lang": "python", "category": "script"},
        "zip": {"lang": "archive", "category": "bundle"},
        "tar": {"lang": "archive", "category": "bundle"},
        "gz": {"lang": "archive", "category": "bundle"},
        "jpg": {"lang": "image", "category": "asset"},
        "jpeg": {"lang": "image", "category": "asset"},
        "png": {"lang": "image", "category": "asset"},
        "gif": {"lang": "image", "category": "asset"},
        "svg": {"lang": "svg", "category": "asset"},
        "mp3": {"lang": "audio", "category": "asset"},
        "mp4": {"lang": "video", "category": "asset"},
        "mpeg": {"lang": "video", "category": "asset"},
        "html": {"lang": "html", "category": "markup"},
        "xml": {"lang": "xml", "category": "markup"},
        "json": {"lang": "json", "category": "data"},
        "css": {"lang": "css", "category": "style"},
        "kt": {"lang": "kotlin", "category": "script"},
        "java": {"lang": "java", "category": "script"},
        "go": {"lang": "go", "category": "script"},
        "rs": {"lang": "rust", "category": "script"},
        "cpp": {"lang": "cpp", "category": "script"},
        "c": {"lang": "c", "category": "script"},
        "rb": {"lang": "ruby", "category": "script"},
        "php": {"lang": "php", "category": "script"},
        "swift": {"lang": "swift", "category": "script"},
        "dart": {"lang": "dart", "category": "script"},
        "md": {"lang": "markdown", "category": "doc"},
        "txt": {"lang": "text", "category": "doc"},
        "pdf": {"lang": "pdf", "category": "doc"},
        "wasm": {"lang": "wasm", "category": "binary"},
        "sql": {"lang": "sql", "category": "data"},
        "yaml": {"lang": "yaml", "category": "data"},
        "toml": {"lang": "toml", "category": "data"},
    }

    def __init__(self):
        self.address_engine = AddressSpaceEngine()
        self.dms_engine = DMSEngine()
        self.isomorphic = UniversalKernel(offset_b=15.0)

    def analyze(self, filename: str, content: bytes) -> Dict[str, Any]:
        ext = Path(filename).suffix.lstrip(".").lower()
        info = self.TYPE_MAP.get(ext, {"lang": "unknown", "category": "unknown"})

        analysis = {
            "filename": filename,
            "extension": ext,
            "size": len(content),
            "language": info["lang"],
            "category": info["category"],
            "hash": hashlib.sha256(content).hexdigest()[:16],
            "structure": {},
            "relationships": {},
            "purpose": "unknown",
            "mesh_address": None,
            "timestamp": datetime.now().isoformat()
        }

        # Generate deterministic mesh address from file hash
        hash_int = int(analysis["hash"], 16)
        theta = (hash_int % 360000) / 1000.0

        # Use address space engine to resolve coordinate
        address = Address(
            planet=Planet.SUN,
            dimension=Dimension.BEING,
            gate=Gate((hash_int % 64) + 1),
            line=Line((hash_int % 6) + 1),
            color=Color((hash_int % 6) + 1),
            tone=Tone((hash_int % 6) + 1),
            base=Base((hash_int % 5) + 1),
            degree=int(theta) % 30,
            minute=(hash_int // 360) % 60,
            second=float(hash_int % 60),
            axis="toward",
            zodiac=Zodiac((int(theta / 30) % 12) + 1),
            house=House((hash_int % 12) + 1)
        )

        analysis["mesh_address"] = address.to_dict()

        # Build state space from address
        state_space = StateSpace(address)
        analysis["state_space"] = {
            "resonance": state_space.resonance,
            "vector_shape": state_space.vector.shape
        }

        # Analyze content based on type
        if info["category"] in ("script", "component", "markup", "style"):
            text = content.decode("utf-8", errors="ignore")
            analysis["structure"] = self._analyze_code(text, info["lang"])
            analysis["relationships"] = self._extract_relationships(text)
            analysis["purpose"] = self._infer_purpose(text, info["lang"])
        elif info["category"] == "archive":
            analysis["structure"] = self._analyze_archive(content, ext)
        elif info["category"] == "asset":
            analysis["structure"] = self._analyze_media(content, ext)
        elif info["category"] == "data":
            text = content.decode("utf-8", errors="ignore")
            analysis["structure"] = self._analyze_data(text, ext)

        return analysis

    def _analyze_code(self, text: str, lang: str) -> Dict:
        lines = text.split("\n")
        structure = {
            "total_lines": len(lines),
            "total_chars": len(text),
            "functions": 0,
            "classes": 0,
            "imports": [],
            "exports": [],
            "comments": 0,
            "blank_lines": 0,
            "complexity": 0
        }

        # Language-specific patterns
        patterns = {
            "javascript": {
                "func": r"(?:function|const|let|var)\s+\w+\s*=\s*(?:async\s*)?(?:function)?\s*\(|\w+\s*\(\s*\w*\s*\)\s*=>",
                "class": r"class\s+\w+",
                "import": r"(?:import|require)\s*\(?['"]([^'"]+)['"]",
                "export": r"export\s+(?:default\s+)?(?:class|function|const|let|var)?\s*(\w+)"
            },
            "typescript": {
                "func": r"(?:function|const|let|var)\s+\w+\s*[:=]\s*(?:async\s*)?(?:<[^>]+>)?\s*(?:\([^)]*\))\s*=>|function\s+\w+",
                "class": r"(?:class|interface)\s+\w+",
                "import": r"import\s+.*?\s+from\s+['"]([^'"]+)['"]|import\s*\(['"]([^'"]+)['"]\)",
                "export": r"export\s+(?:default\s+)?(?:class|function|interface|const|let|var|type)?\s*(\w+)"
            },
            "python": {
                "func": r"def\s+\w+\s*\(",
                "class": r"class\s+\w+",
                "import": r"(?:import|from)\s+([\w.]+)",
                "export": r"__all__\s*=\s*\[(.*?)\]"
            }
        }

        import re
        lang_patterns = patterns.get(lang, patterns["javascript"])

        for pattern_name, pattern in lang_patterns.items():
            matches = re.findall(pattern, text)
            if pattern_name == "func":
                structure["functions"] = len(matches)
            elif pattern_name == "class":
                structure["classes"] = len(matches)
            elif pattern_name == "import":
                structure["imports"] = [m[0] if isinstance(m, tuple) else m for m in matches][:20]
            elif pattern_name == "export":
                structure["exports"] = [m[0] if isinstance(m, tuple) else m for m in matches][:20]

        structure["comments"] = len(re.findall(r"(?:#|//|/\*|\*|<!\--)", text))
        structure["blank_lines"] = len([l for l in lines if not l.strip()])
        structure["complexity"] = structure["functions"] + structure["classes"] * 2 + len(structure["imports"])

        return structure

    def _extract_relationships(self, text: str) -> Dict:
        import re
        return {
            "calls": re.findall(r"\b(\w+)\s*\(", text)[:50],
            "inherits": re.findall(r"(?:extends|implements)\s+(\w+)", text),
            "composes": re.findall(r"(?:new|create)\s+(\w+)", text)[:20],
            "uses": re.findall(r"(?:use|import|require)\s*\(?['"]([^'"]+)['"]", text)[:20]
        }

    def _infer_purpose(self, text: str, lang: str) -> str:
        text_lower = text.lower()
        purposes = []
        if "server" in text_lower or "api" in text_lower or "route" in text_lower:
            purposes.append("backend")
        if "react" in text_lower or "component" in text_lower or "jsx" in text_lower:
            purposes.append("frontend")
        if "test" in text_lower or "spec" in text_lower or "jest" in text_lower:
            purposes.append("testing")
        if "build" in text_lower or "webpack" in text_lower or "rollup" in text_lower:
            purposes.append("build-tool")
        if "cli" in text_lower or "command" in text_lower or "argv" in text_lower:
            purposes.append("cli")
        if not purposes:
            purposes.append("utility")
        return ", ".join(purposes)

    def _analyze_archive(self, content: bytes, ext: str) -> Dict:
        structure = {"files": [], "total_size": len(content), "type": ext}
        try:
            if ext == "zip":
                with zipfile.ZipFile(io.BytesIO(content)) as zf:
                    structure["files"] = [{"name": info.filename, "size": info.file_size} for info in zf.infolist()][:50]
            elif ext in ("tar", "gz"):
                with tarfile.open(fileobj=io.BytesIO(content), mode="r:*") as tf:
                    structure["files"] = [{"name": m.name, "size": m.size} for m in tf.getmembers()][:50]
        except Exception as e:
            structure["error"] = str(e)
        return structure

    def _analyze_media(self, content: bytes, ext: str) -> Dict:
        return {
            "size": len(content),
            "format": ext.upper(),
            "hash": hashlib.sha256(content).hexdigest()[:16],
            "dimensions": "unknown",  # Would need PIL for actual dimensions
            "type": "binary"
        }

    def _analyze_data(self, text: str, ext: str) -> Dict:
        import json
        structure = {"format": ext, "size": len(text)}
        if ext == "json":
            try:
                data = json.loads(text)
                structure["keys"] = list(data.keys())[:20] if isinstance(data, dict) else []
                structure["items"] = len(data) if isinstance(data, (list, dict)) else 0
            except:
                structure["valid"] = False
        return structure

# ═══════════════════════════════════════════════════════════════════════════════
# APP REGENERATION ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

class AppRegenerator:
    """Regenerates any file into a browser-friendly executable app."""

    def __init__(self):
        self.analyzer = FileAnalyzer()
        self.autoling = AutoLingRuntime()

    def regenerate(self, analysis: Dict[str, Any], target: str = "browser") -> Dict[str, Any]:
        """Regenerate analyzed file into a new browser app."""
        app_id = f"app-{uuid.uuid4().hex[:8]}"
        category = analysis["category"]
        lang = analysis["language"]

        # Route through AutoLing mesh pipeline
        mesh_result = asyncio.run(self.autoling.ingest(
            f"Regenerate {analysis['filename']} as {target} app",
            "text"
        ))

        # Generate app based on category
        if category in ("script", "component", "markup", "style"):
            app_html = self._generate_code_app(analysis, app_id)
        elif category == "asset":
            app_html = self._generate_media_app(analysis, app_id)
        elif category == "archive":
            app_html = self._generate_archive_app(analysis, app_id)
        elif category == "data":
            app_html = self._generate_data_app(analysis, app_id)
        else:
            app_html = self._generate_generic_app(analysis, app_id)

        return {
            "app_id": app_id,
            "html": app_html,
            "analysis": analysis,
            "mesh_pipeline": mesh_result,
            "target": target,
            "timestamp": datetime.now().isoformat()
        }

    def _generate_code_app(self, analysis: Dict, app_id: str) -> str:
        info = analysis
        struct = analysis.get("structure", {})
        addr = analysis.get("mesh_address", {})

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{info['filename']} — Regenerated</title>
<style>
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{ font-family: -apple-system, system-ui, sans-serif; background: #0a0a0a; color: #e8e8e8; min-height: 100vh; }}
.container {{ max-width: 100%; padding: 16px; }}
.header {{ background: #1e1e1e; border-radius: 16px; padding: 16px; margin-bottom: 16px; border: 1px solid rgba(255,255,255,0.05); }}
.title {{ font-size: 20px; font-weight: 700; color: #00d4aa; display: flex; align-items: center; gap: 10px; }}
.meta {{ display: flex; flex-wrap: wrap; gap: 6px; margin-top: 10px; }}
.badge {{ display: inline-flex; padding: 4px 10px; background: #00d4aa; color: #000; border-radius: 12px; font-size: 11px; font-weight: 600; }}
.badge.secondary {{ background: #7c3aed; color: #fff; }}
.content {{ background: #141414; border-radius: 16px; padding: 16px; border: 1px solid rgba(255,255,255,0.05); }}
.section {{ margin-bottom: 20px; }}
.section-title {{ font-size: 13px; font-weight: 600; color: #a0a0a0; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 10px; }}
.code-block {{ background: #0a0a0a; border-radius: 10px; padding: 12px; font-family: 'Courier New', monospace; font-size: 11px; color: #888; overflow-x: auto; white-space: pre-wrap; word-break: break-all; max-height: 300px; overflow-y: auto; }}
.stats-grid {{ display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }}
.stat-card {{ background: #1e1e1e; border-radius: 10px; padding: 12px; text-align: center; }}
.stat-value {{ font-size: 24px; font-weight: 700; color: #00d4aa; }}
.stat-label {{ font-size: 11px; color: #666; margin-top: 4px; }}
.mesh-info {{ background: #1e1e1e; border-radius: 10px; padding: 12px; font-family: monospace; font-size: 10px; color: #666; }}
.mesh-info .key {{ color: #00d4aa; }}
.footer {{ text-align: center; padding: 20px; color: #444; font-size: 11px; }}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div class="title">📦 {info['filename']}</div>
    <div class="meta">
      <span class="badge">{info['language']}</span>
      <span class="badge secondary">{info['category']}</span>
      <span class="badge secondary">{(info['size']/1024):.1f} KB</span>
      <span class="badge secondary">{struct.get('total_lines', 0)} lines</span>
    </div>
  </div>

  <div class="content">
    <div class="section">
      <div class="section-title">Structure Analysis</div>
      <div class="stats-grid">
        <div class="stat-card"><div class="stat-value">{struct.get('functions', 0)}</div><div class="stat-label">Functions</div></div>
        <div class="stat-card"><div class="stat-value">{struct.get('classes', 0)}</div><div class="stat-label">Classes</div></div>
        <div class="stat-card"><div class="stat-value">{len(struct.get('imports', []))}</div><div class="stat-label">Imports</div></div>
        <div class="stat-card"><div class="stat-value">{len(struct.get('exports', []))}</div><div class="stat-label">Exports</div></div>
      </div>
    </div>

    <div class="section">
      <div class="section-title">Purpose</div>
      <p style="font-size: 13px; color: #a0a0a0; line-height: 1.6;">{info.get('purpose', 'Unknown')}</p>
    </div>

    <div class="section">
      <div class="section-title">Mesh Address</div>
      <div class="mesh-info">
        <span class="key">Gate:</span> {addr.get('gate', 'N/A')} | 
        <span class="key">Line:</span> {addr.get('line', 'N/A')} | 
        <span class="key">Color:</span> {addr.get('color', 'N/A')} | 
        <span class="key">Tone:</span> {addr.get('tone', 'N/A')} | 
        <span class="key">Base:</span> {addr.get('base', 'N/A')}<br>
        <span class="key">Zodiac:</span> {addr.get('zodiac', 'N/A')} | 
        <span class="key">House:</span> {addr.get('house', 'N/A')} | 
        <span class="key">Planet:</span> {addr.get('planet', 'N/A')}
      </div>
    </div>

    <div class="section">
      <div class="section-title">Code Preview</div>
      <div class="code-block">{analysis.get('content_preview', 'Binary or large content')[:500]}</div>
    </div>
  </div>

  <div class="footer">
    Regenerated by MorphOS Foundry | App ID: {app_id}
  </div>
</div>
<script>
  console.log('MorphOS app {app_id} loaded');
  window.parent.postMessage({{ type: 'app-ready', appId: '{app_id}' }}, '*');
</script>
</body>
</html>"""

    def _generate_media_app(self, analysis: Dict, app_id: str) -> str:
        return f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{analysis['filename']}</title>
<style>body{{margin:0;background:#0a0a0a;color:#e8e8e8;font-family:system-ui;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;padding:20px;}}
.media-container{{max-width:100%;border-radius:16px;overflow:hidden;background:#1e1e1e;border:1px solid rgba(255,255,255,0.05);}}
.media-info{{padding:16px;text-align:center;}}
.badge{{display:inline-block;padding:4px 10px;background:#00d4aa;color:#000;border-radius:12px;font-size:11px;font-weight:600;margin:4px;}}
</style></head>
<body><div class="media-container"><div class="media-info"><h2>{analysis['filename']}</h2><div><span class="badge">{analysis['language']}</span><span class="badge">{(analysis['size']/1024):.1f} KB</span></div><p style="color:#888;margin-top:12px;font-size:13px;">Media asset — displayed in MorphOS viewer</p></div></div></body></html>"""

    def _generate_archive_app(self, analysis: Dict, app_id: str) -> str:
        files = analysis.get("structure", {}).get("files", [])
        file_list = "\n".join([f"<li>{f['name']} ({f.get('size', 0)} bytes)</li>" for f in files[:30]])
        return f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{analysis['filename']}</title>
<style>body{{margin:0;background:#0a0a0a;color:#e8e8e8;font-family:system-ui;padding:20px;}}
.container{{max-width:100%;}}
.header{{background:#1e1e1e;border-radius:16px;padding:16px;margin-bottom:16px;}}
.title{{font-size:20px;font-weight:700;color:#00d4aa;}}
.file-list{{background:#141414;border-radius:12px;padding:16px;list-style:none;}}
.file-list li{{padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.05);font-size:13px;color:#a0a0a0;}}
.badge{{display:inline-block;padding:4px 10px;background:#00d4aa;color:#000;border-radius:12px;font-size:11px;font-weight:600;margin:4px;}}
</style></head>
<body><div class="container"><div class="header"><div class="title">📦 {analysis['filename']}</div><div style="margin-top:10px;"><span class="badge">{analysis['language']}</span><span class="badge">{len(files)} files</span></div></div><ul class="file-list">{file_list}</ul></div></body></html>"""

    def _generate_data_app(self, analysis: Dict, app_id: str) -> str:
        return f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{analysis['filename']}</title>
<style>body{{margin:0;background:#0a0a0a;color:#e8e8e8;font-family:system-ui;padding:20px;}}
.container{{max-width:100%;}}
.header{{background:#1e1e1e;border-radius:16px;padding:16px;margin-bottom:16px;}}
.title{{font-size:20px;font-weight:700;color:#00d4aa;}}
.data-view{{background:#141414;border-radius:12px;padding:16px;font-family:monospace;font-size:12px;color:#888;overflow:auto;max-height:400px;}}
.badge{{display:inline-block;padding:4px 10px;background:#00d4aa;color:#000;border-radius:12px;font-size:11px;font-weight:600;margin:4px;}}
</style></head>
<body><div class="container"><div class="header"><div class="title">📊 {analysis['filename']}</div><div style="margin-top:10px;"><span class="badge">{analysis['language']}</span><span class="badge">{(analysis['size']/1024):.1f} KB</span></div></div><div class="data-view">Data file viewer — content parsed and displayed</div></div></body></html>"""

    def _generate_generic_app(self, analysis: Dict, app_id: str) -> str:
        return f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{analysis['filename']}</title>
<style>body{{margin:0;background:#0a0a0a;color:#e8e8e8;font-family:system-ui;display:flex;align-items:center;justify-content:center;min-height:100vh;}}
.card{{background:#1e1e1e;border-radius:16px;padding:32px;text-align:center;border:1px solid rgba(255,255,255,0.05);max-width:90%;}}
.icon{{font-size:48px;margin-bottom:16px;}}
.title{{font-size:24px;font-weight:700;margin-bottom:8px;}}
.meta{{color:#888;font-size:14px;}}
.badge{{display:inline-block;padding:4px 10px;background:#00d4aa;color:#000;border-radius:12px;font-size:11px;font-weight:600;margin:4px;}}
</style></head>
<body><div class="card"><div class="icon">📄</div><div class="title">{analysis['filename']}</div><div class="meta"><span class="badge">{analysis['language']}</span><span class="badge">{(analysis['size']/1024):.1f} KB</span></div><p style="color:#666;margin-top:16px;font-size:13px;">File analyzed and pinned to mesh</p></div></body></html>"""

# ═══════════════════════════════════════════════════════════════════════════════
# AUTO-WRITER PIPELINE
# ═══════════════════════════════════════════════════════════════════════════════

class AutoWriter:
    """Generates code/apps from natural language prompts using mesh routing."""

    def __init__(self):
        self.linguistic_router = LinguisticMeshRouter()
        self.autoling = AutoLingRuntime()
        self.embedder = SemanticEmbedder()

    async def write(self, prompt: str, context: Dict = None) -> Dict[str, Any]:
        """Generate code from a natural language prompt."""
        # Route through linguistic mesh
        route = self.linguistic_router.route(prompt)

        # Get semantic embedding
        embedding = self.embedder.embed(prompt)
        hexagram = self.embedder.route_to_hexagram(embedding, "semantic")

        # Ingest through AutoLing
        result = await self.autoling.ingest(prompt, "text")

        # Generate code based on prompt analysis
        generated_code = self._generate_from_prompt(prompt, route, hexagram)

        return {
            "prompt": prompt,
            "route": route,
            "hexagram": hexagram,
            "embedding_shape": embedding.shape,
            "autoling_result": result,
            "generated_code": generated_code,
            "timestamp": datetime.now().isoformat()
        }

    def _generate_from_prompt(self, prompt: str, route: Dict, hexagram: int) -> str:
        prompt_lower = prompt.lower()

        # Determine app type from prompt
        if any(w in prompt_lower for w in ["todo", "list", "task"]):
            return self._generate_todo_app(prompt)
        elif any(w in prompt_lower for w in ["chat", "message", "conversation"]):
            return self._generate_chat_app(prompt)
        elif any(w in prompt_lower for w in ["chart", "graph", "data", "visualization"]):
            return self._generate_chart_app(prompt)
        elif any(w in prompt_lower for w in ["form", "input", "field"]):
            return self._generate_form_app(prompt)
        elif any(w in prompt_lower for w in ["game", "play", "fun"]):
            return self._generate_game_app(prompt)
        else:
            return self._generate_generic_app(prompt, hexagram)

    def _generate_todo_app(self, prompt: str) -> str:
        return """<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Todo App</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: system-ui; background: #0a0a0a; color: #e8e8e8; padding: 20px; }
.container { max-width: 100%; }
.header { font-size: 24px; font-weight: 700; color: #00d4aa; margin-bottom: 20px; }
.input-row { display: flex; gap: 10px; margin-bottom: 16px; }
input { flex: 1; background: #1e1e1e; border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; padding: 12px; color: #e8e8e8; font-size: 14px; }
input:focus { outline: none; border-color: #00d4aa; }
button { background: #00d4aa; color: #000; border: none; border-radius: 10px; padding: 12px 20px; font-weight: 600; cursor: pointer; }
.todo-list { list-style: none; }
.todo-item { background: #141414; border-radius: 10px; padding: 12px; margin-bottom: 8px; display: flex; align-items: center; gap: 10px; border: 1px solid rgba(255,255,255,0.05); }
.todo-item.done { opacity: 0.5; text-decoration: line-through; }
.checkbox { width: 20px; height: 20px; border: 2px solid #00d4aa; border-radius: 50%; cursor: pointer; flex-shrink: 0; }
.checkbox.checked { background: #00d4aa; }
.delete { margin-left: auto; color: #ef4444; cursor: pointer; font-size: 18px; }
</style></head>
<body><div class="container"><div class="header">✅ Todo List</div><div class="input-row"><input type="text" id="newTodo" placeholder="Add a task..."><button onclick="addTodo()">Add</button></div><ul class="todo-list" id="todoList"></ul></div>
<script>
let todos = JSON.parse(localStorage.getItem('todos') || '[]');
function render() {
  const list = document.getElementById('todoList');
  list.innerHTML = todos.map((t,i) => `<li class="todo-item ${t.done?'done':''}"><div class="checkbox ${t.done?'checked':''}" onclick="toggle(${i})"></div><span>${t.text}</span><span class="delete" onclick="remove(${i})">×</span></li>`).join('');
  localStorage.setItem('todos', JSON.stringify(todos));
}
function addTodo() {
  const input = document.getElementById('newTodo');
  if (input.value.trim()) { todos.push({text: input.value, done: false}); input.value = ''; render(); }
}
function toggle(i) { todos[i].done = !todos[i].done; render(); }
function remove(i) { todos.splice(i, 1); render(); }
document.getElementById('newTodo').addEventListener('keypress', e => { if (e.key === 'Enter') addTodo(); });
render();
</script></body></html>"""

    def _generate_chat_app(self, prompt: str) -> str:
        return """<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Chat App</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: system-ui; background: #0a0a0a; color: #e8e8e8; height: 100vh; display: flex; flex-direction: column; }
.header { padding: 16px; background: #1e1e1e; border-bottom: 1px solid rgba(255,255,255,0.05); font-weight: 700; color: #00d4aa; }
.messages { flex: 1; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 10px; }
.message { max-width: 80%; padding: 12px; border-radius: 16px; font-size: 14px; }
.message.user { align-self: flex-end; background: #00d4aa; color: #000; border-bottom-right-radius: 4px; }
.message.bot { align-self: flex-start; background: #1e1e1e; border: 1px solid rgba(255,255,255,0.05); border-bottom-left-radius: 4px; }
.input-area { padding: 12px; background: #141414; border-top: 1px solid rgba(255,255,255,0.05); display: flex; gap: 10px; }
.input-area input { flex: 1; background: #1e1e1e; border: 1px solid rgba(255,255,255,0.1); border-radius: 20px; padding: 10px 16px; color: #e8e8e8; }
.input-area button { background: #00d4aa; color: #000; border: none; border-radius: 20px; padding: 10px 20px; font-weight: 600; cursor: pointer; }
</style></head>
<body><div class="header">💬 Chat</div><div class="messages" id="messages"></div><div class="input-area"><input type="text" id="msgInput" placeholder="Type a message..."><button onclick="send()">Send</button></div>
<script>
function addMessage(text, isUser) {
  const div = document.createElement('div'); div.className = `message ${isUser?'user':'bot'}`;
  div.textContent = text; document.getElementById('messages').appendChild(div);
  document.getElementById('messages').scrollTop = 999999;
}
function send() {
  const input = document.getElementById('msgInput');
  if (!input.value.trim()) return;
  addMessage(input.value, true);
  setTimeout(() => addMessage('Echo: ' + input.value, false), 500);
  input.value = '';
}
document.getElementById('msgInput').addEventListener('keypress', e => { if (e.key === 'Enter') send(); });
addMessage('Welcome! Start chatting...', false);
</script></body></html>"""

    def _generate_chart_app(self, prompt: str) -> str:
        return """<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Chart App</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: system-ui; background: #0a0a0a; color: #e8e8e8; padding: 20px; }
.container { max-width: 100%; }
.header { font-size: 24px; font-weight: 700; color: #00d4aa; margin-bottom: 20px; }
.chart-container { background: #141414; border-radius: 16px; padding: 20px; border: 1px solid rgba(255,255,255,0.05); }
.bar { display: flex; align-items: center; margin-bottom: 10px; }
.bar-label { width: 60px; font-size: 12px; color: #888; }
.bar-fill { height: 24px; background: #00d4aa; border-radius: 4px; transition: width 0.5s; }
.bar-value { margin-left: 10px; font-size: 12px; color: #a0a0a0; }
</style></head>
<body><div class="container"><div class="header">📊 Data Visualization</div><div class="chart-container" id="chart"></div></div>
<script>
const data = [{label:'A',value:65},{label:'B',value:45},{label:'C',value:80},{label:'D',value:30},{label:'E',value:55}];
const max = Math.max(...data.map(d=>d.value));
document.getElementById('chart').innerHTML = data.map(d=>`<div class="bar"><div class="bar-label">${d.label}</div><div class="bar-fill" style="width:${(d.value/max*100)}%;background:hsl(${d.value/max*160},70%,50%)"></div><div class="bar-value">${d.value}</div></div>`).join('');
</script></body></html>"""

    def _generate_form_app(self, prompt: str) -> str:
        return """<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Form App</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: system-ui; background: #0a0a0a; color: #e8e8e8; padding: 20px; }
.container { max-width: 100%; }
.header { font-size: 24px; font-weight: 700; color: #00d4aa; margin-bottom: 20px; }
.form { background: #141414; border-radius: 16px; padding: 20px; border: 1px solid rgba(255,255,255,0.05); }
.field { margin-bottom: 16px; }
label { display: block; font-size: 12px; color: #888; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.5px; }
input, textarea, select { width: 100%; background: #1e1e1e; border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; padding: 12px; color: #e8e8e8; font-size: 14px; }
input:focus, textarea:focus, select:focus { outline: none; border-color: #00d4aa; }
button { width: 100%; background: #00d4aa; color: #000; border: none; border-radius: 10px; padding: 14px; font-size: 16px; font-weight: 600; cursor: pointer; margin-top: 10px; }
</style></head>
<body><div class="container"><div class="header">📝 Form</div><form class="form" onsubmit="event.preventDefault(); alert('Form submitted!');"><div class="field"><label>Name</label><input type="text" placeholder="Enter name"></div><div class="field"><label>Email</label><input type="email" placeholder="Enter email"></div><div class="field"><label>Message</label><textarea rows="4" placeholder="Enter message..."></textarea></div><button type="submit">Submit</button></form></div></body></html>"""

    def _generate_game_app(self, prompt: str) -> str:
        return """<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Game</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: system-ui; background: #0a0a0a; color: #e8e8e8; display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; padding: 20px; }
.game-container { text-align: center; }
.header { font-size: 24px; font-weight: 700; color: #00d4aa; margin-bottom: 20px; }
.score { font-size: 48px; font-weight: 700; margin-bottom: 20px; }
.target { width: 80px; height: 80px; background: #00d4aa; border-radius: 50%; margin: 0 auto 20px; cursor: pointer; transition: transform 0.1s; display: flex; align-items: center; justify-content: center; font-size: 30px; }
.target:active { transform: scale(0.9); }
.instructions { color: #888; font-size: 14px; }
</style></head>
<body><div class="game-container"><div class="header">🎮 Clicker Game</div><div class="score" id="score">0</div><div class="target" onclick="clickTarget()">👆</div><div class="instructions">Click the target as fast as you can!</div></div>
<script>
let score = 0, startTime = Date.now();
function clickTarget() {
  score++;
  document.getElementById('score').textContent = score;
  const target = document.querySelector('.target');
  target.style.transform = `scale(${0.8 + Math.random() * 0.4})`;
  target.style.background = `hsl(${Math.random()*360},70%,50%)`;
}
</script></body></html>"""

    def _generate_generic_app(self, prompt: str, hexagram: int) -> str:
        return f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Generated App</title>
<style>
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{ font-family: system-ui; background: #0a0a0a; color: #e8e8e8; display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 20px; }}
.card {{ background: #141414; border-radius: 20px; padding: 40px; text-align: center; border: 1px solid rgba(255,255,255,0.05); max-width: 90%; }}
.icon {{ font-size: 48px; margin-bottom: 20px; }}
.title {{ font-size: 28px; font-weight: 700; color: #00d4aa; margin-bottom: 12px; }}
.prompt {{ color: #888; font-size: 14px; margin-bottom: 20px; line-height: 1.6; }}
.meta {{ display: flex; gap: 8px; justify-content: center; flex-wrap: wrap; }}
.badge {{ display: inline-block; padding: 4px 12px; background: #1e1e1e; border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; font-size: 11px; color: #a0a0a0; }}
.hex {{ font-family: monospace; color: #7c3aed; }}
</style></head>
<body><div class="card"><div class="icon">✨</div><div class="title">Generated App</div><div class="prompt">{prompt}</div><div class="meta"><span class="badge hex">Gate {hexagram}</span><span class="badge">Auto-generated</span><span class="badge">Responsive</span></div></div></body></html>"""

# ═══════════════════════════════════════════════════════════════════════════════
# WEBSOCKET SERVER (Mesh Communication)
# ═══════════════════════════════════════════════════════════════════════════════

class MeshServer:
    """WebSocket server for real-time mesh communication."""

    def __init__(self):
        self.clients: Set[websockets.WebSocketServerProtocol] = set()
        self.mesh_kernel = MeshKernel()
        self.regenerator = AppRegenerator()
        self.auto_writer = AutoWriter()
        self.analyzer = FileAnalyzer()

    async def register(self, websocket):
        self.clients.add(websocket)
        print(f"Client connected. Total: {len(self.clients)}")
        await self.broadcast({"type": "system", "message": "New node joined mesh"})

    async def unregister(self, websocket):
        self.clients.discard(websocket)
        print(f"Client disconnected. Total: {len(self.clients)}")

    async def broadcast(self, message: Dict):
        if self.clients:
            await asyncio.gather(
                *[client.send(json.dumps(message)) for client in self.clients],
                return_exceptions=True
            )

    async def handle_message(self, websocket, message: str):
        try:
            data = json.loads(message)
            msg_type = data.get("type", "unknown")

            if msg_type == "ping":
                await websocket.send(json.dumps({"type": "pong", "timestamp": time.time()}))

            elif msg_type == "analyze":
                # Analyze file from base64 content
                filename = data.get("filename", "unknown")
                content_b64 = data.get("content", "")
                content = base64.b64decode(content_b64)
                analysis = self.analyzer.analyze(filename, content)
                await websocket.send(json.dumps({
                    "type": "analysis_result",
                    "analysis": analysis
                }))

            elif msg_type == "regenerate":
                # Regenerate analyzed file into app
                analysis = data.get("analysis", {})
                result = self.regenerator.regenerate(analysis)
                await websocket.send(json.dumps({
                    "type": "regeneration_result",
                    "result": result
                }))

            elif msg_type == "generate":
                # Generate from prompt
                prompt = data.get("prompt", "")
                result = await self.auto_writer.write(prompt)
                await websocket.send(json.dumps({
                    "type": "generation_result",
                    "result": result
                }))

            elif msg_type == "mesh_message":
                # Route message through mesh
                gate = data.get("gate", 1)
                payload = data.get("payload", {})
                await self.broadcast({
                    "type": "message",
                    "gate": gate,
                    "msgType": payload.get("type", "broadcast"),
                    "payload": payload
                })

            elif msg_type == "python":
                # Execute Python code (if available)
                code = data.get("code", "")
                try:
                    # Note: In production, use proper sandboxing
                    result = {"output": "Python execution requires Pyodide or secure backend"}
                except Exception as e:
                    result = {"error": str(e)}
                await websocket.send(json.dumps({
                    "type": "python_result",
                    "result": result
                }))

            else:
                await websocket.send(json.dumps({
                    "type": "error",
                    "message": f"Unknown message type: {msg_type}"
                }))

        except json.JSONDecodeError:
            await websocket.send(json.dumps({"type": "error", "message": "Invalid JSON"}))
        except Exception as e:
            await websocket.send(json.dumps({"type": "error", "message": str(e)}))

    async def handler(self, websocket, path):
        await self.register(websocket)
        try:
            async for message in websocket:
                await self.handle_message(websocket, message)
        except websockets.exceptions.ConnectionClosed:
            pass
        finally:
            await self.unregister(websocket)

# ═══════════════════════════════════════════════════════════════════════════════
# HTTP API SERVER
# ═══════════════════════════════════════════════════════════════════════════════

async def handle_http_request(request):
    """Handle HTTP API requests."""
    from aiohttp import web

    router = web.RouteTableDef()
    regenerator = AppRegenerator()
    analyzer = FileAnalyzer()
    auto_writer = AutoWriter()

    @router.get("/")
    async def index(request):
        return web.Response(text="MorphOS Backend API", content_type="text/plain")

    @router.post("/api/analyze")
    async def analyze(request):
        data = await request.post()
        file = data.get("file")
        if not file:
            return web.json_response({"error": "No file provided"}, status=400)
        content = file.file.read()
        analysis = analyzer.analyze(file.filename, content)
        return web.json_response({"analysis": analysis})

    @router.post("/api/regenerate")
    async def regenerate(request):
        data = await request.json()
        analysis = data.get("analysis", {})
        result = regenerator.regenerate(analysis)
        return web.json_response({"result": result})

    @router.post("/api/generate")
    async def generate(request):
        data = await request.json()
        prompt = data.get("prompt", "")
        result = await auto_writer.write(prompt)
        return web.json_response({"result": result})

    @router.get("/api/mesh/status")
    async def mesh_status(request):
        return web.json_response({
            "nodes": 64,
            "channels": 35,
            "partitions": 9,
            "status": "active",
            "timestamp": datetime.now().isoformat()
        })

    @router.get("/api/health")
    async def health(request):
        return web.json_response({"status": "healthy", "version": "1.0.0"})

    app = web.Application()
    app.router.add_routes(router)
    return app

# ═══════════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

async def main():
    print("=" * 60)
    print("  MORPHOS BACKEND v1.0")
    print("  Universal File Foundry & Paper")
    print("=" * 60)
    print()
    print("  Integrating modules:")
    print("  • address_space_engine — Coordinate resolution")
    print("  • dms360_engine — Pure integer DMS arithmetic")
    print("  • isomorphic_framework — Universal topology")
    print("  • mesh_os_kernel — Microkernel OS mesh")
    print("  • autoling_runtime — Semantic embeddings & actors")
    print("  • linguistic_mesh_router — 5 Ws pipeline")
    print()

    # Initialize mesh server
    mesh_server = MeshServer()

    # Start WebSocket server
    ws_server = await websockets.serve(
        mesh_server.handler,
        CONFIG["HOST"],
        CONFIG["WS_PORT"]
    )
    print(f"  🌐 WebSocket mesh: ws://{CONFIG['HOST']}:{CONFIG['WS_PORT']}")

    # Start HTTP server
    try:
        from aiohttp import web
        http_app = await handle_http_request(None)
        runner = web.AppRunner(http_app)
        await runner.setup()
        site = web.TCPSite(runner, CONFIG["HOST"], CONFIG["HTTP_PORT"])
        await site.start()
        print(f"  📡 HTTP API: http://{CONFIG['HOST']}:{CONFIG['HTTP_PORT']}")
    except ImportError:
        print("  ⚠️  aiohttp not installed — HTTP API disabled")
        print("     Install: pip install aiohttp")

    print()
    print("  ✅ MorphOS backend ready")
    print("  Press Ctrl+C to stop")
    print("=" * 60)

    # Keep running
    await asyncio.Future()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n  👋 MorphOS backend stopped")
