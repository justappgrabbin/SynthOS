/*
===================================================================
MORPHOS v28 CORE ENGINE PATCH — BEHAVIOR-FIRST MORPHOGENIC COMPILER
Bridges v22/v23 native loops into v28 standalone executable organs.

Install:
  Place before OS.init(), then run:

  MorphPatch.install();
  OS.init();

Supports both:
  Generator.generate(artifact)
  Generator.generate(analysis, detection, filename, originalBytes)

Output:
  *_regenerated_organ.html

No iframe.
No backend.
No passive viewer.
The generated file owns its own local message substrate.
===================================================================
*/

(function(){
  const MorphPatch = {
    version: "v28-behavior-morphogenic-compiler-1.2",

    esc(s='') {
      return String(s).replace(/[&<>"']/g, c => ({
        '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'
      }[c]));
    },

    safeName(name='artifact') {
      return String(name || 'artifact').replace(/\.[^/.]+$/, '').replace(/[^\w.-]+/g, '_') || 'artifact';
    },

    normalizeInput(arg1, detection={}, filename="morphic_organ.js", originalBytes=null) {
      // Shape A: Generator.generate(artifact)
      if (arg1 && (arg1.name || arg1.text || arg1.content) && !arg1.components && !arg1.functions && !arg1.type) {
        return {
          name: arg1.name || filename || "morphic_organ.js",
          text: arg1.text || arg1.content || "",
          analysis: arg1.analysis || {},
          detection: arg1.detection || detection || {},
          byteLength: arg1.byteLength || originalBytes?.length || 0
        };
      }

      // Shape B: Generator.generate(analysis, detection, filename, originalBytes)
      const analysis = arg1 || {};
      const textParts = [
        analysis.text || "",
        analysis.sample || "",
        analysis.firstChars || "",
        JSON.stringify({
          analysisType: analysis.type || "",
          components: analysis.components || [],
          functions: analysis.functions || [],
          classes: analysis.classes || [],
          apis: analysis.apis || [],
          keys: analysis.keys || [],
          headers: analysis.headers || []
        })
      ];

      return {
        name: filename || "morphic_organ.js",
        text: textParts.join("\n"),
        analysis,
        detection: detection || {},
        byteLength: originalBytes?.length || analysis.byteLength || 0
      };
    },

    /*
    1. BEHAVIOR ANALYZER ENGINE
    Extracts intent, data signatures, and capability clues.
    */
    analyzeArtifact(artifact) {
      const text = String(artifact.text || "").toLowerCase();
      const analysis = artifact.analysis || {};
      const detection = artifact.detection || {};
      const name = this.safeName(artifact.name);

      const profile =
        text.includes("calc") || text.includes("math") || text.includes("sum") || (analysis.functions || []).some(f => /calc|sum|compute|add/i.test(f.name || "")) ? "calculator" :
        text.includes("task") || text.includes("todo") || text.includes("list") || (analysis.components || []).some(c => c.type === "list") ? "tasks" :
        text.includes("route") || text.includes("nav") || (analysis.components || []).some(c => c.type === "navigation") ? "router" :
        text.includes("canvas") || text.includes("draw") || (analysis.apis || []).includes("canvas") || (analysis.apis || []).includes("getContext") ? "field_renderer" :
        "substrate_pulse";

      const capabilities = [];

      const addCap = cap => { if (!capabilities.includes(cap)) capabilities.push(cap); };

      if (/add|compute|input|calc|math|sum/.test(text)) addCap("arithmetic_eval");
      if (/save|memory|local|persist/.test(text) || (analysis.apis || []).some(a => ["localStorage","indexedDB"].includes(a))) addCap("local_storage_persistence");
      if (/list|check|task|todo|collection/.test(text)) addCap("collection_mutation");
      if (/route|nav|screen|page/.test(text)) addCap("route_mutation");
      if (/canvas|draw|render|field/.test(text)) addCap("field_rendering");
      if ((analysis.functions || []).length) addCap("function_signature_map");
      if ((analysis.components || []).length) addCap("component_signature_map");
      if (["image","audio","video","document","archive","binary","unknown"].includes(detection.type)) addCap("payload_representation");

      return {
        name,
        originalName: artifact.name || name,
        profile,
        capabilities,
        sourceType: detection.type || "unknown",
        sourceSubtype: detection.subtype || "unknown",
        byteLength: artifact.byteLength || 0,
        timestamp: Date.now(),
        extracted: {
          functions: (analysis.functions || []).map(f => f.name || "anonymous").slice(0, 32),
          components: (analysis.components || []).map(c => c.type || c.name || "component").slice(0, 32),
          apis: (analysis.apis || []).slice(0, 32),
          keys: (analysis.keys || analysis.headers || []).slice(0, 32)
        }
      };
    },

    /*
    2. BEHAVIOR GRAPH COMPILER
    Builds message-addressed causal graph from inferred profile.
    Mutators are deterministic state transforms emitted into the child organ.
    */
    compileBehaviorGraph(analysis) {
      const graph = {
        id: "graph_" + Math.random().toString(36).slice(2, 9),
        root: analysis.name,
        profile: analysis.profile,
        capabilities: analysis.capabilities,
        intents: [],
        initialState: {
          cycleCount: 0,
          lastIntent: "genesis",
          lastMsg: "",
          log: [],
          sourceType: analysis.sourceType,
          sourceSubtype: analysis.sourceSubtype
        },
        mutators: {}
      };

      const addIntent = i => { if (!graph.intents.includes(i)) graph.intents.push(i); };

      if (analysis.profile === "calculator") {
        ["press_key", "clear_display", "calculate"].forEach(addIntent);
        graph.initialState.display = "0";
        graph.initialState.equation = "";

        graph.mutators = {
          press_key: `
            const key = String(intent.payload.key ?? "");
            if (!/^[0-9+\\-*/().]$/.test(key)) return;
            if (state.display === "0") state.display = key;
            else state.display += key;
            state.equation += key;
            state.lastMsg = "key accepted";
          `,
          clear_display: `
            state.display = "0";
            state.equation = "";
            state.lastMsg = "display cleared";
          `,
          calculate: `
            try {
              const expr = String(state.equation || "").replace(/[^0-9+\\-*/().]/g, "");
              if (!expr) throw new Error("empty expression");
              state.display = String(Function('"use strict";return (' + expr + ')')());
              state.equation = state.display;
              state.lastMsg = "calculated";
            } catch(e) {
              state.display = "Error";
              state.equation = "";
              state.lastMsg = e.message;
            }
          `
        };

      } else if (analysis.profile === "tasks") {
        ["add_task", "toggle_task", "clear_tasks"].forEach(addIntent);
        graph.initialState.tasks = [];

        graph.mutators = {
          add_task: `
            const text = String(intent.payload.text || state.inputBuffer || "").trim();
            if (text) state.tasks.push({ text, done: false, id: Date.now().toString(36) });
            state.inputBuffer = "";
            state.lastMsg = "task added";
          `,
          toggle_task: `
            const idx = Number(intent.payload.index);
            if (state.tasks[idx]) state.tasks[idx].done = !state.tasks[idx].done;
            state.lastMsg = "task toggled";
          `,
          clear_tasks: `
            state.tasks = [];
            state.lastMsg = "tasks cleared";
          `
        };

      } else if (analysis.profile === "router") {
        ["navigate", "next_route", "reset_route"].forEach(addIntent);
        graph.initialState.route = "home";
        graph.initialState.routes = ["home", "work", "memory", "field"];

        graph.mutators = {
          navigate: `
            state.route = intent.payload.route || "home";
            state.lastMsg = "route changed";
          `,
          next_route: `
            const i = state.routes.indexOf(state.route);
            state.route = state.routes[(i + 1) % state.routes.length];
            state.lastMsg = "route advanced";
          `,
          reset_route: `
            state.route = "home";
            state.lastMsg = "route reset";
          `
        };

      } else if (analysis.profile === "field_renderer") {
        ["pulse_field", "mutate_vector", "render_field"].forEach(addIntent);
        graph.initialState.pulseIntensity = 0.64;
        graph.initialState.renderTick = 0;

        graph.mutators = {
          pulse_field: `
            state.pulseIntensity = Math.min(1.0, Number(state.pulseIntensity || 0.64) + 0.05);
            if (state.pulseIntensity >= 1.0) state.pulseIntensity = 0.64;
            state.lastMsg = "field pulsed";
          `,
          mutate_vector: `
            state.vector = (state.vector || 1) * -1;
            state.lastMsg = "vector mutated";
          `,
          render_field: `
            state.renderTick = (state.renderTick || 0) + 1;
            state.lastMsg = "field rendered";
          `
        };

      } else {
        ["pulse_field", "mutate_vector", "inspect_payload"].forEach(addIntent);
        graph.initialState.pulseIntensity = 0.64;
        graph.initialState.vector = 1;

        graph.mutators = {
          pulse_field: `
            state.pulseIntensity = Math.min(1.0, Number(state.pulseIntensity || 0.64) + 0.05);
            if (state.pulseIntensity >= 1.0) state.pulseIntensity = 0.64;
            state.lastMsg = "substrate pulse";
          `,
          mutate_vector: `
            state.vector = (state.vector || 1) * -1;
            state.lastMsg = "vector mutated";
          `,
          inspect_payload: `
            state.lastMsg = "payload " + state.sourceType + ":" + state.sourceSubtype;
          `
        };
      }

      // Capability extras
      if (analysis.capabilities.includes("local_storage_persistence")) {
        addIntent("save_state"); addIntent("load_state");
        graph.mutators.save_state = `
          localStorage.setItem("morph_organ_state", JSON.stringify(state));
          state.lastMsg = "state saved";
        `;
        graph.mutators.load_state = `
          try {
            const loaded = JSON.parse(localStorage.getItem("morph_organ_state") || "{}");
            Object.assign(state, loaded);
            state.lastMsg = "state loaded";
          } catch(e) { state.lastMsg = e.message; }
        `;
      }

      if (analysis.capabilities.includes("function_signature_map")) {
        addIntent("execute_signature");
        graph.initialState.signatures = analysis.extracted.functions;
        graph.mutators.execute_signature = `
          const sig = intent.payload.signature || state.signatures?.[0] || "anonymous";
          state.lastMsg = "executed behavior signature: " + sig;
          state.signatureResult = String(sig).length + state.cycleCount;
        `;
      }

      if (analysis.capabilities.includes("payload_representation")) {
        addIntent("inspect_payload");
      }

      return graph;
    },

    /*
    3. STANDALONE ORGAN EMITTER
    Emits a closed-loop HTML child organ with message bus and deterministic mutation state.
    */
    emitExecutableOrgan(analysis, graph) {
      const esc = this.esc;

      let viewLayout = "";
      let interfaceScript = "";

      if (analysis.profile === "calculator") {
        viewLayout = `
          <div class="display" id="calc-display">0</div>
          <div class="grid calc-grid">
            ${['7','8','9','/','4','5','6','*','1','2','3','-','0','.','=','C'].map(k => {
              if(k === '=') return `<button class="accent" onclick="sendOrganIntent('calculate')">=</button>`;
              if(k === 'C') return `<button class="danger" onclick="sendOrganIntent('clear_display')">C</button>`;
              return `<button onclick="sendOrganIntent('press_key', {key:'${k}'})">${k}</button>`;
            }).join('\n')}
          </div>
        `;
        interfaceScript = `
          const calc = document.getElementById("calc-display");
          if (calc) calc.textContent = state.display;
        `;

      } else if (analysis.profile === "tasks") {
        viewLayout = `
          <div class="row">
            <input type="text" id="task-input" placeholder="New structural intent...">
            <button onclick="const input = document.getElementById('task-input'); sendOrganIntent('add_task', {text: input.value}); input.value=''">Add</button>
          </div>
          <button class="danger" onclick="sendOrganIntent('clear_tasks')">Clear Tasks</button>
          <div id="task-list"></div>
        `;
        interfaceScript = `
          const listEl = document.getElementById("task-list");
          if (listEl) {
            listEl.innerHTML = (state.tasks || []).map((t, i) => \`
              <div class="task">
                <input type="checkbox" \${t.done ? "checked" : ""} onclick="sendOrganIntent('toggle_task', {index:\${i}})">
                <span style="\${t.done ? "text-decoration:line-through;color:var(--muted)" : ""}">\${esc(t.text)}</span>
              </div>
            \`).join("") || '<div class="empty">No active tasks in substrate.</div>';
          }
        `;

      } else if (analysis.profile === "router") {
        viewLayout = `
          <div id="route-view" class="display">home</div>
          <div class="grid">
            <button onclick="sendOrganIntent('navigate', {route:'home'})">Home</button>
            <button onclick="sendOrganIntent('navigate', {route:'work'})">Work</button>
            <button onclick="sendOrganIntent('navigate', {route:'memory'})">Memory</button>
            <button onclick="sendOrganIntent('next_route')">Next</button>
          </div>
        `;
        interfaceScript = `
          const route = document.getElementById("route-view");
          if (route) route.textContent = state.route;
        `;

      } else {
        viewLayout = `
          <div class="pulse-wrap">
            <div id="pulse-indicator"></div>
            <button onclick="sendOrganIntent('pulse_field')">Perturb Substrate Field</button>
            <button onclick="sendOrganIntent('mutate_vector')">Mutate Vector</button>
            <button onclick="sendOrganIntent('inspect_payload')">Inspect Payload</button>
          </div>
        `;
        interfaceScript = `
          const pulse = document.getElementById("pulse-indicator");
          if (pulse) pulse.style.transform = "scale(" + (Number(state.pulseIntensity || 0.64) * 2) + ")";
        `;
      }

      // Add extra controls if available
      const extraControls = graph.intents
        .filter(i => !["press_key","clear_display","calculate","add_task","toggle_task","clear_tasks","navigate","next_route","reset_route","pulse_field","mutate_vector","inspect_payload"].includes(i))
        .map(i => `<button class="secondary" onclick="sendOrganIntent('${i}')">${esc(i)}</button>`)
        .join("");

      const mutatorsSource = Object.entries(graph.mutators)
        .map(([intent, code]) => `${intent}: function(state, intent) { ${code} }`)
        .join(",\n");

      const standaloneHTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>${esc(analysis.name)} — Regenerated Organ Substrate</title>
  <style>
    :root {
      --bg: #050511; --panel: rgba(15,15,38,0.95); --line: rgba(184,150,255,0.32);
      --text: #f8f2ff; --muted: #bdb0dc; --cyan: #44e6ff; --purple: #8b5cf6;
      --accent: #ff6b2b; --danger: #ff4757; --green:#79ffbb;
    }
    * { box-sizing:border-box; }
    body { margin: 0; background: radial-gradient(circle at 10% 0%,rgba(139,92,246,.28),transparent 32%), var(--bg); color: var(--text); font-family: system-ui, -apple-system, sans-serif; padding: 16px; }
    .organ-frame { max-width: 560px; margin: 20px auto; background: var(--panel); border: 1px solid var(--line); border-radius: 16px; padding: 20px; box-shadow: 0 12px 40px rgba(0,0,0,0.5); }
    h2 { font-size: 16px; text-transform: uppercase; letter-spacing: 1px; color: var(--cyan); margin-top: 0; margin-bottom: 16px; border-bottom: 1px solid rgba(184,150,255,0.15); padding-bottom: 8px; }
    button { background: #111118; border: 1px solid var(--line); color: #fff; padding: 8px 14px; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: 600; margin:3px; }
    button:hover { background: var(--purple); border-color: var(--cyan); }
    button.accent { background: var(--purple); border-color: var(--cyan); }
    button.danger { background: rgba(255,71,87,0.1); border-color: var(--danger); color: var(--danger); }
    button.secondary { background:rgba(255,255,255,.07); }
    input { background:#0d0d16; border:1px solid var(--line); color:#fff; padding:8px; border-radius:8px; width:100%; }
    .display { background: #020208; border: 1px solid var(--line); border-radius: 8px; padding: 12px; font-family: monospace; font-size: 20px; text-align: right; color: var(--cyan); word-break: break-all; margin-bottom:12px; }
    .grid { display:grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-top: 12px; }
    .row { display:flex; gap:8px; margin-bottom:12px; }
    .task { display:flex; align-items:center; gap:8px; background:rgba(255,255,255,0.03); padding:8px; margin-bottom:4px; border-radius:6px; border:1px solid rgba(184,150,255,0.1); }
    .empty { color:var(--muted); font-size:12px; padding:8px; }
    #pulse-indicator { width:80px; height:80px; border-radius:50%; background:radial-gradient(circle, var(--cyan), transparent); margin:20px auto; transition: transform 0.1s ease; }
    .meta-metrics { display: flex; justify-content: space-between; gap:8px; flex-wrap:wrap; font-size: 11px; color: var(--muted); margin-top: 16px; background: rgba(0,0,0,0.2); padding: 8px; border-radius: 6px; font-family: monospace; }
    .bus-monitor { background:#020208; border:1px solid rgba(68,230,255,.2); border-radius:8px; padding:10px; margin-top:12px; max-height:180px; overflow:auto; font-family:monospace; font-size:11px; color:var(--green); }
    .statebox { background:#020208; border:1px solid rgba(184,150,255,.2); border-radius:8px; padding:10px; margin-top:12px; max-height:220px; overflow:auto; font-family:monospace; font-size:11px; color:#c9c0ee; white-space:pre-wrap; }
  </style>
</head>
<body>
  <div class="organ-frame">
    <h2>🧬 ${esc(analysis.name)}</h2>

    ${viewLayout}

    <div>${extraControls}</div>

    <div class="meta-metrics">
      <span>Profile: <span style="color:var(--cyan)">${esc(analysis.profile)}</span></span>
      <span>Cycles: <span id="metric-cycles">0</span></span>
      <span>Last Intent: <span id="metric-intent" style="color:var(--cyan)">genesis</span></span>
    </div>

    <div class="bus-monitor" id="bus-monitor"></div>
    <pre class="statebox" id="state-vector">{}</pre>
  </div>

  <script>
    const esc = (s) => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

    let state = ${JSON.stringify(graph.initialState)};
    const mutators = {
      ${mutatorsSource}
    };

    const LocalBus = {
      listeners: {},
      on(type, cb) { (this.listeners[type] ||= []).push(cb); },
      emit(type, payload = {}) {
        logBus(type, payload);
        (this.listeners[type] || []).forEach(cb => cb(payload));
      }
    };

    LocalBus.on("ui:intent", intent => {
      if (mutators[intent.action]) {
        state.cycleCount++;
        state.lastIntent = intent.action;
        state.log = [...(state.log || []), { action:intent.action, ts:Date.now() }].slice(-30);
        mutators[intent.action](state, intent);
        LocalBus.emit("state:mutated", { state, action:intent.action });
      }
    });

    LocalBus.on("state:mutated", packet => syncDOM());

    function sendOrganIntent(action, payload = {}) {
      LocalBus.emit("ui:intent", { action, payload, ts: Date.now() });

      if(window.parent !== window) {
        window.parent.postMessage({
          source: "MorphOSBehaviorObserver",
          type: "organ:intent",
          action,
          payload,
          ts: Date.now()
        }, "*");
      }
    }

    function logBus(type, payload) {
      const el = document.getElementById("bus-monitor");
      if (!el) return;
      el.innerHTML += "<div>[" + type + "] " + esc(JSON.stringify(payload)) + "</div>";
      el.scrollTop = el.scrollHeight;
    }

    function syncDOM() {
      document.getElementById("metric-cycles").textContent = state.cycleCount;
      document.getElementById("metric-intent").textContent = state.lastIntent;
      document.getElementById("state-vector").textContent = JSON.stringify(state, null, 2);
      ${interfaceScript}
    }

    syncDOM();
    LocalBus.emit("substrate:online", { ts:Date.now(), profile:"${esc(analysis.profile)}", intents:${JSON.stringify(graph.intents)} });
  <\/script>
</body>
</html>`;

      return {
        filename: analysis.name + "_regenerated_organ.html",
        mimeType: "text/html",
        content: standaloneHTML,
        size: standaloneHTML.length,
        description: "v28 behavior-first standalone executable organ"
      };
    },

    /*
    BRIDGE HOOK
    Replaces older generator behavior with v28 morphogenesis.
    */
    install() {
      if (!window.Generator) window.Generator = {};
      const previous = window.Generator.generate;
      window.Generator.previousGenerate = previous;

      window.Generator.generate = (...args) => {
        const artifact = MorphPatch.normalizeInput(...args);
        console.log("[MorphOS v28] Compiling behavior surface for:", artifact.name);
        const analysis = MorphPatch.analyzeArtifact(artifact);
        const graph = MorphPatch.compileBehaviorGraph(analysis);
        return MorphPatch.emitExecutableOrgan(analysis, graph);
      };

      console.log("[MorphOS] System updated to v28 behavior-first morphogenesis.");
      return true;
    }
  };

  window.MorphPatch = MorphPatch;
})();
