/**
 * ORCHESTRATOR.JS — The Minimal Breather
 * 
 * This is NOT a controller. It is a heartbeat pump.
 * It seeds the first agent, then merely keeps the field alive.
 * All intelligence is in the agents and the artifacts.
 */

const { Profile } = require('./profile');
const { Agent } = require('./agent');
const { GlobalIndex } = require('./index');

class Orchestrator {
  constructor(config = {}) {
    this.index = new GlobalIndex();
    this.agents = new Map();
    this.interval = config.interval || 1000;
    this.maxAgents = config.maxAgents || 100;
    this.timer = null;
  }

  /**
   * Seed the system with a root need and a primordial agent.
   */
  seed(rootNeed) {
    // Create the primordial need
    const needId = this.index.broadcastNeed({
      type: rootNeed.type || 'scaffold',
      depth: 0,
      pressure: 1.0,
      preferredTone: rootNeed.tone || 3, // Outer Vision to start building
      ...rootNeed
    });

    // Spawn the primordial agent
    const primordial = new Agent({
      profile: new Profile({
        tone: rootNeed.tone || 3,
        centers: { throat: 0.9, ajna: 0.8, g: 0.7 },
        codons: [1, 2, 3, 14, 15, 43, 23] // Common builder gates
      }),
      index: this.index
    });

    this.agents.set(primordial.id, primordial);
    this.index.agents.set(primordial.id, {
      profile: primordial.profile,
      lastHeartbeat: Date.now()
    });

    return { needId, agentId: primordial.id };
  }

  /**
   * Start the heartbeat.
   */
  start() {
    this.timer = setInterval(() => this._pulse(), this.interval);
    return this;
  }

  /**
   * Stop the heartbeat.
   */
  stop() {
    if (this.timer) clearInterval(this.timer);
    return this;
  }

  /**
   * One pulse: all living agents heartbeat, reap stale needs.
   */
  async _pulse() {
    // Reap stale needs
    this.index.reap();

    // Heartbeat all living agents
    const promises = [];
    for (const [id, agent] of this.agents) {
      if (agent.state !== 'dying') {
        promises.push(agent.heartbeat().catch(err => ({ error: err.message, agentId: id })));
      }
    }
    await Promise.all(promises);

    // Cleanup dead agents from memory (artifacts persist in index)
    for (const [id, agent] of this.agents) {
      if (agent.state === 'dying') {
        this.agents.delete(id);
      }
    }

    // Spawn ambient agents if population is low and pressure is high
    if (this.agents.size < 5) {
      const highPressureNeeds = Array.from(this.index.needs.values())
        .filter(n => n.status === 'open' && this.index._calculatePressure(n) > 0.8);

      if (highPressureNeeds.length > 0) {
        const need = highPressureNeeds[0];
        const ambient = new Agent({
          profile: new Profile({ tone: need.preferredTone || Math.floor(Math.random() * 6) + 1 }),
          index: this.index
        });
        this.agents.set(ambient.id, ambient);
        this.index.agents.set(ambient.id, { profile: ambient.profile, lastHeartbeat: Date.now() });
      }
    }
  }

  /**
   * Get system state report.
   */
  report() {
    return {
      agents: {
        living: this.agents.size,
        totalEver: this.index.agents.size
      },
      needs: {
        open: Array.from(this.index.needs.values()).filter(n => n.status === 'open').length,
        claimed: Array.from(this.index.needs.values()).filter(n => n.status === 'claimed').length,
        resolved: Array.from(this.index.needs.values()).filter(n => n.status === 'resolved').length,
        stale: Array.from(this.index.needs.values()).filter(n => n.status === 'stale').length
      },
      artifacts: this.index.artifacts.size,
      convergences: Array.from(this.index.lineage.entries())
        .filter(([_, lineage]) => lineage.length >= 2).length
    };
  }
}

module.exports = { Orchestrator };
