// ═════════════════════════════════════════════════════════════════════════════
// MORPHOS KERNEL v1.0
// Phone-First Morphing GNN Operating System
// ═════════════════════════════════════════════════════════════════════════════

const MorphOS = (() => {
  'use strict';

  const CONFIG = {
    NODE_COUNT: 64,
    CONNECTION_RADIUS: 120,
    REPULSION: 200,
    ATTRACTION: 0.02,
    DAMPING: 0.9,
    MAX_SPEED: 3,
    MESH_COLOR: 'rgba(0, 212, 170, 0.12)',
    NODE_COLORS: { idle: '#333', active: '#00d4aa', processing: '#7c3aed', error: '#ef4444', success: '#22c55e' },
    PYODIDE_URL: 'https://cdn.jsdelivr.net/pyodide/v0.25.0/full/pyodide.js',
    BACKEND_URL: '/api',
    WS_URL: 'ws://localhost:8765'
  };

  const state = {
    nodes: [], edges: [], messages: [], apps: new Map(), activeApp: 'foundry',
    pyodide: null, pythonReady: false, ws: null, meshConnected: false,
    selectedNode: null, camera: { x: 0, y: 0, zoom: 1, targetZoom: 1 },
    pointer: { x: 0, y: 0, down: false, dragging: false, dragTarget: null },
    frame: 0, lastTime: 0, canvas: null, ctx: null, width: 0, height: 0, dpr: 1,
    fileRegistry: new Map(), generatedApps: new Map()
  };

  const GATE_CHANNELS = [
    [1,8],[2,14],[3,60],[4,63],[5,15],[6,59],[7,31],[9,52],
    [10,34],[10,20],[10,57],[11,56],[12,22],[13,33],[16,48],[17,62],
    [18,58],[19,49],[20,34],[20,57],[21,45],[23,43],[24,61],[25,51],
    [26,44],[27,50],[28,38],[29,46],[30,41],[32,54],[35,36],[37,40],
    [39,55],[42,53],[47,64]
  ];

  const GATE_NAMES = {
    1:'Creation',2:'Reception',3:'Difficulty',4:'Folly',5:'Waiting',6:'Conflict',
    7:'Army',8:'Holding',9:'Taming',10:'Treading',11:'Peace',12:'Standstill',
    13:'Fellowship',14:'Possession',15:'Modesty',16:'Enthusiasm',17:'Following',
    18:'Work',19:'Approach',20:'Contemplation',21:'Biting',22:'Grace',23:'Splitting',
    24:'Return',25:'Innocence',26:'Taming',27:'Nourishing',28:'Preponderance',
    29:'Abyss',30:'Clinging',31:'Influence',32:'Duration',33:'Retreat',34:'Power',
    35:'Progress',36:'Darkening',37:'Family',38:'Opposition',39:'Obstruction',
    40:'Deliverance',41:'Decrease',42:'Increase',43:'Breakthrough',44:'Coming',
    45:'Gathering',46:'Pushing',47:'Oppression',48:'Well',49:'Revolution',
    50:'Cauldron',51:'Shock',52:'Keeping',53:'Development',54:'Marrying',
    55:'Abundance',56:'Wandering',57:'Gentle',58:'Joyous',59:'Dispersing',
    60:'Limiting',61:'Inner',62:'Preponderance',63:'Completion',64:'Completion'
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // 1. GNN MESH ENGINE (Vanilla JS — No Libraries)
  // ═══════════════════════════════════════════════════════════════════════════

  class MeshNode {
    constructor(id, gateNum) {
      this.id = id; this.gate = gateNum;
      this.name = GATE_NAMES[gateNum] || `Gate-${gateNum}`;
      this.x = Math.random() * 800 - 400; this.y = Math.random() * 800 - 400;
      this.vx = 0; this.vy = 0;
      this.radius = 18 + Math.random() * 8;
      this.phase = 'idle'; this.coherence = Math.random() * 0.5 + 0.3;
      this.messages = []; this.connections = new Set();
      this.data = null; this.type = 'semantic';
      this.lastPulse = 0; this.pulsePhase = Math.random() * Math.PI * 2;
    }
    pulse() { this.lastPulse = Date.now(); this.pulsePhase = 0; }
    receive(msg) {
      this.messages.push(msg);
      if (this.messages.length > 20) this.messages.shift();
      this.pulse(); this.phase = 'processing';
      setTimeout(() => { if (this.messages.length === 0) this.phase = 'idle'; }, 500);
    }
  }

  function initMesh() {
    for (let i = 1; i <= 64; i++) {
      const node = new MeshNode(`node-${i}`, i);
      const angle = (i / 64) * Math.PI * 2;
      const radius = 200 + (i % 8) * 30;
      node.x = Math.cos(angle) * radius; node.y = Math.sin(angle) * radius;
      state.nodes.push(node);
    }
    GATE_CHANNELS.forEach(([g1, g2]) => {
      const n1 = state.nodes[g1 - 1], n2 = state.nodes[g2 - 1];
      if (n1 && n2) {
        n1.connections.add(n2.id); n2.connections.add(n1.id);
        state.edges.push({ source: n1, target: n2, strength: Math.random() * 0.5 + 0.5 });
      }
    });
  }

  function updateMeshPhysics() {
    const nodes = state.nodes, edges = state.edges;
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const n1 = nodes[i], n2 = nodes[j];
        const dx = n2.x - n1.x, dy = n2.y - n1.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const force = (CONFIG.REPULSION * CONFIG.REPULSION) / (dist * dist);
        const fx = (dx / dist) * force, fy = (dy / dist) * force;
        n1.vx -= fx; n1.vy -= fy; n2.vx += fx; n2.vy += fy;
      }
    }
    edges.forEach(edge => {
      const n1 = edge.source, n2 = edge.target;
      const dx = n2.x - n1.x, dy = n2.y - n1.y;
      const dist = Math.sqrt(dx * dx + dy * dy) || 1;
      const force = (dist - CONFIG.CONNECTION_RADIUS) * CONFIG.ATTRACTION * edge.strength;
      const fx = (dx / dist) * force, fy = (dy / dist) * force;
      n1.vx += fx; n1.vy += fy; n2.vx -= fx; n2.vy -= fy;
    });
    nodes.forEach(n => {
      n.vx -= n.x * 0.0005; n.vy -= n.y * 0.0005;
      n.vx *= CONFIG.DAMPING; n.vy *= CONFIG.DAMPING;
      const speed = Math.sqrt(n.vx * n.vx + n.vy * n.vy);
      if (speed > CONFIG.MAX_SPEED) { n.vx = (n.vx / speed) * CONFIG.MAX_SPEED; n.vy = (n.vy / speed) * CONFIG.MAX_SPEED; }
      n.x += n.vx; n.y += n.vy;
    });
  }

  function renderMesh() {
    const { ctx, width, height, camera, dpr } = state;
    ctx.clearRect(0, 0, width, height);
    ctx.save();
    ctx.translate(width / 2 + camera.x, height / 2 + camera.y);
    ctx.scale(camera.zoom, camera.zoom);
    ctx.strokeStyle = CONFIG.MESH_COLOR; ctx.lineWidth = 1;
    state.edges.forEach(edge => {
      const { source: n1, target: n2 } = edge;
      ctx.beginPath(); ctx.moveTo(n1.x, n1.y); ctx.lineTo(n2.x, n2.y); ctx.stroke();
      const t = (state.frame * 0.02 + edge.strength * 10) % 1;
      const px = n1.x + (n2.x - n1.x) * t, py = n1.y + (n2.y - n1.y) * t;
      ctx.fillStyle = 'rgba(0, 212, 170, 0.3)'; ctx.beginPath(); ctx.arc(px, py, 2, 0, Math.PI * 2); ctx.fill();
    });
    state.nodes.forEach(node => {
      const isSelected = state.selectedNode === node;
      const pulseAge = Date.now() - node.lastPulse;
      const pulseSize = pulseAge < 1000 ? Math.sin(pulseAge * 0.01) * 6 : 0;
      if (node.phase !== 'idle' || isSelected) {
        const glowColor = CONFIG.NODE_COLORS[node.phase] || CONFIG.NODE_COLORS.idle;
        ctx.shadowColor = glowColor; ctx.shadowBlur = isSelected ? 20 : 10;
      }
      ctx.fillStyle = isSelected ? '#fff' : (CONFIG.NODE_COLORS[node.phase] || '#333');
      ctx.beginPath(); ctx.arc(node.x, node.y, node.radius + pulseSize, 0, Math.PI * 2); ctx.fill();
      ctx.shadowBlur = 0;
      ctx.strokeStyle = 'rgba(255,255,255,0.2)'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(node.x, node.y, node.radius * 0.7, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = '#fff'; ctx.font = `bold ${node.radius * 0.5}px monospace`;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(node.gate, node.x, node.y);
      if (node.messages.length > 0) {
        ctx.fillStyle = '#f59e0b'; ctx.beginPath();
        ctx.arc(node.x + node.radius * 0.7, node.y - node.radius * 0.7, 6, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#000'; ctx.font = '9px monospace';
        ctx.fillText(Math.min(node.messages.length, 9), node.x + node.radius * 0.7, node.y - node.radius * 0.7);
      }
    });
    ctx.restore();
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 2. MESSAGE PASSING SYSTEM
  // ═══════════════════════════════════════════════════════════════════════════

  class MeshMessage {
    constructor(type, payload, fromNode, toNode, ttl = 10) {
      this.id = `msg-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      this.type = type; this.payload = payload; this.from = fromNode; this.to = toNode;
      this.ttl = ttl; this.trace = [fromNode?.id || 'system'];
      this.timestamp = Date.now(); this.status = 'transit';
    }
  }

  function routeMessage(msg) {
    if (!msg.to && msg.payload?.targetGate) {
      msg.to = state.nodes[msg.payload.targetGate - 1];
    }
    if (!msg.to) {
      const neighbors = msg.from ? Array.from(msg.from.connections).map(id => state.nodes.find(n => n.id === id)) : state.nodes;
      neighbors.forEach(n => {
        if (n && n !== msg.from) {
          const copy = new MeshMessage(msg.type, msg.payload, msg.from, n, msg.ttl - 1);
          copy.trace = [...msg.trace, n.id]; n.receive(copy);
        }
      });
      return;
    }
    msg.to.receive(msg);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 3. PYODIDE INTEGRATION
  // ═══════════════════════════════════════════════════════════════════════════

  async function initPyodide() {
    try {
      showToast('Loading Python runtime...', 'info');
      const script = document.createElement('script');
      script.src = CONFIG.PYODIDE_URL;
      script.onload = async () => {
        state.pyodide = await loadPyodide();
        state.pythonReady = true;
        showToast('Python ready ✓', 'success');
        updateStatus('online');
      };
      document.head.appendChild(script);
    } catch (e) {
      showToast('Python failed: ' + e.message, 'error');
      updateStatus('offline');
    }
  }

  async function runPython(code, context = {}) {
    if (!state.pythonReady || !state.pyodide) { showToast('Python not ready', 'warning'); return null; }
    try {
      let fullCode = '';
      for (const [key, val] of Object.entries(context)) { fullCode += `${key} = ${JSON.stringify(val)}\n`; }
      fullCode += code;
      return await state.pyodide.runPythonAsync(fullCode);
    } catch (e) { showToast('Python error: ' + e.message, 'error'); return null; }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 4. FILE ANALYSIS & REGENERATION ENGINE
  // ═══════════════════════════════════════════════════════════════════════════

  const FILE_TYPE_MAP = {
    'js': { icon: '📜', lang: 'javascript', type: 'script' },
    'ts': { icon: '📘', lang: 'typescript', type: 'script' },
    'jsx': { icon: '⚛️', lang: 'jsx', type: 'component' },
    'tsx': { icon: '⚛️', lang: 'tsx', type: 'component' },
    'py': { icon: '🐍', lang: 'python', type: 'script' },
    'zip': { icon: '📦', lang: 'archive', type: 'bundle' },
    'tar': { icon: '📦', lang: 'archive', type: 'bundle' },
    'gz': { icon: '📦', lang: 'archive', type: 'bundle' },
    'jpg': { icon: '🖼️', lang: 'image', type: 'asset' },
    'jpeg': { icon: '🖼️', lang: 'image', type: 'asset' },
    'png': { icon: '🖼️', lang: 'image', type: 'asset' },
    'gif': { icon: '🖼️', lang: 'image', type: 'asset' },
    'svg': { icon: '🎨', lang: 'svg', type: 'asset' },
    'mp3': { icon: '🎵', lang: 'audio', type: 'asset' },
    'mp4': { icon: '🎬', lang: 'video', type: 'asset' },
    'mpeg': { icon: '🎬', lang: 'video', type: 'asset' },
    'html': { icon: '🌐', lang: 'html', type: 'markup' },
    'xml': { icon: '📋', lang: 'xml', type: 'markup' },
    'json': { icon: '📊', lang: 'json', type: 'data' },
    'css': { icon: '🎨', lang: 'css', type: 'style' },
    'kt': { icon: '🔷', lang: 'kotlin', type: 'script' },
    'java': { icon: '☕', lang: 'java', type: 'script' },
    'go': { icon: '🔵', lang: 'go', type: 'script' },
    'rs': { icon: '🦀', lang: 'rust', type: 'script' },
    'cpp': { icon: '⚡', lang: 'cpp', type: 'script' },
    'c': { icon: '⚡', lang: 'c', type: 'script' },
    'rb': { icon: '💎', lang: 'ruby', type: 'script' },
    'php': { icon: '🐘', lang: 'php', type: 'script' },
    'swift': { icon: '🦉', lang: 'swift', type: 'script' },
    'dart': { icon: '🎯', lang: 'dart', type: 'script' },
    'md': { icon: '📝', lang: 'markdown', type: 'doc' },
    'txt': { icon: '📄', lang: 'text', type: 'doc' },
    'pdf': { icon: '📕', lang: 'pdf', type: 'doc' },
    'wasm': { icon: '🔩', lang: 'wasm', type: 'binary' },
    'sql': { icon: '🗄️', lang: 'sql', type: 'data' },
    'yaml': { icon: '📋', lang: 'yaml', type: 'data' },
    'toml': { icon: '⚙️', lang: 'toml', type: 'data' }
  };

  function getFileInfo(file) {
    const name = file.name;
    const ext = name.split('.').pop().toLowerCase();
    const info = FILE_TYPE_MAP[ext] || { icon: '📄', lang: 'unknown', type: 'unknown' };
    return { ...info, name, ext, size: file.size };
  }

  async function analyzeFile(file) {
    const info = getFileInfo(file);
    const content = await file.text().catch(() => null);
    const analysis = {
      info, content,
      structure: {
        lines: content ? content.split('\n').length : 0,
        characters: content ? content.length : 0,
        functions: 0, classes: 0, imports: [], exports: [], dependencies: [], complexity: 0
      },
      relationships: { calls: [], inherits: [], composes: [], uses: [] },
      purpose: 'unknown'
    };
    if (content) {
      const funcMatches = content.match(/(?:function|def|const\s+\w+\s*=\s*(?:async\s*)?\(|\w+\s*\(\s*\w+\s*\)\s*=>|class\s+\w+)/g);
      analysis.structure.functions = funcMatches ? funcMatches.length : 0;
      analysis.structure.classes = (content.match(/class\s+/g) || []).length;
      analysis.structure.imports = [...content.matchAll(/(?:import|require|from)\s+['"]([^'"]+)['"]/g)].map(m => m[1]);
      analysis.structure.exports = [...content.matchAll(/(?:export|module\.exports)\s+(?:default\s+)?(?:class|function|const|let|var)?\s*(\w+)/g)].map(m => m[1]);
    }
    return analysis;
  }

  async function regenerateApp(analysis, target = 'browser') {
    const appId = `app-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const { info } = analysis;
    let appHTML = `<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>${info.name}</title><style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:system-ui,sans-serif; background:#0a0a0a; color:#e8e8e8; padding:16px; }
.app-container { max-width:100%; }
.app-header { padding:12px; background:#1e1e1e; border-radius:12px; margin-bottom:16px; }
.app-title { font-size:18px; font-weight:600; }
.app-meta { font-size:12px; color:#888; margin-top:4px; }
.app-content { background:#141414; border-radius:12px; padding:16px; min-height:200px; }
pre { background:#0a0a0a; padding:12px; border-radius:8px; overflow:auto; font-size:12px; }
.badge { display:inline-block; padding:2px 8px; background:#00d4aa; color:#000; border-radius:10px; font-size:10px; font-weight:600; margin:2px; }
</style></head><body><div class="app-container"><div class="app-header"><div class="app-title">${info.icon} ${info.name}</div><div class="app-meta"><span class="badge">${info.lang}</span><span class="badge">${info.type}</span><span class="badge">${(info.size/1024).toFixed(1)}KB</span><span class="badge">${analysis.structure.lines}lines</span></div></div><div class="app-content"><p><strong>Regenerated from ${info.ext.toUpperCase()}</strong></p><p style="color:#888;font-size:13px;margin:8px 0;">Functions:${analysis.structure.functions}|Classes:${analysis.structure.classes}|Imports:${analysis.structure.imports.length}</p>`;
    if (info.type === 'script' || info.type === 'markup') {
      appHTML += `<pre><code>${analysis.content ? analysis.content.slice(0,2000).replace(/</g,'&lt;') : 'Binary'}</code></pre>`;
    } else if (info.type === 'asset') {
      appHTML += `<p>Asset file — embedded resource</p>`;
    }
    appHTML += `</div></div><script>console.log('App ${appId} loaded');window.parent.postMessage({type:'app-ready',appId:'${appId}'},'*');</script></body></html>`;
    return { appId, appHTML, info, analysis };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 5. APP WINDOW MANAGER
  // ═══════════════════════════════════════════════════════════════════════════

  function createAppWindow(appId, title, content, options = {}) {
    const win = document.createElement('div');
    win.className = 'app-window';
    win.id = `win-${appId}`;
    win.style.cssText = `top:${options.top||60}px;left:${options.left||20}px;width:${options.width||'calc(100% - 40px)'};height:${options.height||'calc(100% - 160px)'};`;
    const isBrowser = options.type === 'browser';
    const isFoundry = options.type === 'foundry';
    const isPaper = options.type === 'paper';
    const isSettings = options.type === 'settings';
    let bodyContent = '';
    if (isBrowser) {
      bodyContent = `<div class="browser-view"><div class="browser-toolbar"><button class="ctrl-btn" onclick="MorphOS.goBack('${appId}')">←</button><button class="ctrl-btn" onclick="MorphOS.goForward('${appId}')">→</button><input type="text" id="url-${appId}" placeholder="Enter URL..." value="${options.url||'https://example.com'}"><button class="ctrl-btn" onclick="MorphOS.loadURL('${appId}')">↻</button></div><iframe id="frame-${appId}" class="browser-frame" src="${options.url||'about:blank'}" sandbox="allow-scripts allow-same-origin allow-forms allow-popups"></iframe></div>`;
    } else if (isFoundry) {
      bodyContent = `<div class="foundry-view" id="foundry-${appId}"><div class="foundry-dropzone" id="dropzone-${appId}" ondragover="event.preventDefault();this.classList.add('dragover')" ondragleave="this.classList.remove('dragover')" ondrop="MorphOS.handleDrop(event,'${appId}')"><div class="dz-icon">📥</div><div class="dz-text">Drop files here or click to browse</div><div class="dz-hint">Supports: JS, TS, JSX, TSX, Python, ZIP, images, audio, video, and more</div></div><div id="files-${appId}" style="display:flex;flex-wrap:wrap;gap:4px;"></div><div id="stages-${appId}" style="display:flex;flex-direction:column;gap:8px;"></div></div>`;
    } else if (isPaper) {
      bodyContent = `<div class="paper-view" id="paper-${appId}"><textarea class="paper-prompt" id="prompt-${appId}" placeholder="Describe the app you want to build...\n\nExample: 'A todo list with dark theme'\n\nOr paste code here"></textarea><button class="paper-generate-btn" id="gen-${appId}" onclick="MorphOS.generateFromPrompt('${appId}')"><span class="spinner" style="display:none" id="spinner-${appId}"></span><span id="gen-text-${appId}">✨ Generate App</span></button><div class="paper-preview" id="preview-${appId}" style="display:none;"><div class="preview-header"><span>Preview</span><button class="ctrl-btn" onclick="MorphOS.installApp('${appId}')">📌 Install</button></div><iframe id="preview-frame-${appId}" class="preview-frame" sandbox="allow-scripts allow-same-origin"></iframe></div></div>`;
    } else if (isSettings) {
      bodyContent = buildSettingsView();
    } else {
      bodyContent = `<iframe id="frame-${appId}" class="browser-frame" srcdoc="${content.replace(/"/g,'&quot;')}" sandbox="allow-scripts allow-same-origin"></iframe>`;
    }
    win.innerHTML = `<div class="app-header" onmousedown="MorphOS.startDrag(event,'${appId}')"><div class="title"><span class="app-icon">${options.icon||'📄'}</span>${title}</div><div class="controls"><button class="ctrl-btn" onclick="MorphOS.minimizeApp('${appId}')">−</button><button class="ctrl-btn" onclick="MorphOS.maximizeApp('${appId}')">□</button><button class="ctrl-btn close" onclick="MorphOS.closeApp('${appId}')">×</button></div></div><div class="app-body">${bodyContent}</div>`;
    document.getElementById('app-windows').appendChild(win);
    state.apps.set(appId, { element: win, type: options.type, title, ...options });
    requestAnimationFrame(() => { win.style.animation = 'slide-up 0.3s ease-out'; });
    return win;
  }

  function buildSettingsView() {
    return `<div class="settings-view"><div class="settings-group"><div class="sg-header">Mesh Network</div><div class="sg-body"><div class="setting-row"><div><div class="setting-label">Auto-connect to mesh</div><div class="setting-desc">Join distributed mesh on startup</div></div><div class="setting-control"><div class="toggle on" onclick="this.classList.toggle('on')"><div class="knob"></div></div></div></div><div class="setting-row"><div><div class="setting-label">WebSocket URL</div><div class="setting-desc">Backend mesh endpoint</div></div><div class="setting-control"><input type="text" value="ws://localhost:8765" style="width:160px;background:var(--surface-2);border:1px solid rgba(255,255,255,0.1);border-radius:6px;padding:6px 10px;color:var(--text);font-size:12px;"></div></div></div></div><div class="settings-group"><div class="sg-header">Python Runtime</div><div class="sg-body"><div class="setting-row"><div><div class="setting-label">Pyodide (in-browser)</div><div class="setting-desc">Load Python WASM runtime</div></div><div class="setting-control"><div class="toggle on" onclick="this.classList.toggle('on')"><div class="knob"></div></div></div></div></div></div><div class="settings-group"><div class="sg-header">Foundry</div><div class="sg-body"><div class="setting-row"><div><div class="setting-label">Auto-analyze on drop</div><div class="setting-desc">Immediately parse file structure</div></div><div class="setting-control"><div class="toggle on" onclick="this.classList.toggle('on')"><div class="knob"></div></div></div></div></div></div><div class="settings-group"><div class="sg-header">About</div><div class="sg-body" style="font-size:12px;color:var(--text-2);line-height:1.6;"><p><strong>MorphOS v1.0</strong></p><p>Universal File Foundry & Paper</p><p>64-node mesh topology based on I Ching / Human Design</p></div></div></div>`;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 6. UI HELPERS
  // ═══════════════════════════════════════════════════════════════════════════

  function showToast(message, type = 'info', duration = 3000) {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    const icons = { success: '✓', error: '✗', warning: '⚠', info: 'ℹ' };
    toast.innerHTML = `<span class="toast-icon">${icons[type]||'ℹ'}</span><span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), duration + 300);
  }

  function updateStatus(status) {
    const dot = document.getElementById('mesh-status-dot');
    const text = document.getElementById('mesh-status-text');
    dot.className = `dot ${status}`;
    text.textContent = status === 'online' ? 'Mesh Online' : status === 'busy' ? 'Mesh Busy' : 'Mesh Offline';
    state.meshConnected = status === 'online';
  }

  function updateClock() {
    document.getElementById('clock').textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  function updateNodeInfo(node) {
    const panel = document.getElementById('node-info');
    if (!node) { panel.classList.remove('visible'); return; }
    document.getElementById('ni-addr').textContent = `G${node.gate}.${node.name}`;
    document.getElementById('ni-phase').textContent = node.phase;
    document.getElementById('ni-coherence').textContent = node.coherence.toFixed(3);
    document.getElementById('ni-messages').textContent = node.messages.length;
    document.getElementById('ni-type').textContent = node.type;
    panel.classList.add('visible');
  }

  let dragApp = null, dragOffsetX = 0, dragOffsetY = 0;
  function startDrag(e, appId) {
    const app = state.apps.get(appId);
    if (!app || app.element.classList.contains('maximized')) return;
    dragApp = app.element;
    const rect = dragApp.getBoundingClientRect();
    dragOffsetX = e.clientX - rect.left; dragOffsetY = e.clientY - rect.top;
    document.addEventListener('mousemove', onDrag); document.addEventListener('mouseup', stopDrag);
  }
  function onDrag(e) {
    if (!dragApp) return;
    dragApp.style.left = (e.clientX - dragOffsetX) + 'px';
    dragApp.style.top = (e.clientY - dragOffsetY) + 'px';
  }
  function stopDrag() { dragApp = null; document.removeEventListener('mousemove', onDrag); document.removeEventListener('mouseup', stopDrag); }

  // ═══════════════════════════════════════════════════════════════════════════
  // 7. APP ACTIONS
  // ═══════════════════════════════════════════════════════════════════════════

  async function handleDrop(e, appId) {
    e.preventDefault();
    const dropzone = document.getElementById(`dropzone-${appId}`);
    dropzone.classList.remove('dragover');
    const files = Array.from(e.dataTransfer.files);
    if (files.length === 0) return;
    showToast(`Processing ${files.length} file(s)...`, 'info');
    for (const file of files) {
      const info = getFileInfo(file);
      const chip = document.createElement('div');
      chip.className = 'file-chip';
      chip.innerHTML = `<span class="chip-icon">${info.icon}</span><span class="chip-name">${info.name}</span><span class="chip-remove" onclick="this.parentElement.remove()">×</span>`;
      document.getElementById(`files-${appId}`).appendChild(chip);
      const analysis = await analyzeFile(file);
      state.fileRegistry.set(info.name, { info, analysis, file });
      addCompilerStage(appId, `Analyzing ${info.name}`, analysis);
      const regen = await regenerateApp(analysis);
      state.generatedApps.set(regen.appId, regen);
      addCompilerStage(appId, `Regenerated ${info.name}`, null, 'success', regen.appId);
      showToast(`${info.name} regenerated!`, 'success');
    }
  }

  function addCompilerStage(appId, name, analysis, status = 'processing', appIdRef = null) {
    const stages = document.getElementById(`stages-${appId}`);
    const stage = document.createElement('div');
    stage.className = 'compiler-stage';
    stage.innerHTML = `<div class="stage-header"><span class="stage-name">${name}</span><span class="stage-status">${status === 'processing' ? '<span class="spinner"></span>' : status === 'success' ? '✓' : '✗'}</span></div><div class="stage-bar"><div class="fill" style="width:${status==='success'?100:status==='error'?0:30}%"></div></div>${analysis ? `<div class="stage-output">${JSON.stringify(analysis.structure, null, 2).slice(0, 300)}</div>` : ''}${appIdRef ? `<button class="paper-generate-btn" style="margin-top:8px;padding:8px;" onclick="MorphOS.openApp('${appIdRef}')">Open App</button>` : ''}`;
    stages.appendChild(stage);
    setTimeout(() => stage.querySelector('.fill').style.width = '100%', 100);
  }

  async function generateFromPrompt(appId) {
    const prompt = document.getElementById(`prompt-${appId}`).value;
    if (!prompt.trim()) { showToast('Enter a prompt first', 'warning'); return; }
    const btn = document.getElementById(`gen-${appId}`);
    const spinner = document.getElementById(`spinner-${appId}`);
    const text = document.getElementById(`gen-text-${appId}`);
    btn.disabled = true; spinner.style.display = 'block'; text.textContent = 'Generating...';
    try {
      // Route through mesh
      const targetGate = Math.floor(Math.random() * 64) + 1;
      const msg = new MeshMessage('generate', { prompt, targetGate }, state.nodes[0]);
      routeMessage(msg);
      // Generate app HTML
      const appHTML = `<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Generated App</title><style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:system-ui,sans-serif; background:#0a0a0a; color:#e8e8e8; padding:20px; }
.container { max-width:100%; }
h1 { font-size:24px; margin-bottom:16px; color:#00d4aa; }
p { font-size:14px; line-height:1.6; color:#a0a0a0; margin-bottom:12px; }
.card { background:#1e1e1e; border-radius:12px; padding:16px; margin-bottom:12px; border:1px solid rgba(255,255,255,0.05); }
.badge { display:inline-block; padding:4px 10px; background:#00d4aa; color:#000; border-radius:12px; font-size:11px; font-weight:600; margin:4px 4px 0 0; }
.prompt-box { background:#141414; border-radius:8px; padding:12px; font-family:monospace; font-size:12px; color:#888; border:1px solid rgba(255,255,255,0.05); }
</style></head><body><div class="container"><h1>✨ Generated App</h1><div class="card"><p><strong>Prompt:</strong></p><div class="prompt-box">${prompt.replace(/</g,'&lt;')}</div></div><div class="card"><p><strong>Features:</strong></p><div class="badge">Responsive</div><div class="badge">Dark Theme</div><div class="badge">Mobile-First</div></div><div class="card"><p><strong>Mesh Route:</strong> Gate ${targetGate} → ${GATE_NAMES[targetGate]}</p><p style="font-size:12px;color:#666;margin-top:8px;">Generated by MorphOS Paper</p></div></div><script>console.log('Generated app loaded');window.parent.postMessage({type:'app-ready',appId:'generated'},'*');</script></body></html>`;
      const preview = document.getElementById(`preview-${appId}`);
      const frame = document.getElementById(`preview-frame-${appId}`);
      frame.srcdoc = appHTML;
      preview.style.display = 'block';
      showToast('App generated!', 'success');
    } catch (e) {
      showToast('Generation failed: ' + e.message, 'error');
    } finally {
      btn.disabled = false; spinner.style.display = 'none'; text.textContent = '✨ Generate App';
    }
  }

  function installApp(appId) {
    const frame = document.getElementById(`preview-frame-${appId}`);
    if (!frame) return;
    const newAppId = `installed-${Date.now()}`;
    const win = createAppWindow(newAppId, 'Installed App', '', { type: 'app', icon: '📱', width: '100%', height: 'calc(100% - 100px)', top: 40, left: 0 });
    const newFrame = win.querySelector('iframe');
    newFrame.srcdoc = frame.srcdoc;
    showToast('App installed to tray!', 'success');
    addToTray(newAppId, '📱', 'App');
  }

  function addToTray(appId, icon, label) {
    const tray = document.getElementById('app-tray');
    const app = document.createElement('div');
    app.className = 'tray-app';
    app.dataset.app = appId;
    app.innerHTML = `<span class="icon">${icon}</span><span class="label">${label}</span>`;
    app.onclick = () => openApp(appId);
    tray.insertBefore(app, document.getElementById('add-btn'));
  }

  function openApp(appId) {
    const app = state.apps.get(appId);
    if (app) {
      app.element.classList.remove('minimized');
      app.element.style.zIndex = 100 + state.apps.size;
    }
  }

  function closeApp(appId) {
    const app = state.apps.get(appId);
    if (app) { app.element.remove(); state.apps.delete(appId); }
  }

  function minimizeApp(appId) {
    const app = state.apps.get(appId);
    if (app) app.element.classList.add('minimized');
  }

  function maximizeApp(appId) {
    const app = state.apps.get(appId);
    if (app) app.element.classList.toggle('maximized');
  }

  function loadURL(appId) {
    const url = document.getElementById(`url-${appId}`).value;
    document.getElementById(`frame-${appId}`).src = url;
  }

  function goBack(appId) { document.getElementById(`frame-${appId}`).contentWindow.history.back(); }
  function goForward(appId) { document.getElementById(`frame-${appId}`).contentWindow.history.forward(); }

  // ═══════════════════════════════════════════════════════════════════════════
  // 8. CANVAS INTERACTIONS
  // ═══════════════════════════════════════════════════════════════════════════

  function initCanvas() {
    state.canvas = document.getElementById('morph-canvas');
    state.ctx = state.canvas.getContext('2d');
    state.dpr = window.devicePixelRatio || 1;
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    state.canvas.addEventListener('pointerdown', onPointerDown);
    state.canvas.addEventListener('pointermove', onPointerMove);
    state.canvas.addEventListener('pointerup', onPointerUp);
    state.canvas.addEventListener('wheel', onWheel, { passive: false });
  }

  function resizeCanvas() {
    const rect = state.canvas.getBoundingClientRect();
    state.width = rect.width; state.height = rect.height;
    state.canvas.width = state.width * state.dpr;
    state.canvas.height = state.height * state.dpr;
    state.ctx.scale(state.dpr, state.dpr);
  }

  function onPointerDown(e) {
    state.pointer.down = true;
    state.pointer.x = e.clientX; state.pointer.y = e.clientY;
    const worldX = (e.clientX - state.width / 2 - state.camera.x) / state.camera.zoom;
    const worldY = (e.clientY - state.height / 2 - state.camera.y) / state.camera.zoom;
    let clicked = null;
    for (const node of state.nodes) {
      const dx = worldX - node.x, dy = worldY - node.y;
      if (Math.sqrt(dx * dx + dy * dy) < node.radius) { clicked = node; break; }
    }
    if (clicked) {
      state.selectedNode = clicked;
      state.pointer.dragging = false;
      updateNodeInfo(clicked);
      clicked.pulse();
      // Send message through mesh
      const msg = new MeshMessage('select', { gate: clicked.gate, action: 'inspect' }, clicked);
      routeMessage(msg);
    } else {
      state.selectedNode = null;
      updateNodeInfo(null);
      state.pointer.dragging = true;
    }
  }

  function onPointerMove(e) {
    if (!state.pointer.down) return;
    const dx = e.clientX - state.pointer.x;
    const dy = e.clientY - state.pointer.y;
    if (state.pointer.dragging) {
      state.camera.x += dx;
      state.camera.y += dy;
    }
    state.pointer.x = e.clientX;
    state.pointer.y = e.clientY;
  }

  function onPointerUp() {
    state.pointer.down = false;
    state.pointer.dragging = false;
  }

  function onWheel(e) {
    e.preventDefault();
    const zoomSpeed = 0.001;
    state.camera.targetZoom *= 1 - e.deltaY * zoomSpeed;
    state.camera.targetZoom = Math.max(0.2, Math.min(5, state.camera.targetZoom));
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 9. MAIN LOOP
  // ═══════════════════════════════════════════════════════════════════════════

  function loop() {
    state.frame++;
    // Smooth zoom
    state.camera.zoom += (state.camera.targetZoom - state.camera.zoom) * 0.1;
    updateMeshPhysics();
    renderMesh();
    requestAnimationFrame(loop);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 10. INITIALIZATION
  // ═══════════════════════════════════════════════════════════════════════════

  function init() {
    initMesh();
    initCanvas();
    loop();
    updateClock();
    setInterval(updateClock, 60000);

    // Tray click handlers
    document.querySelectorAll('.tray-app').forEach(app => {
      app.addEventListener('click', () => {
        const appType = app.dataset.app;
        document.querySelectorAll('.tray-app').forEach(a => a.classList.remove('active'));
        app.classList.add('active');
        // Open corresponding app window
        const existing = Array.from(state.apps.values()).find(a => a.type === appType);
        if (existing) {
          existing.element.classList.remove('minimized');
          existing.element.style.zIndex = 100 + state.apps.size;
        } else {
          const configs = {
            foundry: { title: 'Foundry', icon: '🔥', type: 'foundry' },
            paper: { title: 'Paper', icon: '📄', type: 'paper' },
            browser: { title: 'Browser', icon: '🌐', type: 'browser', url: 'https://example.com' },
            settings: { title: 'Settings', icon: '⚙️', type: 'settings' }
          };
          const cfg = configs[appType];
          if (cfg) createAppWindow(`${appType}-${Date.now()}`, cfg.title, '', cfg);
        }
      });
    });

    // Add button
    document.getElementById('add-btn').addEventListener('click', () => {
      document.getElementById('overlay-menu').classList.add('visible');
    });

    // Menu actions
    document.querySelectorAll('.menu-option').forEach(opt => {
      opt.addEventListener('click', () => {
        const action = opt.dataset.action;
        document.getElementById('overlay-menu').classList.remove('visible');
        if (action === 'upload') {
          document.getElementById('file-input').click();
        } else if (action === 'prompt') {
          document.querySelector('.tray-app[data-app="paper"]').click();
        } else if (action === 'paste') {
          navigator.clipboard.readText().then(text => {
            document.querySelector('.tray-app[data-app="paper"]').click();
            setTimeout(() => {
              const ta = document.querySelector('.paper-prompt');
              if (ta) ta.value = text;
            }, 300);
          });
        } else if (action === 'url') {
          document.querySelector('.tray-app[data-app="browser"]').click();
        } else if (action === 'camera') {
          showToast('Camera access requested', 'info');
        }
      });
    });

    document.getElementById('menu-cancel').addEventListener('click', () => {
      document.getElementById('overlay-menu').classList.remove('visible');
    });

    // File input
    document.getElementById('file-input').addEventListener('change', (e) => {
      const files = Array.from(e.target.files);
      if (files.length > 0) {
        document.querySelector('.tray-app[data-app="foundry"]').click();
        setTimeout(() => {
          const foundryId = Array.from(state.apps.keys()).find(id => state.apps.get(id).type === 'foundry');
          if (foundryId) {
            files.forEach(file => {
              const info = getFileInfo(file);
              showToast(`Dropped: ${info.name}`, 'info');
            });
          }
        }, 300);
      }
    });

    // Init Pyodide
    initPyodide();

    // WebSocket
    try {
      state.ws = new WebSocket(CONFIG.WS_URL);
      state.ws.onopen = () => { updateStatus('online'); showToast('Mesh connected', 'success'); };
      state.ws.onmessage = (e) => {
        const data = JSON.parse(e.data);
        if (data.type === 'message') {
          const node = state.nodes[data.gate - 1];
          if (node) node.receive(new MeshMessage(data.msgType, data.payload, null, node));
        }
      };
      state.ws.onclose = () => updateStatus('offline');
    } catch (e) { console.log('WebSocket not available'); }

    showToast('MorphOS initialized', 'success');
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // PUBLIC API
  // ═══════════════════════════════════════════════════════════════════════════

  return {
    init,
    startDrag, onDrag, stopDrag,
    handleDrop, generateFromPrompt, installApp,
    closeApp, minimizeApp, maximizeApp, openApp,
    loadURL, goBack, goForward,
    runPython,
    showToast,
    getState: () => state
  };
})();

// Start
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', MorphOS.init);
} else {
  MorphOS.init();
}
