import { VikiProvider, useViki } from '@/context/VikiContext';
import Header from '@/components/Header';
import Chat from '@/components/Chat';
import CodeViewer from '@/components/CodeViewer';
import GraphViewer from '@/components/GraphViewer';
import RulesPanel from '@/components/RulesPanel';
import ProjectManager from '@/components/ProjectManager';

function AppContent() {
  const { activeMode } = useViki();
  return (
    <div style={{ width: '100vw', height: '100vh', display: 'flex', flexDirection: 'column', background: '#050508', overflow: 'hidden' }}>
      <Header />
      <main style={{ flex: 1, marginTop: 52, overflow: 'hidden' }}>
        {activeMode === 'chat' && <Chat />}
        {activeMode === 'code' && <CodeViewer />}
        {activeMode === 'graph' && <GraphViewer />}
        {activeMode === 'rules' && <RulesPanel />}
        {activeMode === 'projects' && <ProjectManager />}
      </main>
    </div>
  );
}

export default function App() {
  return <VikiProvider><AppContent /></VikiProvider>;
}
