/**
 * IndexedDB Storage Layer
 * 
 * Stores: conversations, projects (apps/games/videos), 
 * semantic network state, knowledge base, working memory
 */

const DB_NAME = 'viki_db';
const DB_VERSION = 1;

interface DBStores {
  conversations: ConversationRecord;
  projects: ProjectRecord;
  knowledge: KnowledgeRecord;
  memory: MemoryRecord;
}

export interface ConversationRecord {
  id: string;
  timestamp: number;
  role: 'user' | 'system';
  content: string;
  type: 'chat' | 'code' | 'video' | 'system';
  metadata?: Record<string, unknown>;
}

export interface ProjectRecord {
  id: string;
  name: string;
  type: 'app' | 'game' | 'video';
  created: number;
  updated: number;
  code?: string;
  language?: string;
  description?: string;
  videoUrl?: string;
  files?: ProjectFile[];
}

export interface ProjectFile {
  path: string;
  content: string;
  language: string;
}

export interface KnowledgeRecord {
  id: string;
  subject: string;
  relation: string;
  object: string;
  value?: number;
  timestamp: number;
}

export interface MemoryRecord {
  id: string;
  key: string;
  data: unknown;
  timestamp: number;
}

let dbInstance: IDBDatabase | null = null;

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (dbInstance) { resolve(dbInstance); return; }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => { dbInstance = req.result; resolve(req.result); };
    req.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('conversations')) {
        db.createObjectStore('conversations', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('projects')) {
        const ps = db.createObjectStore('projects', { keyPath: 'id' });
        ps.createIndex('type', 'type', { unique: false });
        ps.createIndex('updated', 'updated', { unique: false });
      }
      if (!db.objectStoreNames.contains('knowledge')) {
        const ks = db.createObjectStore('knowledge', { keyPath: 'id' });
        ks.createIndex('subject', 'subject', { unique: false });
        ks.createIndex('timestamp', 'timestamp', { unique: false });
      }
      if (!db.objectStoreNames.contains('memory')) {
        db.createObjectStore('memory', { keyPath: 'id' });
      }
    };
  });
}

// Generic store operations
async function put<T>(storeName: keyof DBStores, data: T): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.put(data);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

async function get<T>(storeName: keyof DBStores, id: string): Promise<T | undefined> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.get(id);
    req.onsuccess = () => resolve(req.result as T | undefined);
    req.onerror = () => reject(req.error);
  });
}

async function getAll<T>(storeName: keyof DBStores): Promise<T[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result as T[]);
    req.onerror = () => reject(req.error);
  });
}

async function getAllByIndex<T>(
  storeName: keyof DBStores,
  indexName: string,
  value: IDBValidKey
): Promise<T[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const idx = store.index(indexName);
    const req = idx.getAll(value);
    req.onsuccess = () => resolve(req.result as T[]);
    req.onerror = () => reject(req.error);
  });
}

async function remove(storeName: keyof DBStores, id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

async function clear(storeName: keyof DBStores): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.clear();
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// ─── Conversation API ───

export async function saveConversation(msg: Omit<ConversationRecord, 'id'>): Promise<string> {
  const id = `${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
  await put('conversations', { ...msg, id });
  return id;
}

export async function getConversations(): Promise<ConversationRecord[]> {
  const all = await getAll<ConversationRecord>('conversations');
  return all.sort((a, b) => a.timestamp - b.timestamp);
}

export async function deleteConversation(id: string): Promise<void> {
  await remove('conversations', id);
}

export async function clearConversations(): Promise<void> {
  await clear('conversations');
}

// ─── Project API ───

export async function saveProject(proj: Omit<ProjectRecord, 'id' | 'created' | 'updated'>): Promise<string> {
  const id = `${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
  const now = Date.now();
  await put('projects', { ...proj, id, created: now, updated: now });
  return id;
}

export async function updateProject(id: string, updates: Partial<ProjectRecord>): Promise<void> {
  const existing = await get<ProjectRecord>('projects', id);
  if (!existing) throw new Error(`Project ${id} not found`);
  await put('projects', { ...existing, ...updates, updated: Date.now() });
}

export async function getProjects(): Promise<ProjectRecord[]> {
  const all = await getAll<ProjectRecord>('projects');
  return all.sort((a, b) => b.updated - a.updated);
}

export async function getProjectsByType(type: ProjectRecord['type']): Promise<ProjectRecord[]> {
  return getAllByIndex<ProjectRecord>('projects', 'type', type);
}

export async function deleteProject(id: string): Promise<void> {
  await remove('projects', id);
}

// ─── Knowledge API ───

export async function storeKnowledge(subject: string, relation: string, object: string, value?: number): Promise<string> {
  const id = `${subject}:${relation}:${object}`;
  await put('knowledge', { id, subject, relation, object, value: value ?? 0, timestamp: Date.now() });
  return id;
}

export async function getKnowledgeBySubject(subject: string): Promise<KnowledgeRecord[]> {
  return getAllByIndex<KnowledgeRecord>('knowledge', 'subject', subject);
}

export async function getAllKnowledge(): Promise<KnowledgeRecord[]> {
  return getAll<KnowledgeRecord>('knowledge');
}

// ─── Memory API ───

export async function setMemory(key: string, data: unknown): Promise<void> {
  await put('memory', { id: key, key, data, timestamp: Date.now() });
}

export async function getMemory<T>(key: string): Promise<T | undefined> {
  const rec = await get<MemoryRecord>('memory', key);
  return rec?.data as T | undefined;
}
