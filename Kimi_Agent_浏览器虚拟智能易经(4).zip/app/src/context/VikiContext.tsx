import { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { getEngine } from '@/engine/viki';
import type { Mode, ChatMessage } from '@/engine/viki';
import type { ProjectRecord } from '@/storage/db';

interface VikiContextValue {
  messages: ChatMessage[];
  activeMode: Mode;
  isProcessing: boolean;
  projects: ProjectRecord[];
  currentCode: string | null;
  graphStats: { nodes: number; triples: number; stime: number; types: string[]; constraints: Array<{ name: string; description: string; verified: boolean }>; rules: number; verified: number } | null;
  discoveredRules: Array<{ pattern: Array<{ subject: string; relation: string; object: string }>; action: string; confidence: number; occurrences: number; verified: boolean }>;
  setActiveMode: (mode: Mode) => void;
  sendMessage: (text: string) => Promise<void>;
  verifyRule: (index: number) => Promise<void>;
  deleteProject: (id: string) => Promise<void>;
  clearChat: () => void;
  viewCode: (code: string) => void;
}

const VikiContext = createContext<VikiContextValue | null>(null);

export function VikiProvider({ children }: { children: React.ReactNode }) {
  const engineRef = useRef(getEngine());
  const engine = engineRef.current;
  const [, forceUpdate] = useState(0);

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [activeMode, setActiveMode] = useState<Mode>('chat');
  const [isProcessing, setIsProcessing] = useState(false);
  const [projects, setProjects] = useState<ProjectRecord[]>([]);
  const [currentCode, setCurrentCode] = useState<string | null>(null);
  const [graphStats, setGraphStats] = useState<VikiContextValue['graphStats']>(null);
  const [discoveredRules, setDiscoveredRules] = useState<VikiContextValue['discoveredRules']>([]);

  const sync = useCallback(() => {
    setMessages([...engine.messages]);
    setActiveMode(engine.activeMode);
    setIsProcessing(engine.isProcessing);
    setProjects([...engine.projects]);
    setCurrentCode(engine.currentCode);
    setGraphStats(engine.getGraphStats());
    setDiscoveredRules(engine.getDiscoveredRules());
    forceUpdate(v => v + 1);
  }, [engine]);

  useEffect(() => {
    engine.onUpdate = sync;
    engine.init().then(sync);
    return () => { engine.onUpdate = null; };
  }, [engine, sync]);

  const sendMessage = useCallback(async (text: string) => { await engine.sendMessage(text); }, [engine]);
  const verifyRule = useCallback(async (index: number) => { await engine.verifyRule(index); }, [engine]);
  const deleteProject = useCallback(async (id: string) => { await engine.deleteProject(id); }, [engine]);
  const clearChat = useCallback(() => { engine.clearChat(); }, [engine]);
  const viewCode = useCallback((code: string) => { engine.viewCode(code); }, [engine]);
  const setMode = useCallback((mode: Mode) => { engine.setMode(mode); }, [engine]);

  const value: VikiContextValue = {
    messages, activeMode, isProcessing, projects, currentCode, graphStats, discoveredRules,
    setActiveMode: setMode, sendMessage, verifyRule, deleteProject, clearChat, viewCode,
  };

  return <VikiContext.Provider value={value}>{children}</VikiContext.Provider>;
}

export function useViki(): VikiContextValue {
  const ctx = useContext(VikiContext);
  if (!ctx) throw new Error('useViki must be used within VikiProvider');
  return ctx;
}
