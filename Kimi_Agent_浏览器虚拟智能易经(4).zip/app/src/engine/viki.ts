/**
 * VIKI Unified Engine v6 — Deterministic Meta-System
 * 
 * NO RANDOMNESS. Same input → same output.
 * The backend IS the simulation.
 * Rules are explicit, named, and verifiable.
 */

import {
  GraphManager,
  DiscoveryEngine,
  SimulationEngine,
  createNode,
  type DiscoveredRule,
  CONSTRAINT_LIBRARY,
} from './meta';

import { GATES, getGate } from './gates';
import { parseIntent, generateCode } from './codegen';
import { saveConversation, getConversations, saveProject, getProjects, deleteProject, setMemory, getMemory } from '@/storage/db';
import type { ProjectRecord } from '@/storage/db';

export type Mode = 'chat' | 'code' | 'video' | 'graph' | 'rules' | 'projects';

export interface ChatMessage {
  id: string;
  role: 'user' | 'system';
  content: string;
  type: 'chat' | 'code' | 'video' | 'system';
  timestamp: number;
  metadata?: Record<string, unknown>;
}

export class VikiEngine {
  graph: GraphManager;
  discovery: DiscoveryEngine;
  simulation: SimulationEngine;
  messages: ChatMessage[] = [];
  activeMode: Mode = 'chat';
  isProcessing = false;
  projects: ProjectRecord[] = [];
  currentCode: string | null = null;
  onUpdate: (() => void) | null = null;

  // Session counter for deterministic IDs
  private sessionCounter = 0;
  private nextId(): string {
    return `n${Date.now()}_${this.sessionCounter++}`;
  }

  constructor() {
    this.graph = new GraphManager();
    this.discovery = new DiscoveryEngine();
    this.simulation = new SimulationEngine(this.graph);
    this.initDefaultConstraints();
    this.initDefaultGraph();
  }

  private initDefaultConstraints(): void {
    this.graph.addConstraint('conservation', 'Data must never be lost, only transformed', CONSTRAINT_LIBRARY.conservation);
    this.graph.addConstraint('consistency', 'State A must always lead to state B', CONSTRAINT_LIBRARY.consistency);
    this.graph.addConstraint('coherence', 'Every node must relate to the semantic root', CONSTRAINT_LIBRARY.coherence);
    this.graph.addConstraint('typeIntegrity', 'No dangling references', CONSTRAINT_LIBRARY.typeIntegrity);
  }

  private initDefaultGraph(): void {
    // Root node
    const root = createNode('root', 'root');
    root.attributes.set('name', 'VIKI');
    this.graph.addNode(root);

    // Initialize 64 gates as nodes
    for (const gate of GATES) {
      const node = createNode(`gate_${gate.gate}`, 'gate');
      node.attributes.set('aminoAcid', gate.aminoAcid);
      node.attributes.set('codons', gate.codons);
      node.attributes.set('dimension', gate.dimension);
      node.attributes.set('element', gate.element);
      node.attributes.set('sign', gate.sign);
      node.attributes.set('keynote', gate.keynote);
      this.graph.addNode(node);
      this.graph.assert('root', 'contains', `gate_${gate.gate}`);
      this.graph.assert(`gate_${gate.gate}`, 'is_a', 'gate');
      this.graph.assert(`gate_${gate.gate}`, 'has_amino_acid', gate.aminoAcid);
      this.graph.assert(`gate_${gate.gate}`, 'has_dimension', gate.dimension);
      this.graph.assert(`gate_${gate.gate}`, 'has_element', gate.element);
    }

    // Dimension nodes
    for (const dim of ['Movement', 'Evolution', 'Being', 'Design', 'Space']) {
      const node = createNode(`dim_${dim.toLowerCase()}`, 'dimension');
      node.attributes.set('name', dim);
      this.graph.addNode(node);
      this.graph.assert('root', 'contains', `dim_${dim.toLowerCase()}`);
    }
  }

  async init(): Promise<void> {
    // Load saved graph state
    const savedGraph = await getMemory<string>('graph_state');
    if (savedGraph) {
      try { this.graph.deserialize(savedGraph); } catch { /* ignore corrupt state */ }
    }

    // Load messages
    const convs = await getConversations();
    for (const conv of convs) {
      this.messages.push({
        id: conv.id,
        role: conv.role as 'user' | 'system',
        content: conv.content,
        type: conv.type as ChatMessage['type'],
        timestamp: conv.timestamp,
        metadata: conv.metadata as Record<string, unknown> || {},
      });
    }

    // Load projects
    this.projects = await getProjects();

    // Run discovery on conversation history
    const allText = convs.map(c => c.content).join('. ');
    if (allText.length > 20) {
      const triples = this.discovery.parseText(allText);
      for (const t of triples) {
        this.graph.assert(t.subject, t.relation, t.object);
      }
      this.discovery.discoverPatterns(triples);
    }
  }

  async saveGraph(): Promise<void> {
    await setMemory('graph_state', this.graph.serialize());
  }

  async sendMessage(text: string): Promise<void> {
    if (!text.trim() || this.isProcessing) return;
    this.isProcessing = true;
    this._notify();

    // 1. Store user message
    const userMsg: ChatMessage = {
      id: this.nextId(), role: 'user', content: text, type: 'chat', timestamp: Date.now(),
    };
    this.messages.push(userMsg);
    await saveConversation({ timestamp: Date.now(), role: 'user', content: text, type: 'chat' });

    // 2. PARSE: Convert input to triples
    const lower = text.toLowerCase().trim();
    const isCodeRequest = /(create|make|build|generate|write)\s+(a\s+|an\s+)?(game|app|code|script|program)/.test(lower)
      || /(snake|pong|platformer|shooter|calculator|todo|paint|clock|counter)/.test(lower);
    const isVideoRequest = /(create|make|generate)\s+(a\s+|an\s+)?video/.test(lower) || /video of/.test(lower);
    const isGraphQuery = /(show|list|find|what|who|where)\s+(node|gate|triple|relation)/.test(lower);
    const isRuleQuery = /(rule|constraint|verify|check|falsify)/.test(lower);

    // Parse text into triples
    const parsedTriples = this.discovery.parseText(text);
    for (const t of parsedTriples) {
      this.graph.assert(t.subject, t.relation, t.object);
    }

    // 3. DISCOVER: Find patterns
    const newRules = this.discovery.discoverPatterns(parsedTriples);

    // 4. MAP: Hash input to gate (deterministic, not random)
    let hash = 0;
    for (let i = 0; i < text.length; i++) {
      hash = ((hash << 5) - hash) + text.charCodeAt(i);
      hash = hash & 0xFFFFFFFF;
    }
    const gateNum = (Math.abs(hash) % 64) + 1;
    const line = (Math.abs(hash >> 6) % 6) + 1;
    const color = (Math.abs(hash >> 12) % 6) + 1;
    const tone = (Math.abs(hash >> 18) % 6) + 1;
    const base = (Math.abs(hash >> 24) % 4) + 1;
    const gate = getGate(gateNum) || GATES[0];

    // Determine dominant dimension from gate
    const dimKey = `dim_${gate.dimension.toLowerCase()}`;
    void dimKey;

    try {
      if (isCodeRequest) {
        // CODE: Parse intent → generate (deterministic mapping)
        const intent = parseIntent(text);
        const result = generateCode(intent);

        // Parse generated code into triples
        const codeTriples = this.discovery.parseCode(result.code, result.language);
        for (const t of codeTriples) {
          this.graph.assert(t.subject, t.relation, t.object);
        }

        // Save project
        const projectFiles = result.files?.map(f => ({ ...f, language: result.language || 'javascript' }));
        await saveProject({
          name: `${intent.subtype}_${intent.type}`,
          type: intent.type === 'game' ? 'game' : 'app',
          description: text,
          code: result.code,
          language: result.language,
          files: projectFiles,
        });
        this.projects = await getProjects();

        const sysMsg: ChatMessage = {
          id: this.nextId(),
          role: 'system',
          content: `Gate ${gate.gate}.${line} (${gate.aminoAcid}) → ${gate.dimension} mode\n\nBuilding ${intent.subtype} ${intent.type} through deterministic pattern mapping...\n\nGenerated ${result.language?.toUpperCase() || 'HTML'} source. Click "View Code" to see and run.`,
          type: 'code',
          timestamp: Date.now(),
          metadata: { code: result.code, language: result.language, files: projectFiles, gate: gate.gate, line, color, tone, base },
        };
        this.messages.push(sysMsg);
        this.currentCode = result.code;
        await saveConversation({ timestamp: Date.now(), role: 'system', content: sysMsg.content, type: 'code', metadata: sysMsg.metadata });

      } else if (isVideoRequest) {
        const desc = text.replace(/(create|make|generate|a|an|video|of)\s+/gi, '').trim() || 'abstract scene';
        const sysMsg: ChatMessage = {
          id: this.nextId(),
          role: 'system',
          content: `Gate ${gate.gate}.${line} (${gate.aminoAcid}) → ${gate.dimension} mode\n\nVideo description: "${desc}"\n\nThe scene is structured through ${gate.keynote} — ${gate.shadow} transforms into ${gate.gift}.\n\nIn the full deployment, the AI video pipeline renders from this semantic description.`,
          type: 'video',
          timestamp: Date.now(),
          metadata: { description: desc, gate: gate.gate, dimension: gate.dimension },
        };
        this.messages.push(sysMsg);
        await saveConversation({ timestamp: Date.now(), role: 'system', content: sysMsg.content, type: 'video', metadata: sysMsg.metadata });

      } else if (isGraphQuery) {
        // Show graph state
        const nodeCount = this.graph.nodeCount();
        const tripleCount = this.graph.query().length;
        const types = Array.from(new Set(this.graph.getAllNodes().map(n => n.semanticType)));
        const rules = this.discovery.getDiscoveredRules();
        const verified = rules.filter(r => r.verified).length;

        const sysMsg: ChatMessage = {
          id: this.nextId(),
          role: 'system',
          content: `Graph State:\n  Nodes: ${nodeCount}\n  Triples: ${tripleCount}\n  Types: ${types.join(', ')}\n  Discovered Rules: ${rules.length} (${verified} verified)\n  Simulated Time: ${this.graph.getSTIME()}\n\nGate ${gate.gate}.${line} active (${gate.dimension}).`,
          type: 'system',
          timestamp: Date.now(),
          metadata: { nodeCount, tripleCount, stime: this.graph.getSTIME() },
        };
        this.messages.push(sysMsg);
        await saveConversation({ timestamp: Date.now(), role: 'system', content: sysMsg.content, type: 'system' });

      } else if (isRuleQuery) {
        // Run falsification
        const violations = this.simulation.falsify();
        const constraints = this.graph.getConstraints();

        let content = `Constraint Check:\n`;
        for (const c of constraints) {
          const v = violations.find(v => v.constraint === c.name);
          content += `  ${c.name}: ${c.verified ? 'VERIFIED' : 'UNVERIFIED'} — ${v ? v.violations.length + ' violations' : 'OK'}\n`;
        }
        if (violations.length === 0) {
          content += `\nAll verified constraints pass. The simulation is consistent.`;
        } else {
          content += `\nViolations found:\n`;
          for (const v of violations) {
            for (const vi of v.violations) {
              content += `  [${v.constraint}] ${vi.message}\n`;
            }
          }
        }
        content += `\nGate ${gate.gate}.${line} (${gate.dimension}) — ${gate.keynote}`;

        const sysMsg: ChatMessage = {
          id: this.nextId(), role: 'system', content, type: 'system', timestamp: Date.now(),
          metadata: { violations: violations.length, constraints: constraints.length },
        };
        this.messages.push(sysMsg);
        await saveConversation({ timestamp: Date.now(), role: 'system', content, type: 'system' });

      } else {
        // CHAT: Deterministic response from gate data
        const lines = {1:"Investigation",2:"Projection",3:"Trial & Error",4:"Opportunism",5:"Heresy",6:"Role Model"};
        const colors = {1:"Fear",2:"Hope",3:"Desire",4:"Need",5:"Guilt",6:"Innocence"};
        const tones = {1:"Touch",2:"Taste",3:"Smell",4:"Hearing",5:"Sight",6:"Knowing"};
        const bases = {1:"Point",2:"Line",3:"Plane",4:"Volume"};

        // Check for learned patterns
        const allRules = this.discovery.getDiscoveredRules();
        const relevant = allRules.filter(r => r.verified && r.pattern.some(p => text.toLowerCase().includes(p.subject)));

        let content = '';
        if (relevant.length > 0) {
          content += `Pattern recognized from previous interactions:\n`;
          for (const r of relevant.slice(0, 3)) {
            content += `  ${r.pattern.map(p => `${p.subject} ${p.relation} ${p.object}`).join(', ')}\n`;
          }
          content += `\n`;
        }

        content += `${gate.keynote} — ${gate.aminoAcid} (Gate ${gate.gate})\n`;
        content += `Line ${line}: ${lines[line as keyof typeof lines] || 'Unknown'}\n`;
        content += `Color ${color}: ${colors[color as keyof typeof colors] || 'Unknown'}\n`;
        content += `Tone ${tone}: ${tones[tone as keyof typeof tones] || 'Unknown'}\n`;
        content += `Base ${base}: ${bases[base as keyof typeof bases] || 'Unknown'}\n\n`;
        content += `${gate.gift}: ${gate.shadow} transforms into ${gate.gift}.\n`;
        content += `Siddhi: ${gate.siddhi}.\n`;

        // Parse triples from user input for follow-up
        if (parsedTriples.length > 0) {
          content += `\nParsed ${parsedTriples.length} semantic triple(s):\n`;
          for (const t of parsedTriples.slice(0, 3)) {
            content += `  ${t.subject} —${t.relation}→ ${t.object}\n`;
          }
        }
        if (newRules.length > 0) {
          content += `\nDiscovered ${newRules.length} new pattern(s). Verify in Rules tab.`;
        }

        const sysMsg: ChatMessage = {
          id: this.nextId(), role: 'system', content, type: 'chat', timestamp: Date.now(),
          metadata: { gate: gate.gate, line, color, tone, base, dimension: gate.dimension, triples: parsedTriples.length, rules: newRules.length },
        };
        this.messages.push(sysMsg);
        await saveConversation({ timestamp: Date.now(), role: 'system', content, type: 'chat', metadata: sysMsg.metadata });
      }

      // 5. SAVE: Persist graph state
      await this.saveGraph();

    } catch (err) {
      this.messages.push({
        id: this.nextId(), role: 'system',
        content: `Simulation error: ${err instanceof Error ? err.message : String(err)}`,
        type: 'system', timestamp: Date.now(),
      });
    }

    this.isProcessing = false;
    this._notify();
  }

  async verifyRule(index: number): Promise<void> {
    this.discovery.verifyRule(index);
    await this.saveGraph();
    this._notify();
  }

  async deleteProject(id: string): Promise<void> {
    await deleteProject(id);
    this.projects = await getProjects();
    this._notify();
  }

  getDiscoveredRules(): DiscoveredRule[] {
    return this.discovery.getDiscoveredRules();
  }

  getGraphStats() {
    return {
      nodes: this.graph.nodeCount(),
      triples: this.graph.query().length,
      stime: this.graph.getSTIME(),
      types: Array.from(new Set(this.graph.getAllNodes().map(n => n.semanticType))),
      constraints: this.graph.getConstraints(),
      rules: this.discovery.getDiscoveredRules().length,
      verified: this.discovery.getDiscoveredRules().filter(r => r.verified).length,
    };
  }

  viewCode(code: string): void { this.currentCode = code; this.activeMode = 'code'; this._notify(); }
  setMode(mode: Mode): void { this.activeMode = mode; this._notify(); }
  clearChat(): void { this.messages = []; this._notify(); }

  private _notify(): void { this.onUpdate?.(); }
}

let _engine: VikiEngine | null = null;
export function getEngine(): VikiEngine {
  if (!_engine) _engine = new VikiEngine();
  return _engine;
}
