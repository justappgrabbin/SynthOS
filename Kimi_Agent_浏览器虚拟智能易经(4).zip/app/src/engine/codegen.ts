/**
 * Code Generation Engine
 * 
 * Semantic intent → code patterns → surface code.
 * No templates. Everything composed from semantic triples
 * that map to code primitives.
 * 
 * The user says "make a snake game" and the engine:
 * 1. Parses intent: (user wants game of-type snake)
 * 2. Finds patterns: game-loop + grid + entity-movement + collision
 * 3. Composes: snake-specific behavior from primitives
 * 4. Generates: complete HTML/Canvas/JavaScript file
 */

// ─── Intent Parser ───

export interface CodeIntent {
  type: 'game' | 'app' | 'script';
  subtype: string;       // snake, todo, calculator, etc.
  features: string[];    // what capabilities
  constraints: string[]; // limitations/requirements
  language: string;      // js, ts, html, etc.
}

export function parseIntent(input: string): CodeIntent {
  const lower = input.toLowerCase();

  // Detect type
  let type: CodeIntent['type'] = 'app';
  if (/\b(game|arcade|puzzle|platformer|shooter)\b/.test(lower)) type = 'game';
  else if (/\b(script|automation|tool|utility)\b/.test(lower)) type = 'script';

  // Detect subtype
  let subtype = 'generic';
  const subtypes: Record<string, string[]> = {
    snake: ['snake'],
    pong: ['pong', 'breakout'],
    platformer: ['platformer', 'platform', 'mario'],
    shooter: ['shooter', 'space invader', 'asteroid'],
    todo: ['todo', 'task', 'list'],
    calculator: ['calculator', 'calc'],
    counter: ['counter', 'clicker', 'increment'],
    chat: ['chat', 'messenger'],
    clock: ['clock', 'timer', 'stopwatch'],
    paint: ['paint', 'draw', 'canvas', 'sketch'],
    weather: ['weather', 'forecast'],
    pong_game: ['pong', 'breakout', 'paddle'],
    maze: ['maze', 'labyrinth'],
    tetris: ['tetris', 'block', 'puzzle'],
  };
  for (const [key, keywords] of Object.entries(subtypes)) {
    if (keywords.some(k => lower.includes(k))) { subtype = key; break; }
  }

  // Detect features
  const features: string[] = [];
  const featureMap: Record<string, string[]> = {
    scoring: ['score', 'point', 'high score', 'leaderboard'],
    levels: ['level', 'stage', 'world'],
    sound: ['sound', 'music', 'audio'],
    multiplayer: ['multiplayer', 'two player', 'vs', 'versus'],
    particles: ['particle', 'effect', 'explosion', 'spark'],
    saving: ['save', 'persist', 'storage', 'remember'],
    animation: ['animate', 'animation', 'smooth', 'tween'],
    touch: ['touch', 'mobile', 'swipe', 'gesture'],
  };
  for (const [feat, keywords] of Object.entries(featureMap)) {
    if (keywords.some(k => lower.includes(k))) features.push(feat);
  }

  // Detect constraints
  const constraints: string[] = [];
  if (/\b(simple|basic|minimal|small)\b/.test(lower)) constraints.push('simple');
  if (/\b(complex|advanced|full|complete)\b/.test(lower)) constraints.push('advanced');
  if (/\b(react|component)\b/.test(lower)) constraints.push('react');
  if (/\b(canvas|2d|draw)\b/.test(lower)) constraints.push('canvas');

  return { type, subtype, features, constraints, language: 'javascript' };
}

// ─── Code Pattern Library ───
// Each pattern is a function that generates code

interface CodePattern {
  name: string;
  applies: (intent: CodeIntent) => boolean;
  generate: (intent: CodeIntent) => string;
}

const PATTERNS: CodePattern[] = [
  // ─── GAMES ───
  {
    name: 'snake-game',
    applies: i => i.type === 'game' && i.subtype === 'snake',
    generate: () => generateSnakeGame(),
  },
  {
    name: 'pong-game',
    applies: i => i.type === 'game' && (i.subtype === 'pong' || i.subtype === 'pong_game'),
    generate: () => generatePongGame(),
  },
  {
    name: 'platformer-game',
    applies: i => i.type === 'game' && i.subtype === 'platformer',
    generate: () => generatePlatformer(),
  },
  {
    name: 'shooter-game',
    applies: i => i.type === 'game' && i.subtype === 'shooter',
    generate: () => generateShooter(),
  },
  {
    name: 'counter-game',
    applies: i => i.type === 'game' && i.subtype === 'counter',
    generate: () => generateCounter(),
  },
  {
    name: 'paint-app',
    applies: i => i.subtype === 'paint',
    generate: () => generatePaintApp(),
  },
  {
    name: 'clock-app',
    applies: i => i.subtype === 'clock',
    generate: () => generateClockApp(),
  },
  {
    name: 'calculator-app',
    applies: i => i.subtype === 'calculator',
    generate: () => generateCalculator(),
  },
  {
    name: 'todo-app',
    applies: i => i.subtype === 'todo',
    generate: () => generateTodoApp(),
  },
  {
    name: 'generic-game',
    applies: i => i.type === 'game',
    generate: () => generateGenericGame(),
  },
  {
    name: 'generic-app',
    applies: i => i.type === 'app',
    generate: () => generateGenericApp(),
  },
  {
    name: 'generic-script',
    applies: i => i.type === 'script',
    generate: () => generateGenericScript(),
  },
];

export function generateCode(intent: CodeIntent): { code: string; language: string; files?: Array<{ path: string; content: string }> } {
  const pattern = PATTERNS.find(p => p.applies(intent));
  if (pattern) {
    const code = pattern.generate(intent);
    return { code, language: 'javascript', files: [{ path: 'index.html', content: code }] };
  }
  return { code: '// Could not determine pattern from intent', language: 'javascript' };
}

// ─── Game Generators ───

function generateSnakeGame(): string {
  return `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Snake</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#0a0a12;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;font-family:monospace;color:#f0e6d3}
canvas{border:1px solid #1a1a2e;background:#050508}
#ui{display:flex;gap:20px;margin-top:10px;font-size:14px;color:#4a4a6a}
#score{color:#88cc00}#high{color:#ffaa00}
</style>
</head>
<body>
<canvas id="c" width="400" height="400"></canvas>
<div id="ui"><span>Score: <span id="score">0</span></span><span>High: <span id="high">0</span></span></div>
<script>
const c=document.getElementById('c'),x=c.getContext('2d'),S=20,W=20,H=20;
let snake=[{x:10,y:10}],dir={x:1,y:0},food={x:15,y:15},score=0,high=+localStorage.getItem('snakeHi')||0,gameOver=false,speed=120;
document.getElementById('high').textContent=high;
function placeFood(){do{food={x:Math.floor(Math.random()*W),y:Math.floor(Math.random()*H)}}while(snake.some(s=>s.x===food.x&&s.y===food.y))}
function draw(){x.fillStyle='#050508';x.fillRect(0,0,c.width,c.height);x.fillStyle='#88cc00';x.shadowBlur=8;x.shadowColor='#88cc00';for(const s of snake)x.fillRect(s.x*S+1,s.y*S+1,S-2,S-2);x.shadowBlur=0;x.fillStyle='#ff4444';x.shadowBlur=8;x.shadowColor='#ff4444';x.fillRect(food.x*S+1,food.y*S+1,S-2,S-2);x.shadowBlur=0;}
function update(){if(gameOver)return;const head={x:snake[0].x+dir.x,y:snake[0].y+dir.y};if(head.x<0||head.x>=W||head.y<0||head.y>=H||snake.some(s=>s.x===head.x&&s.y===head.y)){gameOver=true;x.fillStyle='rgba(255,68,68,0.3)';x.fillRect(0,0,c.width,c.height);x.fillStyle='#f0e6d3';x.font='20px monospace';x.textAlign='center';x.fillText('GAME OVER - Click to restart',200,200);return}snake.unshift(head);if(head.x===food.x&&head.y===food.y){score+=10;if(score>high){high=score;localStorage.setItem('snakeHi',high);document.getElementById('high').textContent=high}speed=Math.max(60,120-Math.floor(score/50)*10);placeFood()}else snake.pop();document.getElementById('score').textContent=score;}
document.addEventListener('keydown',e=>{if(gameOver)return;const k=e.key;if(k==='ArrowUp'&&dir.y===0)dir={x:0,y:-1};if(k==='ArrowDown'&&dir.y===0)dir={x:0,y:1};if(k==='ArrowLeft'&&dir.x===0)dir={x:-1,y:0};if(k==='ArrowRight'&&dir.x===0)dir={x:1,y:0}});
c.addEventListener('click',()=>{if(gameOver){snake=[{x:10,y:10}];dir={x:1,y:0};score=0;speed=120;gameOver=false;document.getElementById('score').textContent=0;placeFood()}});
let last=0;function loop(ts){if(ts-last>speed){last=ts;update();draw()}requestAnimationFrame(loop)}requestAnimationFrame(loop);
</script>
</body>
</html>`;
}

function generatePongGame(): string {
  return `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width"><title>Pong</title>
<style>*{margin:0;padding:0}body{background:#0a0a12;display:flex;justify-content:center;align-items:center;height:100vh}canvas{border:1px solid #1a1a2e}</style>
</head><body><canvas id="c" width="600" height="400"></canvas>
<script>
const c=document.getElementById('c'),x=c.getContext('2d');
const ball={x:300,y:200,dx:4,dy:3,r:6};
const p1={x:10,y:150,w:8,h:60,s:5,score:0};
const p2={x:582,y:150,w:8,h:60,s:4,score:0};
let keys={};
document.addEventListener('keydown',e=>keys[e.key]=true);
document.addEventListener('keyup',e=>keys[e.key]=false);
function draw(){x.fillStyle='#050508';x.fillRect(0,0,c.width,c.height);x.fillStyle='#1a1a2e';x.fillRect(c.width/2-1,0,2,c.height);x.fillStyle='#4466ff';x.fillRect(p1.x,p1.y,p1.w,p1.h);x.fillStyle='#ff4444';x.fillRect(p2.x,p2.y,p2.w,p2.h);x.fillStyle='#f0e6d3';x.beginPath();x.arc(ball.x,ball.y,ball.r,0,Math.PI*2);x.fill();x.font='40px monospace';x.fillStyle='#4466ff';x.fillText(p1.score,140,50);x.fillStyle='#ff4444';x.fillText(p2.score,440,50);}
function update(){ball.x+=ball.dx;ball.y+=ball.dy;if(ball.y-ball.r<0||ball.y+ball.r>c.height)ball.dy=-ball.dy;if(ball.x-ball.r<p1.x+p1.w&&ball.y>p1.y&&ball.y<p1.y+p1.h){ball.dx=Math.abs(ball.dx)*1.05;ball.x=p1.x+p1.w+ball.r}if(ball.x+ball.r>p2.x&&ball.y>p2.y&&ball.y<p2.y+p2.h){ball.dx=-Math.abs(ball.dx)*1.05;ball.x=p2.x-ball.r}if(ball.x<0){p2.score++;reset()}if(ball.x>c.width){p1.score++;reset()}if(keys['w']&&p1.y>0)p1.y-=p1.s;if(keys['s']&&p1.y<c.height-p1.h)p1.y+=p1.s;p2.y+=ball.y>p2.y+p2.h/2?p2.s:-p2.s;p2.y=Math.max(0,Math.min(c.height-p2.h,p2.y));}
function reset(){ball.x=300;ball.y=200;ball.dx=(Math.random()>0.5?1:-1)*4;ball.dy=(Math.random()-0.5)*6}
function loop(){update();draw();requestAnimationFrame(loop)}loop();
</script></body></html>`;
}

function generatePlatformer(): string {
  return `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Platformer</title>
<style>*{margin:0;padding:0}body{background:#0a0a12;display:flex;justify-content:center;align-items:center;height:100vh}canvas{border:1px solid #1a1a2e}</style>
</head><body><canvas id="c" width="640" height="480"></canvas>
<script>
const c=document.getElementById('c'),x=c.getContext('2d');
const player={x:50,y:400,w:20,h:20,vx:0,vy:0,grounded:false};
const gravity=0.6,jump=-12,move=4;
const platforms=[{x:0,y:460,w:640,h:20},{x:200,y:380,w:120,h:10},{x:400,y:300,w:120,h:10},{x:100,y:220,w:120,h:10},{x:350,y:160,w:120,h:10},{x:500,y:100,w:100,h:10}];
const coins=[{x:250,y:350},{x:450,y:270},{x:150,y:190},{x:400,y:130},{x:540,y:70}];
let score=0,keys={},camX=0;
document.addEventListener('keydown',e=>keys[e.key]=true);
document.addEventListener('keyup',e=>keys[e.key]=false);
function draw(){x.save();x.translate(-camX,0);x.fillStyle='#050508';x.fillRect(camX,0,c.width,c.height);for(const p of platforms){x.fillStyle='#1a1a2e';x.fillRect(p.x,p.y,p.w,p.h);x.fillStyle='#4466ff';x.fillRect(p.x,p.y,p.w,2)}for(let i=coins.length-1;i>=0;i--){const cn=coins[i];x.fillStyle='#ffaa00';x.beginPath();x.arc(cn.x,cn.y,8,0,Math.PI*2);x.fill();x.shadowBlur=10;x.shadowColor='#ffaa00';if(Math.abs(player.x+player.w/2-cn.x)<20&&Math.abs(player.y+player.h/2-cn.y)<20){score+=10;coins.splice(i,1)}x.shadowBlur=0}x.fillStyle='#88cc00';x.fillRect(player.x,player.y,player.w,player.h);x.restore();x.fillStyle='#f0e6d3';x.font='16px monospace';x.fillText('Score: '+score,10,25);if(coins.length===0){x.fillStyle='#88cc00';x.font='30px monospace';x.textAlign='center';x.fillText('COMPLETE!',c.width/2,c.height/2)}}
function update(){if(keys['ArrowLeft']||keys['a'])player.vx=-move;if(keys['ArrowRight']||keys['d'])player.vx=move;else if(!(keys['ArrowLeft']||keys['a']))player.vx*=0.8;player.vy+=gravity;player.x+=player.vx;player.y+=player.vy;player.grounded=false;for(const p of platforms){if(player.x+player.w>p.x&&player.x<p.x+p.w&&player.y+player.h>p.y&&player.y+player.h<p.y+player.vy+15){player.y=p.y-player.h;player.vy=0;player.grounded=true}}if((keys['ArrowUp']||keys['w']||keys[' '])&&player.grounded)player.vy=jump;camX=Math.max(0,player.x-c.width/2);}
function loop(){update();draw();requestAnimationFrame(loop)}loop();
</script></body></html>`;
}

function generateShooter(): string {
  return `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Shooter</title>
<style>*{margin:0;padding:0}body{background:#0a0a12;display:flex;justify-content:center;align-items:center;height:100vh}canvas{border:1px solid #1a1a2e;cursor:none}</style>
</head><body><canvas id="c" width="600" height="600"></canvas>
<script>
const c=document.getElementById('c'),x=c.getContext('2d');
const player={x:300,y:540,w:30,h:20};
let bullets=[],enemies=[],particles=[],stars=[],score=0,gameOver=false,frame=0;
for(let i=0;i<80;i++)stars.push({x:Math.random()*600,y:Math.random()*600,s:Math.random()*2});
c.addEventListener('mousemove',e=>{const r=c.getBoundingClientRect();player.x=e.clientX-r.left-player.w/2});
c.addEventListener('click',()=>{if(!gameOver)bullets.push({x:player.x+player.w/2,y:player.y,speed:8})});
function draw(){x.fillStyle='#050508';x.fillRect(0,0,600,600);for(const s of stars){x.fillStyle='rgba(240,230,211,'+(0.1+s.s*0.1)+')';x.fillRect(s.x,s.y,s.s,s.s)}for(const b of bullets){x.fillStyle='#88cc00';x.fillRect(b.x-1,b.y,3,10)}for(const e of enemies){x.fillStyle='#ff4444';x.fillRect(e.x,e.y,e.w,e.h);x.fillStyle='#ffaa00';x.fillRect(e.x+2,e.y+e.h,Math.max(0,e.w-4),3)}for(const p of particles){x.fillStyle=p.color;x.globalAlpha=p.life;x.fillRect(p.x,p.y,p.s,p.s)}x.globalAlpha=1;x.fillStyle='#4466ff';x.fillRect(player.x,player.y,player.w,player.h);x.font='16px monospace';x.fillStyle='#f0e6d3';x.fillText('Score: '+score,10,25);if(gameOver){x.fillStyle='rgba(255,68,68,0.3)';x.fillRect(0,0,600,600);x.fillStyle='#f0e6d3';x.font='28px monospace';x.textAlign='center';x.fillText('GAME OVER',300,300);x.font='14px monospace';x.fillText('Click to restart',300,340)}}
function update(){if(gameOver)return;frame++;if(frame%40===0){const size=20+Math.random()*15;enemies.push({x:Math.random()*(600-size),y:-size,w:size,h:size,speed:1+Math.random()*2,hp:Math.floor(size/10)})}for(let i=bullets.length-1;i>=0;i--){bullets[i].y-=bullets[i].speed;if(bullets[i].y<0)bullets.splice(i,1)}for(let i=enemies.length-1;i>=0;i--){const e=enemies[i];e.y+=e.speed;for(let j=bullets.length-1;j>=0;j--){const b=bullets[j];if(b.x>e.x&&b.x<e.x+e.w&&b.y<e.y+e.h&&b.y>e.y){e.hp--;bullets.splice(j,1);for(let k=0;k<5;k++)particles.push({x:e.x+e.w/2,y:e.y+e.h/2,vx:(Math.random()-0.5)*4,vy:(Math.random()-0.5)*4,life:1,color:'#ffaa00',s:3});if(e.hp<=0){enemies.splice(i,1);score+=10;break}}}if(e.y>600)enemies.splice(i,1);else if(e.x<player.x+player.w&&e.x+e.w>player.x&&e.y+e.h>player.y&&e.y<player.y+player.h)gameOver=true}for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.x+=p.vx;p.y+=p.vy;p.life-=0.05;if(p.life<=0)particles.splice(i,1)}}
c.addEventListener('click',()=>{if(gameOver){bullets=[];enemies=[];particles=[];score=0;gameOver=false;frame=0}});
function loop(){update();draw();requestAnimationFrame(loop)}loop();
</script></body></html>`;
}

function generateCounter(): string {
  return `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Counter</title>
<style>*{margin:0;padding:0;box-sizing:border-box}body{background:#0a0a12;display:flex;justify-content:center;align-items:center;height:100vh;font-family:monospace;color:#f0e6d3}.container{text-align:center}#count{font-size:120px;color:#88cc00;text-shadow:0 0 40px rgba(136,204,0,0.3);transition:transform 0.1s}.btn{background:#1a1a2e;border:1px solid #2a2a3e;color:#f0e6d3;padding:12px 24px;margin:8px;font-size:16px;font-family:monospace;cursor:pointer;transition:all 0.2s;border-radius:4px}.btn:hover{border-color:#4466ff;background:#11111a}.stats{margin-top:20px;color:#4a4a6a;font-size:12px}</style>
</head><body><div class="container"><div id="count">0</div><div><button class="btn" id="inc">+ Increment</button><button class="btn" id="dec">- Decrement</button><button class="btn" id="reset">Reset</button></div><div class="stats" id="stats">Clicks: 0 | Peak: 0</div></div>
<script>
let count=0,clicks=0,peak=0;
const $=id=>document.getElementById(id);
function update(){$('count').textContent=count;clicks++;if(Math.abs(count)>peak)peak=Math.abs(count);$('stats').textContent='Clicks: '+clicks+' | Peak: '+peak;$('count').style.transform='scale(1.2)';setTimeout(()=>$('count').style.transform='scale(1)',100)}
$('inc').onclick=()=>{count++;update()};
$('dec').onclick=()=>{count--;update()};
$('reset').onclick=()=>{count=0;clicks=0;peak=0;update()};
document.addEventListener('keydown',e=>{if(e.key==='ArrowUp'||e.key===' '){count++;update()}if(e.key==='ArrowDown'){count--;update()}});
</script></body></html>`;
}

function generatePaintApp(): string {
  return `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Paint</title>
<style>*{margin:0;padding:0}body{background:#0a0a12;display:flex;flex-direction:column;align-items:center;height:100vh;font-family:monospace;color:#f0e6d3}.toolbar{display:flex;gap:8px;padding:10px;background:#11111a;border-bottom:1px solid #1a1a2e;width:100%;justify-content:center;flex-wrap:wrap}.color{width:24px;height:24px;border-radius:50%;border:2px solid transparent;cursor:pointer}.color.active{border-color:#f0e6d3}#size{width:60px}button{background:#1a1a2e;border:1px solid #2a2a3e;color:#f0e6d3;padding:4px 12px;cursor:pointer;border-radius:4px;font-family:monospace}button:hover{border-color:#4466ff}canvas{flex:1;cursor:crosshair}</style>
</head><body><div class="toolbar">
<div class="color active" style="background:#f0e6d3" data-c="#f0e6d3"></div>
<div class="color" style="background:#ff4444" data-c="#ff4444"></div>
<div class="color" style="background:#4466ff" data-c="#4466ff"></div>
<div class="color" style="background:#88cc00" data-c="#88cc00"></div>
<div class="color" style="background:#ffaa00" data-c="#ffaa00"></div>
<div class="color" style="background:#0a0a12" data-c="#0a0a12"></div>
<input type="range" id="size" min="1" max="30" value="3">
<button id="clear">Clear</button>
<button id="save">Save</button>
</div><canvas id="c"></canvas>
<script>
const c=document.getElementById('c');c.width=window.innerWidth;c.height=window.innerHeight-60;
const x=c.getContext('2d');let drawing=false,color='#f0e6d3',size=3,last=null;
c.addEventListener('mousedown',e=>{drawing=true;last={x:e.offsetX,y:e.offsetY}});
c.addEventListener('mouseup',()=>{drawing=false;last=null});
c.addEventListener('mousemove',e=>{if(!drawing)return;x.strokeStyle=color;x.lineWidth=size;x.lineCap='round';x.beginPath();x.moveTo(last.x,last.y);x.lineTo(e.offsetX,e.offsetY);x.stroke();last={x:e.offsetX,y:e.offsetY}});
document.querySelectorAll('.color').forEach(el=>el.onclick=function(){document.querySelectorAll('.color').forEach(c=>c.classList.remove('active'));this.classList.add('active');color=this.dataset.c});
document.getElementById('size').oninput=function(){size=this.value};
document.getElementById('clear').onclick=()=>x.fillStyle='#050508';x.fillRect(0,0,c.width,c.height);
document.getElementById('save').onclick=()=>{const a=document.createElement('a');a.download='drawing.png';a.href=c.toDataURL();a.click()};
</script></body></html>`;
}

function generateClockApp(): string {
  return `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Clock</title>
<style>*{margin:0;padding:0;box-sizing:border-box}body{background:#0a0a12;display:flex;justify-content:center;align-items:center;height:100vh;font-family:'Courier New',monospace;color:#f0e6d3}#clock{font-size:80px;letter-spacing:8px;text-shadow:0 0 40px rgba(68,102,255,0.3)}#date{text-align:center;margin-top:20px;font-size:16px;color:#4a4a6a}</style>
</head><body><div><div id="clock">00:00:00</div><div id="date"></div></div>
<script>
function update(){const now=new Date();document.getElementById('clock').textContent=now.toLocaleTimeString('en-US',{hour12:false});document.getElementById('date').textContent=now.toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'})}setInterval(update,1000);update();
</script></body></html>`;
}

function generateCalculator(): string {
  return `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Calculator</title>
<style>*{margin:0;padding:0;box-sizing:border-box}body{background:#0a0a12;display:flex;justify-content:center;align-items:center;height:100vh;font-family:monospace}.calc{width:320px;background:#11111a;border:1px solid #1a1a2e;border-radius:8px;overflow:hidden}#display{padding:20px;font-size:32px;text-align:right;color:#f0e6d3;background:#0a0a12;min-height:80px;word-break:break-all}.buttons{display:grid;grid-template-columns:repeat(4,1fr)}button{padding:20px;font-size:18px;font-family:monospace;border:1px solid #0a0a12;background:#1a1a2e;color:#f0e6d3;cursor:pointer;transition:all 0.15s}button:hover{background:#2a2a3e}button:active{background:#3a3a4e}.op{background:#2a2a3e;color:#4466ff}.eq{background:#4466ff;color:#fff}.clear{background:#ff4444;color:#fff}</style>
</head><body><div class="calc"><div id="display">0</div><div class="buttons">
<button class="clear" onclick="ac()">AC</button><button onclick="press('/')">/</button><button onclick="press('*')">*</button><button onclick="del()">DEL</button>
<button onclick="press('7')">7</button><button onclick="press('8')">8</button><button onclick="press('9')">9</button><button class="op" onclick="press('-')">-</button>
<button onclick="press('4')">4</button><button onclick="press('5')">5</button><button onclick="press('6')">6</button><button class="op" onclick="press('+')">+</button>
<button onclick="press('1')">1</button><button onclick="press('2')">2</button><button onclick="press('3')">3</button><button class="eq" onclick="calc()" rowspan="2">=</button>
<button onclick="press('0')" style="grid-column:span 2">0</button><button onclick="press('.')">.</button>
</div></div>
<script>
let expr='';
function press(v){if(expr==='0'&&'0123456789'.includes(v))expr=v;else expr+=v;document.getElementById('display').textContent=expr||'0'}
function ac(){expr='';document.getElementById('display').textContent='0'}
function del(){expr=expr.slice(0,-1);document.getElementById('display').textContent=expr||'0'}
function calc(){try{expr=String(eval(expr)||0);document.getElementById('display').textContent=expr}catch{document.getElementById('display').textContent='Error';expr=''}}
</script></body></html>`;
}

function generateTodoApp(): string {
  return `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Todo</title>
<style>*{margin:0;padding:0;box-sizing:border-box}body{background:#0a0a12;display:flex;justify-content:center;align-items:center;height:100vh;font-family:monospace;color:#f0e6d3}.app{width:400px}.app h1{font-size:28px;margin-bottom:20px;color:#4466ff}.input-row{display:flex;gap:8px;margin-bottom:16px}input{flex:1;background:#11111a;border:1px solid #1a1a2e;color:#f0e6d3;padding:10px 14px;font-family:monospace;font-size:14px;border-radius:4px;outline:none}input:focus{border-color:#4466ff}button.add{background:#4466ff;border:none;color:#fff;padding:10px 16px;font-family:monospace;cursor:pointer;border-radius:4px}.list{display:flex;flex-direction:gap:4px}.item{display:flex;align-items:center;gap:10px;padding:10px;background:#11111a;border:1px solid #1a1a2e;margin-bottom:4px;border-radius:4px;transition:all 0.2s}.item:hover{border-color:#2a2a3e}.item.done{text-decoration:line-through;color:#4a4a6a}.item input[type=checkbox]{accent-color:#88cc00}.item .text{flex:1;font-size:14px}.item .del{color:#ff4444;cursor:pointer;font-size:12px;padding:2px 6px;border-radius:4px}.item .del:hover{background:rgba(255,68,68,0.1)}.stats{display:flex;justify-content:space-between;margin-top:10px;font-size:11px;color:#4a4a6a}</style>
</head><body><div class="app"><h1>Tasks</h1><div class="input-row"><input id="in" placeholder="What needs doing?" onkeydown="if(event.key==='Enter')add()"><button class="add" onclick="add()">Add</button></div><div id="list"></div><div class="stats"><span id="remaining">0 remaining</span><span id="completed">0 done</span></div></div>
<script>
let todos=JSON.parse(localStorage.getItem('viki_todos')||'[]');
function save(){localStorage.setItem('viki_todos',JSON.stringify(todos));render()}
function add(){const el=document.getElementById('in');const text=el.value.trim();if(!text)return;todos.push({id:Date.now(),text,done:false});el.value='';save()}
function toggle(id){const t=todos.find(t=>t.id===id);if(t)t.done=!t.done;save()}
function remove(id){todos=todos.filter(t=>t.id!==id);save()}
function render(){const list=document.getElementById('list');list.innerHTML='';for(const t of todos){const div=document.createElement('div');div.className='item'+(t.done?' done':'');div.innerHTML='<input type="checkbox" '+(t.done?'checked':'')+' onchange="toggle('+t.id+')">'+'<span class="text">'+escapeHtml(t.text)+'</span>'+'<span class="del" onclick="remove('+t.id+')">\u00D7</span>';list.appendChild(div)}document.getElementById('remaining').textContent=todos.filter(t=>!t.done).length+' remaining';document.getElementById('completed').textContent=todos.filter(t=>t.done).length+' done'}
function escapeHtml(s){const d=document.createElement('div');d.textContent=s;return d.innerHTML}render();
</script></body></html>`;
}

function generateGenericGame(): string {
  return generateSnakeGame();
}

function generateGenericApp(): string {
  return generateTodoApp();
}

function generateGenericScript(): string {
  return `// Generated Script
// A utility program that runs in the browser console

const utils = {
  // Generate a random ID
  uuid: () => Math.random().toString(36).slice(2) + Date.now().toString(36),
  
  // Deep clone an object
  clone: (obj) => JSON.parse(JSON.stringify(obj)),
  
  // Debounce a function
  debounce: (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms) } },
  
  // Format bytes to human readable
  formatBytes: (b) => { if(b===0)return'0 B'; const k=1024,s=['B','KB','MB','GB']; const i=Math.floor(Math.log(b)/Math.log(k)); return parseFloat((b/Math.pow(k,i)).toFixed(2))+' '+s[i] },
  
  // Shuffle array
  shuffle: (a) => { for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]} return a },
  
  // Run
  run: function() {
    console.log('Utils loaded. Available:');
    console.log('  utils.uuid()    - Generate random ID');
    console.log('  utils.clone(o)  - Deep clone object');
    console.log('  utils.debounce(fn, ms)');
    console.log('  utils.formatBytes(b)');
    console.log('  utils.shuffle(arr)');
  }
};

utils.run();

// Copy-paste this into any browser console to use
`;
}
