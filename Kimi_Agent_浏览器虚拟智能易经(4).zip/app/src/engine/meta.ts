/**
 * VIKI Meta-System v6 — Deterministic Simulation Architecture
 * 
 * Based on Sheldon Klein's MESSY + AUTOLING + DISEMINER + AutoNovel
 * 
 * Principles:
 * 1. NO RANDOMNESS in the core engine — same input → same output
 * 2. Semantic triples (S-R-O) are the universal data structure
 * 3. The backend IS the simulation
 * 4. Rules are explicit, named, and human-verifiable
 * 5. The system DISCOVERS patterns through structured dependency analysis
 * 6. Output is falsifiable against genetic constraints
 * 7. The developer is the informant who verifies discovered rules
 * 
 * Three Layers:
 *   STATE: The 69,120-node mesh (graph of MetaNodes)
 *   RULES: Genetic constraints (verified, deterministic logic)
 *   PARSER: Discovery engine (AUTOLING/DISEMINER fieldworker)
 */

// ─── Layer 1: STATE — The MetaNode & Graph ───

export interface Triple {
  readonly subject: string;
  readonly relation: string;
  readonly object: string;
}

export interface MetaNode {
  readonly id: string;
  readonly semanticType: string;
  createdAt: number;
  dependencies: Map<string, string[]>; // relation → [target_ids]
  state: Map<string, unknown>;
  attributes: Map<string, unknown>;
}

export function createNode(id: string, semanticType: string): MetaNode {
  return {
    id,
    semanticType,
    createdAt: Date.now(),
    dependencies: new Map(),
    state: new Map(),
    attributes: new Map(),
  };
}

export function addRelation(node: MetaNode, relation: string, targetId: string): void {
  const existing = node.dependencies.get(relation) || [];
  if (!existing.includes(targetId)) {
    node.dependencies.set(relation, [...existing, targetId]);
  }
}

export function removeRelation(node: MetaNode, relation: string, targetId: string): void {
  const existing = node.dependencies.get(relation) || [];
  node.dependencies.set(relation, existing.filter(id => id !== targetId));
}

export function getRelations(node: MetaNode, relation?: string): Array<{ relation: string; targets: string[] }> {
  if (relation) {
    const targets = node.dependencies.get(relation);
    return targets ? [{ relation, targets: [...targets] }] : [];
  }
  return Array.from(node.dependencies.entries()).map(([rel, targets]) => ({ relation: rel, targets: [...targets] }));
}

// ─── GraphManager — The 69,120-node mesh ───

export class GraphManager {
  private nodes = new Map<string, MetaNode>();
  private triples: Triple[] = [];
  private indexByType = new Map<string, Set<string>>();
  private indexByRelation = new Map<string, Set<string>>();
  private stime = 0; // simulated time (Klein's concept)

  // Genetic constraints — the "DNA" of the system
  private constraints: Array<{
    name: string;
    description: string;
    check: (graph: GraphManager) => Array<{ violated: boolean; nodeId?: string; message: string }>;
    verified: boolean;
  }> = [];

  getSTIME(): number { return this.stime; }
  tick(): void { this.stime++; }

  addNode(node: MetaNode): void {
    this.nodes.set(node.id, node);
    if (!this.indexByType.has(node.semanticType)) {
      this.indexByType.set(node.semanticType, new Set());
    }
    this.indexByType.get(node.semanticType)!.add(node.id);
  }

  getNode(id: string): MetaNode | undefined {
    return this.nodes.get(id);
  }

  hasNode(id: string): boolean {
    return this.nodes.has(id);
  }

  removeNode(id: string): void {
    const node = this.nodes.get(id);
    if (node) {
      this.indexByType.get(node.semanticType)?.delete(id);
    }
    this.nodes.delete(id);
    // Remove triples involving this node
    this.triples = this.triples.filter(t => t.subject !== id && t.object !== id);
  }

  getAllNodes(): MetaNode[] {
    return Array.from(this.nodes.values());
  }

  getNodesByType(type: string): MetaNode[] {
    const ids = this.indexByType.get(type);
    if (!ids) return [];
    return Array.from(ids).map(id => this.nodes.get(id)!).filter(Boolean);
  }

  nodeCount(): number {
    return this.nodes.size;
  }

  // Assert a triple into the graph
  assert(subject: string, relation: string, object: string): Triple {
    const triple: Triple = { subject, relation, object };
    // Check if already exists
    const exists = this.triples.some(t => 
      t.subject === subject && t.relation === relation && t.object === object
    );
    if (!exists) {
      this.triples.push(triple);
      // Index
      if (!this.indexByRelation.has(relation)) {
        this.indexByRelation.set(relation, new Set());
      }
      this.indexByRelation.get(relation)!.add(subject);
      // Add to node dependencies
      const subjNode = this.nodes.get(subject);
      if (subjNode) addRelation(subjNode, relation, object);
    }
    return triple;
  }

  // Query triples — deterministic pattern matching
  query(subject?: string, relation?: string, object?: string): Triple[] {
    return this.triples.filter(t => {
      if (subject !== undefined && t.subject !== subject) return false;
      if (relation !== undefined && t.relation !== relation) return false;
      if (object !== undefined && t.object !== object) return false;
      return true;
    });
  }

  // Find path between two nodes (breadth-first, deterministic)
  findPath(from: string, to: string, maxDepth: number = 5): Triple[][] {
    const paths: Triple[][] = [];
    const queue: Array<{ node: string; path: Triple[] }> = [{ node: from, path: [] }];
    const visited = new Set<string>();
    visited.add(from);

    while (queue.length > 0) {
      const current = queue.shift()!;
      if (current.path.length >= maxDepth) continue;

      const node = this.nodes.get(current.node);
      if (!node) continue;

      for (const [rel, targets] of node.dependencies) {
        for (const targetId of targets) {
          const triple: Triple = { subject: current.node, relation: rel, object: targetId };
          const newPath = [...current.path, triple];
          if (targetId === to) {
            paths.push(newPath);
          } else if (!visited.has(targetId) && current.path.length < maxDepth - 1) {
            visited.add(targetId);
            queue.push({ node: targetId, path: newPath });
          }
        }
      }
    }
    return paths;
  }

  // ─── Genetic Constraints ───

  addConstraint(name: string, description: string, check: (graph: GraphManager) => Array<{ violated: boolean; nodeId?: string; message: string }>): void {
    this.constraints.push({ name, description, check, verified: false });
  }

  verifyConstraint(name: string): void {
    const c = this.constraints.find(c => c.name === name);
    if (c) c.verified = true;
  }

  getConstraints() {
    return this.constraints.map(c => ({ name: c.name, description: c.description, verified: c.verified }));
  }

  // Run all verified constraints — falsifiable!
  checkConstraints(): Array<{ name: string; results: Array<{ violated: boolean; nodeId?: string; message: string }> }> {
    return this.constraints
      .filter(c => c.verified)
      .map(c => ({ name: c.name, results: c.check(this) }));
  }

  // Serialize the entire graph (substrate-independent)
  serialize(): string {
    const data = {
      stime: this.stime,
      nodes: Array.from(this.nodes.values()).map(n => ({
        id: n.id,
        semanticType: n.semanticType,
        createdAt: n.createdAt,
        dependencies: Array.from(n.dependencies.entries()).map(([k, v]) => [k, v]),
        state: Array.from(n.state.entries()).map(([k, v]) => [k, v]),
        attributes: Array.from(n.attributes.entries()).map(([k, v]) => [k, v]),
      })),
      triples: this.triples,
      constraints: this.constraints.map(c => ({ name: c.name, description: c.description, verified: c.verified })),
    };
    return JSON.stringify(data);
  }

  // Deserialize — reconstruct the simulation
  deserialize(json: string): void {
    const data = JSON.parse(json);
    this.stime = data.stime || 0;
    this.nodes.clear();
    this.triples = [];
    this.indexByType.clear();
    this.indexByRelation.clear();

    for (const n of data.nodes) {
      const node = createNode(n.id, n.semanticType);
      node.createdAt = n.createdAt;
      for (const [k, v] of n.dependencies) node.dependencies.set(k, v);
      for (const [k, v] of n.state) node.state.set(k, v);
      for (const [k, v] of n.attributes) node.attributes.set(k, v);
      this.addNode(node);
    }
    for (const t of data.triples) {
      this.triples.push(t);
    }
    for (const c of data.constraints || []) {
      this.constraints.push({ ...c, check: () => [] }); // check functions can't be serialized
    }
  }
}

// ─── Layer 2: RULES — Genetic Constraints ───

// Pre-defined constraint library
export const CONSTRAINT_LIBRARY = {
  // Conservation: data must never be lost, only transformed
  conservation: (graph: GraphManager) => {
    const results: Array<{ violated: boolean; nodeId?: string; message: string }> = [];
    const allNodes = graph.getAllNodes();
    for (const node of allNodes) {
      const hasRelations = node.dependencies.size > 0 || graph.query(node.id).length > 0;
      if (!hasRelations && allNodes.length > 1) {
        results.push({ violated: true, nodeId: node.id, message: `Node ${node.id} (${node.semanticType}) is isolated — no relations` });
      }
    }
    return results;
  },

  // Consistency: state A must always lead to state B
  consistency: (graph: GraphManager) => {
    const results: Array<{ violated: boolean; nodeId?: string; message: string }> = [];
    // Check for contradictory triples
    const triples = graph.query();
    for (const t1 of triples) {
      for (const t2 of triples) {
        if (t1.subject === t2.subject && t1.relation === t2.relation && t1.object !== t2.object) {
          // Same subject, same relation, different object — check for exclusion
          const exclusionTriples = graph.query(t1.subject, 'excludes', t2.object);
          if (exclusionTriples.length > 0) {
            results.push({ violated: true, nodeId: t1.subject, message: `Contradiction: ${t1.subject} ${t1.relation} both ${t1.object} and ${t2.object}` });
          }
        }
      }
    }
    return results;
  },

  // Coherence: every node must relate to the semantic root
  coherence: (graph: GraphManager) => {
    const results: Array<{ violated: boolean; nodeId?: string; message: string }> = [];
    const allNodes = graph.getAllNodes();
    const rootNodes = graph.getNodesByType('root');
    if (rootNodes.length === 0) return results;
    const rootId = rootNodes[0].id;
    for (const node of allNodes) {
      if (node.id === rootId) continue;
      const paths = graph.findPath(node.id, rootId, 5);
      if (paths.length === 0) {
        results.push({ violated: true, nodeId: node.id, message: `Node ${node.id} (${node.semanticType}) has no path to root` });
      }
    }
    return results;
  },

  // Type integrity: nodes must only relate to compatible types
  typeIntegrity: (graph: GraphManager) => {
    const results: Array<{ violated: boolean; nodeId?: string; message: string }> = [];
    const allNodes = graph.getAllNodes();
    for (const node of allNodes) {
      for (const [rel, targets] of node.dependencies) {
        for (const targetId of targets) {
          const target = graph.getNode(targetId);
          if (!target) {
            results.push({ violated: true, nodeId: node.id, message: `Dangling reference: ${node.id} → ${rel} → ${targetId} (node missing)` });
          }
        }
      }
    }
    return results;
  },
};

// ─── Layer 3: PARSER — Discovery Engine (AUTOLING-derived) ───

export interface DiscoveredRule {
  pattern: Triple[];     // what triggers this rule
  action: string;        // what to do
  confidence: number;    // 0.0 - 1.0, based on frequency
  occurrences: number;   // how many times seen
  verified: boolean;     // has the informant approved this?
}

export class DiscoveryEngine {
  private discoveredRules: DiscoveredRule[] = [];
  private patternFrequency = new Map<string, number>();

  // Parse text into semantic triples using dependency patterns
  parseText(text: string): Triple[] {
    const triples: Triple[] = [];
    const sentences = text.toLowerCase()
      .replace(/[^\w\s.,;:!?]/g, '')
      .split(/[.!?]+/)
      .map(s => s.trim())
      .filter(Boolean);

    for (const sentence of sentences) {
      const words = sentence.split(/\s+/).filter(Boolean);
      if (words.length >= 3) {
        // Simple S-V-O parsing: first noun = subject, verb = relation, rest = object
        const subject = words[0];
        // Find the verb (simple heuristic: words that look like verbs)
        let verbIdx = 1;
        for (let i = 1; i < words.length; i++) {
          if (this.isVerb(words[i])) { verbIdx = i; break; }
        }
        const relation = words[verbIdx];
        const object = words.slice(verbIdx + 1).join(' ') || 'something';
        triples.push({ subject, relation, object });
      }
    }
    return triples;
  }

  // Parse code into semantic triples (AST → triples)
  parseCode(code: string, language: string = 'javascript'): Triple[] {
    const triples: Triple[] = [];
    triples.push({ subject: 'code_block', relation: 'language', object: language });

    // Detect functions
    const functionMatches = code.matchAll(/(?:function|const|let|var)\s+(\w+)\s*[=\(]/g);
    for (const match of functionMatches) {
      triples.push({ subject: 'code_block', relation: 'defines', object: match[1] });
    }

    // Detect imports/requires
    const importMatches = code.matchAll(/(?:import|require)\s*\(?['"]([^'"]+)['"]/g);
    for (const match of importMatches) {
      triples.push({ subject: 'code_block', relation: 'depends_on', object: match[1] });
    }

    // Detect classes
    const classMatches = code.matchAll(/class\s+(\w+)/g);
    for (const match of classMatches) {
      triples.push({ subject: 'code_block', relation: 'defines_class', object: match[1] });
    }

    // Detect variables
    const varMatches = code.matchAll(/(?:const|let|var)\s+(\w+)\s*=/g);
    for (const match of varMatches) {
      triples.push({ subject: 'code_block', relation: 'declares', object: match[1] });
    }

    return triples;
  }

  // Discover patterns from a sequence of triples
  discoverPatterns(triples: Triple[]): DiscoveredRule[] {
    const newRules: DiscoveredRule[] = [];

    // Find repeated subject-relation pairs
    const pairFreq = new Map<string, number>();
    for (const t of triples) {
      const key = `${t.subject}:${t.relation}`;
      pairFreq.set(key, (pairFreq.get(key) || 0) + 1);
    }

    for (const [key, freq] of pairFreq) {
      if (freq >= 2) {
        const [subject, relation] = key.split(':');
        const objects = triples.filter(t => t.subject === subject && t.relation === relation).map(t => t.object);
        const patternKey = `${subject}:${relation}:${objects.join('|')}`;
        const existingFreq = this.patternFrequency.get(patternKey) || 0;
        this.patternFrequency.set(patternKey, existingFreq + freq);

        const confidence = Math.min(1.0, (existingFreq + freq) / 10);
        newRules.push({
          pattern: [{ subject, relation, object: objects[0] }],
          action: `assert(${subject}, ${relation}, ${objects[0]})`,
          confidence,
          occurrences: existingFreq + freq,
          verified: false,
        });
      }
    }

    // Find transitive patterns (A→B, B→C implies A→C)
    for (let i = 0; i < triples.length - 1; i++) {
      const t1 = triples[i];
      const t2 = triples[i + 1];
      if (t1.object === t2.subject) {
        const patternKey = `transitive:${t1.relation}:${t2.relation}`;
        const freq = (this.patternFrequency.get(patternKey) || 0) + 1;
        this.patternFrequency.set(patternKey, freq);
        newRules.push({
          pattern: [t1, t2],
          action: `transitive(${t1.subject}, ${t1.relation}, ${t2.relation}, ${t2.object})`,
          confidence: Math.min(1.0, freq / 5),
          occurrences: freq,
          verified: false,
        });
      }
    }

    this.discoveredRules.push(...newRules);
    return newRules;
  }

  getDiscoveredRules(): DiscoveredRule[] {
    return [...this.discoveredRules];
  }

  verifyRule(index: number): void {
    if (index >= 0 && index < this.discoveredRules.length) {
      this.discoveredRules[index].verified = true;
    }
  }

  private isVerb(word: string): boolean {
    const commonVerbs = ['is', 'are', 'was', 'were', 'has', 'have', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'can', 'make', 'create', 'build', 'generate', 'write', 'use', 'need', 'want', 'think', 'feel', 'know', 'see', 'hear', 'go', 'come', 'take', 'give', 'put', 'set', 'get', 'let', 'run', 'move', 'turn', 'play', 'show', 'tell', 'ask', 'work', 'call', 'try', 'say', 'find', 'look', 'help', 'try', 'become', 'leave', 'mean', 'keep', 'let', 'begin', 'seem', 'show', 'hear', 'play', 'move', 'live', 'believe', 'hold', 'bring', 'happen', 'stand', 'lose', 'pay', 'meet', 'include', 'continue', 'set', 'learn', 'change', 'lead', 'understand', 'watch', 'follow', 'stop', 'create', 'speak', 'read', 'allow', 'add', 'spend', 'grow', 'open', 'walk', 'win', 'offer', 'remember', 'love', 'consider', 'appear', 'buy', 'wait', 'serve', 'die', 'send', 'expect', 'build', 'stay', 'fall', 'cut', 'reach', 'kill', 'remain', 'suggest', 'raise', 'pass', 'sell', 'require', 'report', 'decide', 'pull'];
    if (commonVerbs.includes(word)) return true;
    return false;
  }
}

// ─── Simulation Engine (MESSY-derived) ───

export class SimulationEngine {
  private graph: GraphManager;
  constructor(graph: GraphManager) { this.graph = graph; }

  // Apply a discovered rule to the graph
  applyRule(rule: DiscoveredRule): void {
    if (!rule.verified) return;
    for (const pattern of rule.pattern) {
      this.graph.assert(pattern.subject, pattern.relation, pattern.object);
    }
    this.graph.tick();
  }

  // Simulate one step — process all verified rules
  step(): { applied: number; violations: Array<{ name: string; results: Array<{ violated: boolean; nodeId?: string; message: string }> }> } {
    const discovery = new DiscoveryEngine();
    // Re-discover from current graph state
    const allTriples = this.graph.query();
    const rules = discovery.discoverPatterns(allTriples);
    let applied = 0;
    for (const rule of rules) {
      if (rule.verified) {
        this.applyRule(rule);
        applied++;
      }
    }
    const violations = this.graph.checkConstraints();
    return { applied, violations };
  }

  // Run falsification check — returns all constraint violations
  falsify(): Array<{ constraint: string; violations: Array<{ nodeId?: string; message: string }> }> {
    const results = this.graph.checkConstraints();
    return results
      .filter(r => r.results.some(v => v.violated))
      .map(r => ({
        constraint: r.name,
        violations: r.results.filter(v => v.violated).map(v => ({ nodeId: v.nodeId, message: v.message })),
      }));
  }
}
