// ─── Core Types ───

export type Dimension = 'MOVEMENT' | 'EVOLUTION' | 'BEING' | 'DESIGN' | 'SPACE';

export interface DimensionConfig {
  code: string;
  name: Dimension;
  keynote: string;
  question: string;
  sense: string;
  color: string;
  binary: string;
}

export const DIMENSIONS: DimensionConfig[] = [
  { code: 'M', name: 'MOVEMENT', keynote: 'I Define', question: 'Where?', sense: 'Seeing', color: '#FF4444', binary: 'Yang/Yang' },
  { code: 'E', name: 'EVOLUTION', keynote: 'I Remember', question: 'What?', sense: 'Taste', color: '#4466FF', binary: 'Yang/Yin' },
  { code: 'B', name: 'BEING', keynote: 'I Am', question: 'When?', sense: 'Touch', color: '#88CC00', binary: 'Yin/Yin' },
  { code: 'D', name: 'DESIGN', keynote: 'I Design', question: 'Why?', sense: 'Smell', color: '#FFAA00', binary: 'Yin/Yang' },
  { code: 'S', name: 'SPACE', keynote: 'I Think', question: 'Who?', sense: 'Hearing', color: '#F0E6D3', binary: 'Subjective' },
];

export interface CoherenceReading {
  value: number;
  timestamp: number;
  dimension: Dimension;
}

export interface EngineOutput {
  timestamp: string;
  type: 'revelation' | 'system' | 'error';
  dimension?: Dimension;
  coherence?: number;
  message: string;
  sentences?: string[];
  followUpQuestions?: string[];
}

export interface NaturalRevelation {
  opening: string;
  body: string[];
  closing: string;
  dimension: string;
  coherence: number;
  tension: number;
  followUpQuestions: string[];
}

export interface MultiDimensionalRevelation {
  primary: NaturalRevelation;
  dimensions: NaturalRevelation[];
}

export interface QueryResult {
  input: string;
  measurements: { length: number; words: number; energy: number; density: number };
  dimension: Dimension;
  coherence: number;
  tension: number;
  revelation: NaturalRevelation;
  multiDim: MultiDimensionalRevelation;
  systemNote: string;
}
