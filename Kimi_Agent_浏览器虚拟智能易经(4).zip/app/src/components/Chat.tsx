import { useState, useRef, useEffect, useCallback } from 'react';
import { useViki } from '@/context/VikiContext';
import { Send, Trash2 } from 'lucide-react';

export default function Chat() {
  const { messages, sendMessage, isProcessing, clearChat } = useViki();
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, [messages]);

  const handleSubmit = useCallback(async () => {
    if (!input.trim() || isProcessing) return;
    const text = input.trim();
    setInput('');
    await sendMessage(text);
  }, [input, isProcessing, sendMessage]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSubmit(); } }, [handleSubmit]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {messages.length === 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', gap: 12, color: '#4A4A6A' }}>
            <p style={{ fontSize: 14 }}>VIKI Meta-System v6</p>
            <p style={{ fontSize: 12, textAlign: 'center', maxWidth: 400 }}>Deterministic simulation. No randomness. Rules are explicit and verifiable.</p>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'center' }}>
              {['Make a snake game', 'Show graph state', 'Check constraints', 'What is gate 48'].map(ex => (
                <button key={ex} onClick={() => { setInput(ex); }} style={{ padding: '5px 10px', borderRadius: 4, border: '1px solid #1A1A2E', background: 'rgba(26,26,46,0.3)', color: '#5A5A7A', fontSize: 11, cursor: 'pointer' }}>{ex}</button>
              ))}
            </div>
          </div>
        )}
        {messages.map(msg => (
          <div key={msg.id} style={{ display: 'flex', flexDirection: 'column', alignItems: msg.role === 'user' ? 'flex-end' : 'flex-start', maxWidth: '100%' }}>
            <div style={{ padding: '10px 14px', borderRadius: msg.role === 'user' ? '12px 12px 4px 12px' : '12px 12px 12px 4px', background: msg.role === 'user' ? 'rgba(68,102,255,0.1)' : 'rgba(26,26,46,0.5)', border: `1px solid ${msg.role === 'user' ? 'rgba(68,102,255,0.2)' : '#1A1A2E'}`, maxWidth: '90%', whiteSpace: 'pre-wrap' }}>
              <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 13, lineHeight: 1.6, color: msg.role === 'user' ? '#F0E6D3' : '#A0A0C0', margin: 0 }}>{msg.content}</p>
              {msg.metadata && typeof (msg.metadata as Record<string, string>).code === 'string' && (
                <button onClick={() => {}} style={{ marginTop: 8, padding: '4px 10px', background: 'rgba(68,102,255,0.15)', border: '1px solid rgba(68,102,255,0.3)', borderRadius: 4, color: '#4466FF', fontSize: 11, cursor: 'pointer' }}>View Code</button>
              )}
            </div>
            <span style={{ fontSize: 9, color: '#3A3A5A', fontFamily: "'JetBrains Mono', monospace", padding: '2px 4px' }}>{new Date(msg.timestamp).toLocaleTimeString()}</span>
          </div>
        ))}
        {isProcessing && <div style={{ padding: '8px 16px', color: '#4A4A6A', fontSize: 12 }}>Processing...</div>}
      </div>
      <div style={{ borderTop: '1px solid #1A1A2E', padding: '10px 16px', background: 'rgba(5,5,8,0.95)', display: 'flex', gap: 8, alignItems: 'center' }}>
        <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKeyDown} placeholder="Enter query..." style={{ flex: 1, background: '#11111A', border: '1px solid #1A1A2E', borderRadius: 8, padding: '10px 14px', color: '#F0E6D3', fontSize: 14, outline: 'none' }} />
        <button onClick={handleSubmit} disabled={isProcessing || !input.trim()} style={{ width: 36, height: 36, borderRadius: 8, border: 'none', background: input.trim() ? '#4466FF' : '#1A1A2E', color: '#fff', cursor: input.trim() ? 'pointer' : 'default', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Send size={14} /></button>
        <button onClick={clearChat} style={{ width: 32, height: 32, borderRadius: 6, border: 'none', background: 'transparent', color: '#4A4A6A', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Trash2 size={12} /></button>
      </div>
    </div>
  );
}
