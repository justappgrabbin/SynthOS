import { useViki } from '@/context/VikiContext';
import type { Mode } from '@/engine/viki';
import { MessageSquare, Code2, GitGraph, Scale, FolderOpen } from 'lucide-react';

const TABS: { mode: Mode; label: string; icon: typeof MessageSquare }[] = [
  { mode: 'chat', label: 'Chat', icon: MessageSquare },
  { mode: 'code', label: 'Code', icon: Code2 },
  { mode: 'graph', label: 'Graph', icon: GitGraph },
  { mode: 'rules', label: 'Rules', icon: Scale },
  { mode: 'projects', label: 'Projects', icon: FolderOpen },
];

export default function Header() {
  const { activeMode, setActiveMode, isProcessing, graphStats } = useViki();
  return (
    <header style={{ height: 48, background: 'rgba(5,5,8,0.95)', backdropFilter: 'blur(12px)', borderBottom: '1px solid #1A1A2E', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 16px', position: 'fixed', top: 0, left: 0, right: 0, zIndex: 50 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <h1 style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 18, fontWeight: 700, color: '#F0E6D3', letterSpacing: '-0.02em' }}>VIKI</h1>
        <div style={{ width: 6, height: 6, borderRadius: '50%', background: isProcessing ? '#FFAA00' : '#88CC00' }} />
        {graphStats && <span style={{ fontSize: 10, color: '#4A4A6A', fontFamily: "'JetBrains Mono', monospace" }}>N:{graphStats.nodes} T:{graphStats.triples} R:{graphStats.verified}/{graphStats.rules}</span>}
      </div>
      <nav style={{ display: 'flex', gap: 2 }}>
        {TABS.map(({ mode, label, icon: Icon }) => (
          <button key={mode} onClick={() => setActiveMode(mode)} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '5px 12px', borderRadius: 6, border: 'none', background: activeMode === mode ? 'rgba(68,102,255,0.12)' : 'transparent', color: activeMode === mode ? '#4466FF' : '#4A4A6A', fontFamily: "'Space Grotesk', sans-serif", fontSize: 12, fontWeight: activeMode === mode ? 600 : 500, cursor: 'pointer', transition: 'all 0.2s' }}>
            <Icon size={14} />{label}
          </button>
        ))}
      </nav>
    </header>
  );
}
