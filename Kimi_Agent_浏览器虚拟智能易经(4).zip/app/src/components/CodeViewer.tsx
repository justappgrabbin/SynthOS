import { useViki } from '@/context/VikiContext';
import { Copy, Download, Play } from 'lucide-react';

export default function CodeViewer() {
  const { currentCode, messages } = useViki();

  const findLastCode = () => {
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].metadata?.code) return messages[i].metadata!.code as string;
    }
    return currentCode || '';
  };

  const code = findLastCode();

  const handleCopy = () => { if (code) navigator.clipboard.writeText(code); };
  const handleDownload = () => {
    if (!code) return;
    const blob = new Blob([code], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'index.html'; a.click();
    URL.revokeObjectURL(url);
  };
  const handleRun = () => {
    if (!code) return;
    const blob = new Blob([code], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  };

  if (!code) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', gap: 12, color: '#4A4A6A' }}>
        <p style={{ fontSize: 14 }}>No code generated yet.</p>
        <p style={{ fontSize: 12 }}>Ask the system to build something.</p>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 16px', borderBottom: '1px solid #1A1A2E', background: 'rgba(5,5,8,0.8)' }}>
        <span style={{ fontSize: 11, fontWeight: 500, letterSpacing: '0.08em', textTransform: 'uppercase' as const, color: '#4A4A6A' }}>Generated Code</span>
        <div style={{ display: 'flex', gap: 6 }}>
          <button onClick={handleCopy} style={{ padding: '4px 10px', borderRadius: 4, border: '1px solid #1A1A2E', background: 'transparent', color: '#6A6A8A', fontSize: 11, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}><Copy size={12} />Copy</button>
          <button onClick={handleDownload} style={{ padding: '4px 10px', borderRadius: 4, border: '1px solid #1A1A2E', background: 'transparent', color: '#6A6A8A', fontSize: 11, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}><Download size={12} />Download</button>
          <button onClick={handleRun} style={{ padding: '4px 10px', borderRadius: 4, border: 'none', background: '#4466FF', color: '#fff', fontSize: 11, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}><Play size={12} />Run</button>
        </div>
      </div>
      <div style={{ flex: 1, overflow: 'auto', background: '#0A0A12' }}>
        <pre style={{ margin: 0, padding: '16px 20px', fontFamily: "'JetBrains Mono', monospace", fontSize: 12, lineHeight: 1.6, color: '#A0A0C0', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}><code>{code}</code></pre>
      </div>
    </div>
  );
}
