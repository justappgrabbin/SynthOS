import { useViki } from '@/context/VikiContext';
import { Scale, Check, AlertTriangle } from 'lucide-react';

export default function RulesPanel() {
  const { discoveredRules, verifyRule, graphStats } = useViki();

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'auto', padding: '16px 20px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
        <Scale size={16} color="#FFAA00" />
        <h2 style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 14, fontWeight: 600, color: '#F0E6D3', margin: 0 }}>Discovered Rules</h2>
      </div>

      {graphStats && (
        <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
          <div style={{ padding: '6px 12px', background: 'rgba(26,26,46,0.3)', borderRadius: 6, fontSize: 12, color: '#6A6A8A' }}>
            Total: {graphStats.rules}
          </div>
          <div style={{ padding: '6px 12px', background: 'rgba(136,204,0,0.1)', borderRadius: 6, fontSize: 12, color: '#88CC00' }}>
            Verified: {graphStats.verified}
          </div>
          <div style={{ padding: '6px 12px', background: 'rgba(255,170,0,0.1)', borderRadius: 6, fontSize: 12, color: '#FFAA00' }}>
            Pending: {graphStats.rules - graphStats.verified}
          </div>
        </div>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {discoveredRules.length === 0 && (
          <div style={{ padding: '40px 20px', textAlign: 'center', color: '#4A4A6A' }}>
            <AlertTriangle size={24} style={{ marginBottom: 8, opacity: 0.5 }} />
            <p style={{ fontSize: 13 }}>No rules discovered yet.</p>
            <p style={{ fontSize: 11 }}>Interact with the system to trigger pattern discovery.</p>
          </div>
        )}

        {discoveredRules.map((rule, i) => (
          <div key={i} style={{ padding: '10px 14px', background: rule.verified ? 'rgba(136,204,0,0.05)' : 'rgba(26,26,46,0.3)', borderRadius: 6, border: `1px solid ${rule.verified ? 'rgba(136,204,0,0.2)' : '#1A1A2E'}`, display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10 }}>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: rule.verified ? '#88CC00' : '#FFAA00' }} />
                <span style={{ fontSize: 10, color: rule.verified ? '#88CC00' : '#FFAA00', fontWeight: 600 }}>{rule.verified ? 'VERIFIED' : 'PENDING'}</span>
                <span style={{ fontSize: 10, color: '#4A4A6A' }}>conf: {(rule.confidence * 100).toFixed(0)}% | n={rule.occurrences}</span>
              </div>
              {rule.pattern.map((p, j) => (
                <div key={j} style={{ fontSize: 12, color: '#8A8AAA', fontFamily: "'JetBrains Mono', monospace", marginBottom: 2 }}>
                  {p.subject} <span style={{ color: '#4466FF' }}>—{p.relation}→</span> {p.object}
                </div>
              ))}
              <div style={{ fontSize: 10, color: '#5A5A7A', marginTop: 4 }}>{rule.action}</div>
            </div>
            {!rule.verified && (
              <button onClick={() => verifyRule(i)} style={{ padding: '4px 10px', borderRadius: 4, border: '1px solid rgba(136,204,0,0.3)', background: 'rgba(136,204,0,0.1)', color: '#88CC00', fontSize: 11, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4, whiteSpace: 'nowrap' }}>
                <Check size={10} /> Verify
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
