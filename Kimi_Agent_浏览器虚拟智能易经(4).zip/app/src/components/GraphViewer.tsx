import { useViki } from '@/context/VikiContext';
import { GitGraph, Box, ArrowRight } from 'lucide-react';

export default function GraphViewer() {
  const { graphStats } = useViki();

  if (!graphStats) {
    return <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: '#4A4A6A' }}>Loading graph...</div>;
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'auto', padding: '16px 20px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
        <GitGraph size={16} color="#4466FF" />
        <h2 style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 14, fontWeight: 600, color: '#F0E6D3', margin: 0 }}>Graph State</h2>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8, marginBottom: 20 }}>
        <StatCard label="Nodes" value={graphStats.nodes} />
        <StatCard label="Triples" value={graphStats.triples} />
        <StatCard label="Sim Time" value={graphStats.stime} />
        <StatCard label="Rules" value={`${graphStats.verified}/${graphStats.rules}`} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <div>
          <h3 style={{ fontSize: 11, color: '#4A4A6A', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>Node Types</h3>
          {graphStats.types.map(type => (
            <div key={type} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 10px', background: 'rgba(26,26,46,0.3)', borderRadius: 4, marginBottom: 4 }}>
              <Box size={12} color="#4466FF" />
              <span style={{ fontSize: 12, color: '#A0A0C0' }}>{type}</span>
            </div>
          ))}
        </div>

        <div>
          <h3 style={{ fontSize: 11, color: '#4A4A6A', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>Constraints</h3>
          {graphStats.constraints.map(c => (
            <div key={c.name} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 10px', background: c.verified ? 'rgba(136,204,0,0.08)' : 'rgba(26,26,46,0.3)', borderRadius: 4, marginBottom: 4, border: `1px solid ${c.verified ? 'rgba(136,204,0,0.2)' : '#1A1A2E'}` }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: c.verified ? '#88CC00' : '#4A4A6A' }} />
              <div>
                <span style={{ fontSize: 11, color: '#A0A0C0', fontWeight: 600 }}>{c.name}</span>
                <span style={{ fontSize: 10, color: '#5A5A7A', display: 'block' }}>{c.description}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ marginTop: 16 }}>
        <h3 style={{ fontSize: 11, color: '#4A4A6A', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>Architecture</h3>
        <div style={{ padding: '12px 16px', background: 'rgba(26,26,46,0.3)', borderRadius: 8, fontSize: 12, color: '#6A6A8A', lineHeight: 1.8, fontFamily: "'JetBrains Mono', monospace" }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span style={{ color: '#88CC00' }}>STATE</span>
            <ArrowRight size={12} color="#4A4A6A" />
            <span>69,120-node mesh (MetaNodes with S-R-O triples)</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span style={{ color: '#4466FF' }}>RULES</span>
            <ArrowRight size={12} color="#4A4A6A" />
            <span>Genetic constraints (conservation, consistency, coherence, typeIntegrity)</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ color: '#FFAA00' }}>PARSER</span>
            <ArrowRight size={12} color="#4A4A6A" />
            <span>Discovery engine (AUTOLING + DISEMINER fieldworker)</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: number | string }) {
  return (
    <div style={{ padding: '12px', background: 'rgba(26,26,46,0.3)', borderRadius: 8, textAlign: 'center' }}>
      <div style={{ fontSize: 20, fontWeight: 700, color: '#F0E6D3', fontFamily: "'JetBrains Mono', monospace" }}>{value}</div>
      <div style={{ fontSize: 10, color: '#4A4A6A', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}</div>
    </div>
  );
}
