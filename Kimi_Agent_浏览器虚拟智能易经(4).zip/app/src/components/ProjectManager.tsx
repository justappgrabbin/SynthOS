import { useViki } from '@/context/VikiContext';
import { Gamepad2, Globe, Trash2, Code2 } from 'lucide-react';

const TYPE_ICONS: Record<string, typeof Gamepad2> = { game: Gamepad2, app: Globe };
const TYPE_COLORS: Record<string, string> = { game: '#88CC00', app: '#4466FF' };

export default function ProjectManager() {
  const { projects, deleteProject } = useViki();

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'auto', padding: '16px 20px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <span style={{ fontSize: 11, fontWeight: 500, letterSpacing: '0.08em', textTransform: 'uppercase' as const, color: '#4A4A6A' }}>Projects ({projects.length})</span>
      </div>
      {projects.length === 0 && (
        <div style={{ textAlign: 'center', padding: '60px 20px', color: '#4A4A6A' }}>
          <Code2 size={36} style={{ marginBottom: 12, opacity: 0.4 }} />
          <p style={{ fontSize: 14 }}>No projects yet</p>
          <p style={{ fontSize: 12 }}>Ask the system to build games or apps.</p>
        </div>
      )}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 12 }}>
        {projects.map(proj => {
          const Icon = TYPE_ICONS[proj.type] || Code2;
          const color = TYPE_COLORS[proj.type] || '#4A4A6A';
          return (
            <div key={proj.id} style={{ padding: '14px 16px', background: 'rgba(26,26,46,0.3)', borderRadius: 8, border: '1px solid #1A1A2E' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                <div style={{ width: 32, height: 32, borderRadius: 8, background: `${color}15`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon size={16} color={color} /></div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ fontSize: 13, fontWeight: 600, color: '#F0E6D3', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{proj.name}</p>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 2 }}>
                    <span style={{ fontSize: 10, color, textTransform: 'uppercase' as const, letterSpacing: '0.05em' }}>{proj.type}</span>
                    <span style={{ fontSize: 10, color: '#4A4A6A' }}>{new Date(proj.created).toLocaleDateString()}</span>
                  </div>
                </div>
                <button onClick={() => deleteProject(proj.id)} style={{ width: 24, height: 24, borderRadius: 4, border: 'none', background: 'transparent', color: '#4A4A6A', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Trash2 size={12} /></button>
              </div>
              {proj.description && <p style={{ fontSize: 12, color: '#5A5A7A', lineHeight: 1.5, marginBottom: 8 }}>{proj.description}</p>}
              {proj.code && <span style={{ padding: '3px 8px', borderRadius: 4, background: 'rgba(68,102,255,0.08)', color: '#4466FF', fontSize: 10, fontFamily: "'JetBrains Mono', monospace" }}>HTML</span>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
