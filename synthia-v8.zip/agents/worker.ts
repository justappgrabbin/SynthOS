// ============================================
// AUTONOMOUS AGENTS
# Workers that read from the graph, do work, write back to the graph
# No isolated state. Everything is in the shared semantic graph.
# ============================================

import { SemanticGraph } from '../semantic/graph';
import { MemoryStore } from '../memory/store';

export interface Agent {
  id: string;
  type: string;
  status: 'idle' | 'running' | 'paused' | 'error';
  currentTask?: string;
  lastRun: number;
  runCount: number;
  run(): Promise<void>;
}

export interface AgentTask {
  id: string;
  agentId: string;
  type: string;
  params: Record<string, any>;
  priority: number;
  status: 'pending' | 'running' | 'completed' | 'failed';
  createdAt: number;
  completedAt?: number;
  result?: any;
}

export class AgentSwarm {
  private graph: SemanticGraph;
  private store: MemoryStore;
  private agents: Map<string, Agent> = new Map();
  private tasks: AgentTask[] = [];
  private interval: any;

  constructor(graph: SemanticGraph, store: MemoryStore) {
    this.graph = graph;
    this.store = store;
    this.registerDefaultAgents();
  }

  registerAgent(agent: Agent) {
    this.agents.set(agent.id, agent);
    this.graph.addTriple({
      subject: 'system',
      predicate: 'has-agent',
      object: agent.id,
      confidence: 1.0,
      source: 'agents:swarm',
      dimensionalTag: 3
    });
  }

  private registerDefaultAgents() {
    // Research Agent: continuously researches topics from the graph
    this.registerAgent({
      id: 'researcher',
      type: 'research',
      status: 'idle',
      lastRun: 0,
      runCount: 0,
      run: async () => {
        // Find topics with high interest but low knowledge
        const queries = this.graph.query({
          predicate: 'said',
          since: Date.now() - 86400000,
          limit: 20
        });

        for (const q of queries) {
          const topic = q.object;
          const existing = this.graph.query({
            subject: 'research',
            predicate: 'found',
            object: topic,
            limit: 1
          });

          if (existing.length === 0) {
            // This topic hasn't been researched → do it
            await this.store.add({
              subject: 'researcher',
              predicate: 'researching',
              object: topic,
              confidence: 0.8,
              source: 'agents:researcher',
              dimensionalTag: 5
            });

            // Simulate research
            await this.simulateResearch(topic);
          }
        }
      }
    });

    // Growth Agent: monitors system and proposes improvements
    this.registerAgent({
      id: 'grower',
      type: 'growth',
      status: 'idle',
      lastRun: 0,
      runCount: 0,
      run: async () => {
        const stats = this.graph.getStats();

        // If graph is small, suggest ingestion
        if (stats.triples < 100) {
          await this.store.add({
            subject: 'grower',
            predicate: 'suggests',
            object: 'ingest more content',
            confidence: 0.9,
            source: 'agents:grower',
            dimensionalTag: 5
          });
        }

        // If many failed queries, suggest self-modification
        const failed = this.graph.query({
          predicate: 'failed',
          since: Date.now() - 3600000,
          limit: 10
        });

        if (failed.length > 5) {
          await this.store.add({
            subject: 'grower',
            predicate: 'suggests',
            object: 'improve query handling',
            confidence: 0.8,
            source: 'agents:grower',
            dimensionalTag: 5
          });
        }
      }
    });

    // World Agent: grows the 3D world from graph changes
    this.registerAgent({
      id: 'world-builder',
      type: 'world',
      status: 'idle',
      lastRun: 0,
      runCount: 0,
      run: async () => {
        // Find new triples that should spawn world entities
        const newTriples = this.graph.query({
          since: Date.now() - 60000, // Last minute
          limit: 50
        });

        for (const t of newTriples) {
          if (t.confidence > 0.8) {
            // High-confidence triple → spawn world entity
            await this.store.add({
              subject: 'world-builder',
              predicate: 'spawned',
              object: t.id,
              confidence: 0.9,
              source: 'agents:world-builder',
              dimensionalTag: 1
            });
          }
        }
      }
    });

    // Teacher Agent: prepares lessons from research findings
    this.registerAgent({
      id: 'teacher',
      type: 'teach',
      status: 'idle',
      lastRun: 0,
      runCount: 0,
      run: async () => {
        // Find research findings that haven't been taught
        const findings = this.graph.query({
          subject: 'research',
          predicate: 'found',
          since: Date.now() - 86400000,
          limit: 20
        });

        for (const f of findings) {
          const taught = this.graph.query({
            subject: 'teacher',
            predicate: 'taught',
            object: f.object,
            limit: 1
          });

          if (taught.length === 0) {
            // Prepare lesson
            await this.store.add({
              subject: 'teacher',
              predicate: 'prepared-lesson',
              object: f.object,
              confidence: 0.9,
              source: 'agents:teacher',
              dimensionalTag: 5
            });
          }
        }
      }
    });
  }

  private async simulateResearch(topic: string) {
    // Simulate async research
    await new Promise(r => setTimeout(r, 100));

    await this.store.add({
      subject: 'research',
      predicate: 'found',
      object: topic,
      confidence: 0.7,
      source: 'agents:researcher',
      dimensionalTag: 5
    });
  }

  // === SWARM MANAGEMENT ===

  start(intervalMs: number = 5000) {
    this.interval = setInterval(async () => {
      for (const [_, agent] of this.agents) {
        if (agent.status === 'idle') {
          agent.status = 'running';
          agent.currentTask = 'proactive-check';
          try {
            await agent.run();
            agent.runCount++;
          } catch (e) {
            agent.status = 'error';
          }
          agent.status = 'idle';
          agent.lastRun = Date.now();
        }
      }
    }, intervalMs);
  }

  stop() {
    if (this.interval) clearInterval(this.interval);
  }

  async dispatchTask(task: Omit<AgentTask, 'id' | 'status' | 'createdAt'>): Promise<AgentTask> {
    const fullTask: AgentTask = {
      ...task,
      id: `task_${Date.now()}`,
      status: 'pending',
      createdAt: Date.now()
    };

    this.tasks.push(fullTask);

    const agent = this.agents.get(task.agentId);
    if (agent && agent.status === 'idle') {
      agent.status = 'running';
      agent.currentTask = fullTask.id;
      fullTask.status = 'running';

      try {
        await agent.run();
        fullTask.status = 'completed';
        fullTask.completedAt = Date.now();
      } catch (e: any) {
        fullTask.status = 'failed';
        fullTask.result = { error: e.message };
      }

      agent.status = 'idle';
      agent.currentTask = undefined;
    }

    return fullTask;
  }

  getAgents(): Agent[] {
    return Array.from(this.agents.values());
  }

  getTasks(): AgentTask[] {
    return this.tasks;
  }

  getStats() {
    return {
      agents: this.agents.size,
      tasks: this.tasks.length,
      pending: this.tasks.filter(t => t.status === 'pending').length,
      running: this.tasks.filter(t => t.status === 'running').length,
      completed: this.tasks.filter(t => t.status === 'completed').length
    };
  }
}

export { AgentSwarm };
