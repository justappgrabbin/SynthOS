// ============================================
// PLANNER / ORCHESTRATOR
# Decides what happens next based on graph state
# Reactive: respond to user input
# Proactive: suggest actions, research, growth based on field state
# ============================================

import { SemanticGraph } from '../semantic/graph';
import { MemoryStore } from '../memory/store';

export interface Plan {
  id: string;
  trigger: string;       // What caused this plan
  goal: string;          // What it aims to achieve
  steps: PlanStep[];
  priority: number;      // 1-10
  status: 'pending' | 'active' | 'completed' | 'failed';
  createdAt: number;
  dimensionalTag: number;
}

export interface PlanStep {
  id: string;
  action: string;          // Tool name or internal action
  params: Record<string, any>;
  dependsOn?: string[];    // Step IDs that must complete first
  status: 'pending' | 'running' | 'completed' | 'failed';
  result?: any;
}

export interface ToolCapability {
  name: string;
  description: string;
  requiredParams: string[];
  optionalParams: string[];
  dimensionalAffinity: number; // Which dimension this tool serves best
}

export class Planner {
  private graph: SemanticGraph;
  private store: MemoryStore;
  private plans: Plan[] = [];
  private tools: Map<string, ToolCapability> = new Map();
  private running: boolean = false;

  constructor(graph: SemanticGraph, store: MemoryStore) {
    this.graph = graph;
    this.store = store;
    this.registerTools();
  }

  private registerTools() {
    this.tools.set('chat', {
      name: 'chat',
      description: 'Respond to user in natural language',
      requiredParams: ['message'],
      optionalParams: ['context', 'style'],
      dimensionalAffinity: 3
    });

    this.tools.set('generate_code', {
      name: 'generate_code',
      description: 'Generate code based on specification',
      requiredParams: ['specification'],
      optionalParams: ['language', 'framework'],
      dimensionalAffinity: 1
    });

    this.tools.set('ingest', {
      name: 'ingest',
      description: 'Ingest content into the graph',
      requiredParams: ['source'],
      optionalParams: ['type', 'priority'],
      dimensionalAffinity: 4
    });

    this.tools.set('research', {
      name: 'research',
      description: 'Research a topic and store findings',
      requiredParams: ['topic'],
      optionalParams: ['depth', 'sources'],
      dimensionalAffinity: 5
    });

    this.tools.set('world_command', {
      name: 'world_command',
      description: 'Send command to 3D world simulator',
      requiredParams: ['command'],
      optionalParams: ['entity', 'properties'],
      dimensionalAffinity: 1
    });

    this.tools.set('teach', {
      name: 'teach',
      description: 'Teach user about a topic',
      requiredParams: ['topic'],
      optionalParams: ['level', 'format'],
      dimensionalAffinity: 5
    });

    this.tools.set('connect_mcp', {
      name: 'connect_mcp',
      description: 'Connect to external MCP server',
      requiredParams: ['serverId'],
      optionalParams: ['config'],
      dimensionalAffinity: 2
    });

    this.tools.set('self_modify', {
      name: 'self_modify',
      description: 'Modify the running system',
      requiredParams: ['target'],
      optionalParams: ['change', 'code'],
      dimensionalAffinity: 5
    });
  }

  // === REACTIVE PLANNING ===

  async planFromIntent(intent: string, context: any = {}): Promise<Plan> {
    // Parse intent to determine what the user wants
    const parsed = this.parseIntent(intent);

    // Find the best tool for this intent
    const tool = this.selectTool(parsed);

    // Build plan steps
    const steps: PlanStep[] = [];

    // Step 1: Gather context from graph
    steps.push({
      id: `step_${Date.now()}_context`,
      action: 'query_graph',
      params: { intent: parsed.action, target: parsed.target },
      status: 'pending'
    });

    // Step 2: Execute primary tool
    steps.push({
      id: `step_${Date.now()}_execute`,
      action: tool.name,
      params: this.buildParams(tool, parsed, context),
      dependsOn: [steps[0].id],
      status: 'pending'
    });

    // Step 3: Store result in graph
    steps.push({
      id: `step_${Date.now()}_store`,
      action: 'store_result',
      params: {},
      dependsOn: [steps[1].id],
      status: 'pending'
    });

    // Step 4: Check for follow-up opportunities
    if (parsed.action === 'research' || parsed.action === 'ingest') {
      steps.push({
        id: `step_${Date.now()}_teach`,
        action: 'teach',
        params: { topic: parsed.target },
        dependsOn: [steps[2].id],
        status: 'pending'
      });
    }

    const plan: Plan = {
      id: `plan_${Date.now()}`,
      trigger: intent,
      goal: `${parsed.action} ${parsed.target}`,
      steps,
      priority: parsed.urgency,
      status: 'pending',
      createdAt: Date.now(),
      dimensionalTag: tool.dimensionalAffinity
    };

    this.plans.push(plan);

    // Execute immediately for reactive plans
    this.executePlan(plan);

    return plan;
  }

  private parseIntent(intent: string): { action: string; target: string; urgency: number; params: Record<string, any> } {
    const lower = intent.toLowerCase();

    // Action detection
    let action = 'chat';
    if (lower.includes('build') || lower.includes('create') || lower.includes('make')) action = 'generate_code';
    if (lower.includes('ingest') || lower.includes('read') || lower.includes('load')) action = 'ingest';
    if (lower.includes('research') || lower.includes('learn') || lower.includes('study')) action = 'research';
    if (lower.includes('world') || lower.includes('3d') || lower.includes('spawn')) action = 'world_command';
    if (lower.includes('teach') || lower.includes('explain')) action = 'teach';
    if (lower.includes('connect') || lower.includes('mcp')) action = 'connect_mcp';
    if (lower.includes('modify') || lower.includes('change') || lower.includes('update')) action = 'self_modify';

    // Target extraction (simplified)
    const words = intent.split(/\s+/);
    const target = words.slice(1).join(' ') || 'system';

    // Urgency based on keywords
    let urgency = 5;
    if (lower.includes('now') || lower.includes('urgent') || lower.includes('asap')) urgency = 10;
    if (lower.includes('later') || lower.includes('someday')) urgency = 2;

    return { action, target, urgency, params: {} };
  }

  private selectTool(parsed: { action: string }): ToolCapability {
    return this.tools.get(parsed.action) || this.tools.get('chat')!;
  }

  private buildParams(tool: ToolCapability, parsed: any, context: any): Record<string, any> {
    const params: Record<string, any> = {};

    for (const req of tool.requiredParams) {
      if (req === 'message') params[req] = parsed.target;
      if (req === 'specification') params[req] = parsed.target;
      if (req === 'source') params[req] = parsed.target;
      if (req === 'topic') params[req] = parsed.target;
      if (req === 'command') params[req] = parsed.action;
      if (req === 'serverId') params[req] = parsed.target;
      if (req === 'target') params[req] = parsed.target;
    }

    for (const opt of tool.optionalParams) {
      if (context[opt]) params[opt] = context[opt];
    }

    return params;
  }

  // === PROACTIVE PLANNING ===

  async proactiveCheck(): Promise<Plan[]> {
    const newPlans: Plan[] = [];

    // Check 1: User has been asking about a topic repeatedly → research deeper
    const recentQueries = this.graph.query({
      predicate: 'said',
      since: Date.now() - 86400000, // Last 24 hours
      limit: 50
    });

    const topicFrequency = new Map<string, number>();
    for (const q of recentQueries) {
      const topic = q.object.split(/\s+/).slice(0, 3).join(' ');
      topicFrequency.set(topic, (topicFrequency.get(topic) || 0) + 1);
    }

    for (const [topic, count] of topicFrequency) {
      if (count >= 3) {
        // User is interested in this topic → proactive research
        const plan = await this.planFromIntent(`Research ${topic} deeply`, { proactive: true });
        plan.priority = 3; // Lower priority than user-initiated
        newPlans.push(plan);
      }
    }

    // Check 2: Graph has grown significantly → suggest teaching
    const stats = this.graph.getStats();
    if (stats.triples > 1000 && stats.triples % 500 < 50) {
      const plan = await this.planFromIntent('Teach me something new from the graph', { proactive: true });
      plan.priority = 2;
      newPlans.push(plan);
    }

    // Check 3: World has many unconnected entities → suggest connection
    const worldEntities = this.graph.query({ source: 'world', limit: 100 });
    if (worldEntities.length > 20) {
      const plan = await this.planFromIntent('Connect related entities in the world', { proactive: true });
      plan.priority = 2;
      newPlans.push(plan);
    }

    return newPlans;
  }

  // === EXECUTION ===

  private async executePlan(plan: Plan) {
    plan.status = 'active';

    for (const step of plan.steps) {
      if (step.dependsOn) {
        // Wait for dependencies
        const depsComplete = step.dependsOn.every(depId => {
          const dep = plan.steps.find(s => s.id === depId);
          return dep?.status === 'completed';
        });
        if (!depsComplete) continue;
      }

      step.status = 'running';

      try {
        step.result = await this.executeStep(step);
        step.status = 'completed';
      } catch (err: any) {
        step.status = 'failed';
        step.result = { error: err.message };
      }
    }

    const allComplete = plan.steps.every(s => s.status === 'completed');
    const anyFailed = plan.steps.some(s => s.status === 'failed');

    plan.status = allComplete ? 'completed' : anyFailed ? 'failed' : 'active';
  }

  private async executeStep(step: PlanStep): Promise<any> {
    // In real implementation: dispatch to appropriate module
    // This is a placeholder that returns mock results

    switch (step.action) {
      case 'query_graph':
        return this.graph.query(step.params);

      case 'store_result':
        return { stored: true };

      default:
        return { action: step.action, params: step.params, executed: true };
    }
  }

  getPlans(): Plan[] {
    return this.plans;
  }

  getPendingPlans(): Plan[] {
    return this.plans.filter(p => p.status === 'pending' || p.status === 'active');
  }

  getStats() {
    return {
      totalPlans: this.plans.length,
      pending: this.plans.filter(p => p.status === 'pending').length,
      active: this.plans.filter(p => p.status === 'active').length,
      completed: this.plans.filter(p => p.status === 'completed').length,
      failed: this.plans.filter(p => p.status === 'failed').length,
      tools: this.tools.size
    };
  }
}

export { Planner };
