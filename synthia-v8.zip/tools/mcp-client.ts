// ============================================
// MCP TOOL CLIENT
# All external integrations as plugins on the shared graph
# No hardcoded APIs. Everything registers as a tool.
# ============================================

import { SemanticGraph } from '../semantic/graph';

export interface Tool {
  id: string;
  name: string;
  description: string;
  provider: string;        // 'internal', 'mcp', 'api', 'local'
  config: Record<string, any>;
  execute: (params: Record<string, any>) => Promise<any>;
  schema: {
    input: Record<string, { type: string; required: boolean; description: string }>;
    output: Record<string, { type: string; description: string }>;
  };
}

export class ToolRegistry {
  private graph: SemanticGraph;
  private tools: Map<string, Tool> = new Map();

  constructor(graph: SemanticGraph) {
    this.graph = graph;
    this.registerInternalTools();
  }

  register(tool: Tool) {
    this.tools.set(tool.id, tool);
    this.graph.addTriple({
      subject: 'system',
      predicate: 'has-tool',
      object: tool.id,
      confidence: 1.0,
      source: 'tools:registry',
      dimensionalTag: 2
    });
    this.graph.addTriple({
      subject: tool.id,
      predicate: 'provided-by',
      object: tool.provider,
      confidence: 1.0,
      source: 'tools:registry',
      dimensionalTag: 2
    });
  }

  private registerInternalTools() {
    // Chat tool
    this.register({
      id: 'tool:chat',
      name: 'chat',
      description: 'Natural language conversation',
      provider: 'internal',
      config: {},
      execute: async (params) => {
        return {
          response: `Processed: ${params.message}`,
          context: params.context || {}
        };
      },
      schema: {
        input: {
          message: { type: 'string', required: true, description: 'User message' }
        },
        output: {
          response: { type: 'string', description: 'System response' }
        }
      }
    });

    // Code generation tool
    this.register({
      id: 'tool:codegen',
      name: 'generate_code',
      description: 'Generate code from specification',
      provider: 'internal',
      config: {},
      execute: async (params) => {
        const { language, specification } = params;
        return {
          code: `// ${language} code for: ${specification}\nexport default function() { return "${specification}"; }`,
          language,
          specification
        };
      },
      schema: {
        input: {
          language: { type: 'string', required: true, description: 'Target language' },
          specification: { type: 'string', required: true, description: 'What to build' }
        },
        output: {
          code: { type: 'string', description: 'Generated code' }
        }
      }
    });

    // Ingestion tool
    this.register({
      id: 'tool:ingest',
      name: 'ingest',
      description: 'Ingest content into the graph',
      provider: 'internal',
      config: {},
      execute: async (params) => {
        return {
          source: params.source,
          type: params.type,
          status: 'queued'
        };
      },
      schema: {
        input: {
          source: { type: 'string', required: true, description: 'File path or URL' },
          type: { type: 'string', required: false, description: 'Content type' }
        },
        output: {
          status: { type: 'string', description: 'Ingestion status' }
        }
      }
    });

    // World command tool
    this.register({
      id: 'tool:world',
      name: 'world_command',
      description: 'Control the 3D world simulator',
      provider: 'internal',
      config: {},
      execute: async (params) => {
        return {
          command: params.command,
          entity: params.entity,
          executed: true
        };
      },
      schema: {
        input: {
          command: { type: 'string', required: true, description: 'Command to execute' },
          entity: { type: 'string', required: true, description: 'Target entity' }
        },
        output: {
          executed: { type: 'boolean', description: 'Whether command succeeded' }
        }
      }
    });

    // Research tool
    this.register({
      id: 'tool:research',
      name: 'research',
      description: 'Research a topic',
      provider: 'internal',
      config: {},
      execute: async (params) => {
        return {
          topic: params.topic,
          findings: [`Finding about ${params.topic}`],
          sources: ['internal-graph']
        };
      },
      schema: {
        input: {
          topic: { type: 'string', required: true, description: 'Topic to research' }
        },
        output: {
          findings: { type: 'array', description: 'Research findings' }
        }
      }
    });

    // Teach tool
    this.register({
      id: 'tool:teach',
      name: 'teach',
      description: 'Teach user about a topic',
      provider: 'internal',
      config: {},
      execute: async (params) => {
        return {
          topic: params.topic,
          lesson: `Lesson about ${params.topic}: [content from graph]`,
          level: params.level || 'intermediate'
        };
      },
      schema: {
        input: {
          topic: { type: 'string', required: true, description: 'Topic to teach' }
        },
        output: {
          lesson: { type: 'string', description: 'Generated lesson' }
        }
      }
    });
  }

  // === MCP SERVER CONNECTION ===

  async connectMCPServer(config: {
    id: string;
    name: string;
    url: string;
    tools: Array<{ name: string; description: string; schema: any }>;
  }): Promise<void> {
    for (const toolDef of config.tools) {
      const tool: Tool = {
        id: `mcp:${config.id}:${toolDef.name}`,
        name: toolDef.name,
        description: toolDef.description,
        provider: `mcp:${config.id}`,
        config: { serverUrl: config.url },
        execute: async (params) => {
          // In real implementation: call MCP server via protocol
          return { tool: toolDef.name, params, result: 'mcp-call-mock' };
        },
        schema: toolDef.schema || { input: {}, output: {} }
      };

      this.register(tool);
    }

    this.graph.addTriple({
      subject: 'system',
      predicate: 'connected-to-mcp',
      object: config.id,
      confidence: 1.0,
      source: 'tools:registry',
      dimensionalTag: 2
    });
  }

  // === TOOL EXECUTION ===

  async execute(toolId: string, params: Record<string, any>): Promise<any> {
    const tool = this.tools.get(toolId);
    if (!tool) throw new Error(`Tool not found: ${toolId}`);

    // Validate required params
    for (const [key, spec] of Object.entries(tool.schema.input)) {
      if (spec.required && !(key in params)) {
        throw new Error(`Missing required param: ${key}`);
      }
    }

    // Execute
    const result = await tool.execute(params);

    // Store execution in graph
    this.graph.addTriple({
      subject: toolId,
      predicate: 'executed-with',
      object: JSON.stringify(params).substring(0, 100),
      confidence: 1.0,
      source: 'tools:registry',
      dimensionalTag: 1
    });

    return result;
  }

  getTool(id: string): Tool | undefined {
    return this.tools.get(id);
  }

  getAllTools(): Tool[] {
    return Array.from(this.tools.values());
  }

  getToolsByProvider(provider: string): Tool[] {
    return Array.from(this.tools.values()).filter(t => t.provider === provider);
  }

  getStats() {
    const internal = this.getToolsByProvider('internal').length;
    const mcp = this.getAllTools().filter(t => t.provider.startsWith('mcp:')).length;

    return {
      total: this.tools.size,
      internal,
      mcp,
      providers: Array.from(new Set(Array.from(this.tools.values()).map(t => t.provider)))
    };
  }
}

export { ToolRegistry };
