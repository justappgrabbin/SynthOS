// ============================================
// MEMORY STORE
# Persistent storage with vector search capability
# Pluggable backend: SQLite (local) or Supabase (cloud)
# ============================================

import { SemanticGraph, Triple, Node } from '../semantic/graph';

export interface MemoryConfig {
  backend: 'sqlite' | 'supabase' | 'memory';
  connectionString?: string;
  apiKey?: string;
  embeddingDim?: number;
}

export class MemoryStore {
  private graph: SemanticGraph;
  private config: MemoryConfig;
  private dirty: Set<string> = new Set(); // Modified triples since last sync
  private syncInterval: any;

  constructor(graph: SemanticGraph, config: MemoryConfig) {
    this.graph = graph;
    this.config = { embeddingDim: 128, ...config };

    if (config.backend === 'supabase') {
      this.initSupabase();
    } else if (config.backend === 'sqlite') {
      this.initSQLite();
    }

    // Auto-sync every 30 seconds
    this.syncInterval = setInterval(() => this.sync(), 30000);
  }

  // === INITIALIZATION ===

  private initSupabase() {
    // In real implementation: import { createClient } from '@supabase/supabase-js'
    // Create tables: triples, nodes, embeddings
    console.log('Supabase backend initialized');
  }

  private initSQLite() {
    // In real implementation: import Database from 'better-sqlite3'
    // Create tables: triples(subject, predicate, object, timestamp, confidence, source, embedding)
    console.log('SQLite backend initialized');
  }

  // === WRITE OPERATIONS ===

  async add(triple: Omit<Triple, 'id' | 'timestamp'>): Promise<Triple> {
    const result = this.graph.addTriple(triple);
    this.dirty.add(result.id);
    await this.persistTriple(result);
    return result;
  }

  private async persistTriple(triple: Triple) {
    if (this.config.backend === 'memory') return;

    // Batch writes in real implementation
    // await supabase.from('triples').upsert(triple);
    // Or: db.prepare('INSERT INTO triples ...').run(triple);
  }

  // === READ OPERATIONS ===

  async query(pattern: any): Promise<Triple[]> {
    // First check local graph (fast)
    const local = this.graph.query(pattern);
    if (local.length > 0) return local;

    // Then check persistent store (slow but complete)
    if (this.config.backend !== 'memory') {
      return await this.queryPersistent(pattern);
    }

    return [];
  }

  private async queryPersistent(pattern: any): Promise<Triple[]> {
    // In real implementation:
    // const { data } = await supabase.from('triples').select('*').match(pattern);
    // Or: db.prepare('SELECT * FROM triples WHERE ...').all(pattern);
    return [];
  }

  async vectorSearch(query: number[], limit: number = 10): Promise<Array<{ triple: Triple; similarity: number }>> {
    if (this.config.backend === 'memory') {
      // Brute force for memory backend
      const results: Array<{ triple: Triple; similarity: number }> = [];
      for (const [_, triple] of this.graph['triples']) {
        if (triple.embedding) {
          const sim = this.cosineSimilarity(query, triple.embedding);
          if (sim > 0.5) results.push({ triple, similarity: sim });
        }
      }
      return results.sort((a, b) => b.similarity - a.similarity).slice(0, limit);
    }

    // In real implementation: pgvector query for Supabase, or custom vector index for SQLite
    return [];
  }

  private cosineSimilarity(a: number[], b: number[]): number {
    let dot = 0;
    for (let i = 0; i < a.length; i++) dot += a[i] * b[i];
    return dot;
  }

  // === SYNC ===

  async sync(): Promise<void> {
    if (this.dirty.size === 0) return;

    const toSync = Array.from(this.dirty).map(id => this.graph['triples'].get(id)).filter(Boolean);

    if (this.config.backend === 'supabase') {
      // await supabase.from('triples').upsert(toSync);
    } else if (this.config.backend === 'sqlite') {
      // Batch insert
    }

    this.dirty.clear();
    console.log(`Synced ${toSync.length} triples to ${this.config.backend}`);
  }

  // === SNAPSHOT ===

  async snapshot(): Promise<string> {
    await this.sync();
    return this.graph.serialize();
  }

  async restore(data: string): Promise<void> {
    // In real implementation: clear store, load from serialized data
    console.log('Restoring from snapshot...');
  }

  // === CLEANUP ===

  dispose() {
    if (this.syncInterval) clearInterval(this.syncInterval);
    this.sync();
  }
}

export { MemoryStore };
