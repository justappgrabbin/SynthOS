// ============================================
// INGESTION PIPELINE
# Reads anything → extracts meaning → feeds the shared graph
# Plugins: text, PDF, code, URL, API, image (OCR), audio (transcription)
# ============================================

import { SemanticGraph } from '../semantic/graph';
import { MemoryStore } from '../memory/store';

export interface IngestionTask {
  id: string;
  source: string;        // File path, URL, API endpoint
  type: 'text' | 'pdf' | 'code' | 'url' | 'api' | 'image' | 'audio';
  priority: number;      // 1-10
  metadata: Record<string, any>;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  extractedTriples: number;
  errors: string[];
}

export interface Extractor {
  type: string;
  canHandle(source: string, type: string): boolean;
  extract(source: string, metadata: any): Promise<Array<{subject: string; predicate: string; object: string; confidence: number}>>;
}

export class IngestionPipeline {
  private graph: SemanticGraph;
  private store: MemoryStore;
  private extractors: Extractor[] = [];
  private queue: IngestionTask[] = [];
  private processing: boolean = false;

  constructor(graph: SemanticGraph, store: MemoryStore) {
    this.graph = graph;
    this.store = store;
    this.registerDefaultExtractors();
  }

  registerExtractor(extractor: Extractor) {
    this.extractors.push(extractor);
  }

  private registerDefaultExtractors() {
    // Text extractor
    this.registerExtractor({
      type: 'text',
      canHandle: (src, type) => type === 'text' || src.endsWith('.txt') || src.endsWith('.md'),
      extract: async (src, meta) => {
        // In real implementation: read file, parse sentences, extract SPO triples
        const content = meta.content || src;
        return this.extractTriplesFromText(content);
      }
    });

    // Code extractor
    this.registerExtractor({
      type: 'code',
      canHandle: (src, type) => type === 'code' || /\.(ts|js|py|rs|go|java)$/.test(src),
      extract: async (src, meta) => {
        // Extract: classes, functions, imports, exports as triples
        const content = meta.content || src;
        return this.extractTriplesFromCode(content);
      }
    });

    // HD content extractor
    this.registerExtractor({
      type: 'hd',
      canHandle: (src, type) => type === 'hd' || src.toLowerCase().includes('human design'),
      extract: async (src, meta) => {
        const content = meta.content || src;
        return this.extractTriplesFromHD(content);
      }
    });

    // URL extractor
    this.registerExtractor({
      type: 'url',
      canHandle: (src, type) => type === 'url' || src.startsWith('http'),
      extract: async (src, meta) => {
        // In real implementation: fetch, parse HTML, extract text, then extract triples
        return [{ subject: 'url', predicate: 'fetched', object: src, confidence: 0.9 }];
      }
    });
  }

  // === PUBLIC API ===

  async ingest(source: string, type: string = 'auto', metadata: any = {}): Promise<IngestionTask> {
    const task: IngestionTask = {
      id: `ingest_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      source,
      type: type === 'auto' ? this.detectType(source) : type as any,
      priority: metadata.priority || 5,
      metadata,
      status: 'pending',
      extractedTriples: 0,
      errors: []
    };

    this.queue.push(task);
    this.queue.sort((a, b) => b.priority - a.priority);

    if (!this.processing) {
      this.processQueue();
    }

    return task;
  }

  private detectType(source: string): string {
    if (source.startsWith('http')) return 'url';
    if (/\.(ts|js|py|rs|go)$/.test(source)) return 'code';
    if (/\.(pdf|doc)$/.test(source)) return 'pdf';
    if (/\.(jpg|png|gif)$/.test(source)) return 'image';
    if (/\.(mp3|wav)$/.test(source)) return 'audio';
    return 'text';
  }

  private async processQueue() {
    this.processing = true;

    while (this.queue.length > 0) {
      const task = this.queue.shift()!;
      task.status = 'processing';

      try {
        const extractor = this.extractors.find(e => e.canHandle(task.source, task.type));
        if (!extractor) {
          task.errors.push(`No extractor found for type: ${task.type}`);
          task.status = 'failed';
          continue;
        }

        const triples = await extractor.extract(task.source, task.metadata);

        for (const t of triples) {
          await this.store.add({
            subject: t.subject,
            predicate: t.predicate,
            object: t.object,
            confidence: t.confidence,
            source: `ingest:${task.id}`,
            dimensionalTag: 4 // Context dimension for ingested knowledge
          });
        }

        task.extractedTriples = triples.length;
        task.status = 'completed';

        // Store ingestion metadata in graph
        this.graph.addTriple({
          subject: task.id,
          predicate: 'ingested',
          object: task.source,
          confidence: 1.0,
          source: 'ingest:pipeline',
          dimensionalTag: 4
        });

      } catch (err: any) {
        task.errors.push(err.message);
        task.status = 'failed';
      }
    }

    this.processing = false;
  }

  // === EXTRACTION METHODS ===

  private extractTriplesFromText(text: string): Array<{subject: string; predicate: string; object: string; confidence: number}> {
    const triples: Array<{subject: string; predicate: string; object: string; confidence: number}> = [];

    // Simple sentence parsing: first word = subject, second = predicate, rest = object
    const sentences = text.split(/[.!?]/).filter(s => s.trim().length > 0);

    for (const sentence of sentences) {
      const words = sentence.trim().split(/\s+/);
      if (words.length >= 3) {
        triples.push({
          subject: words[0].toLowerCase(),
          predicate: words[1].toLowerCase(),
          object: words.slice(2).join(' ').toLowerCase(),
          confidence: 0.6
        });
      }
    }

    // Extract HD-specific patterns
    const gatePattern = /\bgate\s*(\d+)\b/gi;
    let match;
    while ((match = gatePattern.exec(text)) !== null) {
      triples.push({
        subject: `gate_${match[1]}`,
        predicate: 'mentioned-in',
        object: 'text',
        confidence: 0.9
      });
    }

    const channelPattern = /\bchannel\s*(\d+)\b/gi;
    while ((match = channelPattern.exec(text)) !== null) {
      triples.push({
        subject: `channel_${match[1]}`,
        predicate: 'mentioned-in',
        object: 'text',
        confidence: 0.9
      });
    }

    return triples;
  }

  private extractTriplesFromCode(code: string): Array<{subject: string; predicate: string; object: string; confidence: number}> {
    const triples: Array<{subject: string; predicate: string; object: string; confidence: number}> = [];

    // Extract classes
    const classPattern = /class\s+(\w+)/g;
    let match;
    while ((match = classPattern.exec(code)) !== null) {
      triples.push({
        subject: match[1],
        predicate: 'is-a',
        object: 'class',
        confidence: 1.0
      });
    }

    // Extract functions
    const funcPattern = /(?:function|const|let|var)\s+(\w+)\s*[=:]/g;
    while ((match = funcPattern.exec(code)) !== null) {
      triples.push({
        subject: match[1],
        predicate: 'is-a',
        object: 'function',
        confidence: 0.9
      });
    }

    // Extract imports
    const importPattern = /import\s+.*?\s+from\s+['"]([^'"]+)['"]/g;
    while ((match = importPattern.exec(code)) !== null) {
      triples.push({
        subject: 'module',
        predicate: 'imports',
        object: match[1],
        confidence: 1.0
      });
    }

    return triples;
  }

  private extractTriplesFromHD(content: string): Array<{subject: string; predicate: string; object: string; confidence: number}> {
    const triples: Array<{subject: string; predicate: string; object: string; confidence: number}> = [];

    // Gate definitions
    const gatePattern = /Gate\s*(\d+)[^\w]*([^\n]+)/gi;
    let match;
    while ((match = gatePattern.exec(content)) !== null) {
      const gateNum = match[1];
      const desc = match[2].trim();
      triples.push({
        subject: `gate_${gateNum}`,
        predicate: 'description',
        object: desc,
        confidence: 0.9
      });
    }

    // Center associations
    const centerPattern = /(\w+)\s+Center/gi;
    while ((match = centerPattern.exec(content)) !== null) {
      triples.push({
        subject: match[1].toLowerCase(),
        predicate: 'is-a',
        object: 'center',
        confidence: 0.8
      });
    }

    return triples;
  }

  getQueue(): IngestionTask[] {
    return this.queue;
  }

  getStats() {
    return {
      queueLength: this.queue.length,
      extractors: this.extractors.length,
      processing: this.processing
    };
  }
}

export { IngestionPipeline };
