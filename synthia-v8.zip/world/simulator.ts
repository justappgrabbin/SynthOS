// ============================================
// WORLD SIMULATOR
# 3D visualization of the shared semantic graph
# Not a separate world — it's a view INTO the graph
# Every entity in the world IS a node in the graph
# ============================================

import { SemanticGraph } from '../semantic/graph';

export interface WorldEntity {
  id: string;
  nodeId: string;        // Links back to graph node
  position: [number, number, number];
  velocity: [number, number, number];
  size: number;
  color: [number, number, number];
  growth: number;        // 0-1 based on graph activity
  connections: string[]; // Other entity IDs
  type: 'node' | 'attractor' | 'cluster' | 'path';
}

export interface WorldView {
  entities: WorldEntity[];
  camera: { position: [number, number, number]; target: [number, number, number] };
  time: number;
  selectedNode?: string;
}

export class WorldSimulator {
  private graph: SemanticGraph;
  private entities: Map<string, WorldEntity> = new Map();
  private time: number = 0;
  private running: boolean = false;
  private interval: any;

  constructor(graph: SemanticGraph) {
    this.graph = graph;
  }

  // === SYNCHRONIZATION ===
  // The world is a VIEW of the graph, not a separate store

  sync(): void {
    // Get all graph nodes
    const graphNodes = this.graph.query({ limit: 1000 });

    // Create/update entities for each node
    for (const triple of graphNodes) {
      const entityId = `world:${triple.subject}`;

      if (!this.entities.has(entityId)) {
        // New node in graph → spawn entity
        this.spawnEntity(entityId, triple.subject);
      } else {
        // Existing node → grow it
        this.growEntity(entityId);
      }
    }

    // Update connections based on graph paths
    this.updateConnections();

    // Remove entities for deleted nodes
    for (const [id, entity] of this.entities) {
      const stillExists = this.graph.query({
        subject: entity.nodeId,
        limit: 1
      }).length > 0;

      if (!stillExists) {
        this.entities.delete(id);
      }
    }
  }

  private spawnEntity(id: string, nodeId: string): WorldEntity {
    const entity: WorldEntity = {
      id,
      nodeId,
      position: [
        (Math.random() - 0.5) * 100,
        (Math.random() - 0.5) * 50,
        (Math.random() - 0.5) * 100
      ],
      velocity: [0, 0, 0],
      size: 2,
      color: this.nodeColor(nodeId),
      growth: 0.1,
      connections: [],
      type: 'node'
    };

    this.entities.set(id, entity);
    return entity;
  }

  private nodeColor(nodeId: string): [number, number, number] {
    // Color based on node type/labels
    if (nodeId.startsWith('gate_')) return [0, 212, 170]; // Teal for gates
    if (nodeId.startsWith('channel_')) return [255, 165, 0]; // Orange for channels
    if (nodeId.startsWith('user')) return [100, 149, 237]; // Blue for user
    if (nodeId.startsWith('system')) return [255, 255, 255]; // White for system
    return [150, 150, 150]; // Gray default
  }

  private growEntity(id: string): void {
    const entity = this.entities.get(id);
    if (!entity) return;

    // Growth based on how much activity this node has
    const activity = this.graph.query({
      subject: entity.nodeId,
      since: Date.now() - 3600000, // Last hour
      limit: 100
    }).length;

    entity.growth = Math.min(1.0, entity.growth + activity * 0.01);
    entity.size = 2 + entity.growth * 8;
  }

  private updateConnections(): void {
    for (const [id, entity] of this.entities) {
      // Find connected nodes in graph
      const paths = this.graph.findPath(entity.nodeId, '*', 2);

      entity.connections = [];
      for (const path of paths) {
        if (path.length > 0) {
          const targetNode = path[path.length - 1].split('→').pop();
          if (targetNode) {
            const targetEntity = `world:${targetNode}`;
            if (this.entities.has(targetEntity)) {
              entity.connections.push(targetEntity);
            }
          }
        }
      }
    }
  }

  // === PHYSICS ===

  tick(dt: number = 0.016): void {
    this.time += dt;

    for (const [_, entity] of this.entities) {
      // Attractor forces: entities with shared connections attract
      for (const connectedId of entity.connections) {
        const connected = this.entities.get(connectedId);
        if (!connected) continue;

        const dx = connected.position[0] - entity.position[0];
        const dy = connected.position[1] - entity.position[1];
        const dz = connected.position[2] - entity.position[2];
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (dist > 0 && dist < 50) {
          const force = 0.001 * (1 - dist / 50);
          entity.velocity[0] += dx * force;
          entity.velocity[1] += dy * force;
          entity.velocity[2] += dz * force;
        }
      }

      // Repulsion: avoid crowding
      for (const [__, other] of this.entities) {
        if (other.id === entity.id) continue;
        const dx = entity.position[0] - other.position[0];
        const dy = entity.position[1] - other.position[1];
        const dz = entity.position[2] - other.position[2];
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (dist > 0 && dist < 10) {
          const force = 0.01 * (10 - dist) / dist;
          entity.velocity[0] += dx * force;
          entity.velocity[1] += dy * force;
          entity.velocity[2] += dz * force;
        }
      }

      // Damping
      entity.velocity[0] *= 0.95;
      entity.velocity[1] *= 0.95;
      entity.velocity[2] *= 0.95;

      // Update position
      entity.position[0] += entity.velocity[0];
      entity.position[1] += entity.velocity[1];
      entity.position[2] += entity.velocity[2];
    }
  }

  // === RENDERING DATA ===

  getView(): WorldView {
    return {
      entities: Array.from(this.entities.values()),
      camera: {
        position: [0, 50, 100],
        target: [0, 0, 0]
      },
      time: this.time
    };
  }

  getEntity(id: string): WorldEntity | undefined {
    return this.entities.get(id);
  }

  getStats() {
    return {
      entities: this.entities.size,
      time: this.time,
      connections: Array.from(this.entities.values()).reduce((sum, e) => sum + e.connections.length, 0) / 2
    };
  }

  // === SIMULATION CONTROL ===

  start(fps: number = 30) {
    if (this.running) return;
    this.running = true;

    this.interval = setInterval(() => {
      this.sync();      // Sync with graph
      this.tick(1 / fps); // Physics step
    }, 1000 / fps);
  }

  stop() {
    this.running = false;
    if (this.interval) clearInterval(this.interval);
  }
}

export { WorldSimulator };
