// ============================================
// SYNTHIA v8 RUNTIME
# The single runtime where everything connects
# One shared graph. All modules are plugins on it.
# ============================================

import { SemanticGraph } from './semantic/graph';
import { MemoryStore } from './memory/store';
import { IngestionPipeline } from './ingest/pipeline';
import { Planner } from './planner/orchestrator';
import { AgentSwarm } from './agents/worker';
import { ToolRegistry } from './tools/mcp-client';
import { WorldSimulator } from './world/simulator';

export interface RuntimeConfig {
  memory: 'sqlite' | 'supabase' | 'memory';
  syncInterval: number;
  agentInterval: number;
  worldFps: number;
}

export class SynthiaRuntime {
  // The one shared graph
  readonly graph: SemanticGraph;

  // All modules are plugins on the graph
  readonly memory: MemoryStore;
  readonly ingest: IngestionPipeline;
  readonly planner: Planner;
  readonly agents: AgentSwarm;
  readonly tools: ToolRegistry;
  readonly world: WorldSimulator;

  private config: RuntimeConfig;
  private running: boolean = false;

  constructor(config: Partial<RuntimeConfig> = {}) {
    this.config = {
      memory: 'memory',
      syncInterval: 30000,
      agentInterval: 5000,
      worldFps: 30,
      ...config
    };

    // 1. Create the shared graph
    this.graph = new SemanticGraph();

    // 2. All modules connect to the same graph
    this.memory = new MemoryStore(this.graph, { backend: this.config.memory });
    this.ingest = new IngestionPipeline(this.graph, this.memory);
    this.planner = new Planner(this.graph, this.memory);
    this.agents = new AgentSwarm(this.graph, this.memory);
    this.tools = new ToolRegistry(this.graph);
    this.world = new WorldSimulator(this.graph);

    // 3. Register system presence in graph
    this.graph.addTriple({
      subject: 'system',
      predicate: 'is',
      object: 'synthia-v8',
      confidence: 1.0,
      source: 'runtime:init',
      dimensionalTag: 5
    });
  }

  // === LIFECYCLE ===

  async start(): Promise<void> {
    if (this.running) return;
    this.running = true;

    console.log('Synthia v8 starting...');

    // Start all modules
    this.agents.start(this.config.agentInterval);
    this.world.start(this.config.worldFps);

    // Initial sync
    this.world.sync();

    console.log('Runtime active');
    console.log(`Graph: ${this.graph.getStats().triples} triples`);
    console.log(`Tools: ${this.tools.getStats().total}`);
    console.log(`Agents: ${this.agents.getStats().agents}`);
  }

  stop(): void {
    this.running = false;
    this.agents.stop();
    this.world.stop();
    this.memory.dispose();
    console.log('Runtime stopped');
  }

  // === USER INTERACTION ===

  async interact(input: string): Promise<any> {
    // 1. Store user input in graph
    await this.memory.add({
      subject: 'user',
      predicate: 'said',
      object: input,
      confidence: 1.0,
      source: 'runtime:interact',
      dimensionalTag: 3
    });

    // 2. Planner creates plan from intent
    const plan = await this.planner.planFromIntent(input);

    // 3. Execute plan steps using tools
    const results: any[] = [];
    for (const step of plan.steps) {
      if (step.status === 'completed' && step.result) {
        results.push(step.result);
      }
    }

    // 4. World syncs to show changes
    this.world.sync();

    // 5. Return response
    return {
      plan: plan.id,
      goal: plan.goal,
      results,
      stats: this.getStats()
    };
  }

  // === DIRECT MODULE ACCESS ===

  async ingestSource(source: string, type?: string): Promise<any> {
    return this.ingest.ingest(source, type);
  }

  async executeTool(toolId: string, params: any): Promise<any> {
    return this.tools.execute(toolId, params);
  }

  async dispatchAgent(agentId: string, task: any): Promise<any> {
    return this.agents.dispatchTask({
      agentId,
      type: task.type,
      params: task.params,
      priority: task.priority || 5
    });
  }

  async queryGraph(pattern: any): Promise<any> {
    return this.graph.query(pattern);
  }

  getWorldView(): any {
    return this.world.getView();
  }

  // === PERSISTENCE ===

  async save(): Promise<string> {
    return this.memory.snapshot();
  }

  async restore(data: string): Promise<void> {
    await this.memory.restore(data);
  }

  // === STATS ===

  getStats() {
    return {
      runtime: {
        running: this.running,
        uptime: Date.now() // Would track actual uptime
      },
      graph: this.graph.getStats(),
      memory: { backend: this.config.memory },
      ingest: this.ingest.getStats(),
      planner: this.planner.getStats(),
      agents: this.agents.getStats(),
      tools: this.tools.getStats(),
      world: this.world.getStats()
    };
  }
}

export { SynthiaRuntime };
