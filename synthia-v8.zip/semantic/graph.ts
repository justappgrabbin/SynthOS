// ============================================
// THE SHARED SEMANTIC GRAPH
// The single source of truth for all Synthia modules
// Klein's triple-store + Vector embeddings + Temporal evolution
// ============================================

export interface Triple {
  id: string;
  subject: string;
  predicate: string;
  object: string;
  timestamp: number;
  confidence: number;
  source: string;        // Which module created this
  embedding?: number[];  // Vector representation
  dimensionalTag: number; // D1-D5
}

export interface Node {
  id: string;
  labels: string[];
  properties: Record<string, any>;
  embedding: number[];
  createdAt: number;
  lastAccessed: number;
  accessCount: number;
}

export interface GraphQuery {
  subject?: string;
  predicate?: string;
  object?: string;
  source?: string;
  since?: number;
  minConfidence?: number;
  dimensionalTag?: number;
  vectorSimilarity?: { nodeId: string; threshold: number };
  limit?: number;
}

export class SemanticGraph {
  private triples: Map<string, Triple> = new Map();
  private nodes: Map<string, Node> = new Map();
  private indices = {
    bySubject: new Map<string, Set<string>>(),
    byPredicate: new Map<string, Set<string>>(),
    byObject: new Map<string, Set<string>>(),
    bySource: new Map<string, Set<string>>(),
    byDimension: new Map<number, Set<string>>(),
    byTime: new Map<number, Set<string>>()
  };
  private clock: number = 0;

  // === CORE OPERATIONS ===

  addTriple(t: Omit<Triple, 'id' | 'timestamp'>): Triple {
    this.clock++;
    const triple: Triple = {
      ...t,
      id: `t_${this.clock}_${Math.random().toString(36).substr(2, 5)}`,
      timestamp: Date.now()
    };

    this.triples.set(triple.id, triple);
    this.indexTriple(triple);
    this.ensureNode(triple.subject);
    this.ensureNode(triple.object);

    return triple;
  }

  private indexTriple(t: Triple) {
    const addToIndex = (map: Map<string, Set<string>>, key: string, id: string) => {
      if (!map.has(key)) map.set(key, new Set());
      map.get(key)!.add(id);
    };

    addToIndex(this.indices.bySubject, t.subject, t.id);
    addToIndex(this.indices.byPredicate, t.predicate, t.id);
    addToIndex(this.indices.byObject, t.object, t.id);
    addToIndex(this.indices.bySource, t.source, t.id);
    addToIndex(this.indices.byDimension, String(t.dimensionalTag), t.id);

    const timeBucket = Math.floor(t.timestamp / 60000); // 1-minute buckets
    addToIndex(this.indices.byTime, String(timeBucket), t.id);
  }

  private ensureNode(id: string) {
    if (!this.nodes.has(id)) {
      this.nodes.set(id, {
        id,
        labels: [],
        properties: {},
        embedding: this.randomEmbedding(),
        createdAt: Date.now(),
        lastAccessed: Date.now(),
        accessCount: 0
      });
    }
  }

  private randomEmbedding(dim: number = 128): number[] {
    const vec = [];
    for (let i = 0; i < dim; i++) vec.push((Math.random() - 0.5) * 2);
    // Normalize
    const mag = Math.sqrt(vec.reduce((s, v) => s + v * v, 0));
    return vec.map(v => v / mag);
  }

  // === QUERIES ===

  query(q: GraphQuery): Triple[] {
    let candidates: Set<string> | null = null;

    if (q.subject) {
      candidates = this.intersect(candidates, this.indices.bySubject.get(q.subject));
    }
    if (q.predicate) {
      candidates = this.intersect(candidates, this.indices.byPredicate.get(q.predicate));
    }
    if (q.object) {
      candidates = this.intersect(candidates, this.indices.byObject.get(q.object));
    }
    if (q.source) {
      candidates = this.intersect(candidates, this.indices.bySource.get(q.source));
    }
    if (q.dimensionalTag) {
      candidates = this.intersect(candidates, this.indices.byDimension.get(String(q.dimensionalTag)));
    }

    if (!candidates) {
      candidates = new Set(this.triples.keys());
    }

    let results = Array.from(candidates)
      .map(id => this.triples.get(id)!)
      .filter(t => {
        if (q.minConfidence && t.confidence < q.minConfidence) return false;
        if (q.since && t.timestamp < q.since) return false;
        return true;
      });

    if (q.vectorSimilarity) {
      const targetNode = this.nodes.get(q.vectorSimilarity.nodeId);
      if (targetNode) {
        results = results.sort((a, b) => {
          const simA = this.cosineSimilarity(
            this.nodes.get(a.subject)?.embedding || [],
            targetNode.embedding
          );
          const simB = this.cosineSimilarity(
            this.nodes.get(b.subject)?.embedding || [],
            targetNode.embedding
          );
          return simB - simA;
        });
      }
    }

    return results.slice(0, q.limit || 100);
  }

  private intersect(a: Set<string> | null, b: Set<string> | undefined): Set<string> {
    if (!b) return a || new Set();
    if (!a) return new Set(b);
    return new Set([...a].filter(x => b.has(x)));
  }

  private cosineSimilarity(a: number[], b: number[]): number {
    if (a.length !== b.length) return 0;
    let dot = 0;
    for (let i = 0; i < a.length; i++) dot += a[i] * b[i];
    return dot;
  }

  // === PATH FINDING ===

  findPath(from: string, to: string, maxDepth: number = 5): string[][] {
    const paths: string[][] = [];
    const visited = new Set<string>();

    const dfs = (current: string, target: string, path: string[], depth: number) => {
      if (depth > maxDepth) return;
      if (current === target) {
        paths.push([...path]);
        return;
      }
      visited.add(current);

      const outgoing = this.indices.bySubject.get(current);
      if (outgoing) {
        for (const tripleId of outgoing) {
          const triple = this.triples.get(tripleId);
          if (triple && !visited.has(triple.object)) {
            path.push(`${triple.predicate}→${triple.object}`);
            dfs(triple.object, target, path, depth + 1);
            path.pop();
          }
        }
      }

      visited.delete(current);
    };

    dfs(from, to, [], 0);
    return paths;
  }

  // === SIMILARITY SEARCH ===

  findSimilar(nodeId: string, threshold: number = 0.7, limit: number = 10): Node[] {
    const target = this.nodes.get(nodeId);
    if (!target) return [];

    const results: Array<{ node: Node; similarity: number }> = [];
    for (const [_, node] of this.nodes) {
      if (node.id === nodeId) continue;
      const sim = this.cosineSimilarity(target.embedding, node.embedding);
      if (sim > threshold) {
        results.push({ node, similarity: sim });
      }
    }

    return results
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, limit)
      .map(r => r.node);
  }

  // === STATS ===

  getStats() {
    return {
      triples: this.triples.size,
      nodes: this.nodes.size,
      clock: this.clock,
      sources: Array.from(this.indices.bySource.keys()),
      dimensions: Array.from(this.indices.byDimension.keys()).map(Number)
    };
  }

  // === SERIALIZATION ===

  serialize(): string {
    return JSON.stringify({
      triples: Array.from(this.triples.values()),
      nodes: Array.from(this.nodes.values()),
      clock: this.clock
    });
  }

  static deserialize(data: string): SemanticGraph {
    const parsed = JSON.parse(data);
    const graph = new SemanticGraph();
    graph.clock = parsed.clock || 0;
    for (const n of parsed.nodes) graph.nodes.set(n.id, n);
    for (const t of parsed.triples) {
      graph.triples.set(t.id, t);
      graph.indexTriple(t);
    }
    return graph;
  }
}

export { SemanticGraph };
