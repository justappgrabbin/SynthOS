#!/usr/bin/env python3
"""
OS ORCHESTRATOR v6.0 - SCAR TISSUE ENGINE
Channels are scars from repeated transformation.

Start with nothing.
Messages create scars.
Channels emerge from scars.
The body graph is the visible skeleton of accumulated transformation.

Architecture:
- Message = primary motion
- Scar = memory of transformation (accumulates weight, decays if unused)
- Channel = crystallized scar (crosses emergence threshold)
- Channel types learned from usage: Defined, Undefined, Personality, Both, Crossing
- Center states track pressure from message traffic
- No predefined channels — everything emerges from message history
"""

import numpy as np
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Optional, Set
from enum import Enum
import json
from datetime import datetime
from collections import defaultdict

# ============================================================
# DATA TABLES
# ============================================================

GATE_DATA = {
  "0": {
    "name": "The Keeper of Keys",
    "ruler": "Pluto",
    "base": "Pressure",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "potential",
      "acceptance",
      "beginning"
    ],
    "line_keywords": {
      "1": "introspection",
      "2": "receptivity",
      "3": "trial",
      "4": "release",
      "5": "perseverance",
      "6": "caution"
    }
  },
  "1": {
    "name": "The Initiator",
    "ruler": "Mars",
    "base": "Action",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "creation",
      "drive",
      "individuality",
      "root"
    ],
    "special": "Wuji point - the big circle",
    "line_keywords": {
      "1": "creative",
      "2": "magnetic",
      "3": "experimental",
      "4": "opportunistic",
      "5": "heretical",
      "6": "transcendent"
    }
  },
  "2": {
    "name": "The Receptor",
    "ruler": "Jupiter",
    "base": "Pulse",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "direction",
      "guidance",
      "receptivity"
    ],
    "line_keywords": {
      "1": "intention",
      "2": "genius",
      "3": "patience",
      "4": "plan",
      "5": "application",
      "6": "fixation"
    }
  },
  "3": {
    "name": "The Ordering",
    "ruler": "Saturn",
    "base": "Bonding",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "innovation",
      "mutation",
      "ordering"
    ],
    "line_keywords": {
      "1": "synthesis",
      "2": "immaturity",
      "3": "innovation",
      "4": "charisma",
      "5": "universalization",
      "6": "triumph"
    }
  },
  "4": {
    "name": "The Formulization",
    "ruler": "Uranus",
    "base": "Security",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "answers",
      "formulization",
      "logic"
    ],
    "line_keywords": {
      "1": "persistence",
      "2": "acceptance",
      "3": "influence",
      "4": "assimilation",
      "5": "universalization",
      "6": "victory"
    }
  },
  "5": {
    "name": "The Pattern",
    "ruler": "Venus",
    "base": "Action",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "rhythm",
      "pattern",
      "habits"
    ],
    "line_keywords": {
      "1": "perseverance",
      "2": "influence",
      "3": "surrender",
      "4": "universalization",
      "5": "heretical",
      "6": "transcendence"
    }
  },
  "6": {
    "name": "The Conflict",
    "ruler": "Neptune",
    "base": "Pressure",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "friction",
      "conflict",
      "growth"
    ],
    "line_keywords": {
      "1": "retreat",
      "2": "diplomacy",
      "3": "trial",
      "4": "victory",
      "5": "arbitration",
      "6": "peace"
    }
  },
  "7": {
    "name": "The Army",
    "ruler": "Moon",
    "base": "Security",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "direction",
      "leadership",
      "organization"
    ],
    "line_keywords": {
      "1": "authority",
      "2": "democracy",
      "3": "influence",
      "4": "abdication",
      "5": "universalization",
      "6": "victory"
    }
  },
  "8": {
    "name": "The Contribution",
    "ruler": "Earth",
    "base": "Action",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "commitment",
      "contribution",
      "focus"
    ],
    "line_keywords": {
      "1": "honesty",
      "2": "service",
      "3": "innovation",
      "4": "correction",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "9": {
    "name": "The Focus",
    "ruler": "Mercury",
    "base": "Bonding",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "concentration",
      "focus",
      "determination"
    ],
    "line_keywords": {
      "1": "inspection",
      "2": "dedication",
      "3": "innovation",
      "4": "rigor",
      "5": "universalization",
      "6": "perfection"
    }
  },
  "10": {
    "name": "The Behavior",
    "ruler": "Sun",
    "base": "Security",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "self",
      "behavior",
      "identity"
    ],
    "line_keywords": {
      "1": "modesty",
      "2": "naturalness",
      "3": "innovation",
      "4": "courage",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "11": {
    "name": "The Ideas",
    "ruler": "Mars",
    "base": "Action",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "ideas",
      "inspiration",
      "seeking"
    ],
    "line_keywords": {
      "1": "attunement",
      "2": "genius",
      "3": "innovation",
      "4": "teaching",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "12": {
    "name": "The Caution",
    "ruler": "Jupiter",
    "base": "Pressure",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "caution",
      "standstill",
      "retreat"
    ],
    "line_keywords": {
      "1": "retreat",
      "2": "purification",
      "3": "innovation",
      "4": "discipline",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "13": {
    "name": "The Listener",
    "ruler": "Saturn",
    "base": "Bonding",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "listening",
      "secrets",
      "witnessing"
    ],
    "line_keywords": {
      "1": "empathy",
      "2": "bigotry",
      "3": "innovation",
      "4": "fatigue",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "14": {
    "name": "The Power Skills",
    "ruler": "Uranus",
    "base": "Security",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "power",
      "skills",
      "resources"
    ],
    "line_keywords": {
      "1": "money",
      "2": "management",
      "3": "innovation",
      "4": "security",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "15": {
    "name": "The Extremes",
    "ruler": "Venus",
    "base": "Action",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "extremes",
      "modesty",
      "rhythm"
    ],
    "line_keywords": {
      "1": "compromise",
      "2": "influence",
      "3": "innovation",
      "4": "acceptance",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "16": {
    "name": "The Skills",
    "ruler": "Neptune",
    "base": "Pressure",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "skills",
      "enthusiasm",
      "identification"
    ],
    "line_keywords": {
      "1": "selection",
      "2": "influence",
      "3": "innovation",
      "4": "identification",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "17": {
    "name": "The Opinion",
    "ruler": "Moon",
    "base": "Bonding",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "opinion",
      "follow",
      "organization"
    ],
    "line_keywords": {
      "1": "openness",
      "2": "influence",
      "3": "innovation",
      "4": "correction",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "18": {
    "name": "The Correction",
    "ruler": "Earth",
    "base": "Security",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "correction",
      "insight",
      "judgment"
    ],
    "line_keywords": {
      "1": "judgment",
      "2": "influence",
      "3": "innovation",
      "4": "correction",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "19": {
    "name": "The Wanting",
    "ruler": "Mercury",
    "base": "Action",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "wanting",
      "need",
      "approach"
    ],
    "line_keywords": {
      "1": "need",
      "2": "influence",
      "3": "innovation",
      "4": "approach",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "20": {
    "name": "The Now",
    "ruler": "Sun",
    "base": "Pressure",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "now",
      "contemplation",
      "presence"
    ],
    "line_keywords": {
      "1": "superficiality",
      "2": "influence",
      "3": "innovation",
      "4": "transformation",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "21": {
    "name": "The Hunter/Huntress",
    "ruler": "Mars",
    "base": "Bonding",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "hunter",
      "control",
      "biting"
    ],
    "line_keywords": {
      "1": "warning",
      "2": "influence",
      "3": "innovation",
      "4": "strategy",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "22": {
    "name": "The Grace",
    "ruler": "Jupiter",
    "base": "Security",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "grace",
      "openness",
      "sensitivity"
    ],
    "line_keywords": {
      "1": "second-class",
      "2": "influence",
      "3": "innovation",
      "4": "acceptance",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "23": {
    "name": "The Splitting",
    "ruler": "Saturn",
    "base": "Action",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "splitting",
      "assimilation",
      "mutation"
    ],
    "line_keywords": {
      "1": "proselytization",
      "2": "influence",
      "3": "innovation",
      "4": "assimilation",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "24": {
    "name": "The Rationalizing",
    "ruler": "Uranus",
    "base": "Pressure",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "rationalizing",
      "return",
      "invention"
    ],
    "line_keywords": {
      "1": "inspiration",
      "2": "influence",
      "3": "innovation",
      "4": "invention",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "25": {
    "name": "The Innocent",
    "ruler": "Venus",
    "base": "Bonding",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "innocent",
      "spirit",
      "universal love"
    ],
    "line_keywords": {
      "1": "universalization",
      "2": "influence",
      "3": "innovation",
      "4": "survival",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "26": {
    "name": "The Trickster",
    "ruler": "Neptune",
    "base": "Security",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "trickster",
      "ego",
      "memory"
    ],
    "line_keywords": {
      "1": "influence",
      "2": "influence",
      "3": "innovation",
      "4": "cunning",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "27": {
    "name": "The Nurturing",
    "ruler": "Moon",
    "base": "Action",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "nurturing",
      "caring",
      "responsibility"
    ],
    "line_keywords": {
      "1": "selfishness",
      "2": "influence",
      "3": "innovation",
      "4": "generosity",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "28": {
    "name": "The Struggle",
    "ruler": "Earth",
    "base": "Pressure",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "struggle",
      "purpose",
      "risk"
    ],
    "line_keywords": {
      "1": "preparation",
      "2": "influence",
      "3": "innovation",
      "4": "immortality",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "29": {
    "name": "The Perseverance",
    "ruler": "Mercury",
    "base": "Bonding",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "perseverance",
      "commitment",
      "deepening"
    ],
    "line_keywords": {
      "1": "obsession",
      "2": "influence",
      "3": "innovation",
      "4": "commitment",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "30": {
    "name": "The Feelings",
    "ruler": "Sun",
    "base": "Security",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "feelings",
      "desire",
      "fates"
    ],
    "line_keywords": {
      "1": "composure",
      "2": "influence",
      "3": "innovation",
      "4": "burning",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "31": {
    "name": "The Leading",
    "ruler": "Mars",
    "base": "Action",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "leading",
      "influence",
      "democracy"
    ],
    "line_keywords": {
      "1": "manifestation",
      "2": "influence",
      "3": "innovation",
      "4": "leading",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "32": {
    "name": "The Continuity",
    "ruler": "Jupiter",
    "base": "Pressure",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "continuity",
      "endurance",
      "memory"
    ],
    "line_keywords": {
      "1": "conservation",
      "2": "influence",
      "3": "innovation",
      "4": "transformation",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "33": {
    "name": "The Privacy",
    "ruler": "Saturn",
    "base": "Bonding",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "privacy",
      "retreat",
      "memory"
    ],
    "line_keywords": {
      "1": "avoidance",
      "2": "influence",
      "3": "innovation",
      "4": "surrender",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "34": {
    "name": "The Power",
    "ruler": "Uranus",
    "base": "Security",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "power",
      "transformation",
      "daring"
    ],
    "line_keywords": {
      "1": "annihilation",
      "2": "influence",
      "3": "innovation",
      "4": "transformation",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "35": {
    "name": "The Change",
    "ruler": "Venus",
    "base": "Action",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "change",
      "progress",
      "hunger"
    ],
    "line_keywords": {
      "1": "universalization",
      "2": "influence",
      "3": "innovation",
      "4": "change",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "36": {
    "name": "The Crisis",
    "ruler": "Neptune",
    "base": "Pressure",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "crisis",
      "darkening",
      "experience"
    ],
    "line_keywords": {
      "1": "resistance",
      "2": "influence",
      "3": "innovation",
      "4": "transformation",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "37": {
    "name": "The Friendship",
    "ruler": "Moon",
    "base": "Bonding",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "friendship",
      "community",
      "family"
    ],
    "line_keywords": {
      "1": "mediocrity",
      "2": "influence",
      "3": "innovation",
      "4": "friendship",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "38": {
    "name": "The Opposition",
    "ruler": "Earth",
    "base": "Security",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "opposition",
      "fighter",
      "purpose"
    ],
    "line_keywords": {
      "1": "qualification",
      "2": "influence",
      "3": "innovation",
      "4": "struggle",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "39": {
    "name": "The Provocation",
    "ruler": "Mercury",
    "base": "Action",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "provocation",
      "dissonance",
      "pressure"
    ],
    "line_keywords": {
      "1": "disengagement",
      "2": "influence",
      "3": "innovation",
      "4": "provocation",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "40": {
    "name": "The Aloneness",
    "ruler": "Sun",
    "base": "Pressure",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "aloneness",
      "deliverance",
      "exhaustion"
    ],
    "line_keywords": {
      "1": "recuperation",
      "2": "influence",
      "3": "innovation",
      "4": "organization",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "41": {
    "name": "The Contraction",
    "ruler": "Mars",
    "base": "Bonding",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "contraction",
      "fantasy",
      "dreaming"
    ],
    "line_keywords": {
      "1": "reasonableness",
      "2": "influence",
      "3": "innovation",
      "4": "pragmatism",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "42": {
    "name": "The Growth",
    "ruler": "Jupiter",
    "base": "Security",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "growth",
      "expansion",
      "middle"
    ],
    "line_keywords": {
      "1": "diversification",
      "2": "influence",
      "3": "innovation",
      "4": "growth",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "43": {
    "name": "The Insight",
    "ruler": "Saturn",
    "base": "Action",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "insight",
      "knowing",
      "breakthrough"
    ],
    "line_keywords": {
      "1": "obsession",
      "2": "influence",
      "3": "innovation",
      "4": "insight",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "44": {
    "name": "The Alertness",
    "ruler": "Uranus",
    "base": "Pressure",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "alertness",
      "interaction",
      "instinct"
    ],
    "line_keywords": {
      "1": "prevention",
      "2": "influence",
      "3": "innovation",
      "4": "alertness",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "45": {
    "name": "The Gatherer",
    "ruler": "Venus",
    "base": "Bonding",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "gathering",
      "distribution",
      "collecting"
    ],
    "special": "Collector/Distributor - expands space",
    "line_keywords": {
      "1": "materialism",
      "2": "influence",
      "3": "innovation",
      "4": "gathering",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "46": {
    "name": "The Determination",
    "ruler": "Neptune",
    "base": "Security",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "determination",
      "good fortune",
      "serendipity"
    ],
    "line_keywords": {
      "1": "contribution",
      "2": "influence",
      "3": "innovation",
      "4": "determination",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "47": {
    "name": "The Realizing",
    "ruler": "Moon",
    "base": "Action",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "realizing",
      "oppression",
      "transmutation"
    ],
    "line_keywords": {
      "1": "taking",
      "2": "influence",
      "3": "innovation",
      "4": "realizing",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "48": {
    "name": "The Depth",
    "ruler": "Earth",
    "base": "Pressure",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "depth",
      "solution",
      "competence"
    ],
    "line_keywords": {
      "1": "inadequacy",
      "2": "influence",
      "3": "innovation",
      "4": "depth",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "49": {
    "name": "The Revolution",
    "ruler": "Mercury",
    "base": "Bonding",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "revolution",
      "principles",
      "rejection"
    ],
    "line_keywords": {
      "1": "rejection",
      "2": "influence",
      "3": "innovation",
      "4": "revolution",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "50": {
    "name": "The Values",
    "ruler": "Sun",
    "base": "Security",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "values",
      "immigration",
      "correction"
    ],
    "line_keywords": {
      "1": "migration",
      "2": "influence",
      "3": "innovation",
      "4": "values",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "51": {
    "name": "The Shock",
    "ruler": "Mars",
    "base": "Action",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "shock",
      "awakening",
      "initiation"
    ],
    "line_keywords": {
      "1": "reference",
      "2": "influence",
      "3": "innovation",
      "4": "shock",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "52": {
    "name": "The Concentration",
    "ruler": "Jupiter",
    "base": "Pressure",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "concentration",
      "inaction",
      "meditation"
    ],
    "line_keywords": {
      "1": "rest",
      "2": "influence",
      "3": "innovation",
      "4": "concentration",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "53": {
    "name": "The Beginning",
    "ruler": "Saturn",
    "base": "Bonding",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "beginning",
      "development",
      "start"
    ],
    "line_keywords": {
      "1": "accumulation",
      "2": "influence",
      "3": "innovation",
      "4": "development",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "54": {
    "name": "The Ambition",
    "ruler": "Uranus",
    "base": "Security",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "ambition",
      "drive",
      "materialism"
    ],
    "line_keywords": {
      "1": "influence",
      "2": "influence",
      "3": "innovation",
      "4": "ambition",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "55": {
    "name": "The Spirit",
    "ruler": "Venus",
    "base": "Action",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "spirit",
      "abundance",
      "mood"
    ],
    "line_keywords": {
      "1": "spirit",
      "2": "influence",
      "3": "innovation",
      "4": "abundance",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "56": {
    "name": "The Wanderer",
    "ruler": "Neptune",
    "base": "Pressure",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "wanderer",
      "stimulation",
      "search"
    ],
    "line_keywords": {
      "1": "quality",
      "2": "influence",
      "3": "innovation",
      "4": "wandering",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "57": {
    "name": "The Intuitive",
    "ruler": "Moon",
    "base": "Bonding",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "intuitive",
      "clarity",
      "instinct"
    ],
    "line_keywords": {
      "1": "confusion",
      "2": "influence",
      "3": "innovation",
      "4": "intuition",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "58": {
    "name": "The Joy",
    "ruler": "Earth",
    "base": "Security",
    "tone": 4,
    "color": 4,
    "view": 4,
    "keywords": [
      "joy",
      "vitality",
      "stimulation"
    ],
    "line_keywords": {
      "1": "love",
      "2": "influence",
      "3": "innovation",
      "4": "joy",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "59": {
    "name": "The Sexuality",
    "ruler": "Mercury",
    "base": "Action",
    "tone": 5,
    "color": 5,
    "view": 5,
    "keywords": [
      "sexuality",
      "intimacy",
      "dissemination"
    ],
    "line_keywords": {
      "1": "the",
      "2": "influence",
      "3": "innovation",
      "4": "sexuality",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "60": {
    "name": "The Limitation",
    "ruler": "Sun",
    "base": "Pressure",
    "tone": 6,
    "color": 6,
    "view": 6,
    "keywords": [
      "limitation",
      "acceptance",
      "mutation"
    ],
    "line_keywords": {
      "1": "acceptance",
      "2": "influence",
      "3": "innovation",
      "4": "limitation",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "61": {
    "name": "The Mystery",
    "ruler": "Mars",
    "base": "Bonding",
    "tone": 1,
    "color": 1,
    "view": 1,
    "keywords": [
      "mystery",
      "inner truth",
      "knowing"
    ],
    "line_keywords": {
      "1": "occult",
      "2": "influence",
      "3": "innovation",
      "4": "mystery",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "62": {
    "name": "The Detail",
    "ruler": "Jupiter",
    "base": "Security",
    "tone": 2,
    "color": 2,
    "view": 2,
    "keywords": [
      "detail",
      "caution",
      "small"
    ],
    "line_keywords": {
      "1": "routine",
      "2": "influence",
      "3": "innovation",
      "4": "detail",
      "5": "universalization",
      "6": "transcendence"
    }
  },
  "63": {
    "name": "The Doubt",
    "ruler": "Saturn",
    "base": "Action",
    "tone": 3,
    "color": 3,
    "view": 3,
    "keywords": [
      "doubt",
      "inquiry",
      "after"
    ],
    "line_keywords": {
      "1": "doubt",
      "2": "influence",
      "3": "innovation",
      "4": "inquiry",
      "5": "universalization",
      "6": "transcendence"
    }
  }
}

LINE_DATA = {
  "1": "The Investigator",
  "2": "The Hermit",
  "3": "The Martyr",
  "4": "The Opportunist",
  "5": "The Heretic",
  "6": "The Role Model"
}

CENTER_GATES = {
  "Head": [
    64,
    61,
    63
  ],
  "Ajna": [
    47,
    24,
    4,
    11
  ],
  "Throat": [
    56,
    23,
    62,
    35,
    12,
    45,
    33,
    8
  ],
  "Heart/Ego": [
    51,
    21,
    40,
    26
  ],
  "Spleen": [
    48,
    57,
    44,
    50,
    32,
    28,
    18,
    10
  ],
  "Sacral": [
    5,
    14,
    29,
    59,
    9,
    3,
    42,
    27
  ],
  "Solar Plexus": [
    55,
    30,
    36,
    22,
    37,
    6,
    49
  ],
  "Root": [
    53,
    54,
    60,
    52,
    19,
    41,
    39,
    38
  ],
  "G Center": [
    25,
    15,
    46,
    10,
    7,
    31,
    2,
    1
  ]
}

GATE_CENTERS = {
  "64": [
    "Head"
  ],
  "61": [
    "Head"
  ],
  "63": [
    "Head"
  ],
  "47": [
    "Ajna"
  ],
  "24": [
    "Ajna"
  ],
  "4": [
    "Ajna"
  ],
  "11": [
    "Ajna"
  ],
  "56": [
    "Throat"
  ],
  "23": [
    "Throat"
  ],
  "62": [
    "Throat"
  ],
  "35": [
    "Throat"
  ],
  "12": [
    "Throat"
  ],
  "45": [
    "Throat"
  ],
  "33": [
    "Throat"
  ],
  "8": [
    "Throat"
  ],
  "51": [
    "Heart/Ego"
  ],
  "21": [
    "Heart/Ego"
  ],
  "40": [
    "Heart/Ego"
  ],
  "26": [
    "Heart/Ego"
  ],
  "48": [
    "Spleen"
  ],
  "57": [
    "Spleen"
  ],
  "44": [
    "Spleen"
  ],
  "50": [
    "Spleen"
  ],
  "32": [
    "Spleen"
  ],
  "28": [
    "Spleen"
  ],
  "18": [
    "Spleen"
  ],
  "10": [
    "Spleen",
    "G Center"
  ],
  "5": [
    "Sacral"
  ],
  "14": [
    "Sacral"
  ],
  "29": [
    "Sacral"
  ],
  "59": [
    "Sacral"
  ],
  "9": [
    "Sacral"
  ],
  "3": [
    "Sacral"
  ],
  "42": [
    "Sacral"
  ],
  "27": [
    "Sacral"
  ],
  "55": [
    "Solar Plexus"
  ],
  "30": [
    "Solar Plexus"
  ],
  "36": [
    "Solar Plexus"
  ],
  "22": [
    "Solar Plexus"
  ],
  "37": [
    "Solar Plexus"
  ],
  "6": [
    "Solar Plexus"
  ],
  "49": [
    "Solar Plexus"
  ],
  "53": [
    "Root"
  ],
  "54": [
    "Root"
  ],
  "60": [
    "Root"
  ],
  "52": [
    "Root"
  ],
  "19": [
    "Root"
  ],
  "41": [
    "Root"
  ],
  "39": [
    "Root"
  ],
  "38": [
    "Root"
  ],
  "25": [
    "G Center"
  ],
  "15": [
    "G Center"
  ],
  "46": [
    "G Center"
  ],
  "7": [
    "G Center"
  ],
  "31": [
    "G Center"
  ],
  "2": [
    "G Center"
  ],
  "1": [
    "G Center"
  ]
}

# ============================================================
# ENGINE CLASSES
# ============================================================



# ============================================================
# SHELL INTERFACE
# ============================================================

class FieldShell:
    def __init__(self, threshold=0.5):
        self.engine = ScarTissueFieldFast(emergence_threshold=threshold)

    def cmd_enter(self, args):
        if len(args) < 5:
            return "Usage: enter <id> <base> <tone> <color> <view> [centers...]"
        id_str = args[0]
        coords = [float(x) for x in args[1:5]]
        centers = [int(x) for x in args[5:]] if len(args) > 5 else [1, 2, 3]
        center_names = [list(CENTER_GATES.keys())[c-1] for c in centers if 1 <= c <= 9]
        defined = center_names[:len(center_names)//2 + 1]
        undefined = [c for c in CENTER_GATES.keys() if c not in defined]
        activated = {}
        for c in defined:
            gates = CENTER_GATES.get(c, [])
            activated[c] = [gates[0]] if gates else []
        for c in undefined:
            activated[c] = []
        inhabitant = CenteredInhabitant(id_str, defined, undefined, activated, np.array(coords))
        self.engine.register(inhabitant)
        return f"{id_str} entered scar tissue field"

    def cmd_send(self, args):
        if len(args) < 3:
            return "Usage: send <from> <to> <content> [crystal]"
        from_id, to_id = args[0], args[1]
        content = " ".join(args[2:])
        crystal = args[-1] if args[-1] in ["Personality", "Design", "Monopole"] else "Monopole"
        meeting = self.engine.send_message(from_id, to_id, content, crystal)
        output = []
        output.append(f"Message: '{meeting['message']['content']}'")
        output.append(f"Resonance: {meeting['message']['resonance']} | Scar: {meeting['scar']['path']} (weight: {meeting['scar']['weight']})")
        if meeting['channel_emerged']:
            output.append(f"*** CHANNEL EMERGED: {meeting['emerged_channel']['name']} ({meeting['emerged_channel']['type']}) ***")
        output.append(f"Scars: {meeting['total_scars']} | Channels: {meeting['total_channels']}")
        return "\n".join(output)

    def cmd_status(self, args):
        return json.dumps(self.engine.field_status(), indent=2)

    def cmd_topology(self, args):
        return json.dumps(self.engine.get_channel_topology(), indent=2)

    def execute(self, command):
        parts = command.strip().split()
        if not parts: return ""
        cmd = parts[0].lower()
        args = parts[1:]
        if cmd == "enter": return self.cmd_enter(args)
        elif cmd == "send": return self.cmd_send(args)
        elif cmd == "status": return self.cmd_status(args)
        elif cmd == "topology": return self.cmd_topology(args)
        elif cmd == "help": return "enter <id> <base> <tone> <color> <view> [centers...] | send <from> <to> <content> [crystal] | status | topology | help"
        else: return f"Unknown: {cmd}"

if __name__ == "__main__":
    shell = FieldShell()
    print("OS Orchestrator v6.0 - Scar Tissue Engine")
    print("Channels are scars from repeated transformation.")
    print("Type 'help' for commands")
