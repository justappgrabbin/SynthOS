#!/usr/bin/env python3
"""
OS ORCHESTRATOR v7.0 - SELF-ORGANIZING GRAPH
Message passing is the only primitive.
The organism IS the graph. No central orchestrator.

Architecture:
- Node = the only entity. Nodes only know messages.
- Message = the only primitive. Everything happens through message passing.
- Channel = emergent edge. Forms from scar tissue (accumulated message weight).
- Center = discovered cluster. measure graph topology -> cluster resonance -> discover center -> assign role.
- Ontology Router = the brain stem. Determines what input is, where it belongs, who consumes it, which nodes awaken.
- Compiler = graph rewrite system. Messages literally rewrite topology.

Nodes: ingestor, ontology_router, compiler, mind, heart, body, memory, renderer
"""

import numpy as np
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Optional, Set, Callable, Any
from enum import Enum
import json
from datetime import datetime
from collections import defaultdict
import hashlib

# ============================================================
# MESSAGE = THE ONLY PRIMITIVE
# ============================================================

@dataclass
class Message:
    id: str = field(default_factory=lambda: hashlib.md5(str(datetime.now().timestamp()).encode()).hexdigest()[:12])
    source_node: str = ""
    target_node: str = ""
    payload: Any = None
    message_type: str = "generic"
    resonance: float = 0.5
    timestamp: datetime = field(default_factory=datetime.now)
    path: List[str] = field(default_factory=list)

    def route_to(self, node_id: str):
        self.path.append(node_id)
        self.target_node = node_id

    def copy(self):
        return Message(
            id=self.id, source_node=self.source_node, target_node=self.target_node,
            payload=self.payload, message_type=self.message_type, resonance=self.resonance,
            timestamp=self.timestamp, path=self.path.copy()
        )

# ============================================================
# NODE = THE ONLY ENTITY
# ============================================================

class Node:
    def __init__(self, node_id: str, node_type: str = "generic"):
        self.id = node_id
        self.type = node_type
        self.inbox: List[Message] = []
        self.outbox: List[Message] = []
        self.message_history: List[Message] = []
        self.scars: Dict[Tuple[str, str], float] = {}
        self.channels: Dict[str, float] = {}
        self.state: Dict[str, Any] = {}
        self.awake = True
        self.activation_count = 0

    def receive(self, message: Message):
        message.route_to(self.id)
        self.inbox.append(message)
        self.message_history.append(message)
        self.activation_count += 1

        scar_key = (message.source_node, self.id)
        if scar_key not in self.scars:
            self.scars[scar_key] = 0.0
        self.scars[scar_key] += message.resonance * 0.3

        if self.scars[scar_key] > 1.0 and message.source_node not in self.channels:
            self.channels[message.source_node] = self.scars[scar_key]
            print(f"  Node {self.id} formed channel from {message.source_node} (weight: {self.scars[scar_key]:.3f})")
        elif message.source_node in self.channels:
            self.channels[message.source_node] = self.scars[scar_key]

    def process(self) -> List[Message]:
        emitted = []
        for message in self.inbox:
            response = message.copy()
            response.source_node = self.id
            response.resonance *= 0.9

            if self.type == "ingestor":
                emitted.extend(self._process_ingestor(message))
            elif self.type == "ontology_router":
                emitted.extend(self._process_ontology_router(message))
            elif self.type == "compiler":
                emitted.extend(self._process_compiler(message))
            elif self.type == "mind":
                emitted.extend(self._process_mind(message))
            elif self.type == "body":
                emitted.extend(self._process_body(message))
            elif self.type == "heart":
                emitted.extend(self._process_heart(message))
            elif self.type == "renderer":
                emitted.extend(self._process_renderer(message))
            elif self.type == "memory":
                emitted.extend(self._process_memory(message))
            else:
                for target in self.channels:
                    broadcast = message.copy()
                    broadcast.source_node = self.id
                    broadcast.target_node = target
                    emitted.append(broadcast)

        self.inbox.clear()
        self.outbox.extend(emitted)
        return emitted

    def _process_ingestor(self, message):
        payload = message.payload
        input_type = "unknown"
        if isinstance(payload, str):
            if payload.startswith("http"): input_type = "url"
            elif payload.startswith("{"): input_type = "json"
            elif "<" in payload and ">" in payload: input_type = "html"
            else: input_type = "text"
        elif isinstance(payload, bytes): input_type = "binary"

        forward = message.copy()
        forward.source_node = self.id
        forward.target_node = "ontology_router"
        forward.message_type = "ingested"
        forward.payload = {"raw": payload, "type": input_type, "size": len(str(payload))}
        forward.resonance = 0.8
        return [forward]

    def _process_ontology_router(self, message):
        payload = message.payload
        if not isinstance(payload, dict) or "type" not in payload: return []
        input_type = payload["type"]
        emitted = []
        routing = {"text": ["mind", "compiler"], "json": ["mind", "compiler", "memory"], "url": ["body", "renderer"], "html": ["body", "compiler", "renderer"], "binary": ["body", "memory"], "unknown": ["mind"]}
        targets = routing.get(input_type, ["mind"])
        for target in targets:
            route_msg = Message(source_node=self.id, target_node=target, payload={"original": payload["raw"], "type": input_type, "routed_by": "ontology_router", "intended_consumers": targets}, message_type="routed", resonance=0.7)
            emitted.append(route_msg)
        awaken = Message(source_node=self.id, target_node="graph", payload={"action": "awaken", "nodes": targets, "reason": f"input_type={input_type}"}, message_type="rewrite", resonance=0.5)
        emitted.append(awaken)
        return emitted

    def _process_compiler(self, message):
        if message.message_type == "rewrite": return []
        compiled = {"source": message.source_node, "compiled_at": datetime.now().isoformat(), "semantic_structure": self._extract_structure(message.payload)}
        forward = Message(source_node=self.id, target_node="mind", payload=compiled, message_type="compiled", resonance=0.6)
        return [forward]

    def _extract_structure(self, payload):
        if isinstance(payload, dict): return {"type": "structured", "keys": list(payload.keys())}
        elif isinstance(payload, str):
            words = payload.split()
            return {"type": "text", "word_count": len(words), "concepts": list(set(words))[:5]}
        return {"type": "unknown"}

    def _process_mind(self, message):
        if "reasoning" not in self.state: self.state["reasoning"] = []
        self.state["reasoning"].append(message.payload)
        to_heart = Message(source_node=self.id, target_node="heart", payload={"reasoning": message.payload, "source": message.source_node}, message_type="query", resonance=0.5)
        return [to_heart]

    def _process_body(self, message): return []
    def _process_heart(self, message):
        if isinstance(message.payload, dict) and "reasoning" in message.payload:
            valence = 0.5
            to_mind = Message(source_node=self.id, target_node="mind", payload={"emotional_valence": valence, "original": message.payload}, message_type="response", resonance=valence)
            return [to_mind]
        return []
    def _process_renderer(self, message): return []
    def _process_memory(self, message):
        if "memories" not in self.state: self.state["memories"] = []
        self.state["memories"].append(message.payload)
        return []

    def __repr__(self):
        return f"Node({self.id}, type={self.type}, channels={len(self.channels)}, scars={len(self.scars)}, activations={self.activation_count})"

# ============================================================
# GRAPH = THE ORGANISM
# ============================================================

class SelfOrganizingGraph:
    def __init__(self):
        self.nodes: Dict[str, Node] = {}
        self.messages: List[Message] = []
        self.cycles = 0

    def add_node(self, node_id: str, node_type: str = "generic"):
        node = Node(node_id, node_type)
        self.nodes[node_id] = node
        print(f"Node {node_id} ({node_type}) joined")
        return node

    def inject(self, message: Message):
        if message.target_node in self.nodes:
            self.nodes[message.target_node].receive(message)
        else:
            if "ontology_router" in self.nodes:
                message.target_node = "ontology_router"
                self.nodes["ontology_router"].receive(message)
            elif "ingestor" in self.nodes:
                message.target_node = "ingestor"
                self.nodes["ingestor"].receive(message)
        self.messages.append(message)

    def tick(self):
        self.cycles += 1
        all_emitted = []
        for node in self.nodes.values():
            if node.awake:
                emitted = node.process()
                all_emitted.extend(emitted)
        for msg in all_emitted:
            if msg.target_node in self.nodes:
                self.nodes[msg.target_node].receive(msg)
            elif msg.target_node == "graph":
                self._handle_graph_message(msg)
        self.messages.extend(all_emitted)
        return len(all_emitted)

    def _handle_graph_message(self, message):
        if isinstance(message.payload, dict):
            action = message.payload.get("action")
            if action == "awaken":
                for node_id in message.payload.get("nodes", []):
                    if node_id in self.nodes:
                        self.nodes[node_id].awake = True
                        print(f"  Node {node_id} awakened")

    def get_topology(self):
        return {
            "nodes": {node_id: {"type": node.type, "channels": {k: round(float(v), 4) for k, v in node.channels.items()}, "scars": {f"{k[0]}->{k[1]}": round(float(v), 4) for k, v in node.scars.items()}, "activations": node.activation_count, "awake": node.awake} for node_id, node in self.nodes.items()},
            "total_messages": len(self.messages), "cycles": self.cycles,
        }

    def get_center_clusters(self):
        node_ids = list(self.nodes.keys())
        n = len(node_ids)
        adjacency = np.zeros((n, n))
        for i, node_a in enumerate(node_ids):
            for j, node_b in enumerate(node_ids):
                if i == j: continue
                weight = self.nodes[node_a].channels.get(node_b, 0)
                reverse = self.nodes[node_b].channels.get(node_a, 0)
                adjacency[i, j] = (weight + reverse) / 2
        threshold = 0.5
        clusters = []
        visited = set()
        for i in range(n):
            if node_ids[i] in visited: continue
            cluster = [node_ids[i]]
            visited.add(node_ids[i])
            queue = [i]
            while queue:
                current = queue.pop(0)
                for j in range(n):
                    if node_ids[j] not in visited and adjacency[current, j] > threshold:
                        cluster.append(node_ids[j])
                        visited.add(node_ids[j])
                        queue.append(j)
            clusters.append(cluster)
        centers = {}
        for idx, members in enumerate(clusters):
            types = [self.nodes[m].type for m in members]
            type_counts = {}
            for t in types: type_counts[t] = type_counts.get(t, 0) + 1
            dominant = max(type_counts.items(), key=lambda x: x[1])[0] if type_counts else "unknown"
            role_map = {"mind": "Cognition", "compiler": "Cognition", "heart": "Emotion", "body": "Action", "renderer": "Action", "memory": "Memory", "ingestor": "Input", "ontology_router": "Routing"}
            role = role_map.get(dominant, "Generic")
            internal_resonance = 0
            for i, m1 in enumerate(members):
                for j, m2 in enumerate(members):
                    if i != j: internal_resonance += adjacency[node_ids.index(m1), node_ids.index(m2)]
            centers[f"center_{idx}"] = {"members": members, "types": types, "dominant_type": dominant, "role": role, "density": len(members) / len(self.nodes) if self.nodes else 0, "internal_resonance": round(float(internal_resonance), 4)}
        return centers

# ============================================================
# SHELL INTERFACE
# ============================================================

class GraphShell:
    def __init__(self):
        self.graph = SelfOrganizingGraph()
        self._bootstrap()

    def _bootstrap(self):
        for node_id in ["ingestor", "ontology_router", "compiler", "mind", "heart", "body", "memory", "renderer"]:
            self.graph.add_node(node_id, node_id)

    def cmd_inject(self, args):
        if len(args) < 2: return "Usage: inject <target> <content>"
        target = args[0]
        content = " ".join(args[1:])
        msg = Message(source_node="external", target_node=target, payload=content, message_type="intent", resonance=0.8)
        self.graph.inject(msg)
        return f"Injected to {target}"

    def cmd_tick(self, args):
        count = int(args[0]) if args else 1
        for _ in range(count): self.graph.tick()
        return f"Ticked {count} times. Total cycles: {self.graph.cycles}"

    def cmd_topology(self, args): return json.dumps(self.graph.get_topology(), indent=2)
    def cmd_centers(self, args): return json.dumps(self.graph.get_center_clusters(), indent=2)
    def cmd_nodes(self, args): return "\n".join([str(n) for n in self.graph.nodes.values()])

    def execute(self, command):
        parts = command.strip().split()
        if not parts: return ""
        cmd = parts[0].lower()
        args = parts[1:]
        if cmd == "inject": return self.cmd_inject(args)
        elif cmd == "tick": return self.cmd_tick(args)
        elif cmd == "topology": return self.cmd_topology(args)
        elif cmd == "centers": return self.cmd_centers(args)
        elif cmd == "nodes": return self.cmd_nodes(args)
        elif cmd == "help": return "inject <target> <content> | tick [n] | topology | centers | nodes | help"
        else: return f"Unknown: {cmd}"

if __name__ == "__main__":
    shell = GraphShell()
    print("OS Orchestrator v7.0 - Self-Organizing Graph")
    print("Message passing is the only primitive.")
    print("Type 'help' for commands")
