"""
mesh_bridge.py
The Mesh Bridge — WebSocket Server (Non-Energy Circuit / Python)

This is the bridge between the Python backend (non-energy circuits)
and the JavaScript frontend (energy circuits).

It runs a WebSocket server that:
- Receives messages from the energy circuits (user input, heartbeats)
- Routes them to the organism
- Sends organism state updates back to the energy circuits
- Handles user connections and disconnections

The bridge is the NERVOUS SYSTEM — it carries signals between
the "structural" body (Python) and the "sensory" skin (JavaScript).
"""

import asyncio
import json
import websockets
from typing import Dict, Set, Callable
from organism_orchestrator import DigitalOrganism


class MeshBridge:
    """
    WebSocket bridge connecting Python organism to JavaScript energy circuits.
    """

    def __init__(self, organism: DigitalOrganism, host='localhost', port=8765):
        self.organism = organism
        self.host = host
        self.port = port
        self.clients: Set[websockets.WebSocketServerProtocol] = set()
        self.running = False
        self.server = None

    async def handle_client(self, websocket, path):
        """Handle a new client connection"""
        self.clients.add(websocket)
        print(f"[Bridge] Client connected. Total: {len(self.clients)}")

        try:
            async for message in websocket:
                await self.handle_message(websocket, message)
        except websockets.exceptions.ConnectionClosed:
            pass
        finally:
            self.clients.discard(websocket)
            print(f"[Bridge] Client disconnected. Total: {len(self.clients)}")

    async def handle_message(self, websocket, message):
        """Handle a message from a client"""
        try:
            data = json.loads(message)
            msg_type = data.get('type')

            if msg_type == 'user_input':
                # Process user input
                user_id = data.get('userId')
                text = data.get('text')

                result = self.organism.process_user_input(user_id, text)

                # Send response back
                await websocket.send(json.dumps({
                    'type': 'response',
                    'userId': user_id,
                    'response': result.get('response'),
                    'state': result.get('state'),
                    'motor_active': result.get('motor_active'),
                    'hexagram': result.get('hexagram'),
                    'line': result.get('line'),
                    'phase': result.get('phase')
                }))

            elif msg_type == 'connect_user':
                # Connect a new user
                user_id = data.get('userId')
                profile = data.get('profile', {})

                response = self.organism.connect_user(user_id, profile)

                # Get user's position in state space
                user_entity = self.organism.vessel.entities.get(user_id)

                await websocket.send(json.dumps({
                    'type': 'user_connected',
                    'userId': user_id,
                    'greeting': response,
                    'hexagram': user_entity.hexagram_position if user_entity else 0,
                    'line': user_entity.line_position if user_entity else 1
                }))

            elif msg_type == 'request_state':
                # Send current organism state
                state = self.organism.get_state_snapshot()

                # Also send node states for visualization
                node_states = {}
                for node_id, node in self.organism.vessel.state_space.nodes.items():
                    node_states[node_id] = {
                        'd1': node.d1_impulse,
                        'd2': node.d2_polarity,
                        'd3': node.d3_witness,
                        'd4': node.d4_context,
                        'd5': node.d5_meaning,
                        'amplitude': {'real': node.possibility_amplitude.real, 
                                     'imag': node.possibility_amplitude.imag}
                    }

                await websocket.send(json.dumps({
                    'type': 'state_update',
                    'state': state,
                    'nodes': node_states,
                    'channels': self.organism.channels,
                    'centers': {
                        name: {'node_count': len(data['nodes']), 
                               'activation': data['activation']}
                        for name, data in self.organism.centers.items()
                    }
                }))

            elif msg_type == 'heartbeat':
                # Acknowledge heartbeat
                await websocket.send(json.dumps({
                    'type': 'heartbeat_ack',
                    'timestamp': data.get('timestamp'),
                    'organism_time': self.organism.vessel.time
                }))

            elif msg_type == 'switch_mode':
                # Switch user mode
                user_id = data.get('userId')
                mode = data.get('mode')

                if user_id in self.organism.connected_users:
                    self.organism.connected_users[user_id]['preferred_mode'] = mode

                await websocket.send(json.dumps({
                    'type': 'mode_switched',
                    'userId': user_id,
                    'mode': mode
                }))

        except json.JSONDecodeError:
            print(f"[Bridge] Invalid JSON: {message}")
        except Exception as e:
            print(f"[Bridge] Error handling message: {e}")

    async def broadcast_state(self):
        """Broadcast organism state to all connected clients"""
        if not self.clients:
            return

        state = self.organism.get_state_snapshot()

        message = json.dumps({
            'type': 'state_update',
            'state': state
        }, default=str)

        # Send to all clients
        disconnected = set()
        for client in self.clients:
            try:
                await client.send(message)
            except websockets.exceptions.ConnectionClosed:
                disconnected.add(client)

        # Remove disconnected clients
        self.clients -= disconnected

    async def start(self):
        """Start the WebSocket server"""
        self.running = True

        self.server = await websockets.serve(
            self.handle_client,
            self.host,
            self.port
        )

        print(f"[Bridge] WebSocket server started on ws://{self.host}:{self.port}")

        # Start state broadcast loop
        asyncio.create_task(self.broadcast_loop())

        await self.server.wait_closed()

    async def broadcast_loop(self):
        """Periodically broadcast state to all clients"""
        while self.running:
            await self.broadcast_state()
            await asyncio.sleep(1.0)  # 1 Hz broadcast

    async def stop(self):
        """Stop the WebSocket server"""
        self.running = False
        if self.server:
            self.server.close()
            await self.server.wait_closed()
        print("[Bridge] Stopped")


async def main():
    """Main entry point — start organism and bridge"""
    # Create and awaken organism
    organism = DigitalOrganism()
    organism.awaken()

    # Start simulation
    organism.start()

    # Create and start bridge
    bridge = MeshBridge(organism)

    try:
        await bridge.start()
    except KeyboardInterrupt:
        print("\n[Bridge] Shutting down...")
        await bridge.stop()
        organism.stop()


if __name__ == '__main__':
    asyncio.run(main())
