// ═══════════════════════════════════════════════════════════════
//  MESSY SEMANTIC TRIPLE NETWORK
//  Based on Klein et al. Meta-symbolic Simulation System (1976)
//  and Automatic Novel Writing (1979).
//
//  Core: triples with reality values, lexical expression lists,
//  behavioral rules that test/modify RV, semantics-to-surface
//  generation with value-driven lexical selection.
// ═══════════════════════════════════════════════════════════════

import type { SGNode } from '@/types';

// ── LEXICAL EXPRESSION LIST ─────────────────────────────────
// Each node and relation has an expression list mapping
// semantic values to lexical items. From MESSY manual:
// AFFECTION 3 = /'HATE'/-2.5/'DISLIKE'/-0.5/'LIKE'/2.5/'LOVE'/
export interface LexItem {
  text: string;
  threshold: number;  // value >= threshold selects this item
  pos?: string;       // part of speech for inflection
}

// ── SEMANTIC TRIPLE ─────────────────────────────────────────
// The fundamental unit. Subject-relation-object with reality
// value, time pointer, and hypotheticality. From Novel Writing:
// "The network is composed of semantic triples... predicate
// objects have pointers to triples on their lists."
export interface SemanticTriple {
  id: string;
  subject: string;    // node id
  relation: string;   // relation name
  object: string;     // node id
  rv: number;         // reality value (-inf to +inf)
  time: number;       // temporal index (0 = present, -1 = past, etc.)
  h: number;          // hypotheticality (0 = real, >0 = hypothetical)
  confidence: number; // 0-1, how well attested
  createdAt: number;
  source: 'user' | 'simulated' | 'inferred' | 'generated';
}

// ── NODE WITH EXPRESSION LIST ───────────────────────────────
export interface TripleNode {
  id: string;
  type: 'atom' | 'class' | 'predicate';
  label: string;
  expressions: LexItem[];  // lexical expression list
  features: Record<string, number | string | boolean>;
  createdAt: number;
}

// ── RELATION WITH EXPRESSION LIST ───────────────────────────
export interface TripleRelation {
  name: string;
  type: 'action' | 'state' | 'adj' | 'prep' | 'custom';
  expressions: LexItem[];
  defaultRV: number;
  features: Record<string, unknown>;
}

// ── BEHAVIORAL RULE (MESSY style) ───────────────────────────
// From MESSY manual Section 4. Rules have conditions that test
// reality values and actions that modify the network.
export interface BehavioralRule {
  id: string;
  name: string;
  group: string;        // which group this rule belongs to
  conditions: RuleCondition[];
  actions: RuleAction[];
  probability: number;  // base probability (0-100)
  active: boolean;
  weight: number;       // learned weight (0-1)
}

export interface RuleCondition {
  type: 'rv_test' | 'eq_test' | 'exists' | 'not_exists' | 'probability' | 'class_membership';
  subject?: string;     // can be variable (X, Y, Z)
  relation?: string;
  object?: string;
  operator?: 'GT' | 'LT' | 'GE' | 'LE' | 'EQ' | 'NE';
  value?: number;
  target?: string;      // for VAL(X WEALTH) GT 2 style
  probWeight?: number;  // e.g., 25 (25% chance if condition met)
}

export interface RuleAction {
  type: 'assert' | 'retract' | 'set_rv' | 'modify_rv' | 'add_to_class' | 'remove_from_class' | 'enable_group' | 'disable_group' | 'pick';
  subject?: string;
  relation?: string;
  object?: string;
  value?: number;
  targetClass?: string;
  groupName?: string;
}

// ── TRIPLE STORE ────────────────────────────────────────────
class TripleStore {
  nodes: Map<string, TripleNode> = new Map();
  relations: Map<string, TripleRelation> = new Map();
  triples: SemanticTriple[] = [];
  rules: BehavioralRule[] = [];
  classes: Map<string, Set<string>> = new Map();  // className -> {nodeIds}
  groups: Map<string, boolean> = new Map();        // groupName -> active
  history: Array<{ tick: number; changes: string[] }> = [];
  tick: number = 0;

  private STORAGE_KEY = 'klein_triples_v1';

  constructor() {
    this.load();
    this.seedDefaultRelations();
  }

  // ── NODE OPERATIONS ──────────────────────────────────────

  addNode(id: string, label: string, type: TripleNode['type'] = 'atom', expressions: LexItem[] = []): TripleNode {
    const existing = this.nodes.get(id);
    if (existing) return existing;
    const node: TripleNode = {
      id, label, type, expressions: expressions.length > 0 ? expressions : this.inferExpressions(label),
      features: {}, createdAt: Date.now()
    };
    this.nodes.set(id, node);
    this.save();
    return node;
  }

  findOrCreate(label: string, type: TripleNode['type'] = 'atom', expressions?: LexItem[]): TripleNode {
    const existing = Array.from(this.nodes.values()).find(n => n.label === label && n.type === type);
    if (existing) return existing;
    const id = `${type}_${label.toLowerCase().replace(/\s+/g, '_')}_${Date.now()}`;
    return this.addNode(id, label, type, expressions);
  }

  // ── RELATION OPERATIONS ──────────────────────────────────

  addRelation(name: string, type: TripleRelation['type'] = 'action', expressions: LexItem[] = [], defaultRV = 0): TripleRelation {
    const existing = this.relations.get(name);
    if (existing) return existing;
    const rel: TripleRelation = { name, type, expressions, defaultRV, features: {} };
    this.relations.set(name, rel);
    return rel;
  }

  // ── TRIPLE OPERATIONS ────────────────────────────────────

  assert(subject: string, relation: string, object: string, rv = 1, time = 0, h = 0, source: SemanticTriple['source'] = 'simulated'): SemanticTriple {
    // Ensure nodes and relation exist
    if (!this.nodes.has(subject)) this.addNode(subject, subject);
    if (!this.nodes.has(object)) this.addNode(object, object);
    if (!this.relations.has(relation)) this.addRelation(relation);

    // Check if triple already exists
    const existing = this.triples.find(t =>
      t.subject === subject && t.relation === relation && t.object === object && t.time === time
    );
    if (existing) {
      existing.rv = rv;
      existing.confidence = Math.min(1, existing.confidence + 0.1);
      this.save();
      return existing;
    }

    const triple: SemanticTriple = {
      id: `t_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      subject, relation, object, rv, time, h,
      confidence: 1, createdAt: Date.now(), source
    };
    this.triples.push(triple);
    this.save();
    return triple;
  }

  retract(subject: string, relation: string, object: string): void {
    this.triples = this.triples.filter(t =>
      !(t.subject === subject && t.relation === relation && t.object === object)
    );
    this.save();
  }

  setRV(subject: string, relation: string, object: string, value: number): void {
    const t = this.triples.find(tr =>
      tr.subject === subject && tr.relation === relation && tr.object === object
    );
    if (t) t.rv = value;
    this.save();
  }

  modifyRV(subject: string, relation: string, object: string, delta: number): void {
    const t = this.triples.find(tr =>
      tr.subject === subject && tr.relation === relation && tr.object === object
    );
    if (t) t.rv += delta;
    this.save();
  }

  // ── QUERY ────────────────────────────────────────────────

  query(subject?: string, relation?: string, object?: string): SemanticTriple[] {
    return this.triples.filter(t => {
      if (subject && t.subject !== subject) return false;
      if (relation && t.relation !== relation) return false;
      if (object && t.object !== object) return false;
      return true;
    });
  }

  val(subject: string, relation?: string, object?: string): number {
    if (relation && object) {
      const t = this.triples.find(tr =>
        tr.subject === subject && tr.relation === relation && tr.object === object
      );
      return t ? t.rv : 0;
    }
    // unary: get value of subject's feature
    const node = this.nodes.get(subject);
    return node ? (node.features.value as number || 0) : 0;
  }

  // ── EXPRESSION LIST RESOLUTION ───────────────────────────
  // Select lexical item based on reality value threshold.
  // From MESSY: AFFECTION 3 = /'HATE'/-2.5/'DISLIKE'/-0.5/'LIKE'/2.5/'LOVE'/
  // Given rv=3, selects 'LOVE'. Given rv=0, selects 'LIKE'.
  resolveExpression(nodeId: string, rv = 0): string {
    const node = this.nodes.get(nodeId);
    if (!node || node.expressions.length === 0) return nodeId;
    // Sort by threshold descending, find first where rv >= threshold
    const sorted = [...node.expressions].sort((a, b) => b.threshold - a.threshold);
    for (const item of sorted) {
      if (rv >= item.threshold) return item.text;
    }
    return node.expressions[0].text;
  }

  // ── CLASS OPERATIONS ─────────────────────────────────────

  addToClass(className: string, nodeId: string): void {
    if (!this.classes.has(className)) this.classes.set(className, new Set());
    this.classes.get(className)!.add(nodeId);
  }

  getClassMembers(className: string): string[] {
    return Array.from(this.classes.get(className) || []);
  }

  pickFromClass(className: string): string | undefined {
    const members = this.getClassMembers(className);
    return members[Math.floor(Math.random() * members.length)];
  }

  // ── GROUP OPERATIONS ─────────────────────────────────────

  enableGroup(name: string): void { this.groups.set(name, true); }
  disableGroup(name: string): void { this.groups.set(name, false); }
  isGroupActive(name: string): boolean { return this.groups.get(name) || false; }

  // ── BEHAVIORAL RULE OPERATIONS ───────────────────────────

  addRule(rule: Omit<BehavioralRule, 'id' | 'weight'>): BehavioralRule {
    const full: BehavioralRule = {
      ...rule,
      id: `br_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      weight: 0.5
    };
    this.rules.push(full);
    if (!this.groups.has(rule.group)) this.groups.set(rule.group, true);
    this.save();
    return full;
  }

  // ── RULE EVALUATION ──────────────────────────────────────
  // Evaluate a rule's conditions against current triple state.
  // Returns score (0 = failed, >0 = passed with weight).
  evaluateConditions(rule: BehavioralRule, bindings: Record<string, string> = {}): number {
    let score = 1;
    for (const cond of rule.conditions) {
      const sub = cond.subject ? (bindings[cond.subject] || cond.subject) : undefined;
      const obj = cond.object ? (bindings[cond.object] || cond.object) : undefined;

      switch (cond.type) {
        case 'rv_test': {
          if (!sub || !cond.target) { score = 0; break; }
          // Parse VAL(X WEALTH) GT 2
          const targetParts = cond.target.split(/\s+/);
          const valSubject = bindings[targetParts[0]] || targetParts[0];
          const valRelation = targetParts[1];
          let v = 0;
          if (valRelation) {
            const matches = this.query(valSubject, valRelation);
            v = matches.length > 0 ? matches[0].rv : 0;
          } else {
            v = this.val(valSubject);
          }
          const cmp = cond.value ?? 0;
          let pass = false;
          switch (cond.operator) {
            case 'GT': pass = v > cmp; break;
            case 'LT': pass = v < cmp; break;
            case 'GE': pass = v >= cmp; break;
            case 'LE': pass = v <= cmp; break;
            case 'EQ': pass = v === cmp; break;
            case 'NE': pass = v !== cmp; break;
          }
          if (!pass) score = 0;
          break;
        }
        case 'exists': {
          const matches = this.query(sub, cond.relation, obj);
          if (matches.length === 0) score = 0;
          break;
        }
        case 'not_exists': {
          const matches = this.query(sub, cond.relation, obj);
          if (matches.length > 0) score = 0;
          break;
        }
        case 'eq_test': {
          if (sub !== obj) score = 0;
          break;
        }
        case 'probability': {
          const roll = Math.random() * 100;
          if (roll > (cond.probWeight || 50)) score = 0;
          break;
        }
        case 'class_membership': {
          if (!sub || !cond.target) { score = 0; break; }
          const members = this.getClassMembers(cond.target);
          if (!members.includes(sub)) score = 0;
          break;
        }
      }
      if (score === 0) break;
    }
    return score;
  }

  // Execute rule actions, returning list of change descriptions
  executeActions(rule: BehavioralRule, bindings: Record<string, string> = {}): string[] {
    const changes: string[] = [];
    for (const action of rule.actions) {
      const sub = action.subject ? (bindings[action.subject] || action.subject) : undefined;
      const obj = action.object ? (bindings[action.object] || action.object) : undefined;

      switch (action.type) {
        case 'assert': {
          if (sub && action.relation && obj) {
            this.assert(sub, action.relation, obj, action.value ?? 1);
            changes.push(`ASSERT (${sub} ${action.relation} ${obj}) = ${action.value ?? 1}`);
          }
          break;
        }
        case 'retract': {
          if (sub && action.relation && obj) {
            this.retract(sub, action.relation, obj);
            changes.push(`RETRACT (${sub} ${action.relation} ${obj})`);
          }
          break;
        }
        case 'set_rv': {
          if (sub && action.relation && obj) {
            this.setRV(sub, action.relation, obj, action.value ?? 0);
            changes.push(`SET-RV (${sub} ${action.relation} ${obj}) = ${action.value ?? 0}`);
          }
          break;
        }
        case 'modify_rv': {
          if (sub && action.relation && obj) {
            this.modifyRV(sub, action.relation, obj, action.value ?? 0);
            changes.push(`MOD-RV (${sub} ${action.relation} ${obj}) += ${action.value ?? 0}`);
          }
          break;
        }
        case 'add_to_class': {
          if (sub && action.targetClass) {
            this.addToClass(action.targetClass, sub);
            changes.push(`ADD ${sub} TO ${action.targetClass}`);
          }
          break;
        }
        case 'enable_group': {
          if (action.groupName) {
            this.enableGroup(action.groupName);
            changes.push(`ENABLE GROUP ${action.groupName}`);
          }
          break;
        }
        case 'disable_group': {
          if (action.groupName) {
            this.disableGroup(action.groupName);
            changes.push(`DISABLE GROUP ${action.groupName}`);
          }
          break;
        }
        case 'pick': {
          // PICK assigns a class member to a binding variable
          if (action.targetClass && action.subject) {
            const picked = this.pickFromClass(action.targetClass);
            if (picked) {
              bindings[action.subject] = picked;
              changes.push(`PICK ${action.subject} FROM ${action.targetClass} = ${picked}`);
            }
          }
          break;
        }
      }
    }
    return changes;
  }

  // ── SIMULATION STEP ──────────────────────────────────────
  // Run one tick: evaluate all active rules, execute passing ones
  tickSimulation(): { tick: number; changes: string[]; rulesFired: string[] } {
    this.tick++;
    const allChanges: string[] = [];
    const fired: string[] = [];

    for (const rule of this.rules) {
      if (!rule.active || !this.isGroupActive(rule.group)) continue;

      const bindings: Record<string, string> = {};
      const score = this.evaluateConditions(rule, bindings);
      if (score > 0) {
        // Apply probability
        if (Math.random() * 100 < rule.probability * score) {
          const changes = this.executeActions(rule, bindings);
          if (changes.length > 0) {
            allChanges.push(...changes);
            fired.push(rule.name);
          }
        }
      }
    }

    this.history.push({ tick: this.tick, changes: allChanges });
    this.save();
    return { tick: this.tick, changes: allChanges, rulesFired: fired };
  }

  // ── NARRATIVE REPORT ─────────────────────────────────────
  // Generate narrative from changed triples. From Novel Writing:
  // "The flow of the narrative is derived from reports on the
  // changing state of the modelled universe."
  generateNarrative(depth = 5): string {
    const recent = this.triples
      .filter(t => t.rv !== 0)
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, depth * 3);

    const segments: string[] = [];
    for (const t of recent) {
      const subExpr = this.resolveExpression(t.subject, t.rv);
      const relNode = this.relations.get(t.relation);
      const relExpr = relNode
        ? this.resolveExpression(t.relation, t.rv)
        : t.relation;
      const objExpr = this.resolveExpression(t.object, t.rv);

      const timeMark = t.time < 0 ? 'Once, ' : t.time > 0 ? 'Later, ' : '';
      const hMark = t.h > 0 ? 'perhaps ' : '';

      segments.push(`${timeMark}${subExpr} ${relExpr}${t.rv < 0 ? ' no longer' : ''} ${hMark}${objExpr}.`);
    }

    return segments.join('\n\n');
  }

  // ── STATS ────────────────────────────────────────────────

  stats(): { nodes: number; relations: number; triples: number; rules: number; classes: number; tick: number } {
    return {
      nodes: this.nodes.size,
      relations: this.relations.size,
      triples: this.triples.length,
      rules: this.rules.length,
      classes: this.classes.size,
      tick: this.tick
    };
  }

  // ── PERSISTENCE ──────────────────────────────────────────

  save(): void {
    try {
      const data = {
        nodes: Array.from(this.nodes.entries()),
        relations: Array.from(this.relations.entries()),
        triples: this.triples,
        rules: this.rules,
        classes: Array.from(this.classes.entries()).map(([k, v]) => [k, Array.from(v)]),
        groups: Array.from(this.groups.entries()),
        tick: this.tick,
        history: this.history.slice(-100)  // keep last 100
      };
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(data));
    } catch { /* storage full */ }
  }

  load(): void {
    try {
      const raw = localStorage.getItem(this.STORAGE_KEY);
      if (!raw) return;
      const data = JSON.parse(raw);
      if (data.nodes) this.nodes = new Map(data.nodes);
      if (data.relations) this.relations = new Map(data.relations);
      if (data.triples) this.triples = data.triples;
      if (data.rules) this.rules = data.rules;
      if (data.classes) this.classes = new Map(data.classes.map(([k, v]: [string, string[]]) => [k, new Set(v)]));
      if (data.groups) this.groups = new Map(data.groups);
      if (data.tick) this.tick = data.tick;
      if (data.history) this.history = data.history;
    } catch { /* ignore */ }
  }

  // ── HELPERS ──────────────────────────────────────────────

  private inferExpressions(label: string): LexItem[] {
    // Infer a basic expression list from label
    return [{ text: label, threshold: 0 }];
  }

  private seedDefaultRelations(): void {
    // Seed MESSY default relations from the manual
    const defaults: Array<[string, TripleRelation['type'], LexItem[], number]> = [
      ['AFFECTION', 'state', [
        { text: 'hate', threshold: -2.5 },
        { text: 'dislike', threshold: -0.5 },
        { text: 'like', threshold: 0.5 },
        { text: 'love', threshold: 2.5 }
      ], 0],
      ['SEE', 'action', [{ text: 'see', threshold: 0 }, { text: 'witness', threshold: 1.5 }], 0],
      ['BLACKMAIL', 'action', [{ text: 'blackmail', threshold: 0 }], 0],
      ['GOSSIP', 'action', [{ text: 'gossip about', threshold: 0 }, { text: 'whisper about', threshold: 1 }], 0],
      ['CARESS', 'action', [{ text: 'caress', threshold: 0 }, { text: 'embrace', threshold: 2 }], 0],
      ['FLIRT', 'action', [{ text: 'flirt with', threshold: 0 }, { text: 'court', threshold: 2 }], 0],
      ['FOLLOW', 'action', [{ text: 'follow', threshold: 0 }], 0],
      ['LEAVE', 'action', [{ text: 'leave', threshold: 0 }, { text: 'abandon', threshold: 2 }], 0],
      ['MARRIED', 'state', [{ text: 'married to', threshold: 0 }], 0],
      ['WEALTH', 'state', [
        { text: 'destitute', threshold: -3 },
        { text: 'poor', threshold: -1 },
        { text: 'comfortable', threshold: 0.5 },
        { text: 'wealthy', threshold: 2.5 }
      ], 0],
      ['ATTRACTIVE', 'adj', [
        { text: 'ugly', threshold: -1 },
        { text: 'plain', threshold: 0 },
        { text: 'pretty', threshold: 1 },
        { text: 'beautiful', threshold: 2.5 }
      ], 0],
      ['JEALOUS', 'adj', [{ text: 'calm', threshold: -0.5 }, { text: 'jealous', threshold: 0.5 }], 0],
      ['IS', 'state', [{ text: 'is', threshold: 0 }], 0],
      ['HAS', 'state', [{ text: 'has', threshold: 0 }], 0],
      ['KNOWS', 'state', [{ text: 'knows', threshold: 0 }, { text: 'understands', threshold: 1.5 }], 0],
      ['CAUSES', 'action', [{ text: 'causes', threshold: 0 }, { text: 'leads to', threshold: 1 }], 0],
      ['BELIEVES', 'state', [{ text: 'believes', threshold: 0 }, { text: 'is certain', threshold: 2 }], 0],
    ];
    for (const [name, type, expr, rv] of defaults) {
      if (!this.relations.has(name)) this.addRelation(name, type, expr, rv);
    }
  }

  // Extract triples from parse tree and feed into the network
  extractFromParse(tokens: Array<{ text: string; pos: string }>, deps: Array<{ gov: number; dep: number; rel: string }>): void {
    // Create entity nodes
    for (const tok of tokens) {
      if (/^(NN|NNS|NNP|NNPS|PRP)$/.test(tok.pos)) {
        this.findOrCreate(tok.text, 'atom');
      }
      if (/^(VB|VBD|VBG|VBN|VBP|VBZ)$/.test(tok.pos)) {
        this.addRelation(tok.text, 'action', [{ text: tok.text, threshold: 0 }]);
      }
    }

    // Create triples from dependencies
    for (const d of deps) {
      const gov = tokens[d.gov];
      const depTok = tokens[d.dep];
      if (!gov || !depTok) continue;

      const rel = d.rel.replace(/^(nsubj|nsubj:pass)$/, 'agentOf')
        .replace(/^(dobj|obj)$/, 'patientOf')
        .replace(/^(iobj)$/, 'recipientOf')
        .replace(/^(nmod|obl)$/, 'modifierOf')
        .replace(/^(amod)$/, 'propertyOf')
        || d.rel;

      this.assert(gov.text, rel, depTok.text, 1, 0, 0, 'user');
    }
  }

  // Build from existing graph nodes (bridge from old graphStore)
  buildFromGraphNodes(nodes: SGNode[]): void {
    for (const n of nodes) {
      const type = n.type === 'entity' || n.type === 'object' ? 'atom' :
        n.type === 'concept' ? 'class' : 'atom';
      this.findOrCreate(n.label, type as TripleNode['type']);
    }
  }

  getSnapshot() {
    return {
      nodes: Array.from(this.nodes.values()),
      relations: Array.from(this.relations.values()),
      triples: [...this.triples],
      rules: [...this.rules],
      classes: Array.from(this.classes.entries()).map(([k, v]) => ({ name: k, members: Array.from(v) })),
      groups: Array.from(this.groups.entries()),
      tick: this.tick
    };
  }
}

export const tripleStore = new TripleStore();
