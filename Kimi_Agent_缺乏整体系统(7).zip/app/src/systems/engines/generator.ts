// ═══════════════════════════════════════════════════════════════
//  GENERATOR ENGINE
//  Discourse planner → grammar templates → surface text.
//  Not random text. Structured generation from semantic plans.
// ═══════════════════════════════════════════════════════════════

import type { DiscoursePlan, PlanStep, ParseTree } from '@/types';

export class GeneratorEngine {
  // Generate from a discourse plan
  generate(plan: DiscoursePlan): string {
    const segments: string[] = [];

    for (const step of plan.steps) {
      const text = this.realizeStep(step);
      segments.push(text);
    }

    return segments.join('\n\n');
  }

  private realizeStep(step: PlanStep): string {
    const templates: Record<string, string[]> = {
      state: [
        '{content}',
        'The {content} stretched before them.',
        'It was a time when {content}.',
      ],
      event: [
        '{content}',
        'Then, {content}.',
        'Suddenly, {content}.',
        'Without warning, {content}.',
      ],
      quote: [
        '"{content}," said {agent}.',
        '{agent} spoke: "{content}."',
        '"{content}," {agent} replied.',
      ],
      action: [
        '{agent} {content}.',
        '{agent} began to {content}.',
        'With determination, {agent} {content}.',
      ],
      reveal: [
        'The truth was revealed: {content}.',
        'It became clear that {content}.',
        'At last, {content}.',
      ],
    };

    const stepTemplates = templates[step.type] || templates.state;
    const template = stepTemplates[Math.floor(Math.random() * stepTemplates.length)];

    return template
      .replace('{content}', step.content)
      .replace('{agent}', step.agents[0] || 'someone')
      .replace('{mood}', step.mood);
  }

  // Build a discourse plan from parsed input
  planFromParse(parseTree: ParseTree, intent: string): DiscoursePlan {
    const steps: PlanStep[] = [];
    const tokens = parseTree.tokens;
    const entities = parseTree.entities;

    // Extract key content words
    const nouns = tokens.filter(t => /^NN/.test(t.pos)).map(t => t.text);
    const verbs = tokens.filter(t => /^V/.test(t.pos)).map(t => t.text);

    const mainAgent = entities[0]?.text || nouns[0] || 'the protagonist';

    // Build plan based on intent
    switch (intent) {
      case 'generate-story':
      case 'generate-game':
        steps.push({ type: 'state', content: `world of ${nouns.slice(0, 3).join(' and ')}`, agents: [mainAgent], mood: 'ominous' });
        steps.push({ type: 'event', content: `${verbs[0] || 'something happened'}`, agents: [mainAgent], mood: 'tense' });
        if (verbs.length > 1) {
          steps.push({ type: 'action', content: `${verbs[1]} forward`, agents: [mainAgent], mood: 'determined' });
        }
        steps.push({ type: 'reveal', content: `nothing would ever be the same`, agents: [mainAgent], mood: 'dramatic' });
        break;

      case 'generate-code':
        steps.push({ type: 'state', content: `function accepting ${nouns.slice(0, 2).join(', ')}`, agents: ['developer'], mood: 'technical' });
        steps.push({ type: 'action', content: `process the input through transformation pipeline`, agents: ['system'], mood: 'precise' });
        steps.push({ type: 'reveal', content: `the output emerges, validated and structured`, agents: ['system'], mood: 'satisfying' });
        break;

      case 'generate-script':
        steps.push({ type: 'state', content: `dimly lit scene`, agents: [mainAgent], mood: 'noir' });
        steps.push({ type: 'quote', content: `We need to talk about ${nouns[0] || 'this'}`, agents: [mainAgent], mood: 'tense' });
        steps.push({ type: 'event', content: `${verbs[0] || 'tension escalates'}`, agents: [mainAgent], mood: 'dramatic' });
        break;

      default:
        steps.push({ type: 'state', content: tokens.map(t => t.text).slice(0, 8).join(' '), agents: [mainAgent], mood: 'neutral' });
        if (verbs.length > 0) {
          steps.push({ type: 'action', content: verbs.join(', '), agents: [mainAgent], mood: 'active' });
        }
    }

    return { intent, topic: nouns[0] || 'general', steps };
  }

  // Generate code from semantic specification
  generateCode(spec: { type: string; inputs: string[]; operations: string[]; outputs: string[] }): string {
    const lines: string[] = [];

    // Function signature
    const funcName = spec.type.replace(/\s+/g, '_');
    const params = spec.inputs.map((inp, i) => `${inp.toLowerCase().replace(/\s+/g, '')}_${i}`).join(', ');
    lines.push(`function ${funcName}(${params}) {`);

    // Processing steps
    for (const op of spec.operations) {
      const opName = op.toLowerCase().replace(/\s+/g, '_');
      lines.push(`  const ${opName}_result = ${opName}(input);`);
    }

    // Return
    if (spec.outputs.length > 0) {
      lines.push(`  return { ${spec.outputs.map(o => o.toLowerCase().replace(/\s+/g, '_')).join(', ')} };`);
    }

    lines.push('}');
    return lines.join('\n');
  }

  // ═══════════════════════════════════════════════════════════════
  //  SEMANTICS-TO-SURFACE GENERATION (MESSY-style)
  //  From Klein 1979: "The flow of the narrative is derived from
  //  reports on the changing state of the modelled universe."
  //
  //  Uses expression lists to select lexical items based on
  //  reality values. phrase_structure_rule // canonical_triple
  // ═══════════════════════════════════════════════════════════════

  generateFromTriples(triples: Array<{
    subject: string; relation: string; object: string;
    rv: number; time: number; h: number;
  }>, resolveExpr: (nodeId: string, rv: number) => string): string {
    if (triples.length === 0) return '';

    const segments: string[] = [];

    // Group triples by time for temporal flow
    const byTime = new Map<number, typeof triples>();
    for (const t of triples) {
      const bucket = byTime.get(t.time) || [];
      bucket.push(t);
      byTime.set(t.time, bucket);
    }

    const sortedTimes = Array.from(byTime.keys()).sort((a, b) => a - b);

    for (const time of sortedTimes) {
      const group = byTime.get(time)!;
      const timePhrase = time < 0 ? 'Once, ' : time > 0 ? 'Later, ' : '';

      for (const t of group) {
        const subj = resolveExpr(t.subject, t.rv);
        const rel = resolveExpr(t.relation, t.rv);
        const obj = resolveExpr(t.object, t.rv);

        // Apply high-level transformations from MESSY paper
        // Active voice default, passive if rv < 0
        const voiceMark = t.rv < 0 ? ' no longer' : '';
        const hypoMark = t.h > 0 ? 'perhaps ' : '';

        // Select surface pattern based on relation type
        let sentence: string;
        if (t.relation === 'IS' || t.relation === 'HAS' || t.relation === 'MARRIED') {
          sentence = `${timePhrase}${subj}${voiceMark} ${rel} ${hypoMark}${obj}.`;
        } else if (t.relation === 'AFFECTION' || t.relation === 'JEALOUS') {
          const intensity = Math.abs(t.rv) > 2 ? 'deeply ' : Math.abs(t.rv) > 1 ? '' : 'slightly ';
          sentence = `${timePhrase}${subj}${voiceMark} ${intensity}${rel} ${hypoMark}${obj}.`;
        } else if (t.relation === 'KNOWS' || t.relation === 'BELIEVES') {
          sentence = `${timePhrase}${subj} ${rel}${voiceMark} that ${hypoMark}${obj}.`;
        } else if (t.relation === 'CAUSES' || t.relation === 'LEADS_TO') {
          sentence = `${timePhrase}${subj}${voiceMark} ${rel} ${hypoMark}${obj}.`;
        } else {
          // Default: S + V + O
          sentence = `${timePhrase}${subj}${voiceMark} ${rel} ${hypoMark}${obj}.`;
        }

        // Capitalize first letter
        sentence = sentence.charAt(0).toUpperCase() + sentence.slice(1);
        segments.push(sentence);
      }
    }

    return segments.join('\n\n');
  }

  // Surface realizer: convert structured content to natural text
  realize(text: string, style: 'narrative' | 'technical' | 'dialogue' = 'narrative'): string {
    switch (style) {
      case 'technical':
        return text
          .replace(/\bThe\b/g, 'the')
          .replace(/\bsuddenly\b/gi, 'subsequently')
          .replace(/\bthen\b/gi, 'thereafter')
          + '.';
      case 'dialogue':
        return `"${text.charAt(0).toUpperCase() + text.slice(1)}."`;
      default:
        return text.charAt(0).toUpperCase() + text.slice(1) + '.';
    }
  }
}

export const generator = new GeneratorEngine();
