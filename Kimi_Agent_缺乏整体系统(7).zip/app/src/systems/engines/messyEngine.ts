// ═══════════════════════════════════════════════════════════════
//  MESSY BEHAVIORAL SIMULATION ENGINE
//  Based on Klein et al. Meta-symbolic Simulation System (1976)
//  and "Automatic Novel Writing" (1979).
//
//  Key concept: behavioral rules test and modify semantic triples.
//  Rules live in groups. Conditions test reality values (RV).
//  Actions assert/retract/modify triples. Narrative reports on
//  graph changes. This is the "world engine" — simulation
//  mutates the network, generation reports the changes.
// ═══════════════════════════════════════════════════════════════

import { tripleStore, type BehavioralRule, type RuleCondition, type RuleAction } from '@/systems/memory/tripleStore';

// ── MURDER MYSTERY MODEL ────────────────────────────────────
// Based on MESSY manual murder mystery example and Novel Writing.
// This is Klein's canonical test case — a behavioral model that
// generates plot through rule firing.

function seedMurderMystery(): void {
  // Characters (nodes with expression lists)
  const chars = [
    { id: 'DETECTIVE', label: 'Detective', expr: [
      { text: 'the inspector', threshold: 0 },
      { text: 'the great detective', threshold: 2 }
    ]},
    { id: 'VICTIM', label: 'Victim', expr: [
      { text: 'the victim', threshold: 0 },
      { text: 'the unfortunate soul', threshold: 1.5 }
    ]},
    { id: 'SUSPECT_A', label: 'Suspect A', expr: [
      { text: 'the butler', threshold: 0 },
      { text: 'the suspicious servant', threshold: 1.5 }
    ]},
    { id: 'SUSPECT_B', label: 'Suspect B', expr: [
      { text: 'the heiress', threshold: 0 },
      { text: 'the elegant lady', threshold: 2 }
    ]},
    { id: 'SUSPECT_C', label: 'Suspect C', expr: [
      { text: 'the stranger', threshold: 0 },
      { text: 'the mysterious guest', threshold: 1.5 }
    ]},
    { id: 'CLUE', label: 'Clue', expr: [
      { text: 'the evidence', threshold: 0 },
      { text: 'the damning proof', threshold: 2 }
    ]},
  ];

  for (const c of chars) {
    tripleStore.addNode(c.id, c.label, 'atom', c.expr);
  }

  // Seed classes
  tripleStore.addToClass('SUSPECT', 'SUSPECT_A');
  tripleStore.addToClass('SUSPECT', 'SUSPECT_B');
  tripleStore.addToClass('SUSPECT', 'SUSPECT_C');
  tripleStore.addToClass('SUSPECT', 'DETECTIVE');
  tripleStore.addToClass('CHARACTER', 'VICTIM');
  tripleStore.addToClass('CHARACTER', 'SUSPECT_A');
  tripleStore.addToClass('CHARACTER', 'SUSPECT_B');
  tripleStore.addToClass('CHARACTER', 'SUSPECT_C');
  tripleStore.addToClass('CHARACTER', 'DETECTIVE');

  // Initial world state triples
  tripleStore.assert('VICTIM', 'IS', 'DEAD', 1, 0, 0, 'simulated');
  tripleStore.assert('DETECTIVE', 'KNOWS', 'VICTIM', 1, 0, 0, 'simulated');
  tripleStore.assert('SUSPECT_A', 'MARRIED', 'SUSPECT_B', 0.5, 0, 0, 'simulated');
  tripleStore.assert('SUSPECT_B', 'WEALTH', 'MONEY', 2, 0, 0, 'simulated');
  tripleStore.assert('SUSPECT_A', 'WEALTH', 'MONEY', -1, 0, 0, 'simulated');
  tripleStore.assert('SUSPECT_C', 'AFFECTION', 'SUSPECT_B', 1.5, 0, 0, 'simulated');
  tripleStore.assert('SUSPECT_A', 'JEALOUS', 'SUSPECT_C', 0.5, 0, 0, 'simulated');

  // ── BEHAVIORAL RULES (from MESSY manual pattern) ──────────

  // Rule: If X has motive (poor + married to wealthy victim), X might kill
  tripleStore.addRule({
    name: 'motive_poverty',
    group: 'plot',
    conditions: [
      { type: 'class_membership', subject: 'X', target: 'SUSPECT' },
      { type: 'rv_test', subject: 'X', target: 'X WEALTH', operator: 'LT', value: 0 },
      { type: 'exists', subject: 'VICTIM', relation: 'IS', object: 'DEAD' },
      { type: 'probability', probWeight: 40 }
    ],
    actions: [
      { type: 'assert', subject: 'X', relation: 'HAS', object: 'MOTIVE' },
      { type: 'set_rv', subject: 'X', relation: 'HAS', object: 'MOTIVE', value: 1 }
    ],
    probability: 40,
    active: true
  });

  // Rule: If X is jealous of Y who loves the victim's spouse, X might act
  tripleStore.addRule({
    name: 'motive_jealousy',
    group: 'plot',
    conditions: [
      { type: 'class_membership', subject: 'X', target: 'SUSPECT' },
      { type: 'rv_test', subject: 'X', target: 'X JEALOUS', operator: 'GT', value: 0 },
      { type: 'exists', subject: 'VICTIM', relation: 'IS', object: 'DEAD' },
      { type: 'probability', probWeight: 50 }
    ],
    actions: [
      { type: 'assert', subject: 'X', relation: 'HAS', object: 'MOTIVE' },
      { type: 'modify_rv', subject: 'X', relation: 'JEALOUS', object: 'Y', value: 1 }
    ],
    probability: 50,
    active: true
  });

  // Rule: Discovery — detective finds a clue
  tripleStore.addRule({
    name: 'discovery',
    group: 'investigation',
    conditions: [
      { type: 'exists', subject: 'VICTIM', relation: 'IS', object: 'DEAD' },
      { type: 'not_exists', subject: 'DETECTIVE', relation: 'HAS', object: 'CLUE' },
      { type: 'probability', probWeight: 60 }
    ],
    actions: [
      { type: 'assert', subject: 'DETECTIVE', relation: 'FINDS', object: 'CLUE' },
      { type: 'assert', subject: 'CLUE', relation: 'POINTS_TO', object: 'SUSPECT_A' }
    ],
    probability: 60,
    active: true
  });

  // Rule: Accusation — detective accuses based on clue
  tripleStore.addRule({
    name: 'accusation',
    group: 'investigation',
    conditions: [
      { type: 'exists', subject: 'DETECTIVE', relation: 'FINDS', object: 'CLUE' },
      { type: 'exists', subject: 'CLUE', relation: 'POINTS_TO', object: 'X' },
      { type: 'probability', probWeight: 70 }
    ],
    actions: [
      { type: 'assert', subject: 'DETECTIVE', relation: 'ACCUSES', object: 'X' },
      { type: 'assert', subject: 'X', relation: 'IS', object: 'ACCUSED' }
    ],
    probability: 70,
    active: true
  });

  // Rule: Red herring — wrong clue points elsewhere
  tripleStore.addRule({
    name: 'red_herring',
    group: 'plot',
    conditions: [
      { type: 'exists', subject: 'DETECTIVE', relation: 'FINDS', object: 'CLUE' },
      { type: 'probability', probWeight: 30 }
    ],
    actions: [
      { type: 'assert', subject: 'CLUE', relation: 'MISLEADS', object: 'DETECTIVE' },
      { type: 'set_rv', subject: 'CLUE', relation: 'POINTS_TO', object: 'SUSPECT_A', value: -0.5 }
    ],
    probability: 30,
    active: true
  });

  // Rule: Confession under pressure
  tripleStore.addRule({
    name: 'confession',
    group: 'resolution',
    conditions: [
      { type: 'exists', subject: 'X', relation: 'IS', object: 'ACCUSED' },
      { type: 'exists', subject: 'X', relation: 'HAS', object: 'MOTIVE' },
      { type: 'rv_test', subject: 'X', target: 'X AFFECTION', operator: 'LT', value: 0 },
      { type: 'probability', probWeight: 45 }
    ],
    actions: [
      { type: 'assert', subject: 'X', relation: 'CONFESSES', object: 'CRIME' },
      { type: 'assert', subject: 'X', relation: 'IS', object: 'GUILTY' }
    ],
    probability: 45,
    active: true
  });

  // Rule: Revelation — the truth comes out
  tripleStore.addRule({
    name: 'revelation',
    group: 'resolution',
    conditions: [
      { type: 'exists', subject: 'X', relation: 'CONFESSES', object: 'CRIME' },
      { type: 'exists', subject: 'DETECTIVE', relation: 'KNOWS', object: 'VICTIM' }
    ],
    actions: [
      { type: 'assert', subject: 'TRUTH', relation: 'IS', object: 'REVEALED' },
      { type: 'assert', subject: 'DETECTIVE', relation: 'SOLVES', object: 'CASE' }
    ],
    probability: 100,
    active: true
  });

  // Rule: Plot twist — someone unexpected is involved
  tripleStore.addRule({
    name: 'plot_twist',
    group: 'plot',
    conditions: [
      { type: 'exists', subject: 'VICTIM', relation: 'IS', object: 'DEAD' },
      { type: 'not_exists', subject: 'TRUTH', relation: 'IS', object: 'REVEALED' },
      { type: 'probability', probWeight: 25 }
    ],
    actions: [
      { type: 'assert', subject: 'VICTIM', relation: 'HAD', object: 'SECRET' },
      { type: 'assert', subject: 'SECRET', relation: 'INVOLVES', object: 'SUSPECT_C' }
    ],
    probability: 25,
    active: true
  });

  // Enable plot group
  tripleStore.enableGroup('plot');
  tripleStore.enableGroup('investigation');
  tripleStore.enableGroup('resolution');
}

// ── PROPP-STYLE FAIRY TALE RULES ───────────────────────────
// From "Automatic Novel Writing": Klein automated Propp's
// morphology. These are the narrative functions.

function seedProppTale(): void {
  // Characters
  const chars = [
    { id: 'HERO', label: 'Hero', expr: [{ text: 'the brave hero', threshold: 0 }, { text: 'the young adventurer', threshold: 1 }] },
    { id: 'VILLAIN', label: 'Villain', expr: [{ text: 'the villain', threshold: 0 }, { text: 'the wicked sorcerer', threshold: 2 }] },
    { id: 'PRIZE', label: 'Prize', expr: [{ text: 'the treasure', threshold: 0 }, { text: 'the golden prize', threshold: 1.5 }] },
    { id: 'GUARDIAN', label: 'Guardian', expr: [{ text: 'the guardian', threshold: 0 }, { text: 'the ancient keeper', threshold: 2 }] },
    { id: 'HELPER', label: 'Helper', expr: [{ text: 'the helper', threshold: 0 }, { text: 'the wise guide', threshold: 1.5 }] },
  ];

  for (const c of chars) {
    tripleStore.addNode(c.id, c.label, 'atom', c.expr);
  }

  tripleStore.addToClass('CHARACTER', 'HERO');
  tripleStore.addToClass('CHARACTER', 'VILLAIN');
  tripleStore.addToClass('CHARACTER', 'GUARDIAN');
  tripleStore.addToClass('CHARACTER', 'HELPER');

  // Initial: villain takes prize
  tripleStore.assert('VILLAIN', 'HAS', 'PRIZE', 1, 0, 0, 'simulated');
  tripleStore.assert('HERO', 'WANTS', 'PRIZE', 1, 0, 0, 'simulated');
  tripleStore.assert('GUARDIAN', 'PROTECTS', 'PRIZE', 1, 0, 0, 'simulated');

  // Propp function α: Absentation (hero leaves home)
  tripleStore.addRule({
    name: 'propp_absentation',
    group: 'propp',
    conditions: [
      { type: 'exists', subject: 'HERO', relation: 'WANTS', object: 'PRIZE' },
      { type: 'probability', probWeight: 80 }
    ],
    actions: [
      { type: 'assert', subject: 'HERO', relation: 'DEPARTS', object: 'HOME' },
      { type: 'assert', subject: 'HERO', relation: 'SEEKS', object: 'PRIZE' }
    ],
    probability: 80,
    active: true
  });

  // Propp function δ: Struggle (hero vs villain)
  tripleStore.addRule({
    name: 'propp_struggle',
    group: 'propp',
    conditions: [
      { type: 'exists', subject: 'HERO', relation: 'DEPARTS', object: 'HOME' },
      { type: 'exists', subject: 'VILLAIN', relation: 'HAS', object: 'PRIZE' },
      { type: 'probability', probWeight: 70 }
    ],
    actions: [
      { type: 'assert', subject: 'HERO', relation: 'FIGHTS', object: 'VILLAIN' },
      { type: 'modify_rv', subject: 'VILLAIN', relation: 'HAS', object: 'PRIZE', value: -0.5 }
    ],
    probability: 70,
    active: true
  });

  // Propp function λ: Victory
  tripleStore.addRule({
    name: 'propp_victory',
    group: 'propp',
    conditions: [
      { type: 'exists', subject: 'HERO', relation: 'FIGHTS', object: 'VILLAIN' },
      { type: 'rv_test', subject: 'VILLAIN', target: 'VILLAIN HAS', operator: 'LT', value: 0.5 },
      { type: 'probability', probWeight: 60 }
    ],
    actions: [
      { type: 'assert', subject: 'HERO', relation: 'DEFEATS', object: 'VILLAIN' },
      { type: 'assert', subject: 'VILLAIN', relation: 'IS', object: 'DEFEATED' },
      { type: 'retract', subject: 'VILLAIN', relation: 'HAS', object: 'PRIZE' }
    ],
    probability: 60,
    active: true
  });

  // Propp function P: Return with prize
  tripleStore.addRule({
    name: 'propp_return',
    group: 'propp',
    conditions: [
      { type: 'exists', subject: 'HERO', relation: 'DEFEATS', object: 'VILLAIN' },
      { type: 'not_exists', subject: 'VILLAIN', relation: 'HAS', object: 'PRIZE' }
    ],
    actions: [
      { type: 'assert', subject: 'HERO', relation: 'OBTAINS', object: 'PRIZE' },
      { type: 'assert', subject: 'HERO', relation: 'RETURNS', object: 'HOME' },
      { type: 'assert', subject: 'HERO', relation: 'HAS', object: 'PRIZE' }
    ],
    probability: 90,
    active: true
  });

  // Helper assists
  tripleStore.addRule({
    name: 'helper_assists',
    group: 'propp',
    conditions: [
      { type: 'exists', subject: 'HERO', relation: 'DEPARTS', object: 'HOME' },
      { type: 'exists', subject: 'HERO', relation: 'SEEKS', object: 'PRIZE' },
      { type: 'probability', probWeight: 50 }
    ],
    actions: [
      { type: 'assert', subject: 'HELPER', relation: 'GIVES', object: 'HERO' },
      { type: 'assert', subject: 'HELPER', relation: 'GIVES', object: 'ADVICE' },
      { type: 'modify_rv', subject: 'HERO', relation: 'WANTS', object: 'PRIZE', value: 0.5 }
    ],
    probability: 50,
    active: true
  });

  tripleStore.enableGroup('propp');
}

// ── SIMULATION INTERFACE ────────────────────────────────────

export interface MessySimulationResult {
  tick: number;
  narrative: string;
  changes: string[];
  rulesFired: string[];
  triples: number;
}

export function setupMessyWorld(scenario: 'murder' | 'propp' | 'custom' = 'murder'): void {
  // Don't re-seed if already populated
  if (tripleStore.triples.length > 5) return;

  if (scenario === 'murder') seedMurderMystery();
  else if (scenario === 'propp') seedProppTale();
}

export function tickMessy(): MessySimulationResult {
  const result = tripleStore.tickSimulation();
  const narrative = tripleStore.generateNarrative(5);

  return {
    tick: result.tick,
    narrative,
    changes: result.changes,
    rulesFired: result.rulesFired,
    triples: tripleStore.triples.length
  };
}

export function runMessySimulation(ticks = 5): MessySimulationResult[] {
  const results: MessySimulationResult[] = [];
  for (let i = 0; i < ticks; i++) {
    results.push(tickMessy());
  }
  return results;
}

export function getMessySnapshot() {
  return tripleStore.getSnapshot();
}

export function addMessyRule(rule: Omit<BehavioralRule, 'id' | 'weight'>): BehavioralRule {
  return tripleStore.addRule(rule);
}

// Re-export types for convenience
export type { BehavioralRule, RuleCondition, RuleAction };
