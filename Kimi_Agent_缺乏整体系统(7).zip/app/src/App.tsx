import { useState, useRef, useEffect, useCallback } from 'react';
import { runPipeline, SYSTEMS } from '@/systems/pipeline';
import { tripleStore } from '@/systems/memory/tripleStore';
import { ruleStore } from '@/systems/memory/ruleStore';
import type { PipelineFlow, PipelineNode, ChatMsg, SGNode, SGEdge, Rule } from '@/types';

export default function App() {
  const [messages, setMessages] = useState<ChatMsg[]>([
    { id: 'w', role: 'system', content: 'KLEIN OS\n\nSeven systems. Three generators. One pipeline.\n\nFeed the pipeline:\n• "Write a murder mystery game"\n• "Build a task tracking app"\n• "Create a noir video storyboard"\n• "Explain this code: function fib(n) { ... }"', timestamp: Date.now() }
  ]);
  const [input, setInput] = useState('');
  const [flow, setFlow] = useState<PipelineFlow | null>(null);
  const [processing, setProcessing] = useState(false);
  const [tab, setTab] = useState<'text' | 'game' | 'app' | 'video'>('text');
  const [_feedback, setFeedback] = useState<Array<{ id: string; flowId: string; output: string; verdict: 'accept' | 'reject' | 'correct'; correction?: string; timestamp: number }>>([]);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => endRef.current?.scrollIntoView({ behavior: 'smooth' }), [messages]);

  const submit = useCallback(async () => {
    if (!input.trim() || processing) return;
    setMessages(p => [...p, { id: `u${Date.now()}`, role: 'user', content: input.trim(), timestamp: Date.now() }]);
    setInput(''); setProcessing(true); setFlow(null);

    const result = await runPipeline(input.trim());
    setFlow(result);
    // Auto-switch to artifact tab if applicable
    if (result.artifact.type !== 'text') {
      setTab(result.artifact.type);
    }
    setMessages(p => [...p, { id: `s${Date.now()}`, role: 'system', content: result.finalOutput, flowId: result.id, timestamp: Date.now() }]);
    setProcessing(false);
  }, [input, processing]);

  const onKeyDown = (e: React.KeyboardEvent) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit(); } };

  const handleFeedback = useCallback((flowId: string, output: string, verdict: 'accept' | 'reject' | 'correct', correction?: string) => {
    const entry = { id: `fb_${Date.now()}`, flowId, output, verdict, correction, timestamp: Date.now() };
    setFeedback(p => [...p, entry]);
    // Update rule confidence based on feedback
    if (verdict === 'accept') {
      // Reinforce rules that produced this output
      const rules = ruleStore.getRules();
      for (const r of rules) {
        if (r.useCount > 0) r.confidence = Math.min(1, r.confidence + 0.05);
      }
    } else if (verdict === 'reject') {
      // Decrease confidence of recently used rules
      const rules = ruleStore.getRules();
      for (const r of rules) {
        if (r.useCount > 0) r.confidence = Math.max(0.1, r.confidence - 0.1);
      }
    } else if (verdict === 'correct' && correction) {
      // Learn from correction
      ruleStore.learnFromExample('transformation', output, correction);
    }
  }, []);

  return (
    <div className="h-screen w-screen bg-[#050508] text-white flex overflow-hidden font-mono text-sm selection:bg-amber-500/30">
      {/* LEFT: Chat */}
      <div className="flex-1 flex flex-col min-w-0 border-r border-white/5">
        <header className="px-5 py-3 border-b border-white/5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <span className="font-bold tracking-wider text-amber-400">KLEIN OS</span>
            <span className="text-white/20">|</span>
            <span className="text-white/40 text-xs">Semantic Simulation Generator</span>
          </div>
          <span className={processing ? 'text-amber-400 text-xs' : 'text-emerald-400/60 text-xs'}>{processing ? 'PROCESSING' : 'IDLE'}</span>
        </header>

        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {messages.map(m => (
            <div key={m.id} className={m.role === 'user' ? 'flex justify-end' : ''}>
              <div className={`max-w-[85%] ${m.role === 'user' ? 'bg-white/5' : ''} rounded-lg px-4 py-3`}>
                {m.id === 'w' && <div className="mb-2 pb-2 border-b border-white/5"><span className="text-amber-400 font-bold text-xs tracking-widest">PIPELINE ACTIVE</span></div>}
                <pre className="whitespace-pre-wrap leading-relaxed text-white/80 font-mono text-sm">{m.content}</pre>
                {m.flowId && (
                  <div className="mt-2 pt-2 border-t border-white/5 space-y-2">
                    <div className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-emerald-400" /><span className="text-xs text-emerald-400/60">Pipeline complete</span></div>
                    {/* INFORMANT LEARNING LOOP */}
                    <div className="flex items-center gap-1">
                      <span className="text-[9px] text-white/20 mr-1">INFORMANT:</span>
                      <button onClick={() => handleFeedback(m.flowId!, m.content, 'accept')} className="text-[9px] px-2 py-0.5 rounded bg-emerald-400/10 text-emerald-400/60 hover:bg-emerald-400/20 transition-all">ACCEPT</button>
                      <button onClick={() => handleFeedback(m.flowId!, m.content, 'reject')} className="text-[9px] px-2 py-0.5 rounded bg-red-400/10 text-red-400/60 hover:bg-red-400/20 transition-all">REJECT</button>
                      <button onClick={() => {
                        const corr = prompt('Enter correction:');
                        if (corr) handleFeedback(m.flowId!, m.content, 'correct', corr);
                      }} className="text-[9px] px-2 py-0.5 rounded bg-amber-400/10 text-amber-400/60 hover:bg-amber-400/20 transition-all">CORRECT</button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
          {processing && !flow && <div className="flex items-center gap-2 text-white/30 text-xs px-4"><div className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />Ingesting...</div>}
          <div ref={endRef} />
        </div>

        <div className="px-4 py-3 border-t border-white/5 shrink-0">
          <div className="flex gap-2">
            <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={onKeyDown}
              placeholder="Feed the pipeline..." rows={1}
              className="flex-1 bg-white/3 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-white/20 focus:outline-none focus:border-amber-400/40 resize-none min-h-[48px] max-h-[120px]" />
            <button onClick={submit} disabled={processing || !input.trim()}
              className="px-5 py-3 bg-amber-400/10 border border-amber-400/30 rounded-lg text-amber-400 hover:bg-amber-400/20 disabled:opacity-20 transition-all">{processing ? '...' : '→'}</button>
          </div>
        </div>
      </div>

      {/* RIGHT: Artifact Panel */}
      <div className="w-[560px] shrink-0 flex flex-col bg-black/20">
        {/* Artifact Tabs */}
        <div className="px-4 py-3 border-b border-white/5 shrink-0 flex items-center gap-1">
          {(['text', 'game', 'app', 'video'] as const).map(t => {
            const hasArtifact = flow?.artifact.type === t;
            return (
              <button key={t} onClick={() => setTab(t)}
                className={`text-xs px-3 py-1.5 rounded flex items-center gap-1.5 transition-all ${tab === t ? 'bg-white/10 text-amber-400' : 'text-white/30 hover:text-white/60'}`}>
                {t === 'text' && 'TEXT'}
                {t === 'game' && <><span className="w-1.5 h-1.5 rounded-full bg-purple-400" />GAME</>}
                {t === 'app' && <><span className="w-1.5 h-1.5 rounded-full bg-blue-400" />APP</>}
                {t === 'video' && <><span className="w-1.5 h-1.5 rounded-full bg-pink-400" />VIDEO</>}
                {hasArtifact && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />}
              </button>
            );
          })}
          {flow && <span className="text-xs text-amber-400/60 ml-auto">{flow.intent}</span>}
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto">
          {!flow && (
            <div className="h-full flex flex-col items-center justify-center text-white/20 px-8">
              <div className="grid grid-cols-3 gap-2 mb-6 opacity-30">
                {SYSTEMS.map(s => <div key={s.id} className="w-2 h-2 rounded-full" style={{ backgroundColor: s.color }} />)}
              </div>
              <p className="text-xs text-center">Feed the pipeline to generate artifacts.<br />Try: "Build a detective game" or "Create a task app"</p>
            </div>
          )}

          {flow && tab === 'text' && <TextTab flow={flow} />}
          {flow && tab === 'game' && <GameTab flow={flow} />}
          {flow && tab === 'app' && <AppTab flow={flow} />}
          {flow && tab === 'video' && <VideoTab flow={flow} />}
        </div>

        {/* Bottom: Pipeline + Systems */}
        <div className="border-t border-white/5 shrink-0">
          {/* Mini Pipeline */}
          {flow && (
            <div className="px-4 py-2 border-b border-white/5 overflow-x-auto">
              <div className="flex items-center gap-1">
                {flow.nodes.slice(0, 8).map((n, i) => {
                  const sys = SYSTEMS.find(s => s.id === n.systemId);
                  const color = sys?.color || '#6b7280';
                  return (
                    <div key={n.id} className="flex items-center gap-1">
                      {i > 0 && <span className="text-white/10 text-[8px]">→</span>}
                      <span className="text-[8px] px-1 py-0.5 rounded" style={{ color, backgroundColor: `${color}15` }}>{n.label}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
          <div className="px-4 py-2 flex items-center gap-3">
            {SYSTEMS.map(s => (
              <div key={s.id} className="flex items-center gap-1">
                <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: s.color }} />
                <span className="text-[9px] text-white/30">{s.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── TEXT TAB ────────────────────────────────────────────────
function TextTab({ flow }: { flow: PipelineFlow }) {
  const [subTab, setSubTab] = useState<'output' | 'pipeline' | 'parse' | 'graph' | 'triples' | 'rules'>('output');

  return (
    <div className="h-full flex flex-col">
      <div className="flex gap-1 px-4 pt-3 pb-2 border-b border-white/5">
        {(['output', 'pipeline', 'parse', 'graph', 'triples', 'rules'] as const).map(t => (
          <button key={t} onClick={() => setSubTab(t)} className={`text-[10px] px-2 py-1 rounded ${subTab === t ? 'bg-white/10 text-white/70' : 'text-white/30'}`}>{t.toUpperCase()}</button>
        ))}
      </div>
      <div className="flex-1 overflow-y-auto px-4 py-3">
        {subTab === 'output' && (
          <pre className="whitespace-pre-wrap text-white/70 font-mono text-xs leading-relaxed">{flow.finalOutput}</pre>
        )}
        {subTab === 'pipeline' && (
          <div className="space-y-1">
            {flow.nodes.map((n, i) => <PipeNode key={n.id} node={n} index={i} />)}
          </div>
        )}
        {subTab === 'parse' && flow.parseTree && <ParseView tree={flow.parseTree} />}
        {subTab === 'graph' && flow.graph && <GraphView graph={flow.graph} />}
        {subTab === 'triples' && <TriplesView />}
        {subTab === 'rules' && flow.rules && <RulesView rules={flow.rules} />}
      </div>
    </div>
  );
}

// ── GAME TAB ────────────────────────────────────────────────
function GameTab({ flow }: { flow: PipelineFlow }) {
  const [subTab, setSubTab] = useState<'preview' | 'spec' | 'code'>('preview');
  const artifact = flow.artifact;

  if (artifact.type !== 'game') {
    return <div className="px-4 py-8 text-center text-white/30 text-xs">No game generated. Try: &quot;Build a detective game&quot;</div>;
  }

  const spec = artifact.spec as any;
  const html = artifact.previewHTML || '';

  return (
    <div className="h-full flex flex-col">
      <div className="flex gap-1 px-4 pt-3 pb-2 border-b border-white/5">
        {(['preview', 'spec', 'code'] as const).map(t => (
          <button key={t} onClick={() => setSubTab(t)} className={`text-[10px] px-2 py-1 rounded ${subTab === t ? 'bg-white/10 text-white/70' : 'text-white/30'}`}>{t.toUpperCase()}</button>
        ))}
      </div>
      <div className="flex-1 overflow-y-auto">
        {subTab === 'preview' && (
          <div className="p-2">
            <iframe srcDoc={html} className="w-full h-[400px] rounded-lg border border-white/10 bg-[#0a0a0f]" sandbox="allow-scripts" title="Game Preview" />
          </div>
        )}
        {subTab === 'spec' && spec && (
          <div className="px-4 py-3 space-y-3">
            <div><span className="text-[10px] text-white/30">TITLE</span><div className="text-sm text-purple-400 font-bold">{spec.title}</div></div>
            <div><span className="text-[10px] text-white/30">GENRE</span><div className="text-xs text-white/60">{spec.genre}</div></div>
            <div><span className="text-[10px] text-white/30">WIN CONDITION</span><div className="text-xs text-white/60">{spec.winCondition}</div></div>
            <div><span className="text-[10px] text-white/30">CONTROLS</span><div className="text-xs text-white/60">{spec.controls?.join(', ')}</div></div>
            <div><span className="text-[10px] text-white/30">OBJECTIVES</span>{spec.objectives?.map((o: string, i: number) => <div key={i} className="text-xs text-white/60 pl-2 border-l border-white/10">{o}</div>)}</div>
            <div><span className="text-[10px] text-white/30">ENTITIES ({spec.entities?.length})</span>
              {spec.entities?.map((e: any, i: number) => (
                <div key={i} className="flex items-center gap-2 text-[10px] py-0.5">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: e.color }} />
                  <span className="text-white/50">{e.type}</span>
                  <span className="text-white/30">{e.behavior}</span>
                </div>
              ))}
            </div>
          </div>
        )}
        {subTab === 'code' && (
          <pre className="px-4 py-3 text-[10px] text-green-400/70 font-mono overflow-x-auto whitespace-pre">{html.substring(0, 3000)}{html.length > 3000 ? '\n...' : ''}</pre>
        )}
      </div>
    </div>
  );
}

// ── APP TAB ─────────────────────────────────────────────────
function AppTab({ flow }: { flow: PipelineFlow }) {
  const [subTab, setSubTab] = useState<'preview' | 'spec' | 'files'>('preview');
  const artifact = flow.artifact;

  if (artifact.type !== 'app') {
    return <div className="px-4 py-8 text-center text-white/30 text-xs">No app generated. Try: &quot;Build a task tracking app&quot;</div>;
  }

  const spec = artifact.spec as any;
  const files = artifact.rendered as Record<string, string> || {};
  const preview = artifact.previewHTML || '';

  return (
    <div className="h-full flex flex-col">
      <div className="flex gap-1 px-4 pt-3 pb-2 border-b border-white/5">
        {(['preview', 'spec', 'files'] as const).map(t => (
          <button key={t} onClick={() => setSubTab(t)} className={`text-[10px] px-2 py-1 rounded ${subTab === t ? 'bg-white/10 text-white/70' : 'text-white/30'}`}>{t.toUpperCase()}</button>
        ))}
      </div>
      <div className="flex-1 overflow-y-auto">
        {subTab === 'preview' && (
          <div className="p-2">
            <iframe srcDoc={preview} className="w-full h-[400px] rounded-lg border border-white/10 bg-[#0a0a0f]" sandbox="allow-scripts" title="App Preview" />
          </div>
        )}
        {subTab === 'spec' && spec && (
          <div className="px-4 py-3 space-y-3">
            <div><span className="text-[10px] text-white/30">NAME</span><div className="text-sm text-blue-400 font-bold">{spec.name}</div></div>
            <div><span className="text-[10px] text-white/30">PURPOSE</span><div className="text-xs text-white/60">{spec.purpose}</div></div>
            <div><span className="text-[10px] text-white/30">SCREENS ({spec.screens?.length})</span>
              {spec.screens?.map((s: any, i: number) => (
                <div key={i} className="text-[10px] text-white/50 pl-2 border-l border-white/10 py-0.5">
                  <span className="text-blue-400">{s.route}</span> → {s.name}
                </div>
              ))}
            </div>
            <div><span className="text-[10px] text-white/30">COMPONENTS ({spec.components?.length})</span>
              {spec.components?.map((c: any, i: number) => (
                <div key={i} className="text-[10px] text-white/40 pl-2 border-l border-white/10 py-0.5">
                  {c.name} <span className="text-white/20">({c.type})</span>
                </div>
              ))}
            </div>
            <div><span className="text-[10px] text-white/30">DATA MODEL</span>
              {spec.dataModel?.map((m: any, i: number) => (
                <div key={i} className="text-[10px] text-white/40 pl-2 py-0.5">
                  <span className="text-amber-400">{m.name}</span>: {m.fields.join(', ')}
                </div>
              ))}
            </div>
          </div>
        )}
        {subTab === 'files' && (
          <div className="px-4 py-3 space-y-2">
            {Object.entries(files).map(([name, content]) => (
              <details key={name} className="bg-white/3 rounded border border-white/5">
                <summary className="px-3 py-2 text-[10px] text-white/60 cursor-pointer hover:text-white/80">{name}</summary>
                <pre className="px-3 py-2 text-[9px] text-green-400/60 font-mono overflow-x-auto whitespace-pre border-t border-white/5">{content.substring(0, 1500)}{content.length > 1500 ? '\n...' : ''}</pre>
              </details>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ── VIDEO TAB ───────────────────────────────────────────────
function VideoTab({ flow }: { flow: PipelineFlow }) {
  const [subTab, setSubTab] = useState<'preview' | 'storyboard' | 'script'>('preview');
  const artifact = flow.artifact;

  if (artifact.type !== 'video') {
    return <div className="px-4 py-8 text-center text-white/30 text-xs">No video generated. Try: &quot;Create a noir video storyboard&quot;</div>;
  }

  const spec = artifact.spec as any;
  const html = artifact.previewHTML || '';

  return (
    <div className="h-full flex flex-col">
      <div className="flex gap-1 px-4 pt-3 pb-2 border-b border-white/5">
        {(['preview', 'storyboard', 'script'] as const).map(t => (
          <button key={t} onClick={() => setSubTab(t)} className={`text-[10px] px-2 py-1 rounded ${subTab === t ? 'bg-white/10 text-white/70' : 'text-white/30'}`}>{t.toUpperCase()}</button>
        ))}
      </div>
      <div className="flex-1 overflow-y-auto">
        {subTab === 'preview' && (
          <div className="p-2">
            <iframe srcDoc={html} className="w-full h-[400px] rounded-lg border border-white/10 bg-[#0a0a0f]" sandbox="allow-scripts" title="Video Preview" />
          </div>
        )}
        {subTab === 'storyboard' && spec && (
          <div className="px-4 py-3 space-y-2">
            {spec.scenes?.map((s: any, i: number) => (
              <div key={i} className="bg-white/3 rounded p-3 border border-white/5">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[10px] text-pink-400 font-bold">SCENE {i + 1}</span>
                  <span className="text-[9px] text-white/30 uppercase">{s.type}</span>
                  <span className="text-[9px] text-white/20 ml-auto">{s.duration}ms</span>
                </div>
                <div className="text-[10px] text-white/50 mb-1">{s.setting} | {s.action}</div>
                <div className="flex gap-2 flex-wrap">
                  {s.visualElements?.map((e: any, j: number) => (
                    <span key={j} className="text-[9px] px-1.5 py-0.5 rounded" style={{ backgroundColor: `${e.color}20`, color: e.color, border: `1px solid ${e.color}40` }}>
                      {e.type}: {e.label}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
        {subTab === 'script' && spec && (
          <div className="px-4 py-3 space-y-3">
            <div><span className="text-[10px] text-white/30">TITLE</span><div className="text-sm text-pink-400 font-bold">{spec.title}</div></div>
            <div><span className="text-[10px] text-white/30">NARRATION</span>
              {spec.narration?.map((n: string, i: number) => <div key={i} className="text-xs text-white/60 pl-2 border-l border-pink-400/20 py-0.5">{n}</div>)}
            </div>
            <div><span className="text-[10px] text-white/30">CAPTIONS</span>
              {spec.captions?.map((c: string, i: number) => <div key={i} className="text-[10px] text-white/40 pl-2 py-0.5">{c}</div>)}
            </div>
            <div><span className="text-[10px] text-white/30">CAMERA MOVES</span>
              {spec.cameraMoves?.map((m: any, i: number) => (
                <div key={i} className="text-[10px] text-white/40 pl-2 py-0.5">{m.type} → {m.target} ({m.duration}ms)</div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── SHARED COMPONENTS ───────────────────────────────────────

function PipeNode({ node, index }: { node: PipelineNode; index: number }) {
  const complete = node.status === 'complete';
  const sys = SYSTEMS.find(s => s.id === node.systemId);
  const color = sys?.color || '#6b7280';
  return (
    <div className={`relative pl-4 transition-all ${complete ? 'opacity-100' : 'opacity-40'}`}>
      {index > 0 && <div className="absolute left-[5px] top-[-4px] w-px h-[4px] bg-white/10" />}
      <div className="absolute left-0 top-1.5 w-[11px] h-[11px] rounded-full border-2" style={{ borderColor: color, backgroundColor: complete ? color : 'transparent' }} />
      <div className="ml-2 text-[10px]">
        <span style={{ color }} className="font-bold">{node.label}</span>
        <span className="text-white/20 ml-1">{node.description}</span>
      </div>
    </div>
  );
}

function ParseView({ tree }: { tree: import('@/types').ParseTree }) {
  return (
    <div className="space-y-3">
      <div><span className="text-[10px] text-white/30">TOKENS</span><div className="flex flex-wrap gap-1 mt-1">
        {tree.tokens.slice(0, 25).map((t, i) => <span key={i} className="bg-white/5 rounded px-1 text-[9px]"><span className="text-white/60">{t.text}</span><span className="text-violet-400 ml-0.5">{t.pos}</span></span>)}
      </div></div>
      <div><span className="text-[10px] text-white/30">DEPS</span><div className="space-y-0.5 mt-1">
        {tree.dependencies.slice(0, 8).map((d, i) => <div key={i} className="text-[9px]"><span className="text-white/40">{tree.tokens[d.governor]?.text}</span><span className="text-cyan-400/60 mx-1">→{d.relation}→</span><span className="text-white/40">{tree.tokens[d.dependent]?.text}</span></div>)}
      </div></div>
      {tree.entities.length > 0 && <div><span className="text-[10px] text-white/30">ENTITIES</span><div className="mt-1">
        {tree.entities.map((e, i) => <span key={i} className="text-[9px] text-amber-400 bg-amber-400/10 rounded px-1.5 py-0.5 mr-1">{e.text}</span>)}
      </div></div>}
    </div>
  );
}

function GraphView({ graph }: { graph: { nodes: SGNode[]; edges: SGEdge[] } }) {
  return (
    <div className="space-y-3">
      <div><span className="text-[10px] text-white/30">NODES ({graph.nodes.length})</span><div className="space-y-0.5 mt-1 max-h-[150px] overflow-y-auto">
        {graph.nodes.slice(-15).map(n => (
          <div key={n.id} className="flex items-center gap-1.5 text-[9px]">
            <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: n.type === 'entity' ? '#f59e0b' : n.type === 'action' ? '#22c55e' : n.type === 'concept' ? '#a855f7' : '#6b7280' }} />
            <span className="text-white/50">{n.label}</span><span className="text-white/20">{n.type}</span>
          </div>
        ))}
      </div></div>
      <div><span className="text-[10px] text-white/30">EDGES ({graph.edges.length})</span><div className="space-y-0.5 mt-1 max-h-[120px] overflow-y-auto">
        {graph.edges.slice(-10).map(e => {
          const from = graph.nodes.find(n => n.id === e.from);
          const to = graph.nodes.find(n => n.id === e.to);
          return <div key={e.id} className="text-[9px] flex items-center gap-1"><span className="text-white/40">{from?.label || '?'}</span><span className="text-cyan-400/40">→{e.relation}→</span><span className="text-white/40">{to?.label || '?'}</span><span className="text-white/15 ml-auto">{(e.confidence * 100).toFixed(0)}%</span></div>;
        })}
      </div></div>
    </div>
  );
}

function RulesView({ rules }: { rules: Rule[] }) {
  return (
    <div className="space-y-1">
      {rules.slice(0, 15).map(r => (
        <div key={r.id} className="bg-white/3 rounded px-2 py-1 text-[9px]">
          <div className="flex items-center gap-2"><span className="text-pink-400 font-bold">{r.type}</span><span className="text-white/50">{r.name}</span><span className="text-white/15 ml-auto">w{r.weight.toFixed(2)}</span></div>
          <div className="text-white/30">{r.lhs} → {r.rhs}</div>
        </div>
      ))}
    </div>
  );
}

// ── MESSY TRIPLES VIEW ──────────────────────────────────────
// Displays the semantic triple network with reality values,
// expression lists, and behavioral rules. This is the MESSY
// network inspector.
function TriplesView() {
  const [snap, setSnap] = useState(tripleStore.getSnapshot());
  const [filter, setFilter] = useState<'all' | 'triples' | 'rules' | 'classes'>('all');

  useEffect(() => {
    const iv = setInterval(() => setSnap(tripleStore.getSnapshot()), 1000);
    return () => clearInterval(iv);
  }, []);

  return (
    <div className="space-y-3">
      {/* Stats */}
      <div className="flex gap-3 text-[9px]">
        <span className="text-white/30">NODES: <span className="text-amber-400">{snap.nodes.length}</span></span>
        <span className="text-white/30">TRIPLES: <span className="text-cyan-400">{snap.triples.length}</span></span>
        <span className="text-white/30">RULES: <span className="text-pink-400">{snap.rules.length}</span></span>
        <span className="text-white/30">CLASSES: <span className="text-emerald-400">{snap.classes.length}</span></span>
        <span className="text-white/30">TICK: <span className="text-purple-400">{snap.tick}</span></span>
      </div>

      {/* Filter */}
      <div className="flex gap-1">
        {(['all', 'triples', 'rules', 'classes'] as const).map(f => (
          <button key={f} onClick={() => setFilter(f)} className={`text-[9px] px-2 py-0.5 rounded ${filter === f ? 'bg-white/10 text-white/60' : 'text-white/20'}`}>{f}</button>
        ))}
      </div>

      {/* Triples */}
      {(filter === 'all' || filter === 'triples') && (
        <div>
          <span className="text-[10px] text-white/30">SEMANTIC TRIPLES</span>
          <div className="space-y-0.5 mt-1 max-h-[180px] overflow-y-auto">
            {snap.triples.slice(-15).map(t => (
              <div key={t.id} className="text-[9px] flex items-center gap-1.5">
                <span className="text-white/50">{t.subject}</span>
                <span className="text-cyan-400/50">—{t.relation}→</span>
                <span className="text-white/50">{t.object}</span>
                <span className={`ml-auto ${t.rv > 0 ? 'text-emerald-400/60' : t.rv < 0 ? 'text-red-400/60' : 'text-white/20'}`}>RV:{t.rv.toFixed(1)}</span>
                {t.h > 0 && <span className="text-amber-400/40">H:{t.h}</span>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Behavioral Rules */}
      {(filter === 'all' || filter === 'rules') && (
        <div>
          <span className="text-[10px] text-white/30">BEHAVIORAL RULES</span>
          <div className="space-y-1 mt-1 max-h-[120px] overflow-y-auto">
            {snap.rules.map(r => (
              <div key={r.id} className="bg-white/3 rounded px-2 py-1 text-[9px]">
                <div className="flex items-center gap-2">
                  <span className="text-pink-400 font-bold">{r.group}</span>
                  <span className="text-white/50">{r.name}</span>
                  <span className="text-white/15 ml-auto">p{r.probability}% w{r.weight.toFixed(2)}</span>
                </div>
                <div className="text-white/20">
                  IF {r.conditions.map(c => c.type).join(' + ')} → {r.actions.map(a => a.type).join(', ')}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Classes */}
      {(filter === 'all' || filter === 'classes') && (
        <div>
          <span className="text-[10px] text-white/30">CLASSES</span>
          <div className="space-y-0.5 mt-1">
            {snap.classes.map(c => (
              <div key={c.name} className="text-[9px]">
                <span className="text-emerald-400">{c.name}</span>
                <span className="text-white/30"> = {c.members.join(', ')}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
