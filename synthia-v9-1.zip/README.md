# Synthia v9 — Generative Social Universe

> A social network where every person is a living attractor in a shared semantic field.

## What This Is

Synthia v9 is a **social media platform** + **self-cultivation system** + **generative universe**.

Instead of:
- Chronological feeds → You get **resonance-ordered** content based on manifold proximity
- Private journaling → Your **growth is visible and witnessed** by others
- Static profiles → Your **attractor evolves** as you interact and cultivate
- Isolated apps → Everything is **one shared semantic graph**

## The Architecture

```
┌─────────────────────────────────────────────┐
│  UI (Phone-first)                           │
│  Universe view + Feed + Cultivation path    │
├─────────────────────────────────────────────┤
│  Generative Universe                        │
│  3D visualization of the collective field   │
│  Terrain = manifold curvature               │
│  Entities = people + posts                  │
│  Weather = field turbulence                 │
├─────────────────────────────────────────────┤
│  Social Feed Engine                         │
│  Resonance-ordered (not chronological)      │
│  Modes: resonance / growth / discovery      │
│  Actions: resonate / echo / reply / witness │
├─────────────────────────────────────────────┤
│  Cultivation Engine                         │
│  Growth paths per gate                      │
│  Insights with evidence chains              │
│  Practices with streaks                      │
│  Breakthroughs as field events              │
├─────────────────────────────────────────────┤
│  Resonance Graph (Shared)                   │
│  People = attractors with HD profiles       │
│  Posts = semantic triples with gate tags      │
│  Interactions = field perturbations         │
│  Cultivations = growth events               │
│  Manifold = M(x) = Σ gᵢ/(1+|x-aᵢ|)         │
└─────────────────────────────────────────────┘
```

## Key Concepts

### Resonance Feed
Not "what's new" but "what's close to your attractor in the manifold." Posts from people with similar gate configurations appear first. Discovery mode shows distant attractors.

### Cultivation as Social
Your growth path is not private. Others witness your insights, which strengthens their resonance. Your breakthroughs become attractors for people on similar paths.

### The Universe as Mirror
The 3D world is not a game. It's a living visualization of the collective field. You see:
- Where you are in the manifold
- Who you're close to
- Where the field is turbulent (high activity)
- Where new growth is happening

### Interactions as Field Events
- **Resonate**: Pulls your attractor closer to theirs
- **Echo**: Amplifies a post's resonance in the field
- **Reply**: Creates a new entity connected to the original
- **Witness**: Lighter touch — "I see you" without shifting the field
- **Connect**: Direct person-to-person attraction

## Files

| File | Purpose |
|------|---------|
| `core/resonance-graph.ts` | The shared semantic graph |
| `social/feed-engine.ts` | Resonance-ordered feed |
| `cultivation/growth-path.ts` | Self-cultivation system |
| `universe/generator.ts` | 3D generative universe |
| `ui/app.html` | Phone-first interface |
| `runtime.ts` | Single orchestrator |

## Usage

```typescript
import { SynthiaRuntime } from './runtime';

const synthia = new SynthiaRuntime();
await synthia.start();

// Register yourself
const me = synthia.registerPerson({
  id: 'me',
  name: 'You',
  handle: '@you',
  definedGates: [1, 8, 14],
  definedChannels: [1],
  hdType: 'Generator',
  authority: 'Sacral',
  strategy: 'Respond'
});

// Create a post
synthia.createPost('me', 'Noticing the impulse before acting...', 'reflection', [1, 8]);

// Get your resonance feed
const feed = synthia.getFeed('me', 'resonance');

// Start a cultivation path
synthia.createPath('me', 1);

// Record an insight
synthia.recordInsight('me', 1, 'The impulse is not the action', ['post_123']);

// See the universe
const view = synthia.getUniverseView();
```

## The Vision

This is not a social network. It is a **living field** where:
- Every person is an attractor with gravitational pull
- Every post is a particle that rises and fades
- Every interaction reshapes the manifold
- Every cultivation is witnessed and amplified
- The universe grows more complex as more people join

The more authentic you are, the stronger your attractor. The more you cultivate, the higher you rise in the field. The more you resonate with others, the closer your attractors pull.

This is social media as **ecology**, not **economy**.
