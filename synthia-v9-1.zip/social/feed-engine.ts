// ============================================
// SOCIAL FEED ENGINE
# Not chronological. Not algorithmic. Resonance-ordered.
# What you see is what the manifold brings to your attractor.
# ============================================

import { ResonanceGraph, Post, Person, Interaction } from '../core/resonance-graph';

export interface FeedItem {
  post: Post;
  score: number;
  reason: string;           // Why this appeared in your feed
  resonancePath: string[];  // The chain of connections that brought this
}

export interface FeedContext {
  personId: string;
  mode: 'resonance' | 'growth' | 'discovery' | 'cultivation';
  timeRange: number;        // How far back to look (ms)
  diversityBoost: number;  // 0-1, how much to favor unfamiliar voices
}

export class FeedEngine {
  private graph: ResonanceGraph;

  constructor(graph: ResonanceGraph) {
    this.graph = graph;
  }

  generateFeed(context: FeedContext): FeedItem[] {
    const person = this.graph.people.get(context.personId);
    if (!person) return [];

    const allPosts = Array.from(this.graph.posts.values())
      .filter(p => p.timestamp > Date.now() - context.timeRange);

    const scored = allPosts.map(post => {
      const { score, reason, path } = this.scorePost(post, person, context);
      return { post, score, reason, resonancePath: path };
    });

    return scored
      .sort((a, b) => b.score - a.score)
      .slice(0, 50);
  }

  private scorePost(post: Post, viewer: Person, context: FeedContext): { score: number; reason: string; path: string[] } {
    const postPos = this.graph['postPosition'](post);
    const dist = this.graph['euclideanDistance'](viewer.attractorPosition, postPos);

    let score = 0;
    let reason = '';
    const path: string[] = [];

    switch (context.mode) {
      case 'resonance':
        // Posts close to your attractor in the manifold
        score = (1 / (1 + dist * 5)) * 0.6 + post.resonance * 0.4;
        reason = dist < 0.3 ? 'Close resonance' : 'Field proximity';
        path.push('your-attractor', 'manifold-proximity');
        break;

      case 'growth':
        // Posts that challenge or expand your current position
        score = dist * 0.5 + post.resonance * 0.3;
        if (post.type === 'reflection' || post.type === 'question') score += 0.2;
        reason = 'Growth opportunity';
        path.push('your-attractor', 'expansion-zone');
        break;

      case 'discovery':
        // Posts from distant attractors — new territory
        score = dist * 0.7 + post.resonance * 0.2;
        score += context.diversityBoost * 0.1;
        reason = 'New resonance';
        path.push('distant-attractor', 'discovery-path');
        break;

      case 'cultivation':
        // Posts related to your cultivation path
        const cultivations = this.graph.getCultivationPath(viewer.id);
        const relevantGates = new Set(cultivations.map(c => c.gate));
        const overlap = post.gateResonance.filter(g => relevantGates.has(g)).length;
        score = (overlap / Math.max(1, post.gateResonance.length)) * 0.5 + post.resonance * 0.3 + (1 / (1 + dist)) * 0.2;
        reason = overlap > 0 ? 'Cultivation resonance' : 'Field alignment';
        path.push('cultivation-path', 'gate-alignment');
        break;
    }

    // Boost for posts from people you resonate with
    const author = this.graph.people.get(post.authorId);
    if (author) {
      const authorDist = this.graph['euclideanDistance'](viewer.attractorPosition, author.attractorPosition);
      if (authorDist < 0.3) score += 0.15;
    }

    return { score, reason, path };
  }

  // === SOCIAL ACTIONS ===

  resonate(personId: string, postId: string): Interaction {
    return this.graph.interact({
      fromId: personId,
      toId: postId,
      type: 'resonated',
      strength: 0.5,
      dimensionalTag: 2
    });
  }

  echo(personId: string, postId: string): Interaction {
    const post = this.graph.posts.get(postId);
    if (post) {
      post.echoes.push(`echo_${Date.now()}`);
    }

    return this.graph.interact({
      fromId: personId,
      toId: postId,
      type: 'echoed',
      strength: 0.8,
      dimensionalTag: 2
    });
  }

  reply(personId: string, postId: string, content: string): { interaction: Interaction; replyPost: Post } {
    const original = this.graph.posts.get(postId);
    if (!original) throw new Error('Post not found');

    // Create reply as a new post
    const replyPost = this.graph.createPost({
      authorId: personId,
      content,
      type: 'thought',
      gateResonance: original.gateResonance,
      dimensionalTag: 3
    });

    original.replies.push(replyPost.id);

    const interaction = this.graph.interact({
      fromId: personId,
      toId: postId,
      type: 'replied',
      strength: 0.6,
      dimensionalTag: 3
    });

    return { interaction, replyPost };
  }

  witness(personId: string, postId: string): Interaction {
    // Witnessing is a lighter interaction — "I see you"
    return this.graph.interact({
      fromId: personId,
      toId: postId,
      type: 'witnessed',
      strength: 0.2,
      dimensionalTag: 3
    });
  }

  connect(personId: string, otherPersonId: string): Interaction {
    // Direct person-to-person connection
    const person = this.graph.people.get(personId);
    const other = this.graph.people.get(otherPersonId);
    if (!person || !other) throw new Error('Person not found');

    // Pull attractors closer
    this.graph['pullAttractors'](person, other, 0.05);

    return this.graph.interact({
      fromId: personId,
      toId: otherPersonId,
      type: 'connected',
      strength: 0.7,
      dimensionalTag: 2
    });
  }

  // === NOTIFICATIONS ===

  getNotifications(personId: string): Array<{ type: string; from: string; content: string; timestamp: number }> {
    const notifications: Array<{ type: string; from: string; content: string; timestamp: number }> = [];

    // Replies to your posts
    for (const post of this.graph.posts.values()) {
      if (post.authorId === personId) {
        for (const replyId of post.replies) {
          const reply = this.graph.posts.get(replyId);
          if (reply) {
            notifications.push({
              type: 'reply',
              from: reply.authorId,
              content: reply.content.substring(0, 100),
              timestamp: reply.timestamp
            });
          }
        }

        for (const echoId of post.echoes) {
          notifications.push({
            type: 'echo',
            from: 'someone',
            content: `Echoed: ${post.content.substring(0, 50)}...`,
            timestamp: post.timestamp
          });
        }
      }
    }

    // Resonances on your posts
    for (const interaction of this.graph.interactions.values()) {
      if (interaction.toId === personId && interaction.type === 'resonated') {
        notifications.push({
          type: 'resonance',
          from: interaction.fromId,
          content: 'resonated with you',
          timestamp: interaction.timestamp
        });
      }
    }

    return notifications.sort((a, b) => b.timestamp - a.timestamp).slice(0, 20);
  }
}

export { FeedEngine };
