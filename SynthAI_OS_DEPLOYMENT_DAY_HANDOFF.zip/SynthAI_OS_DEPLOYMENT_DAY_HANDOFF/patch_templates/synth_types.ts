export type SynthFileKind =
  | 'text' | 'code' | 'json' | 'markdown' | 'html' | 'css'
  | 'image' | 'audio' | 'video' | 'pdf' | 'document' | 'spreadsheet'
  | 'archive' | 'binary' | 'unknown';

export interface SynthRelationship {
  type: 'imports' | 'links_to' | 'contains' | 'depends_on' | 'declares' | 'references' | 'generated_from' | 'patches';
  target: string;
  confidence: number;
}

export interface SynthFileRecord {
  id: string;
  originalName: string;
  path: string;
  size: number;
  mime?: string;
  extension?: string;
  kind: SynthFileKind;
  sha256?: string;
  createdAt: string;
  updatedAt: string;
  source: 'upload' | 'zip-child' | 'generated' | 'patched' | 'mounted-app';
  parentArchiveId?: string;
  originalBlobKey: string;
  textKey?: string;
  metadata: Record<string, unknown>;
  relationships: SynthRelationship[];
  status: 'stored' | 'parsed' | 'indexed' | 'repair-needed' | 'mountable' | 'mounted' | 'unsupported';
  safety: {
    originalPreserved: true;
    editable: boolean;
    executable: boolean;
    reason?: string;
  };
}

export interface RepairPlan {
  id: string;
  targetFileIds: string[];
  summary: string;
  severity: 'info' | 'warning' | 'error';
  canAutoApply: boolean;
  steps: RepairStep[];
}

export interface RepairStep {
  action: 'create-file' | 'edit-file' | 'rename-file' | 'install-dependency' | 'mark-unsupported' | 'mount-app';
  targetPath: string;
  reason: string;
  before?: string;
  after?: string;
}

export interface MountedSynthApp {
  id: string;
  title: string;
  sourceFileIds: string[];
  entryType: 'html' | 'react-component' | 'vite-project' | 'dist-bundle' | 'external-service';
  entryPath: string;
  status: 'mountable' | 'mounted' | 'needs-build' | 'blocked';
  reason?: string;
  permissions: {
    canReadOwnFiles: boolean;
    canWriteOwnFiles: boolean;
    canUseNetwork: boolean;
    canUseMcp: boolean;
  };
}
