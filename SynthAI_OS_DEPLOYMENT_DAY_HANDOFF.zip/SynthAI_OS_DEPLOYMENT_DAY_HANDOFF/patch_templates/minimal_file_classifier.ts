import type { SynthFileKind } from './synth_types';

export function classifyFile(name: string, mime = ''): SynthFileKind {
  const ext = name.split('.').pop()?.toLowerCase() ?? '';
  if (['txt'].includes(ext)) return 'text';
  if (['js', 'jsx', 'ts', 'tsx', 'py', 'sh', 'css'].includes(ext)) return ext === 'css' ? 'css' : 'code';
  if (ext === 'json') return 'json';
  if (['md', 'markdown'].includes(ext)) return 'markdown';
  if (['html', 'htm'].includes(ext)) return 'html';
  if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'].includes(ext) || mime.startsWith('image/')) return 'image';
  if (['mp3', 'wav', 'ogg', 'm4a'].includes(ext) || mime.startsWith('audio/')) return 'audio';
  if (['mp4', 'webm', 'mov'].includes(ext) || mime.startsWith('video/')) return 'video';
  if (ext === 'pdf' || mime === 'application/pdf') return 'pdf';
  if (['doc', 'docx', 'odt'].includes(ext)) return 'document';
  if (['xls', 'xlsx', 'csv'].includes(ext)) return 'spreadsheet';
  if (['zip', 'tar', 'gz', '7z'].includes(ext) || mime.includes('zip')) return 'archive';
  if (mime && !mime.startsWith('text/')) return 'binary';
  return 'unknown';
}

export function isEditableKind(kind: SynthFileKind): boolean {
  return ['text', 'code', 'json', 'markdown', 'html', 'css'].includes(kind);
}
