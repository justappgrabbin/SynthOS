import type { SynthFileRecord, MountedSynthApp } from './synth_types';

export function detectMountableApp(records: SynthFileRecord[], title = 'Uploaded App'): MountedSynthApp | null {
  const byPath = new Map(records.map(r => [r.path.toLowerCase(), r]));
  const hasIndex = [...byPath.keys()].some(p => p.endsWith('/index.html') || p === 'index.html');
  const hasPackage = [...byPath.keys()].some(p => p.endsWith('/package.json') || p === 'package.json');
  const hasReactEntry = [...byPath.keys()].some(p => /src\/(main|app)\.(tsx|jsx|ts|js)$/.test(p));
  const hasDist = [...byPath.keys()].some(p => p.endsWith('/dist/index.html') || p === 'dist/index.html');

  if (hasDist) {
    const entry = records.find(r => r.path.toLowerCase().endsWith('dist/index.html'))!;
    return basicApp(title, records, 'dist-bundle', entry.path, 'mountable');
  }

  if (hasIndex && !hasPackage) {
    const entry = records.find(r => r.path.toLowerCase().endsWith('index.html'))!;
    return basicApp(title, records, 'html', entry.path, 'mountable');
  }

  if (hasPackage && hasReactEntry) {
    const entry = records.find(r => /src\/(main|app)\.(tsx|jsx|ts|js)$/i.test(r.path))!;
    return basicApp(title, records, 'vite-project', entry.path, 'needs-build');
  }

  return null;
}

function basicApp(
  title: string,
  records: SynthFileRecord[],
  entryType: MountedSynthApp['entryType'],
  entryPath: string,
  status: MountedSynthApp['status']
): MountedSynthApp {
  return {
    id: crypto.randomUUID(),
    title,
    sourceFileIds: records.map(r => r.id),
    entryType,
    entryPath,
    status,
    permissions: {
      canReadOwnFiles: true,
      canWriteOwnFiles: false,
      canUseNetwork: false,
      canUseMcp: false
    }
  };
}
