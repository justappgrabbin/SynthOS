# Final Architecture

```text
SynthAI OS
├── Interface Layer
│   ├── OS shell
│   ├── window manager
│   ├── dock/app tray
│   ├── library
│   ├── terminal
│   ├── ingest panel
│   └── settings
│
├── File Metabolism Layer
│   ├── upload manager
│   ├── original-byte vault
│   ├── ZIP unpacker
│   ├── text/code reader
│   ├── binary preserver
│   ├── classifier
│   ├── dependency mapper
│   ├── editor/patch manager
│   └── runnable-app mounter
│
├── Runtime Layer
│   ├── message bus
│   ├── graph runtime
│   ├── substrate64
│   ├── memory fabric
│   ├── intent compiler
│   └── safe execution bridge
│
├── Intelligence Layer
│   ├── self-correction engine
│   ├── unknown handler
│   ├── confidence tracker
│   ├── autoling orchestrator
│   ├── self-teaching loop
│   └── optional Python brain service
│
└── Persistence Layer
    ├── IndexedDB/local-first store
    ├── file manifest
    ├── vector/RAG index
    ├── graph index
    └── optional Supabase sync later
```

## Deployment-day rule
Build local-first first. Supabase/server/Python are optional add-ons after the OS can ingest, preserve, index, edit, repair, and mount locally.
