# Do Not Do

- Do not start a new app.
- Do not make the pipeline builder the root.
- Do not make the resonance desktop the root.
- Do not make the astrology app the root.
- Do not add another fake consciousness dashboard instead of ingestion.
- Do not require paid APIs.
- Do not require Supabase just to boot.
- Do not delete files.
- Do not overwrite originals.
- Do not claim every upload is executable.
- Do not run arbitrary uploaded code with full privileges.
- Do not import `.git`, `node_modules`, `dist` as source unless specifically needed.
- Do not merge duplicate UI kits if the app already builds.
- Do not add features before upload/library/editor/repair/mount works.
