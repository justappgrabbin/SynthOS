# Agent Prompt — Copy This

You are merging the user's uploaded SynthAI/Synthia projects into one working application-level OS. Do not create a new product. Do not make a new dashboard. Use the existing OS base and add only necessary missing components.

## Root project
Use `SynthAi-OS-v1.0-SelfCorrecting.zip` as the root/base app.

Keep its OS shell, self-correction architecture, mesh system, agents, autoling orchestrator, ingestion panel, terminal/settings panels, and Capacitor/APK setup.

## Merge sources
Integrate only necessary components from:

- `synthia-rooted-morph-engine-stealth-build-1.zip` for ingestion, morph engine, persistence, address space, MCP bridge
- `resonance-final-merged-deploy-ready.zip` for window manager, dock, app registry, app windows, library, terminal, builder, browser, mesh app
- `synthai_vector_rag_wired.zip` for memory/RAG concepts, not as root
- `autopoetic-resonance-engine.zip` for self-teaching/meta-learning and PDF ingest concepts
- `synthia-mesh-v2.1.zip` for mesh topology refinement
- `aion-substrate.zip` for substrate, file parser, Pyodide references only; do not convert to Next.js
- `syntia_build.zip` for graph runtime, memory fabric, intent compiler, ingest bridge, library store
- `cynthia_consciousness_system.zip` only as optional Python service after the web app works

## Required result
Implement the file metabolism loop:

upload file/folder/zip → preserve original bytes → unpack/read readable content → classify purpose/type → index metadata/text/relationships → display in Library → edit text/code safely → save patched copies → detect missing/broken parts → create repair plans → mount runnable apps/components into SynthAI OS → never delete or overwrite originals.

## Hard constraints
- Do not start over.
- Do not replace the root OS shell.
- Do not require paid APIs.
- Do not require Supabase for local use.
- Do not delete uploaded originals.
- Do not treat all files as executable.
- Do not execute unsafe arbitrary code.
- Keep it phone-first and Capacitor-compatible.
- Keep the build minimal and real.

## Required dependencies
Add only if missing:

```bash
npm install jszip idb nanoid mime-types
```

Optional later:

```bash
npm install @capacitor/filesystem
```

## Required folders
Create/adapt:

```text
src/os/ingestion
src/os/storage
src/os/morph
src/os/runtime
src/os/memory
src/os/apps
src/os/types
src/os/mesh
src/os/intelligence
src/os/bridges
src/os/address
src/ui/windows
src/ui/apps
src/ui/shell
```

## Minimum UI
The OS must expose:

- Ingest app/panel
- Library app/panel
- Editor for text/code files
- Mesh visualizer
- Terminal/log panel
- Settings panel
- App tray/window manager

## Done means
- `npm run dev` works
- upload works
- ZIP unpack works
- originals are preserved
- Library shows uploaded records
- text/code editing works as patched copy/version
- unsupported files remain stored with reason
- mountable apps are detected
- repair plans are generated for broken packages
- `npm run build` passes

Do the smallest necessary changes to make the above real. Do not add extra themes, lore, dashboards, or unrelated features.
