# Build Order — No Detours

## Phase 0 — Boot base
1. Unzip `SynthAi-OS-v1.0-SelfCorrecting.zip`.
2. Run:

```bash
npm install
npm run dev
```

3. Fix only boot/build errors.
4. Do not merge anything until the base loads.

## Phase 1 — Add dependencies
Install only what is necessary:

```bash
npm install jszip idb nanoid mime-types
```

Optional after core works:

```bash
npm install @capacitor/filesystem
```

Do not add heavy AI dependencies on day one.

## Phase 2 — Add file metabolism layer
Create these folders:

```text
src/os/ingestion/
src/os/storage/
src/os/morph/
src/os/runtime/
src/os/memory/
src/os/apps/
src/os/types/
src/os/mesh/
src/os/intelligence/
src/os/bridges/
src/os/address/
```

Then implement/import:

```text
FileVault
IngestionEngine
ZipIngestor
FileClassifier
DependencyMapper
PatchManager
AppMounter
LibraryStore
MessageBus
GraphRuntime
MemoryFabric
```

## Phase 3 — Wire UI
Update the OS shell so the user can access:

```text
Ingest
Library
Editor
Terminal
Mesh
Builder
Settings
```

Import selected windows from `resonance-final-merged-deploy-ready`, but keep `SynthAiOS.tsx` as root shell.

## Phase 4 — Upload behavior
Uploader must handle:

```text
single file
multiple files
folder/drop if browser supports it
zip archive
text/code
binary
image/media preview
```

Never discard original files.

## Phase 5 — Edit/repair behavior
For text/code:

```text
open file
edit file
save patched copy
preserve original
show diff summary
run self-correction checks
```

For unreadable/binary files:

```text
preserve original
classify type
store metadata
preview if supported
mark not text-editable
```

## Phase 6 — Mount runnable apps
A package can be mounted only if it has one of:

```text
index.html
package.json with scripts/build or scripts/dev
src/App.tsx or src/App.jsx
Vite/React app structure
standalone HTML app
```

If it is not runnable, show reason:

```text
Missing package.json
Missing entry point
Missing dependencies
Unsupported binary executable
Needs server not available locally
```

## Phase 7 — Test and build
Run:

```bash
npm run build
```

Then run manual acceptance tests in `tests/ACCEPTANCE_TESTS.md`.
