# Merge Map

## Root/base: keep from `SynthAi-OS-v1.0-SelfCorrecting.zip`

Keep these files as the root structure:

```text
src/App.tsx
src/main.tsx
src/index.css
src/ui/SynthAiOS.tsx
src/ui/store.ts
src/ui/components/IngestionPanel.tsx
src/ui/components/TerminalPanel.tsx
src/ui/components/MeshVisualizer.tsx
src/ui/components/SettingsPanel.tsx
src/ui/components/AgentPanel.tsx
src/ui/components/ConsciousnessField.tsx
src/core/SelfCorrectingEngine.ts
src/core/ConsciousnessEngine.ts
src/core/KnowledgePackManager.ts
src/core/ConfidenceTracker.ts
src/core/OverrideRegistry.ts
src/core/UnknownHandler.ts
src/mesh/MeshNetwork.ts
src/agents/AgentSystem.ts
src/autoling/AutolingOrchestrator.ts
capacitor.config.ts
.github/workflows/build-apk.yml
```

## Bring in from `synthia-rooted-morph-engine-stealth-build-1.zip`

Copy/adapt into the base project:

```text
src/core/addressSpace.ts              → src/os/address/addressSpace.ts
src/core/ingestion.ts                 → src/os/ingestion/source/rootedIngestion.ts
src/lib/morphEngine.ts                → src/os/morph/morphEngine.ts
src/lib/persistence.ts                → src/os/storage/persistence.ts
src/lib/departmentRouter.ts           → src/os/routing/departmentRouter.ts
src/lib/mcpBridge.ts                  → src/os/bridges/mcpBridge.ts
src/lib/types.ts                      → src/os/types/rootedTypes.ts
src/components/DropIngestor.tsx       → integrate into IngestionPanel, do not replace shell
src/components/MeshSurface.tsx        → optional visual source for MeshVisualizer
supabase/schema.sql                   → docs/schema/supabase-schema.sql only; do not require Supabase for local boot
server/mcp/trident_mcp_server.py      → optional later bridge, not needed for first web build
```

## Bring in from `resonance-final-merged-deploy-ready.zip`

Copy/adapt UI components, but do not replace the OS base:

```text
src/components/WindowManager.tsx      → src/ui/windows/WindowManager.tsx
src/components/Dock.tsx               → src/ui/shell/Dock.tsx
src/components/AppGrid.tsx            → src/ui/shell/AppGrid.tsx
src/components/Topbar.tsx             → src/ui/shell/Topbar.tsx
src/components/AppWindows/*.tsx       → src/ui/apps/*App.tsx
src/registry/appRegistry.ts           → src/os/apps/appRegistry.ts
src/store/useOSStore.ts               → adapt into src/ui/store.ts if useful
src/types/os.ts                       → src/os/types/os.ts
src/kernel/browserKernel.ts           → src/os/runtime/browserKernel.ts
src/kernel/phoneSession.ts            → src/os/runtime/phoneSession.ts
```

Required app windows to preserve:

```text
IngestApp
LibraryApp
TerminalApp
BuilderApp
BrowserApp
MeshApp
RagConsoleApp
SettingsApp
ChatApp
GameApp
AppStoreApp
AppCenterApp
```

## Bring in from `synthai_vector_rag_wired.zip`

Use ideas/service only, not as root:

```text
server.js                 → optional src/server/rag/server.js or docs/reference/rag-server.js
public/profile.json       → sample knowledge profile
knowledge/*.pdf           → test ingestion assets only
```

Implement local-first vector memory contract even if server is not enabled.

## Bring in from `autopoetic-resonance-engine.zip`

Copy/adapt engine pieces:

```text
src/engine/MetaLearningController.js  → src/os/intelligence/metaLearning.ts
src/engine/AutopoeticTriad.js         → src/os/intelligence/autopoeticTriad.ts
src/engine/AspirationCore.js          → src/os/intelligence/aspirationCore.ts
src/services/pdfIngestor.js           → src/os/ingestion/pdfIngestor.ts
src/components/LearningDashboard.jsx  → optional UI later, not day-one required
```

## Bring in from `synthia-mesh-v2.1.zip`

```text
three-level-mesh.ts       → src/os/mesh/threeLevelMesh.ts
README.md                 → docs/reference/synthia-mesh-v2.1.md
topology-diagram.html     → docs/reference/topology-diagram.html
```

## Bring in from `aion-substrate.zip`

Use as substrate reference/adapters:

```text
components/ingestion/FileIngestionEngine.tsx → source for ingestion UI/logic
components/mesh/MeshGraph.tsx                → mesh graph reference
components/pyodide/PyodideProvider.tsx       → optional browser Python bridge later
lib/pyodide/file_parser.py                   → optional parser reference
lib/pyodide/mesh_builder.py                  → optional mesh builder reference
lib/pyodide/autoling_core.py                 → optional autoling reference
```

Do not convert the whole app to Next.js. Keep the base Vite/Capacitor app.

## Bring in from `syntia_build.zip`

These are compact runtime primitives. Convert JS to TS where useful:

```text
graph_runtime.js      → src/os/runtime/graphRuntime.ts
memory_fabric.js      → src/os/memory/memoryFabric.ts
intent_compiler.js    → src/os/runtime/intentCompiler.ts
ingest_bridge.js      → src/os/ingestion/ingestBridge.ts
library_store.js      → src/os/storage/libraryStore.ts
substrate64_core.js   → src/os/runtime/substrate64.ts
cynthia_core.js       → src/os/intelligence/cynthiaCore.ts
```

## Optional later: `cynthia_consciousness_system.zip`

Do not block the web/Android app on Python. If included, put it behind an optional service boundary:

```text
python_service/cynthia/*
```

Expose only through a stable API:

```text
POST /api/brain/analyze
POST /api/brain/repair-plan
POST /api/brain/evolve-memory
```
