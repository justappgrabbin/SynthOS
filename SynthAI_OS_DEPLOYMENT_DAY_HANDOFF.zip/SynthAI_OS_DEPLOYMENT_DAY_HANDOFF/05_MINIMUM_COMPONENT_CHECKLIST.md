# Minimum Necessary Components Checklist

## Must exist in final app
- [ ] OS shell
- [ ] App tray/dock/window manager
- [ ] Ingestion panel
- [ ] Library panel
- [ ] Text/code editor
- [ ] Mesh viewer
- [ ] Terminal/log panel
- [ ] Settings panel
- [ ] Local file vault
- [ ] ZIP unpacker
- [ ] File classifier
- [ ] Metadata index
- [ ] Text index
- [ ] Relationship graph
- [ ] Patch/version manager
- [ ] Repair planner
- [ ] App mount detector
- [ ] Local-first memory/RAG placeholder
- [ ] Capacitor/APK setup preserved

## Can wait until after deployment-day build
- [ ] Full Supabase sync
- [ ] Python brain service
- [ ] Pyodide execution
- [ ] live MCP control
- [ ] full vector embeddings
- [ ] advanced PDF OCR
- [ ] game/video generation
- [ ] social network layer
