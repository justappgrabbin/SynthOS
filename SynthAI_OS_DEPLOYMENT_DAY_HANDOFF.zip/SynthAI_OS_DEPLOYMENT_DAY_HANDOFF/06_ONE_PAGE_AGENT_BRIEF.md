# One-Page Agent Brief

Build **SynthAI OS** by using `SynthAi-OS-v1.0-SelfCorrecting.zip` as the root and merging only the necessary missing organs.

The user needs a real upload-and-run environment, not another concept build.

## Build the loop

```text
upload → preserve → ingest → understand → edit → repair → mount → remember
```

## Root stays root
Use the self-correcting OS as root. Keep its shell, engines, mesh, agents, autoling, UI panels, and Capacitor/APK setup.

## Merge required organs
- Rooted morph engine: ingestion, persistence, address space, morph engine.
- Resonance final: windows, dock, app registry, library, terminal, builder, browser, mesh app.
- Syntia build: graph runtime, memory fabric, intent compiler, ingest bridge, library store.
- Vector RAG wired: memory/RAG contract.
- Autopoetic engine: self-teaching loop/PDF ingest idea.
- Mesh v2.1: topology refinement.

## First success condition
User can upload a ZIP of project files, see every file preserved in Library, open/edit code files, see what is broken or missing, and mount the package if it has a runnable entry point.

## No games
Do not make a new dashboard. Do not overbuild. Do not delete originals. Do not call it done unless `npm run build` passes.
