# App Mounting Contract

## Goal
Uploaded projects should appear in SynthAI OS as apps when they are mountable.

## Mountable types
A package is mountable when it is one of:

1. Standalone HTML app with `index.html`.
2. Vite/React app with `package.json`, `src/main.tsx` or `src/main.jsx`, and `src/App.tsx` or `src/App.jsx`.
3. Component module that exports a React component.
4. Static asset bundle with `dist/index.html`.

## Mounted app record

```ts
export interface MountedSynthApp {
  id: string;
  title: string;
  sourceFileIds: string[];
  entryType: 'html' | 'react-component' | 'vite-project' | 'dist-bundle' | 'external-service';
  entryPath: string;
  status: 'mountable' | 'mounted' | 'needs-build' | 'blocked';
  reason?: string;
  permissions: {
    canReadOwnFiles: boolean;
    canWriteOwnFiles: boolean;
    canUseNetwork: boolean;
    canUseMcp: boolean;
  };
}
```

## Safety
Do not run arbitrary JS with full access to the OS. Mount apps through controlled wrappers.

For deployment day:
- HTML apps can render in a sandboxed internal viewer.
- React components can be imported only if copied into source and compiled.
- Vite projects can be marked `needs-build` unless the agent actually wires them into the app registry.
