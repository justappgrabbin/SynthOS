# Self-Correction Contract

## Minimum behavior
The self-correction engine does not need to be magical. It must be practical.

For every ingested file/project, it should detect:

- missing `package.json`
- missing entry point
- broken imports
- missing dependencies
- TypeScript syntax errors when available
- empty placeholder files
- duplicate/conflicting modules
- unsupported file type

## Repair output

```ts
export interface RepairPlan {
  id: string;
  targetFileIds: string[];
  summary: string;
  severity: 'info' | 'warning' | 'error';
  canAutoApply: boolean;
  steps: RepairStep[];
}

export interface RepairStep {
  action: 'create-file' | 'edit-file' | 'rename-file' | 'install-dependency' | 'mark-unsupported' | 'mount-app';
  targetPath: string;
  reason: string;
  before?: string;
  after?: string;
}
```

## Rule
Auto-apply only safe repairs. Anything destructive needs explicit user confirmation.
