# File Metabolism Contract

## File record
Every uploaded file must become a `SynthFileRecord`.

```ts
export type SynthFileKind =
  | 'text'
  | 'code'
  | 'json'
  | 'markdown'
  | 'html'
  | 'css'
  | 'image'
  | 'audio'
  | 'video'
  | 'pdf'
  | 'document'
  | 'spreadsheet'
  | 'archive'
  | 'binary'
  | 'unknown';

export interface SynthFileRecord {
  id: string;
  originalName: string;
  path: string;
  size: number;
  mime?: string;
  extension?: string;
  kind: SynthFileKind;
  sha256?: string;
  createdAt: string;
  updatedAt: string;
  source: 'upload' | 'zip-child' | 'generated' | 'patched' | 'mounted-app';
  parentArchiveId?: string;
  originalBlobKey: string;
  textKey?: string;
  metadata: Record<string, unknown>;
  relationships: SynthRelationship[];
  status: 'stored' | 'parsed' | 'indexed' | 'repair-needed' | 'mountable' | 'mounted' | 'unsupported';
  safety: {
    originalPreserved: true;
    editable: boolean;
    executable: boolean;
    reason?: string;
  };
}

export interface SynthRelationship {
  type: 'imports' | 'links_to' | 'contains' | 'depends_on' | 'declares' | 'references' | 'generated_from' | 'patches';
  target: string;
  confidence: number;
}
```

## Hard rules
- Original bytes must be saved before parsing.
- Parsing failure must not block storage.
- Editing must create a patched copy or version record.
- Never overwrite original uploaded bytes.
- ZIP children must keep a reference to parent archive.
- Every unsupported file still gets a library card.
- Every failure must be visible to the user with a reason.
