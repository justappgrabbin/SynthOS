# Memory Contract

## Storage layers

1. File vault: original blobs and patched copies.
2. Manifest index: file records and metadata.
3. Text index: extracted readable content.
4. Graph index: file relationships, imports, concepts, apps.
5. Vector/RAG index: optional semantic search layer.

## Required searches
The Library must support:

- by filename
- by extension/type
- by project/archive
- by text content for readable files
- by status: stored, indexed, repair-needed, mountable, mounted, unsupported

## Local-first requirement
Use IndexedDB/local storage first. Optional Supabase sync may be added later, but the OS must work without paid backend services.
