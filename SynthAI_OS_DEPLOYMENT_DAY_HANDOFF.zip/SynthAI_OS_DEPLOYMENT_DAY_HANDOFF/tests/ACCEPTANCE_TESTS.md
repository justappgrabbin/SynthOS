# Acceptance Tests

## Boot
- [ ] `npm install` completes.
- [ ] `npm run dev` loads the OS shell.
- [ ] `npm run build` succeeds.

## Upload/preserve
- [ ] Upload a `.txt` file; it appears in Library.
- [ ] Upload a `.js` or `.tsx` file; it appears as code and opens in editor.
- [ ] Upload a `.json` file; it is parsed or safely marked with parse error.
- [ ] Upload a `.png` or `.jpg`; it is preserved and previewed.
- [ ] Upload a `.pdf`; it is preserved and metadata/card appears even if text extraction is incomplete.
- [ ] Upload a `.zip`; archive is preserved and children are indexed.
- [ ] Original uploaded file is never overwritten by edits.

## Library
- [ ] Search by filename works.
- [ ] Filter by type works.
- [ ] Filter by status works.
- [ ] ZIP children show parent archive.
- [ ] Unsupported files show clear reason.

## Editing
- [ ] Open text/code file.
- [ ] Make edit.
- [ ] Save patched copy/version.
- [ ] Original remains preserved.
- [ ] Patch is linked to original.

## Repair
- [ ] Missing package.json creates repair plan.
- [ ] Broken import creates repair warning.
- [ ] Empty placeholder file is flagged.
- [ ] Unsupported binary is marked unsupported, not destroyed.

## Mounting
- [ ] Standalone `index.html` package is detected mountable.
- [ ] Vite/React package is detected as mountable or needs-build.
- [ ] Non-runnable bundle shows reason.
- [ ] Mounted app appears in app tray/library.

## Phone/APK
- [ ] Capacitor config remains present.
- [ ] APK workflow is not removed.
- [ ] UI remains usable on phone width.
