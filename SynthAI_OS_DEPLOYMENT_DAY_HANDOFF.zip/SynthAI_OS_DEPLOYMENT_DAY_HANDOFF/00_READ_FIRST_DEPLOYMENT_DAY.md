# SynthAI OS — Deployment Day Handoff

## Non-negotiable target
Build one unified **application-level OS/runtime** from the existing uploaded projects.

Do **not** start a new app. Do **not** make a new dashboard. Do **not** rename the product into a new concept. Preserve the OS shell and merge only necessary runtime organs into it.

## What this must do
The finished build must support this core loop:

```text
upload file/folder/zip
→ preserve original bytes
→ unpack/read what is readable
→ classify file type and purpose
→ index metadata + text + relationships
→ show it in the OS library
→ allow edit for text/code files
→ detect missing/broken pieces
→ suggest or apply safe repairs
→ mount runnable web apps/components inside SynthAI OS
→ never delete or overwrite original files
```

## What this is
SynthAI OS is an **OS interface + runtime layer** inside a web/Android/Capacitor app.

It is not a Linux/Android kernel replacement today. It is the user's own controlled environment for files, apps, memory, mesh, agents, ingestion, repair, and mounting.

## Base project
Use this as root:

```text
SynthAi-OS-v1.0-SelfCorrecting.zip
```

This is the OS base because it already includes:

- OS shell
- self-correction engine
- consciousness/core engines
- agent system
- mesh system
- autoling orchestrator
- ingestion panel
- terminal/settings panels
- Capacitor/APK build setup

## Required source ZIPs
Use only these as merge sources unless the user gives new files:

1. `SynthAi-OS-v1.0-SelfCorrecting.zip` — root/base OS
2. `synthia-rooted-morph-engine-stealth-build-1.zip` — file metabolism, persistence, MCP bridge, address space
3. `resonance-final-merged-deploy-ready.zip` — desktop/window/app UI components
4. `synthai_vector_rag_wired.zip` — vector/RAG memory service ideas
5. `autopoetic-resonance-engine.zip` — self-teaching/meta-learning loop and PDF ingest idea
6. `synthia-mesh-v2.1.zip` — mesh refinement/topology
7. `aion-substrate.zip` — substrate, Pyodide, file parser, mesh builder
8. `syntia_build.zip` — small runtime primitives: graph_runtime, memory_fabric, intent_compiler, ingest_bridge
9. `cynthia_consciousness_system.zip` — optional Python brain/service pieces only after the web OS works

## Explicit exclusions for deployment-day merge
Do not merge these unless later requested:

- Astrology app as a root app
- duplicated dashboards
- old one-off HTML demos
- pycache files
- `.git` folders from archived uploads
- unrelated chart PDFs unless used as ingestion test files
- duplicate UI kits if the base already builds

## Definition of done
The agent is done only when:

- the app boots
- uploads preserve original files
- ZIP upload unpacks and indexes contents
- text/code files open in editor and can be saved as patched copies
- binary files are preserved and previewed when possible
- file relationships are shown in Library/Mesh
- runnable React/Vite/HTML packages can be mounted as apps or marked as not runnable with a clear reason
- original files are never destroyed
- the build passes `npm run build`
