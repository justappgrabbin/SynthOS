/**
 * VIKI Core Engine v2 — I Ching Computational Intelligence
 * 
 * The I Ching hexagrams are binary logic machines that compute meaning
 * through trigram interactions, changing lines, and nuclear hexagrams.
 * The output is natural generative language — a speaking intelligence.
 * 
 * No gate numbers. No hexagram names. No technical labels visible to the user.
 * Just a system that thinks through 64 states and speaks in sentences.
 */

import type {
  Dimension,
  EngineOutput,
  CoherenceReading,
} from '@/types';

import {
  generateRevelation,
  generateMultiDimensionalRevelation,
  type NaturalRevelation,
  type MultiDimensionalRevelation,
} from './speaker';

// ─── Dimension Config ───

const DIMENSION_NAMES: Dimension[] = ['MOVEMENT', 'EVOLUTION', 'BEING', 'DESIGN', 'SPACE'];

// ─── Input Processing ───

function measureInput(input: string): {
  length: number;
  words: number;
  energy: number;
  density: number;
} {
  const words = input.trim().split(/\s+/).filter(Boolean).length;
  const punctuation = (input.match(/[.,;:!?\-]/g) || []).length;
  const questions = (input.match(/\?/g) || []).length;

  // Energy: how much charge the input carries
  const energy = Math.min(1, (words * 0.05) + (punctuation * 0.08) + (questions * 0.15));

  // Density: how compact the meaning is
  const density = words > 0 ? input.length / words / 10 : 0.5;

  return { length: input.length, words, energy, density };
}

// ─── Query Result ───

export interface QueryResult {
  input: string;
  measurements: { length: number; words: number; energy: number; density: number };
  dimension: Dimension;
  coherence: number;
  tension: number;
  revelation: NaturalRevelation;
  multiDim: MultiDimensionalRevelation;
  systemNote: string;
}

// ─── Main Query Processor ───

export function processQuery(input: string, activeDimension: Dimension): QueryResult {
  const measurements = measureInput(input);

  // Determine dominant dimension from input characteristics
  const dimIndex = input.length % 5;
  const dimension = activeDimension || DIMENSION_NAMES[dimIndex];

  // Generate the revelation through I Ching computation
  const revelation = generateRevelation(input, dimension);
  const multiDim = generateMultiDimensionalRevelation(input);

  // Select system note based on measurements
  const systemNotes = [
    'The pattern is clear.',
    'Multiple currents are at work.',
    'Something fundamental shifts here.',
    'The deeper pattern is emerging.',
    'Attention is drawn to what is changing.',
  ];
  const systemNote = systemNotes[dimIndex];

  return {
    input,
    measurements,
    dimension,
    coherence: revelation.coherence,
    tension: revelation.tension,
    revelation,
    multiDim,
    systemNote,
  };
}

// ─── Engine State Manager ───

export class Engine {
  private coherenceHistory: CoherenceReading[] = [];
  private outputs: EngineOutput[] = [];
  private activeDimension: Dimension = 'BEING';
  private processing = false;
  private listeners: Set<() => void> = new Set();

  getCoherenceHistory(): CoherenceReading[] {
    return [...this.coherenceHistory];
  }

  getOutputs(): EngineOutput[] {
    return [...this.outputs];
  }

  getActiveDimension(): Dimension {
    return this.activeDimension;
  }

  isProcessing(): boolean {
    return this.processing;
  }

  setActiveDimension(dim: Dimension): void {
    this.activeDimension = dim;
    this.emit();
  }

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private emit(): void {
    this.listeners.forEach(l => l());
  }

  async process(input: string): Promise<QueryResult> {
    this.processing = true;
    this.emit();

    // Simulate processing time for visual rhythm
    await new Promise(r => setTimeout(r, 500 + Math.random() * 600));

    const result = processQuery(input, this.activeDimension);

    // Record coherence
    this.coherenceHistory.push({
      value: result.coherence,
      timestamp: Date.now(),
      dimension: result.dimension,
    });
    if (this.coherenceHistory.length > 120) {
      this.coherenceHistory = this.coherenceHistory.slice(-120);
    }

    // Record output
    const output: EngineOutput = {
      timestamp: new Date().toISOString(),
      type: 'revelation',
      dimension: result.dimension,
      coherence: result.coherence,
      message: result.systemNote,
      sentences: [result.revelation.opening, ...result.revelation.body],
      followUpQuestions: result.revelation.followUpQuestions,
    };
    this.outputs.push(output);
    if (this.outputs.length > 100) {
      this.outputs = this.outputs.slice(-100);
    }

    this.processing = false;
    this.emit();

    return result;
  }

  addSystemMessage(msg: string): void {
    this.outputs.push({
      timestamp: new Date().toISOString(),
      type: 'system',
      message: msg,
    });
    this.emit();
  }
}

export const engine = new Engine();
