import { useEngine } from '@/context/EngineContext';
import type { Mode } from '@/context/EngineContext';
import { MessageSquare, Code2, Video, FolderOpen } from 'lucide-react';

const TABS: { mode: Mode; label: string; icon: typeof MessageSquare }[] = [
  { mode: 'chat', label: 'Chat', icon: MessageSquare },
  { mode: 'code', label: 'Code', icon: Code2 },
  { mode: 'video', label: 'Video', icon: Video },
  { mode: 'projects', label: 'Projects', icon: FolderOpen },
];

export default function Header() {
  const { activeMode, setActiveMode, isProcessing, messages } = useEngine();

  // Calculate coherence from message metadata
  const lastCoherentMsg = [...messages].reverse().find(m => m.metadata?.coherence !== undefined);
  const coherence = lastCoherentMsg?.metadata?.coherence ?? 0;
  const coherenceColor = coherence < 0.3 ? '#FF4444' : coherence < 0.7 ? '#4466FF' : '#88CC00';

  return (
    <header
      style={{
        height: 52,
        background: 'rgba(5,5,8,0.9)',
        backdropFilter: 'blur(12px)',
        borderBottom: '1px solid #1A1A2E',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 20px',
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 50,
      }}
    >
      {/* Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <h1
          style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: 22,
            fontWeight: 700,
            color: '#F0E6D3',
            letterSpacing: '-0.02em',
          }}
        >
          VIKI
        </h1>
        <div
          style={{
            width: 6,
            height: 6,
            borderRadius: '50%',
            background: isProcessing ? '#FFAA00' : '#88CC00',
            animation: isProcessing ? 'pulse 1s infinite' : undefined,
          }}
        />
      </div>

      {/* Mode Tabs */}
      <nav style={{ display: 'flex', gap: 4 }}>
        {TABS.map(({ mode, label, icon: Icon }) => {
          const isActive = activeMode === mode;
          return (
            <button
              key={mode}
              onClick={() => setActiveMode(mode)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                padding: '6px 14px',
                borderRadius: 6,
                border: 'none',
                background: isActive ? 'rgba(68,102,255,0.12)' : 'transparent',
                color: isActive ? '#4466FF' : '#4A4A6A',
                fontFamily: "'Space Grotesk', sans-serif",
                fontSize: 12,
                fontWeight: isActive ? 600 : 500,
                letterSpacing: '0.03em',
                cursor: 'pointer',
                transition: 'all 0.2s',
              }}
            >
              <Icon size={14} />
              {label}
            </button>
          );
        })}
      </nav>

      {/* Coherence indicator */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div
          style={{
            width: 60,
            height: 4,
            borderRadius: 2,
            background: '#1A1A2E',
            overflow: 'hidden',
          }}
        >
          <div
            style={{
              width: `${coherence * 100}%`,
              height: '100%',
              borderRadius: 2,
              background: coherenceColor,
              transition: 'all 0.5s',
            }}
          />
        </div>
        <span
          style={{
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: 11,
            color: coherenceColor,
          }}
        >
          {coherence.toFixed(2)}
        </span>
      </div>
    </header>
  );
}
