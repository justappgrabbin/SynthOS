import { useState, useRef, useEffect, useCallback } from 'react';
import { useEngine } from '@/context/EngineContext';
import { DIMENSIONS } from '@/types';
import { Send, Trash2, Sparkles } from 'lucide-react';

export default function Chat() {
  const { messages, sendMessage, isProcessing, activeDimension, setActiveDimension, clearChat, viewCode } = useEngine();
  const [input, setInput] = useState('');
  const [showDimPicker, setShowDimPicker] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = useCallback(async () => {
    if (!input.trim() || isProcessing) return;
    const text = input.trim();
    setInput('');
    await sendMessage(text);
  }, [input, isProcessing, sendMessage]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  }, [handleSubmit]);

  const dimConfig = DIMENSIONS.find(d => d.name === activeDimension)!;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Messages Area */}
      <div
        ref={scrollRef}
        style={{
          flex: 1,
          overflowY: 'auto',
          padding: '20px 24px',
          display: 'flex',
          flexDirection: 'column',
          gap: 16,
        }}
      >
        {messages.length === 0 && <EmptyState />}

        {messages.map((msg) => (
          <div
            key={msg.id}
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: 6,
              alignItems: msg.role === 'user' ? 'flex-end' : 'flex-start',
              maxWidth: '100%',
            }}
          >
            {/* Message bubble */}
            <div
              style={{
                padding: '12px 16px',
                borderRadius: msg.role === 'user' ? '12px 12px 4px 12px' : '12px 12px 12px 4px',
                background: msg.role === 'user' ? `${dimConfig.color}15` : 'rgba(26,26,46,0.5)',
                border: `1px solid ${msg.role === 'user' ? `${dimConfig.color}22` : '#1A1A2E'}`,
                maxWidth: '85%',
                whiteSpace: 'pre-wrap',
              }}
            >
              <p
                style={{
                  fontFamily: "'Space Grotesk', sans-serif",
                  fontSize: 14,
                  lineHeight: 1.7,
                  color: msg.role === 'user' ? '#F0E6D3' : '#A0A0C0',
                  margin: 0,
                }}
              >
                {msg.content}
              </p>

              {/* Code preview button */}
              {msg.metadata?.code && (
                <button
                  onClick={() => viewCode(msg.metadata!.code!)}
                  style={{
                    marginTop: 8,
                    padding: '6px 12px',
                    background: 'rgba(68,102,255,0.15)',
                    border: '1px solid rgba(68,102,255,0.3)',
                    borderRadius: 4,
                    color: '#4466FF',
                    fontFamily: "'Space Grotesk', sans-serif",
                    fontSize: 12,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                  }}
                >
                  <Sparkles size={12} />
                  View Code
                </button>
              )}
            </div>

            {/* Timestamp */}
            <span
              style={{
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: 9,
                color: '#3A3A5A',
                padding: '0 4px',
              }}
            >
              {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </span>
          </div>
        ))}

        {isProcessing && (
          <div style={{ display: 'flex', gap: 6, padding: '8px 16px' }}>
            {[0, 1, 2].map(i => (
              <div
                key={i}
                style={{
                  width: 6,
                  height: 6,
                  borderRadius: '50%',
                  background: dimConfig.color,
                  opacity: 0.4,
                  animation: `bounce 1s ${i * 0.15}s infinite`,
                }}
              />
            ))}
          </div>
        )}
      </div>

      {/* Input Area */}
      <div
        style={{
          borderTop: '1px solid #1A1A2E',
          padding: '12px 20px',
          background: 'rgba(5,5,8,0.95)',
        }}
      >
        {/* Dimension picker */}
        {showDimPicker && (
          <div
            style={{
              display: 'flex',
              gap: 4,
              marginBottom: 8,
              flexWrap: 'wrap',
            }}
          >
            {DIMENSIONS.map((dim) => (
              <button
                key={dim.name}
                onClick={() => { setActiveDimension(dim.name); setShowDimPicker(false); }}
                style={{
                  padding: '3px 10px',
                  borderRadius: 4,
                  border: `1px solid ${activeDimension === dim.name ? dim.color : '#1A1A2E'}`,
                  background: activeDimension === dim.name ? `${dim.color}15` : 'transparent',
                  color: activeDimension === dim.name ? dim.color : '#4A4A6A',
                  fontFamily: "'Space Grotesk', sans-serif",
                  fontSize: 10,
                  cursor: 'pointer',
                }}
              >
                {dim.code} {dim.keynote}
              </button>
            ))}
          </div>
        )}

        <div style={{ display: 'flex', gap: 10, alignItems: 'flex-end' }}>
          {/* Dimension toggle */}
          <button
            onClick={() => setShowDimPicker(!showDimPicker)}
            style={{
              width: 32,
              height: 32,
              borderRadius: 6,
              border: `1px solid ${dimConfig.color}33`,
              background: `${dimConfig.color}0D`,
              color: dimConfig.color,
              fontSize: 11,
              fontWeight: 700,
              cursor: 'pointer',
              flexShrink: 0,
            }}
          >
            {dimConfig.code}
          </button>

          {/* Text input */}
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask, describe, or request... (code, games, videos)"
            rows={1}
            style={{
              flex: 1,
              background: '#11111A',
              border: '1px solid #1A1A2E',
              borderRadius: 8,
              padding: '10px 14px',
              color: '#F0E6D3',
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: 14,
              lineHeight: 1.5,
              resize: 'none',
              outline: 'none',
              minHeight: 42,
              maxHeight: 120,
            }}
          />

          {/* Send button */}
          <button
            onClick={handleSubmit}
            disabled={isProcessing || !input.trim()}
            style={{
              width: 38,
              height: 38,
              borderRadius: 8,
              border: 'none',
              background: input.trim() ? '#4466FF' : '#1A1A2E',
              color: '#fff',
              cursor: input.trim() ? 'pointer' : 'default',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all 0.2s',
              flexShrink: 0,
            }}
          >
            <Send size={16} />
          </button>

          {/* Clear button */}
          <button
            onClick={clearChat}
            style={{
              width: 32,
              height: 32,
              borderRadius: 6,
              border: 'none',
              background: 'transparent',
              color: '#4A4A6A',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
            }}
          >
            <Trash2 size={14} />
          </button>
        </div>
      </div>

      <style>{`
        @keyframes bounce {
          0%, 80%, 100% { transform: translateY(0); }
          40% { transform: translateY(-6px); }
        }
      `}</style>
    </div>
  );
}

function EmptyState() {
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
        gap: 20,
        opacity: 0.6,
      }}
    >
      <div
        style={{
          width: 60,
          height: 60,
          borderRadius: '50%',
          border: '2px solid #1A1A2E',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Sparkles size={28} color="#4A4A6A" />
      </div>
      <div style={{ textAlign: 'center' }}>
        <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 16, color: '#6A6A8A', marginBottom: 8 }}>
          VIKI is ready
        </p>
        <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 13, color: '#4A4A6A', maxWidth: 400, lineHeight: 1.6 }}>
          Ask a question, describe a situation, or request code, games, or videos.
          All computation runs in your browser.
        </p>
      </div>
      <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap', justifyContent: 'center' }}>
        {[
          'Make a snake game',
          'What should I focus on?',
          'Build a todo app',
          'Create a platformer game',
          'How do I decide?',
        ].map((example) => (
          <button
            key={example}
            onClick={() => {
              const textarea = document.querySelector('textarea');
              if (textarea) {
                (textarea as HTMLTextAreaElement).value = example;
                textarea.dispatchEvent(new Event('input', { bubbles: true }));
              }
            }}
            style={{
              padding: '6px 12px',
              borderRadius: 6,
              border: '1px solid #1A1A2E',
              background: 'rgba(26,26,46,0.3)',
              color: '#5A5A7A',
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: 12,
              cursor: 'pointer',
              transition: 'all 0.2s',
            }}
            onMouseEnter={(e) => { (e.target as HTMLElement).style.borderColor = '#4466FF33'; (e.target as HTMLElement).style.color = '#8A8AAA'; }}
            onMouseLeave={(e) => { (e.target as HTMLElement).style.borderColor = '#1A1A2E'; (e.target as HTMLElement).style.color = '#5A5A7A'; }}
          >
            {example}
          </button>
        ))}
      </div>
    </div>
  );
}
