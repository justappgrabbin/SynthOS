import { useEffect } from 'react';
import { EngineProvider, useEngine } from '@/context/EngineContext';
import Header from '@/components/Header';
import Chat from '@/components/Chat';
import CodeViewer from '@/components/CodeViewer';
import VideoPanel from '@/components/VideoPanel';
import ProjectManager from '@/components/ProjectManager';

function AppContent() {
  const { activeMode } = useEngine();

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        // Could add escape behavior
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  return (
    <div
      style={{
        width: '100vw',
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
        background: '#050508',
        overflow: 'hidden',
      }}
    >
      <Header />

      <main
        style={{
          flex: 1,
          marginTop: 52,
          overflow: 'hidden',
          position: 'relative',
        }}
      >
        {activeMode === 'chat' && <Chat />}
        {activeMode === 'code' && <CodeViewer />}
        {activeMode === 'video' && <VideoPanel />}
        {activeMode === 'projects' && <ProjectManager />}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <EngineProvider>
      <AppContent />
    </EngineProvider>
  );
}
