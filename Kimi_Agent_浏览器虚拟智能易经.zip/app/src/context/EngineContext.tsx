import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { SemanticNetwork, NLGenerator, RuleEngine } from '@/engine/messy';
import { parseIntent, generateCode } from '@/engine/codegen';
import { computeSemanticState } from '@/engine/iching';
import { saveConversation, getConversations, saveProject, getProjects, deleteProject } from '@/storage/db';
import { DIMENSIONS } from '@/types';
import type { Dimension } from '@/types';
import type { ProjectRecord } from '@/storage/db';

export type Mode = 'chat' | 'code' | 'video' | 'projects';

export interface ChatMessage {
  id: string;
  role: 'user' | 'system';
  content: string;
  type: 'chat' | 'code' | 'video' | 'system';
  timestamp: number;
  metadata?: {
    code?: string;
    language?: string;
    files?: Array<{ path: string; content: string; language: string }>;
    videoUrl?: string;
    coherence?: number;
    dimension?: string;
  };
}

interface EngineContextValue {
  messages: ChatMessage[];
  activeMode: Mode;
  activeDimension: Dimension;
  isProcessing: boolean;
  isGeneratingVideo: boolean;
  projects: ProjectRecord[];
  currentCode: string | null;
  currentVideoUrl: string | null;
  setActiveMode: (mode: Mode) => void;
  setActiveDimension: (dim: Dimension) => void;
  sendMessage: (text: string) => Promise<void>;
  generateVideo: (desc: string) => Promise<void>;
  loadProjects: () => Promise<void>;
  deleteProject: (id: string) => Promise<void>;
  clearChat: () => void;
  viewCode: (code: string) => void;
  viewVideo: (url: string) => void;
}

const EngineContext = createContext<EngineContextValue | null>(null);

export function EngineProvider({ children }: { children: React.ReactNode }) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [activeMode, setActiveMode] = useState<Mode>('chat');
  const [activeDimension, setActiveDimension] = useState<Dimension>('BEING');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isGeneratingVideo, setIsGeneratingVideo] = useState(false);
  const [projects, setProjects] = useState<ProjectRecord[]>([]);
  const [currentCode, setCurrentCode] = useState<string | null>(null);
  const [currentVideoUrl, setCurrentVideoUrl] = useState<string | null>(null);

  const network = useState(() => new SemanticNetwork())[0];
  const nlg = useState(() => new NLGenerator())[0];
  const _rules = useState(() => new RuleEngine())[0];
  void _rules;

  useEffect(() => {
    getConversations().then(recs => {
      const msgs: ChatMessage[] = recs.map(r => ({
        id: r.id,
        role: r.role as 'user' | 'system',
        content: r.content,
        type: r.type as 'chat' | 'code' | 'video' | 'system',
        timestamp: r.timestamp,
        metadata: r.metadata as ChatMessage['metadata'],
      }));
      setMessages(msgs);
    });
    loadProjects();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadProjects = useCallback(async () => {
    const projs = await getProjects();
    setProjects(projs);
  }, []);

  const deleteProjectHandler = useCallback(async (id: string) => {
    await deleteProject(id);
    await loadProjects();
  }, [loadProjects]);

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim() || isProcessing) return;
    setIsProcessing(true);

    const userMsg: ChatMessage = {
      id: `${Date.now()}_u`,
      role: 'user',
      content: text,
      type: 'chat',
      timestamp: Date.now(),
    };
    setMessages(prev => [...prev, userMsg]);
    await saveConversation({ timestamp: Date.now(), role: 'user', content: text, type: 'chat' });

    const lower = text.toLowerCase();
    const dimIndex = text.length % 5;
    const dimension = DIMENSIONS[dimIndex].name;

    const isCodeRequest = /(create|make|build|generate|write)\s+(a\s+|an\s+)?(game|app|website|code|program|script|tool)/.test(lower)
      || /(snake|pong|platformer|shooter|calculator|todo|paint|clock|counter)/.test(lower);
    const isVideoRequest = /(create|make|generate)\s+(a\s+|an\s+)?video/.test(lower)
      || /video of/.test(lower) || /scene of/.test(lower);

    try {
      if (isVideoRequest) {
        const enhancedDesc = `Cinematic scene: ${text.replace(/(create|make|generate|a|an|video|of)\s+/gi, '').trim() || 'abstract visualization'}`;

        const sysMsg: ChatMessage = {
          id: `${Date.now()}_s`,
          role: 'system',
          content: `Creating video: ${enhancedDesc}`,
          type: 'video',
          timestamp: Date.now(),
        };
        setMessages(prev => [...prev, sysMsg]);
        setIsGeneratingVideo(true);
        setActiveMode('video');

        await new Promise(r => setTimeout(r, 2000));

        const resultMsg: ChatMessage = {
          id: `${Date.now()}_r`,
          role: 'system',
          content: `Video concept rendered: "${enhancedDesc}". In full deployment, the AI video pipeline generates the scene from this description.`,
          type: 'video',
          timestamp: Date.now(),
        };
        setMessages(prev => [...prev, resultMsg]);
        await saveConversation({ timestamp: Date.now(), role: 'system', content: resultMsg.content, type: 'video' });
        setIsGeneratingVideo(false);

      } else if (isCodeRequest) {
        const intent = parseIntent(text);
        const result = generateCode(intent);
        const code = result.code;
        const language = result.language;
        const files = result.files;

        const nlgResult = nlg.generate(text, network, dimension);
        const intro = nlgResult.sentences[0];

        const sysMsg: ChatMessage = {
          id: `${Date.now()}_s`,
          role: 'system',
          content: `${intro}\n\nBuilding ${intent.subtype} ${intent.type}...\n\nGenerated ${intent.subtype} ${intent.type}. Click "View Code" to see the full source.`,
          type: 'code',
          timestamp: Date.now(),
          metadata: { code, language, files: files?.map(f => ({ ...f, language: language || 'javascript' })) },
        };
        setMessages(prev => [...prev, sysMsg]);
        setCurrentCode(code);
        setActiveMode('code');

        await saveConversation({ timestamp: Date.now(), role: 'system', content: sysMsg.content, type: 'code', metadata: sysMsg.metadata });

        const projectFiles = files?.map(f => ({ ...f, language: language || 'javascript' }));
        await saveProject({
          name: `${intent.subtype} ${intent.type}`,
          type: intent.type === 'game' ? 'game' : 'app',
          description: text,
          code,
          language,
          files: projectFiles,
        });
        await loadProjects();

      } else {
        const nlgResult = nlg.generate(text, network, dimension);
        const content = nlgResult.sentences.join('\n\n');
        const state = computeSemanticState(text);

        const sysMsg: ChatMessage = {
          id: `${Date.now()}_s`,
          role: 'system',
          content,
          type: 'chat',
          timestamp: Date.now(),
          metadata: { coherence: state.coherence, dimension },
        };
        setMessages(prev => [...prev, sysMsg]);

        for (const q of nlgResult.followUpQuestions) {
          setMessages(prev => [...prev, {
            id: `${Date.now()}_q_${Math.random().toString(36).slice(2, 5)}`,
            role: 'system',
            content: q,
            type: 'system',
            timestamp: Date.now(),
          }]);
        }

        await saveConversation({ timestamp: Date.now(), role: 'system', content, type: 'chat', metadata: sysMsg.metadata });
      }
    } catch (_err) {
      const errMsg: ChatMessage = {
        id: `${Date.now()}_err`,
        role: 'system',
        content: 'The system encountered an issue. Please try again.',
        type: 'system',
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, errMsg]);
    }

    setIsProcessing(false);
  }, [isProcessing, network, nlg, activeDimension, loadProjects]);

  const generateVideo = useCallback(async (_desc: string) => {
    setIsGeneratingVideo(true);
    setActiveMode('video');
    await new Promise(r => setTimeout(r, 3000));
    setIsGeneratingVideo(false);
  }, []);

  const clearChat = useCallback(() => setMessages([]), []);

  const viewCode = useCallback((code: string) => {
    setCurrentCode(code);
    setActiveMode('code');
  }, []);

  const viewVideo = useCallback((url: string) => {
    setCurrentVideoUrl(url);
    setActiveMode('video');
  }, []);

  const value: EngineContextValue = {
    messages,
    activeMode,
    activeDimension,
    isProcessing,
    isGeneratingVideo,
    projects,
    currentCode,
    currentVideoUrl,
    setActiveMode,
    setActiveDimension,
    sendMessage,
    generateVideo,
    loadProjects,
    deleteProject: deleteProjectHandler,
    clearChat,
    viewCode,
    viewVideo,
  };

  return (
    <EngineContext.Provider value={value}>
      {children}
    </EngineContext.Provider>
  );
}

export function useEngine(): EngineContextValue {
  const ctx = useContext(EngineContext);
  if (!ctx) throw new Error('useEngine must be used within EngineProvider');
  return ctx;
}
