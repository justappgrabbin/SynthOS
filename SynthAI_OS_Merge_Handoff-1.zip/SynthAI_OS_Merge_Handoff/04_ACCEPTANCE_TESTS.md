# Acceptance Tests

The merge is not successful until these work.

## Boot
- `npm install` succeeds.
- `npm run dev` starts.
- SynthAI OS shell loads.
- No blank screen.

## Upload basics
Upload each file type:
- `.txt`
- `.md`
- `.json`
- `.js`
- `.tsx`
- `.html`
- `.css`

Expected:
- file appears in Library
- metadata appears
- original is preserved
- text/code content can be opened

## ZIP ingestion
Upload a ZIP containing a Vite/React app.

Expected:
- original ZIP preserved
- contents unpacked
- tree shown
- package.json detected
- src files classified
- dependencies listed
- entrypoint detected

## Editing
Open a text/code file.

Expected:
- edit content
- save versioned copy
- original remains preserved

## Self-correction
Upload a project with a missing import.

Expected:
- issue is detected
- repair suggestion is displayed
- patch is not applied without confirmation

## Mounting
Upload a simple browser-safe React/Vite project.

Expected:
- OS detects it as mountable
- app appears as icon/window
- preview runs inside SynthAI OS environment

## Safety
Upload binary/APK/PDF.

Expected:
- file is preserved
- type is identified
- preview/index attempted where possible
- it is not blindly executed
