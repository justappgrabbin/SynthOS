# Build Order

## Phase 1 — Make the OS open and run
1. Unzip `SynthAi-OS-v1.0-SelfCorrecting.zip`.
2. Run `npm install`.
3. Run `npm run dev`.
4. Confirm the OS shell loads.
5. Confirm these panels exist:
   - ingestion
   - terminal
   - mesh visualizer
   - agent panel
   - settings

Do not merge anything until the base runs.

## Phase 2 — Replace weak ingestion
Add the file metabolism layer from `synthia-rooted-morph-engine-stealth-build-1.zip`.

Create this folder in the base project:

```text
src/os/metabolism/
```

Add/adapt:

```text
ingestion.ts
addressSpace.ts
morphEngine.ts
persistence.ts
mcpBridge.ts
departmentRouter.ts
```

Then connect `src/ui/components/IngestionPanel.tsx` to this new layer.

## Phase 3 — Preserve every file
Implement a local file registry.

Each uploaded file must produce a record:

```ts
{
  id: string;
  name: string;
  type: string;
  size: number;
  extension: string;
  category: 'text' | 'code' | 'archive' | 'document' | 'image' | 'audio' | 'video' | 'binary' | 'unknown';
  raw: Blob | ArrayBuffer | string;
  text?: string;
  hash: string;
  createdAt: string;
  status: 'preserved' | 'parsed' | 'mounted' | 'error';
}
```

Rule: never overwrite or destroy the original uploaded file.

## Phase 4 — Add ZIP parsing
Use JSZip.

Required behavior:
- Upload ZIP
- Unpack file list
- Preserve original ZIP
- Preserve every extracted file
- Build dependency map
- Detect package.json if present
- Detect React/Vite/Node projects
- Show project tree in Library

## Phase 5 — Add Library mounting
Use Resonance Final app windows only after ingestion works.

Bring in:
- LibraryApp
- IngestApp
- TerminalApp
- BrowserApp
- BuilderApp

These should mount inside SynthAI OS, not become the new app root.

## Phase 6 — Add memory and search
Add a memory adapter:

```text
src/os/memory/
```

Implement:
- metadata search
- text search
- vector/RAG later
- project/file relationship graph

## Phase 7 — Add self-correction
Wire the existing SelfCorrectingEngine to ingestion output.

It should detect:
- missing package.json
- broken imports
- missing dependencies
- syntax errors where detectable
- empty placeholder files
- duplicate modules

First output suggestions. Only apply patches after confirmation.

## Phase 8 — Mount runnable apps
A project can be mounted when:
- it has package.json
- install/build commands are detected
- entrypoint is detected
- dependencies are known
- generated preview can run safely

Do not execute arbitrary binary files.
