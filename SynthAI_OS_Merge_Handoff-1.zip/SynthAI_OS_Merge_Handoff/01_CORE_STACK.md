# Core Stack

## Base OS
```text
SynthAi-OS-v1.0-SelfCorrecting.zip
```
Owns:
- OS shell
- self-correction
- mesh system
- agent system
- Autoling orchestrator
- terminal panel
- settings panel
- ingestion panel
- APK/Capacitor build path

## Runtime / File Metabolism
```text
synthia-rooted-morph-engine-stealth-build-1.zip
```
Pull in:
- `src/core/ingestion.ts`
- `src/core/addressSpace.ts`
- `src/lib/morphEngine.ts`
- `src/lib/persistence.ts`
- `src/lib/mcpBridge.ts`
- `src/lib/departmentRouter.ts`
- Supabase schema as optional persistence reference

## Desktop / Window Apps
```text
resonance-final-merged-deploy-ready.zip
```
Pull in selectively:
- Browser app
- Builder app
- Chat app
- Ingest app
- Library app
- Mesh app
- Terminal app
- Settings app
- App window structure

Do not let this package replace the OS root.

## Memory / RAG
```text
synthai_vector_rag_wired.zip
```
Pull in:
- server-side vector/RAG idea
- profile/knowledge structure
- document indexing approach

Refactor before use. Do not blindly copy the whole server.

## Substrate / Pyodide / Browser Runtime
```text
aion-substrate.zip
```
Pull in:
- File ingestion engine ideas
- Mesh graph
- Pyodide provider
- Python parser helpers
- symbolic calculator
- mesh builder

## Mesh Refinement
```text
synthia-mesh-v2.1.zip
```
Pull in:
- `three-level-mesh.ts`
- topology concepts

## Autopoetic Learning
```text
autopoetic-resonance-engine.zip
```
Pull in:
- MetaLearningController
- AutopoeticTriad
- AspirationCore
- pdfIngestor if useful
- LearningDashboard as optional UI

## Python Agent Brain
```text
cynthia_consciousness_system.zip
```
Pull in later:
- code_reader
- code_generator
- pattern_learner
- memory_inheritance
- cerebrum

This should be a local service or optional bridge, not required for the first working app.
