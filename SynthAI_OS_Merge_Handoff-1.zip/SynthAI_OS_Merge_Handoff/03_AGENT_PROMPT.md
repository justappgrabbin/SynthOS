# Agent Prompt

Use this exact prompt with the coding agent.

```text
You are merging multiple uploaded SynthAI/Synthia projects into one application-level OS.

Base project:
SynthAi-OS-v1.0-SelfCorrecting.zip

Do not replace the base project. Do not create a new app. Upgrade this base into the unified SynthAI OS.

Primary goal:
Create an application-level OS that lets the user upload files, preserve originals, ingest/understand file structure, organize them into a library/mesh, edit text/code files, detect missing pieces, suggest repairs, and mount runnable browser-safe apps inside the OS interface.

Required merge sources:
1. synthia-rooted-morph-engine-stealth-build-1.zip
   - merge ingestion, address space, morph engine, persistence, MCP bridge, router
2. resonance-final-merged-deploy-ready.zip
   - selectively merge desktop app windows: Library, Ingest, Terminal, Browser, Builder, Mesh, Chat, Settings
3. aion-substrate.zip
   - adapt file ingestion, Pyodide provider, mesh graph, parser helpers
4. synthia-mesh-v2.1.zip
   - adapt three-level mesh concepts
5. synthai_vector_rag_wired.zip
   - adapt memory/RAG structure later, not as mandatory first boot dependency
6. autopoetic-resonance-engine.zip
   - adapt MetaLearningController and AutopoeticTriad after ingestion works
7. cynthia_consciousness_system.zip
   - keep as optional Python brain/service; do not block frontend build on it

Hard rules:
- Keep SynthAi-OS-v1.0-SelfCorrecting as root.
- Preserve uploaded originals.
- Never delete files.
- Never overwrite user files without creating a versioned copy.
- Ingestion must work before advanced AI features.
- ZIP upload must unpack, index, classify, and preserve contents.
- Binary files can be stored and previewed where possible, but not executed directly.
- Text/code files should be editable.
- Broken code should generate repair suggestions before patching.
- Mounted apps must be browser-safe.
- No iframe-only fake execution as the main solution.
- No paid API requirement.
- No OpenAI API dependency.
- No new dashboard-only rebuild.

Create these folders in the base project:

src/os/metabolism/
src/os/memory/
src/os/runtime/
src/os/library/
src/os/mounting/
src/os/selfRepair/
src/os/mesh/
src/os/types/

First deliverable:
- Base runs with npm install + npm run dev
- Ingestion panel can upload txt/js/json/html/css/md
- ZIP upload unpacks and lists files
- Library shows preserved files
- Text/code viewer/editor opens files
- File metadata + hash + category is stored locally
- SelfCorrectingEngine produces suggestions for broken imports or missing dependencies

Second deliverable:
- Mount React/Vite projects as internal apps when safe
- Add searchable memory graph
- Add optional vector/RAG service
- Add Pyodide for browser Python parsing
- Add app windows from resonance-final

Do not claim this is a bare-metal OS. It is an application-level OS/runtime.
```
