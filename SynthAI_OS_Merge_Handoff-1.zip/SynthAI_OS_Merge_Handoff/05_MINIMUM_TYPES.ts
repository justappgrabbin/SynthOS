// Minimum shared types for SynthAI OS file metabolism.

export type FileCategory =
  | 'text'
  | 'code'
  | 'archive'
  | 'document'
  | 'image'
  | 'audio'
  | 'video'
  | 'binary'
  | 'unknown';

export type FileStatus =
  | 'preserved'
  | 'parsed'
  | 'indexed'
  | 'mounted'
  | 'error';

export interface SynthFileRecord {
  id: string;
  name: string;
  extension: string;
  mimeType: string;
  size: number;
  hash: string;
  category: FileCategory;
  status: FileStatus;
  createdAt: string;
  updatedAt: string;
  rawRef?: string;
  text?: string;
  parentArchiveId?: string;
  path?: string;
  errors?: string[];
  tags?: string[];
}

export interface SynthProjectRecord {
  id: string;
  name: string;
  rootFileIds: string[];
  packageJsonFileId?: string;
  framework?: 'vite' | 'react' | 'next' | 'node' | 'python' | 'static' | 'unknown';
  entrypoints: string[];
  dependencies: string[];
  missingDependencies: string[];
  mountable: boolean;
  createdAt: string;
}

export interface RepairSuggestion {
  id: string;
  fileId: string;
  severity: 'info' | 'warning' | 'error';
  title: string;
  explanation: string;
  proposedPatch?: string;
  requiresConfirmation: true;
}
